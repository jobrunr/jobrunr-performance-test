package org.jobrunr.server.queue;


import org.assertj.core.api.Condition;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobDetails;
import org.jobrunr.jobs.JobDetailsTestBuilder;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.jobs.lambdas.IocJobLambda;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.queue.TurboQueue.AvailableWorkerTimeDynamicAmountRequest;
import org.jobrunr.server.queue.TurboQueue.JobProcessingTimeCalculator;
import org.jobrunr.server.queue.TurboQueue.WindowedAverage;
import org.jobrunr.server.strategy.DynamicQueueStrategy;
import org.jobrunr.server.strategy.WorkDistributionStrategy;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.storage.navigation.DynamicAmountRequest;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.JobUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.FutureTask;

import static java.time.Duration.ofSeconds;
import static java.time.Instant.now;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toList;
import static java.util.stream.IntStream.range;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.data.Offset.offset;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.utils.CollectionUtils.unionToList;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

@ExtendWith(MockitoExtension.class)
class TurboQueueTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    WorkDistributionStrategy workDistributionStrategy;
    @Mock
    DynamicQueueStrategy dynamicQueueStrategy;

    TurboQueue turboQueue;

    @BeforeEach
    void setUp() {
        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofSeconds(5)));
        lenient().when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(workDistributionStrategy);
        lenient().when(backgroundJobServer.getDynamicQueueStrategy()).thenReturn(dynamicQueueStrategy);
        lenient().when(workDistributionStrategy.getWorkerCount()).thenReturn(10);
        lenient().when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID()));

        turboQueue = new TurboQueue(backgroundJobServer);
    }

    @Test
    void testJobsToProcessNoJobsAndNoRunningAverageAvailableThenOnly1DynamicQueueStrategyCall() {
        // WHEN
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        sleep(20);
        verify(dynamicQueueStrategy, times(1)).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndLessResultsThanRequestedThenOnly1DynamicQueueStrategyCall() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobsInProgress(2));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(2);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndNoRunningAverageAvailableThenOnly1DynamicQueueStrategyCall() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobsInProgress(10));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessWithJobsProcessingButNoRunningAverageAvailableThenOnly1DynamicQueueStrategyCall() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobsInProgress(10));
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        assertThat(jobsToProcess).hasSize(5);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndVeryShortRunningAverageAvailableThenExtraDynamicQueueStrategyCallToFillQueue() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(50)))
                .thenReturn(generateJobsInProgress(50, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy, times(2)).getJobsToProcess(dynamicAmountRequest(50));
    }

    @Test
    void testJobsToProcessAndVeryLongRunningAverageAvailableThenOnly1DynamicQueueStrategyCall() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobsInProgress(10, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndVeryLongRunningJobAveragesAvailableThenQueueIsNotRefilled() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        List<Job> jobs = generateJobsInProgress(10, longRunningJob.getJobDetails());
        fillQueueWithJobs(jobs);

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(2));

        // THEN
        assertThat(jobsToProcess1).hasSize(2);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);


        // WHEN
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        assertThat(jobsToProcess2).hasSize(8);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
        assertThat(refillQueueIfNecessaryFuture()).isNotNull();
    }

    @Test
    void testJobsToProcessAndVeryLongRunningJobAveragesAvailableThenQueueIsRefilledWithJobsThatAreAboutToBeReleased() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(unionToList(
                generateJobsInProgress(now().minusSeconds(58), 6, longRunningJob.getJobDetails()),
                generateJobsInProgress(4, longRunningJob.getJobDetails())));
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(6)))
                .thenReturn(generateJobsInProgress(6, longRunningJob.getJobDetails()));


        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        assertThat(jobsToProcess1).hasSize(6);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(6));
    }

    @Test
    void testJobsToProcessDoesNotOnboardNewJobsIfQueueOccupiedByLongRunningJobs() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(10, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        assertThat(jobsToProcess1).hasSize(6);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);


        // WHEN
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(4));

        // THEN
        assertThat(jobsToProcess2).hasSize(4);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessDoesNotFetchNewJobsIfQueueExceedsMaxQueueSizeFactor() {
        // GIVEN
        Job veryShortRunningJob = setupJobWithVeryShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(100, veryShortRunningJob.getJobDetails()));
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(50)))
                .thenReturn(generateJobsInProgress(50, veryShortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess1).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(50));

        // WHEN
        clearInvocations(dynamicQueueStrategy);
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess2).hasSize(10);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessUsesAvailableWorkersIfExpectedJobsToProcessUsingAverageIsLessThanAvailableWorkers() {
        // GIVEN
        setupJobWithShortRunningAverage();
        setupJobWithLongRunningAverage();

        // WHEN
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersA() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(25, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(5, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(25));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersB() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(22, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersC() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(4, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(2));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersD() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(2, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(8, longRunningJob.getJobDetails()));
        fillJobsCurrentlyInProcessWithJobs(longRunningJob);

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(2));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersE() {
        // GIVEN
        Job veryShortRunningJob = setupJobWithVeryShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(9, veryShortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(1, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(45));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersF() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(25, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(8, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersG() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(now().minusSeconds(58), 8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(25, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(50));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersH() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(now().minusSeconds(58), 8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(25, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(2, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(40));
    }

    @Test
    void testJobsToProcessUsesJobsInProgressAndInQueueToDetermineAvailableWorkersI() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobsInProgress(now().minusSeconds(58), 8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(2, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobsInProgress(25, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(30));
    }

    @Test
    void runningAverageIsImmediatelyAvailable() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(60_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(61_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(59000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_500L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 56_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 61_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_500L);
    }

    @Test
    void runningAverageIsNotImpactedByOutlier() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 52_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 64_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());
        long runningAverageInMillisBeforeOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 10_000).build());
        long runningAverageInMillisAfterOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterOutlier).isEqualTo(runningAverageInMillisBeforeOutlier);
    }

    @Test
    void runningAverageIsNotAnOutlierIfStandardDeviationReallySmallAndItIsWithin1Percent() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_005).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 59_995).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_005).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 59_995).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());
        long runningAverageInMillisBeforeNewValue = windowedAverage.getAverageProcessingTimeInMillis();

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_055).build());
        long runningAverageInMillisAfterNewValue = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterNewValue).isNotCloseTo(runningAverageInMillisBeforeNewValue, offset(5L));
    }

    @Test
    void runningAverageIsResetAfterFiveOutliers() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 52_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 64_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 10_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 12_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 9_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 13_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 8_000).build());
        long runningAverageInMillisAfterOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterOutlier).isZero();
        assertThat(getWindowedAverage(job.getJobDetails())).isNull();
    }

    @Test
    void dynamicAmountRequestWithoutAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, null, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(10));
    }

    @Test
    void dynamicAmountRequestWithAverageProcessingTimeEqualTo0IsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 0L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50));
    }

    @Test
    void dynamicAmountRequestWithVerySmallAverageProcessingTimeAvailableIsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 10L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50));
    }

    @Test
    void dynamicAmountRequestWithMediumAverageProcessingTimeAvailableIsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50)); // (10 * 5000) / 900 but capped
    }

    @Test
    void dynamicAmountRequestWithLargerAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 2500L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(20)); // (10 * 5000) / 2500
    }

    @Test
    void dynamicAmountRequestWithVeryLargeAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 30_000L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(10)); // (10 * 5000) / 30_000 == 2 but 10 workers available, so 10
    }

    @Test
    void dynamicAmountRequestWithOneWorkerOnlyAndVeryLargeAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(2, 5000, 5, 30_000L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(2)); // (1 * 5000) / 30_000 == 0 but 2 workers available, so 2
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableButNoJobAverageAvailableIsCappedToAvailableWorkerCount() {
        Job job = setupJobWithShortRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = new ConcurrentHashMap<>();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(10);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndSlowRunningJobsFromStorageProviderAcceptsLimitedJobs() {
        Job job = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(10);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndFastRunningJobsFromStorageProviderAcceptsAllJob() {
        Job job = setupJobWithShortRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(50);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndBothSlowAndFastRunningJobsFromStorageProviderAcceptsLimitedJobs() {
        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = unionToList(generateJobsInProgress(8, longRunningJob.getJobDetails()), generateJobsInProgress(42, shortRunningJob.getJobDetails()));

        assertThat(dynamicAmountRequest.filter(jobs))
                .hasSize(19)
                .areExactly(8, jobsWithJobDetails(longRunningJob.getJobDetails()))
                .areExactly(11, jobsWithJobDetails(shortRunningJob.getJobDetails()));
    }

    @Test
    void jobProcessingTimeCalculator_takeJobsThatCanBeProcessed_withoutAverageProcessingTimeAvailableIsEqualToAvailableWorkerCount() {
        ConcurrentMap<String, WindowedAverage> emptyJobProcessingTimeAverages = new ConcurrentHashMap<>();

        JobProcessingTimeCalculator jobProcessingTimeCalculator = new JobProcessingTimeCalculator(10, 5000, emptyJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(15);

        List<Job> result = jobProcessingTimeCalculator.takeJobsThatCanBeProcessed(jobs);
        assertThat(result).hasSize(10);
    }

    @Test
    void jobProcessingTimeCalculator_takeJobsThatCanBeProcessed_withShortAverageProcessingTimeAvailableTakesPossibleJobsThatCanBeProcessed() {
        Job shortRunningJob = setupJobWithShortRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        JobProcessingTimeCalculator jobProcessingTimeCalculator = new JobProcessingTimeCalculator(10, 5000, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(60, shortRunningJob.getJobDetails());

        List<Job> result = jobProcessingTimeCalculator.takeJobsThatCanBeProcessed(jobs);
        assertThat(result).hasSize(55);
    }

    @Test
    void jobProcessingTimeCalculator_takeJobsThatCanBeProcessed_withLongAverageProcessingTimeAvailableTakesPossibleJobsThatCanBeProcessed() {
        Job longRunningJob = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        JobProcessingTimeCalculator jobProcessingTimeCalculator = new JobProcessingTimeCalculator(10, 5000, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(20, longRunningJob.getJobDetails());

        List<Job> result = jobProcessingTimeCalculator.takeJobsThatCanBeProcessed(jobs);
        assertThat(result).hasSize(10);
    }

    @Test
    void jobProcessingTimeCalculator_getAvailableWorkers_withLongAverageProcessingTimeAvailableForJobsInProgressThatAreAlmostFinishedIgnoresJobsThatAreAlmostFinished() {
        Job longRunningJob = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        JobProcessingTimeCalculator jobProcessingTimeCalculator = new JobProcessingTimeCalculator(10, 5000, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobsInProgress(now().minusSeconds(58), 10, longRunningJob.getJobDetails());

        jobProcessingTimeCalculator.takeJobsThatCanBeProcessed(jobs);
        assertThat(jobProcessingTimeCalculator.getAvailableWorkers()).isEqualTo(10);
    }

    @Test
    void jobProcessingTimeCalculator_getAvailableWorkers_withLongAverageProcessingTimeAvailableForEnqueuedJobs() {
        Job longRunningJob = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        JobProcessingTimeCalculator jobProcessingTimeCalculator = new JobProcessingTimeCalculator(10, 5000, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateEnqueuedJobs(10, longRunningJob.getJobDetails());

        jobProcessingTimeCalculator.takeJobsThatCanBeProcessed(jobs);
        assertThat(jobProcessingTimeCalculator.getAvailableWorkers()).isEqualTo(0);
    }

    private Job setupJobWithLongRunningAverage() {
        Job longRunningJob = this.<TestService>createJob(x -> x.doWorkThatTakesLong(60), 60_000);
        setupJobWithRunningAverage(longRunningJob);
        return longRunningJob;
    }

    private Job setupJobWithShortRunningAverage() {
        Job shortRunningJob = this.<TestService>createJob(x -> x.doWork("short job"), 900);
        setupJobWithRunningAverage(shortRunningJob);
        return shortRunningJob;
    }

    private Job setupJobWithVeryShortRunningAverage() {
        Job veryShortRunningJob = this.<TestService>createJob(TestService::doWork, 11);
        setupJobWithRunningAverage(veryShortRunningJob);
        return veryShortRunningJob;
    }

    private <S> Job createJob(IocJobLambda<S> jobLambda, long processDuration) {
        return anEnqueuedJobWithName().withJobDetails(jobLambda).withProcessingState().withSucceededState(0, processDuration).build();
    }

    private void setupJobWithRunningAverage(Job job) {
        turboQueue.onThreadReleased(job);
    }

    private void fillQueueWithJobs(List<Job> jobs) {
        ((Queue<Job>) getInternalState(turboQueue, "jobQueue")).addAll(jobs);
    }

    private void fillJobsCurrentlyInProcessWithJobs(Job job) {
        fillJobsCurrentlyInProcessWithJobs(singletonList(job));
    }

    private void fillJobsCurrentlyInProcessWithJobs(List<Job> jobs) {
        ConcurrentMap<UUID, Job> jobsCurrentlyInProcess = getInternalState(turboQueue, "jobsCurrentlyInProcess");
        jobs.forEach(job -> jobsCurrentlyInProcess.put(job.getId(), job));
    }

    private void setQueueSizeFactor(double queueSizeFactor) {
        setInternalState(turboQueue, "queueSizeFactor", queueSizeFactor);
    }

    private WindowedAverage getWindowedAverage(JobDetails jobDetails) {
        return getWindowedAverage(JobUtils.getJobSignature(jobDetails));
    }

    private WindowedAverage getWindowedAverage(String jobSignature) {
        Map<String, WindowedAverage> averageJobProcessingTime = getAllWindowedJobProcessingTimeAverages();
        return averageJobProcessingTime.get(jobSignature);
    }

    private ConcurrentMap<String, WindowedAverage> getAllWindowedJobProcessingTimeAverages() {
        return getInternalState(turboQueue, "averageProcessingTimePerJob");
    }

    private FutureTask<?> refillQueueIfNecessaryFuture() {
        return getInternalState(turboQueue, "refillQueueIfNecessaryFuture");
    }

    private static List<Job> generateJobsInProgress(int amount) {
        return generateJobsInProgress(amount, systemOutPrintLnJobDetails("a test"));
    }

    private static List<Job> generateJobsInProgress(int amount, JobDetailsTestBuilder jobDetailsBuilder) {
        return generateJobsInProgress(amount, jobDetailsBuilder.build());
    }

    private static List<Job> generateJobsInProgress(int amount, JobDetails jobDetails) {
        return range(0, amount).boxed().map(i -> anEnqueuedJobWithName().withJobDetails(jobDetails).withProcessingState().build()).collect(toList());
    }

    private static List<Job> generateJobsInProgress(Instant processingStartedAt, int amount, JobDetails jobDetails) {
        return range(0, amount).boxed().map(i -> anEnqueuedJobWithName().withJobDetails(jobDetails).withProcessingState(processingStartedAt.minusSeconds(2), processingStartedAt).build()).collect(toList());
    }

    private static List<Job> generateEnqueuedJobs(int amount, JobDetails jobDetails) {
        return range(0, amount).boxed().map(i -> anEnqueuedJobWithName().withJobDetails(jobDetails).build()).collect(toList());
    }

    private static AmountRequest dynamicAmountRequest(int amount) {
        return argThat(x -> ascOnPriorityAndUpdatedAt(amount).asString().equals(x.asString()) && x instanceof DynamicAmountRequest);
    }

    private static Condition<Job> jobsWithJobDetails(JobDetails jobDetails) {
        return new Condition<>(j -> j.getJobSignature().equals(JobUtils.getJobSignature(jobDetails)), "expected %s", JobUtils.getJobSignature(jobDetails));
    }
}