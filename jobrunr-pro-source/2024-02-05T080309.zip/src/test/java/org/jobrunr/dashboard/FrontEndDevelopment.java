package org.jobrunr.dashboard;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.SevereJobRunrException;
import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.dashboard.integrations.JaegerObservabilityIntegration;
import org.jobrunr.dashboard.integrations.JiraIssueTrackingIntegration;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.scheduling.BackgroundJob;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.server.configuration.FixedSizeWorkerPoolDynamicQueuePolicy;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.common.SqlStorageProviderFactory;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.diagnostics.DiagnosticsBuilder;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.postgresql.ds.PGSimpleDataSource;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Map;
import java.util.Set;

import static java.time.temporal.ChronoUnit.MINUTES;
import static org.jobrunr.dashboard.JobRunrDashboardWebServerConfiguration.usingStandardDashboardConfiguration;
import static org.jobrunr.jobs.JobDetailsTestBuilder.methodThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.migrations.JobNotFoundConfiguration.usingStandardJobNotFoundConfiguration;
import static org.jobrunr.scheduling.custom.CustomScheduleTestImplementation.myCustomSchedule;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;
import static org.jobrunr.stubs.TestService.*;
import static org.jobrunr.utils.diagnostics.DiagnosticsBuilder.diagnostics;

/**
 * Main Class to run for FrontEndDevelopment
 */
public class FrontEndDevelopment {

    public static void main(String[] args) throws Exception {
        StorageProvider storageProvider = inMemoryStorageProvider();

        // SAVE RECURRING JOBS
        storageProvider.saveRecurringJob(aDefaultRecurringJob()
                .withId("rj-with-server-tag-windows")
                .withName("Recurring job with server tag WINDOWS")
                .withIntervalExpression("PT48H")
                .withServerTag("WINDOWS")
                .withLabels("tenant: Rosoco", "some label", "schedule skipped after downtime")
                .withScheduleJobsSkippedDuringDowntime().build());

        storageProvider.saveRecurringJob(aDefaultRecurringJob()
                .withId("rj-with-server-tag-linux")
                .withName("Recurring job with server tag LINUX")
                .withCronExpression(Cron.every5minutes())
                .withServerTag("LINUX")
                .withLabels("tenant: JobRunr", "a third label")
                .build());

        storageProvider.saveRecurringJob(aDefaultRecurringJob()
                .withId("rj-with-custom-schedule")
                .withName("Recurring job with custom schedule")
                .withCustomSchedule(myCustomSchedule("2052-01-01T01:00:00.000Z"))
                .withLabels("tenant: JobRunr", "custom")
                .build());

        // SAVE NORMAL JOBS
        for (int i = 0; i < 25; i++) {
            storageProvider.save(aFailedJob().withPriority(1).build());
            storageProvider.save(aFailedJob().withPriority(2).build());
        }

        for (int i = 0; i < 25; i++) {
            storageProvider.save(anEnqueuedJob()
                    .withName("a job with progress")
                    .<TestService>withJobDetails(x -> x.doWorkThatTakesLong(JobContext.Null))
                    .withPriority(0)
                    .build());
        }

        for (int i = 0; i < 10; i++) {
            storageProvider.save(anEnqueuedJob()
                    .withName("a job with mutex")
                    .<TestService>withJobDetails(x -> x.doWorkThatTakesLong(JobContext.Null))
                    .withPriority(0)
                    .withMutex("the mutex")
                    .build());
        }

        storageProvider.save(aJob().withJobDetails(methodThatDoesNotExistJobDetails()).withName("a job").withLabels(Set.of("my label")).withState(new ScheduledState(Instant.now().plus(2, MINUTES))).build());
        storageProvider.save(aJob().withName("job b").withScheduledState(Instant.now().plusSeconds(300)).build());
        storageProvider.save(aJob().withName("job a").withScheduledState(Instant.now().plusSeconds(30000)).build());
        storageProvider.save(anEnqueuedJob().withName("job 1 Tenant-A").withDynamicQueue("Tenant-A").build());
        storageProvider.save(anEnqueuedJob().withName("job 2 Tenant-A").withDynamicQueue("Tenant-A").build());
        storageProvider.save(anEnqueuedJob().withName("job 3 Tenant-A").withDynamicQueue("Tenant-A").build());
        storageProvider.save(aJob().withName("job 4 Tenant-A").withScheduledState(Instant.now().plusSeconds(30)).withDynamicQueue("Tenant-A").build());
        storageProvider.save(aJob().withName("job 5 Tenant-A").withScheduledState(Instant.now().plusSeconds(35)).withDynamicQueue("Tenant-A").build());
        storageProvider.save(aJob().withName("job 6 Tenant-A").withScheduledState(Instant.now().plusSeconds(40)).withDynamicQueue("Tenant-A").build());

        JobRunrPro
                .configure()
                .useQueues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue)
                .useStorageProvider(storageProvider)
                .useRateLimiter(
                        concurrentJobRateLimiter("my-concurrent-rate-limiter", 3)
                )
                .useJobNotFoundConfiguration(usingStandardJobNotFoundConfiguration()
                        .andMigrateScheduledJobsThatAreNotFound(
                                ((scheduledJobMatcher, scheduledJobUpdater) -> {
                                    if (scheduledJobMatcher.matches(TestService.class, "doWorkThatDoesNotExist")) {
                                        scheduledJobUpdater.setMethodName("doWork");
                                    }
                                }),
                                ((scheduledJobMatcher, scheduledJobUpdater) -> {
                                    if (scheduledJobMatcher.matches("i.dont.exist.Class")) {
                                        scheduledJobUpdater.deleteJob();
                                    }
                                })
                        ))
                .useDashboardIf(dashboardIsEnabled(args), usingStandardDashboardConfiguration()
                        .andPort(8000)
                        .andContextPath("/test")
                        .andDynamicQueueConfiguration("Tenants", "tenant: ")
                        .andIntegration(
                                new JaegerObservabilityIntegration("http://localhost:16686/"),
                                new JiraIssueTrackingIntegration("https://jobrunr.atlassian.net/", "10001"))
                )
                .useBackgroundJobServer(
                        usingStandardBackgroundJobServerConfiguration()
                                .andWorkerCount(50)
                                .andPollIntervalInSeconds(5)
                                .andTags("DEFAULT", "LINUX")
                                .andDynamicQueuePolicy(new FixedSizeWorkerPoolDynamicQueuePolicy("tenant", Map.of("Tenant-A", 6)))
                )
                .initialize();

        for (int i = 0; i < 10; i++) {
            BackgroundJob
                    .<TestService>startBatch(x -> x.enqueueNewBatchWork(25))
                    .continueWith(() -> System.out.println("Continuation of batch job " + 1));
        }

        for (int i = 0; i < 10; i++) {
            storageProvider.save(aJob()
                    .withJobDetails(TestService::doWorkWithRateLimiter)
                    .withDynamicQueue("Tenant-A")
                    .withPriority(0)
                    .build());
        }

        for (int i = 0; i < 90; i++) {
            storageProvider.save(aJob()
                    .withJobDetails(() -> new TestService().doWorkThatTakesLong(60))
                    .withDynamicQueue("Tenant-A")
                    .withPriority(0)
                    .build());
        }

        for (int i = 0; i < 10000; i++) {
            storageProvider.save(anEnqueuedJobWithName()
                    .<TestService>withJobDetails(x -> x.doWorkThatTakesLong(1))
                    .withPriority(0)
                    .build());
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> Thread.currentThread().interrupt()));

        Thread.currentThread().join();
    }

    private static boolean dashboardIsEnabled(String[] args) {
        return !argsContains(args, "dashboard=false");
    }

    private static boolean argsContains(String[] args, String argToSearch) {
        if (args.length == 0) return false;
        for (String arg : args) {
            if (argToSearch.equalsIgnoreCase(arg)) return true;
        }
        return false;
    }

    private static class ExceptionWithDiagnostics implements SevereJobRunrException.DiagnosticsAware {

        @Override
        public DiagnosticsBuilder getDiagnosticsInfo() {
            return diagnostics().withTitle("Title").withLine("Text").withException(new RuntimeException());
        }
    }

    private static StorageProvider inMemoryStorageProvider() throws SQLException {
        StorageProvider storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return storageProvider;
    }

    private static StorageProvider db2StorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:db2://127.0.0.1:53759/test");
        config.setUsername("db2inst1");
        config.setPassword("foobar1234");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider h2StorageProvider() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:/tmp/test-frontend");
        config.setUsername("sa");
        config.setPassword("sa");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider mariaDBStorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mariadb://localhost:3306/mysql?rewriteBatchedStatements=true&useBulkStmts=false");
        config.setUsername("root");
        config.setPassword("mysql");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider mysqlStorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setDriverClassName("com.mysql.jdbc.Driver");
        config.setJdbcUrl("jdbc:mysql://127.0.0.1:50516/test?rewriteBatchedStatements=true&useSSL=false");
        config.setUsername("test");
        config.setPassword("test");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider oracleStorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:oracle:thin:@127.0.0.1:54076/xepdb1");
        config.setUsername("test");
        config.setPassword("test");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider postgresStorageProvider() throws SQLException {
        PGSimpleDataSource dataSource = new PGSimpleDataSource();
        dataSource.setURL("jdbc:postgresql://127.0.0.1:5432/postgres");
        dataSource.setUser("postgres");
        dataSource.setPassword("postgres");
        dataSource.setProperty("socketTimeout", "10");
        return toStorageProvider(dataSource);
    }

    private static StorageProvider sqliteStorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlite:/tmp/jobrunr-frontend.db");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider sqlServerStorageProvider() throws SQLException {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlserver://localhost:1433;databaseName=tempdb;encrypt=true;trustServerCertificate=true;");
        config.setUsername("sa");
        config.setPassword("yourStrong(!)Password");
        return toStorageProvider(new HikariDataSource(config));
    }

    private static StorageProvider toStorageProvider(DataSource dataSource) {
        StorageProvider storageProvider = SqlStorageProviderFactory.using(dataSource);
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return storageProvider;
    }
}
