package org.jobrunr.storage;

import io.github.artsok.RepeatedIfExceptionsTest;
import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.DynamicQueueStats;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobDetails;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.states.AwaitingState;
import org.jobrunr.jobs.states.FailedBatchJobState;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.BackgroundJobServerConfiguration;
import org.jobrunr.server.LogAllStateChangesFilter;
import org.jobrunr.storage.Paging.AmountBasedList;
import org.jobrunr.storage.Paging.OffsetBasedPage;
import org.jobrunr.storage.StorageProvider.BatchJobChildStats;
import org.jobrunr.storage.listeners.JobStatsChangeListener;
import org.jobrunr.storage.listeners.MetadataChangeListener;
import org.jobrunr.storage.sql.SqlStorageProvider;
import org.jobrunr.stubs.BackgroundJobServerStub;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.annotations.Because;
import org.jobrunr.utils.exceptions.Exceptions;
import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.TestMethodIndexProvider;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.ChronoUnit.HOURS;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThatJobs;
import static org.jobrunr.JobRunrAssertions.assertThatThrownBy;
import static org.jobrunr.JobRunrAssertions.failedJob;
import static org.jobrunr.JobRunrException.shouldNotHappenException;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJobInProgress;
import static org.jobrunr.jobs.BatchJobTestBuilder.aFailedBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.methodThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.aDeletedJob;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.aBackgroundJobServerStatusBasedOn;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.aDefaultBackgroundJobServerStatus;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequestForBatchJobs;
import static org.jobrunr.storage.Paging.OffsetBasedPage.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_METADATA_PREVIOUS_JOB_SIGNATURE;
import static org.jobrunr.utils.JobUtils.getJobFingerprint;
import static org.jobrunr.utils.JobUtils.getJobSignature;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.jobrunr.utils.streams.StreamUtils.batchCollector;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

@ExtendWith(MockitoExtension.class)
public abstract class StorageProviderTest {

    protected TestService testService;
    protected StorageProvider storageProvider;
    protected BackgroundJobServer backgroundJobServer;
    protected JobMapper jobMapper;

    protected BackgroundJobServerConfiguration backgroundJobServerConfiguration;

    @BeforeEach
    public void cleanUpAndSetupBackgroundJobServer() {
        try {
            int testMethodIndex = TestMethodIndexProvider.getTestMethodIndex(this.getClass());
            cleanup(testMethodIndex);
            setUpDatabaseUsingDatabaseManager(testMethodIndex);
            final JsonMapper jsonMapper = getJsonMapper();
            JobRunrPro.configure();
            storageProvider = getStorageProvider();
            backgroundJobServerConfiguration = spy(usingStandardBackgroundJobServerConfiguration().andTags("LINUX", "DEFAULT"));

            backgroundJobServer = new BackgroundJobServerStub(storageProvider, jsonMapper, backgroundJobServerConfiguration);
            jobMapper = new JobMapper(jsonMapper);
        } catch (Exception e) {
            System.out.println("Error occurred");
            throw new RuntimeException(e);
        }
    }

    @AfterEach
    public void cleanupStorageProvider() {
        this.storageProvider.close();
    }

    protected abstract void cleanup(int testMethodIndex);

    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        // allows to use a DatabaseManager like Flyway to do the migrations if necessary
    }

    protected abstract StorageProvider getStorageProvider();

    protected ThrowingStorageProvider makeThrowingStorageProvider(StorageProvider storageProvider) {
        return new ThrowingStorageProvider(storageProvider, "TODO") {
            @Override
            protected void makeStorageProviderThrowException(StorageProvider storageProvider) {
                throw new UnsupportedOperationException("Implement me!");
            }
        };
    }

    @Test
    protected void testAnnounceAndListBackgroundJobServers() {
        final BackgroundJobServerStatus serverStatus1 = aDefaultBackgroundJobServerStatus().withName("server-A").withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus1);
        sleep(100);
        assertThat(storageProvider.getLongestRunningBackgroundJobServerId()).isEqualTo(serverStatus1.getId());

        final BackgroundJobServerStatus serverStatus2 = aDefaultBackgroundJobServerStatus().withName("server-B").withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus2);
        sleep(100);
        storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus2).withLastHeartbeat(now()).build());
        sleep(10);
        storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus1).withLastHeartbeat(now()).build());

        final List<BackgroundJobServerStatus> backgroundJobServers = storageProvider.getBackgroundJobServers();

        assertThat(backgroundJobServers).hasSize(2);
        //why: sqlite has no microseconds precision for timestamps
        assertThat(backgroundJobServers.get(0))
                .hasSameSettingsAs(serverStatus1)
                .hasFirstHeartbeatCloseTo(serverStatus1.getFirstHeartbeat())
                .hasLastHeartbeatAfter(serverStatus1.getFirstHeartbeat());

        assertThat(backgroundJobServers.get(1))
                .hasSameSettingsAs(serverStatus2)
                .hasFirstHeartbeatCloseTo(serverStatus2.getFirstHeartbeat())
                .hasLastHeartbeatAfter(serverStatus2.getFirstHeartbeat());
        assertThat(backgroundJobServers).extracting("name").containsExactly(serverStatus1.getName(), serverStatus2.getName());
        assertThat(backgroundJobServers).extracting("name").containsExactly(serverStatus1.getName(), serverStatus2.getName());

        assertThat(storageProvider.getLongestRunningBackgroundJobServerId()).isEqualTo(serverStatus1.getId());

        storageProvider.signalBackgroundJobServerStopped(serverStatus1);
        assertThat(storageProvider.getBackgroundJobServers()).hasSize(1);
        assertThat(storageProvider.getLongestRunningBackgroundJobServerId()).isEqualTo(serverStatus2.getId());
    }

    @Test
    void testPauseResumeAndControlBackgroundJobServer() {
        // WHEN NO PRIOR DATA
        boolean allProcessingPausedIsFalseByDefault = storageProvider.isAllJobProcessingPaused();
        assertThat(allProcessingPausedIsFalseByDefault).isFalse();

        // GIVEN
        final BackgroundJobServerStatus serverStatus = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus);
        sleep(50);

        // WHEN
        storageProvider.controlBackgroundJobServer(serverStatus.getId(), false);

        // THEN
        boolean keepRunningShouldBeFalse = storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus).withLastHeartbeat(now()).build());
        assertThat(keepRunningShouldBeFalse).isFalse();

        sleep(50);

        // WHEN
        storageProvider.controlBackgroundJobServer(serverStatus.getId(), true);

        // THEN
        boolean keepRunningShouldBeTrue = storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus).withLastHeartbeat(now()).build());
        assertThat(keepRunningShouldBeTrue).isTrue();

        // WHEN
        storageProvider.pauseAllJobProcessing();

        // THEN
        boolean allProcessingPausedShouldBeTrue = storageProvider.isAllJobProcessingPaused();
        assertThat(allProcessingPausedShouldBeTrue).isTrue();
        boolean keepRunningShouldBeFalseAgain = storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus).withLastHeartbeat(now()).build());
        assertThat(keepRunningShouldBeFalseAgain).isFalse();

        // WHEN
        storageProvider.controlBackgroundJobServer(serverStatus.getId(), true);

        // THEN
        boolean allProcessingPausedShouldBeFalse = storageProvider.isAllJobProcessingPaused();
        assertThat(allProcessingPausedShouldBeFalse).isFalse();
        boolean keepRunningShouldBeTrueAgain = storageProvider.signalBackgroundJobServerAlive(aBackgroundJobServerStatusBasedOn(serverStatus).withLastHeartbeat(now()).build());
        assertThat(keepRunningShouldBeTrueAgain).isTrue();
    }

    @Test
    protected void testRemoveTimedOutBackgroundJobServers() {
        final BackgroundJobServerStatus serverStatus1 = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus1);
        sleep(50);
        Instant deleteServersWithHeartbeatOlderThanThis = now();
        sleep(50);

        final BackgroundJobServerStatus serverStatus2 = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus2);

        final int deletedServers = storageProvider.removeTimedOutBackgroundJobServers(deleteServersWithHeartbeatOlderThanThis);
        assertThat(deletedServers).isEqualTo(1);
        assertThat(storageProvider.getBackgroundJobServers()).hasSize(1);
        assertThat(storageProvider.getBackgroundJobServers().get(0).getId()).isEqualTo(serverStatus2.getId());
    }

    @Test
    protected void ifServerHasTimedOutAndSignalsItsAliveAnExceptionIsThrown() {
        final BackgroundJobServerStatus serverStatus = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus);
        sleep(100);

        Instant deleteServersWithHeartbeatOlderThanThis = now();
        storageProvider.removeTimedOutBackgroundJobServers(deleteServersWithHeartbeatOlderThanThis);

        assertThatThrownBy(() -> storageProvider.signalBackgroundJobServerAlive(serverStatus)).isInstanceOf(ServerTimedOutException.class);
    }

    @Test
    protected void testCRUDMetadataLifeCycle() {
        List<JobRunrMetadata> metadataListBeforeCreate = storageProvider.getMetadata("shouldNotHappenException");
        assertThat(metadataListBeforeCreate).isEmpty();

        // CREATE
        JobRunrMetadata metadata1 = new JobRunrMetadata("shouldNotHappenException", UUID.randomUUID().toString(), Exceptions.getStackTraceAsString(shouldNotHappenException("bad!")));
        JobRunrMetadata metadata2 = new JobRunrMetadata("shouldNotHappenException", UUID.randomUUID().toString(), Exceptions.getStackTraceAsString(shouldNotHappenException("Really bad!")));
        JobRunrMetadata metadata3 = new JobRunrMetadata("succeeded-jobs-counter", UUID.randomUUID().toString(), "5");
        storageProvider.saveMetadata(metadata1);
        storageProvider.saveMetadata(metadata2);
        storageProvider.saveMetadata(metadata3);

        // LIST
        List<JobRunrMetadata> metadataListAfterCreate = storageProvider.getMetadata("shouldNotHappenException");
        assertThat(metadataListAfterCreate).hasSize(2);

        // GET
        assertThat(storageProvider.getMetadata("shouldNotHappenException", metadata1.getOwner())).isEqualTo(metadata1);
        assertThat(storageProvider.getMetadata("shouldNotHappenException", metadata2.getOwner())).isEqualTo(metadata2);
        assertThat(storageProvider.getMetadata("somethingThatDoesNotExist", UUID.randomUUID().toString())).isNull();

        // UPDATE
        JobRunrMetadata metadata1Update = new JobRunrMetadata("shouldNotHappenException", metadata1.getOwner(), "An Update");
        JobRunrMetadata metadata2Update = new JobRunrMetadata("shouldNotHappenException", metadata2.getOwner(), "An Update");
        storageProvider.saveMetadata(metadata1Update);
        storageProvider.saveMetadata(metadata2Update);

        List<JobRunrMetadata> metadataListAfterUpdate = storageProvider.getMetadata("shouldNotHappenException");
        assertThat(metadataListAfterUpdate).hasSize(2);

        // DEL
        storageProvider.deleteMetadata("shouldNotHappenException");
        storageProvider.deleteMetadata("shouldNotHappenException", metadata3.getOwner());

        // LIST
        List<JobRunrMetadata> metadataListAfterDelete = storageProvider.getMetadata("shouldNotHappenException");
        assertThat(metadataListAfterDelete).isEmpty();
    }

    @Test
    protected void testOnChangeListenerForSaveAndDeleteMetadata() {
        final SimpleMetadataOnChangeListener onChangeListener = new SimpleMetadataOnChangeListener();
        storageProvider.addJobStorageOnChangeListener(onChangeListener);

        JobRunrMetadata metadata = new JobRunrMetadata(onChangeListener.listenForChangesOfMetadataName(), "some-owner", "some-value");
        storageProvider.saveMetadata(metadata);
        assertThat(onChangeListener.changes).hasSize(1);
        assertThat(onChangeListener.changes.get(0)).hasSize(1);

        storageProvider.deleteMetadata(metadata.getName());
        assertThat(onChangeListener.changes).hasSizeGreaterThanOrEqualTo(2);
        assertThat(onChangeListener.changes.get(onChangeListener.changes.size() - 1)).isEmpty();
    }

    @Test
    protected void testGetDynamicQueueStats() {
        final List<Job> jobs = asList(
                aJobInProgress().withName("excluded, already in progress").withDynamicQueue("tenant-a").withMutex("resource-a").withPriority(1).build(),
                aJob().withName("excluded, mutex already in use").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(10, SECONDS)).withMutex("resource-a").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(9, SECONDS)).withPriority(2).withMutex("resource-b").build(),
                aJob().withName("included, tenant-a, 1").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(8, SECONDS)).withPriority(1).withMutex("resource-b").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(7, SECONDS)).withPriority(2).withMutex("resource-c").build(),
                aJob().withName("included, tenant-b, 1").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(6, SECONDS)).withPriority(1).withMutex("resource-c").build(),
                aJob().withName("included, tenant-a, 3").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(4, SECONDS)).withPriority(2).withMutex("resource-d").build(),
                aJob().withName("included, tenant-a, 2").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(5, SECONDS)).withPriority(2).withoutMutex().build(),
                aJob().withName("included, tenant-b, 2").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build(),
                aJob().withName("included, tenant-less").withoutDynamicQueue().withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build()
        );
        storageProvider.save(jobs);

        DynamicQueueStats dynamicQueueStats = storageProvider.getDynamicQueueStats(null);

        assertThat(dynamicQueueStats)
                .isNotNull()
                .hasDefaultQueueStats(x -> x
                        .hasStats(AWAITING, 0L)
                        .hasStats(SCHEDULED, 0L)
                        .hasStats(ENQUEUED, 1L)
                        .hasStats(PROCESSING, 0L)
                        .hasStats(SUCCEEDED, 0L)
                        .hasStats(FAILED, 0L))
                .hasQueueStats("tenant-a", x -> x
                        .hasStats(AWAITING, 0L)
                        .hasStats(SCHEDULED, 0L)
                        .hasStats(ENQUEUED, 5L)
                        .hasStats(PROCESSING, 1L)
                        .hasStats(SUCCEEDED, 0L)
                        .hasStats(FAILED, 0L))
                .hasQueueStats("tenant-b", x -> x
                        .hasStats(AWAITING, 0L)
                        .hasStats(SCHEDULED, 0L)
                        .hasStats(ENQUEUED, 3L)
                        .hasStats(PROCESSING, 0L)
                        .hasStats(SUCCEEDED, 0L)
                        .hasStats(FAILED, 0L));
    }

    @Test
    protected void testCRUDJobLifeCycle() {
        // SCHEDULED
        Job scheduledJob = aScheduledJob().build();
        Job createdJob = storageProvider.save(scheduledJob);
        Job savedScheduledJob = storageProvider.getJobById(createdJob.getId());
        assertThat(savedScheduledJob).isEqualTo(createdJob);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withScheduledAtTo(now()).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(1000))).contains(createdJob);

        // ENQUEUE
        savedScheduledJob.enqueue();
        storageProvider.save(savedScheduledJob);
        Job savedEnqueuedJob = storageProvider.getJobById(createdJob.getId());
        assertThat(savedEnqueuedJob).isEqualTo(savedScheduledJob);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withScheduledAtTo(now()).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(1000))).contains(savedEnqueuedJob);

        // PROCESSING
        savedEnqueuedJob.startProcessingOn(backgroundJobServer);
        storageProvider.save(savedEnqueuedJob);
        Job savedProcessingJob = storageProvider.getJobById(createdJob.getId());
        assertThat(savedProcessingJob).isEqualTo(savedEnqueuedJob);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(PROCESSING), ascOnPriorityAndUpdatedAt(1000))).contains(savedProcessingJob);

        // FAILED & RESCHEDULED
        savedProcessingJob.failed("A failure", new RuntimeException());
        savedProcessingJob.scheduleAt(now(), "Job failed");
        storageProvider.save(savedProcessingJob);
        Job savedRescheduledJob = storageProvider.getJobById(createdJob.getId());
        assertThat(savedRescheduledJob).isEqualTo(savedProcessingJob);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withScheduledAtTo(now()).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(1000))).contains(savedRescheduledJob);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(PROCESSING), ascOnPriorityAndUpdatedAt(1000))).isEmpty();

        // ENQUEUED
        savedRescheduledJob.enqueue();
        storageProvider.save(savedRescheduledJob);
        Job savedEnqueuedJobRetry = storageProvider.getJobById(createdJob.getId());
        assertThat(savedEnqueuedJobRetry).isEqualTo(savedRescheduledJob);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withScheduledAtTo(now()).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(1000))).contains(savedEnqueuedJobRetry);

        // PROCESSING
        savedEnqueuedJobRetry.startProcessingOn(backgroundJobServer);
        storageProvider.save(savedEnqueuedJobRetry);
        Job savedProcessingJobRetry = storageProvider.getJobById(createdJob.getId());
        assertThat(savedProcessingJobRetry).isEqualTo(savedEnqueuedJobRetry);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(PROCESSING), ascOnPriorityAndUpdatedAt(1000))).contains(savedProcessingJobRetry);

        // SUCCEEDED
        savedProcessingJobRetry.succeeded();
        storageProvider.save(savedProcessingJobRetry);
        Job savedSucceededJob = storageProvider.getJobById(createdJob.getId());
        assertThat(savedSucceededJob).isEqualTo(savedProcessingJobRetry);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(PROCESSING), ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(SUCCEEDED), ascOnPriorityAndUpdatedAt(1000))).contains(savedSucceededJob);

        // DELETED
        savedSucceededJob.delete("By test");
        storageProvider.save(savedSucceededJob);
        Job fetchedDeletedJob = storageProvider.getJobById(createdJob.getId());
        assertThat(fetchedDeletedJob).hasState(DELETED);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(SUCCEEDED), ascOnPriorityAndUpdatedAt(1000))).isEmpty();
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(DELETED), ascOnPriorityAndUpdatedAt(1000))).contains(fetchedDeletedJob);
        assertThat(storageProvider.getJobStats().getAllTimeSucceeded()).isEqualTo(1);

        // DELETED PERMANENTLY
        final int permanentlyDeletedJobs = storageProvider.deleteJobsPermanently(aJobSearchRequest().withJobIds(createdJob.getId()).build());
        assertThat(permanentlyDeletedJobs).isEqualTo(1);
        assertThatThrownBy(() -> storageProvider.getJobById(savedEnqueuedJob.getId())).isInstanceOf(JobNotFoundException.class);
        assertThatJobs(storageProvider.getJobs(new JobSearchRequest(DELETED), ascOnPriorityAndUpdatedAt(1000))).isEmpty();
    }

    @Test
    protected void testSaveOfJobWithSameId() {
        UUID id = UUID.randomUUID();
        Job job1 = anEnqueuedJobWithName().withId(id).build();
        Job job2 = anEnqueuedJobWithName().withId(id).build();

        storageProvider.save(job1);
        assertThatThrownBy(() -> storageProvider.save(job2)).isInstanceOf(ConcurrentJobModificationException.class);
    }

    @Test
    void testSaveReplaceJob() {
        Job initialJob = anEnqueuedJobWithName().build();
        Job updatedJob = aCopyOf(initialJob).build();
        storageProvider.saveReplace(initialJob);
        storageProvider.saveReplace(updatedJob);

        Job actualUpdatedJob = storageProvider.getJobById(updatedJob.getId());
        assertThat(actualUpdatedJob)
                .hasState(ENQUEUED)
                .isReplacingExistingJob();

        // saveReplace may only be called with jobs that are in initial state
        Job updatedJob2 = aCopyOf(initialJob).withVersion(106).withProcessingState().build();
        storageProvider.saveReplace(updatedJob2);
        Job actualUpdatedJob2 = storageProvider.getJobById(updatedJob2.getId());
        assertThat(actualUpdatedJob2)
                .hasVersion(107)
                .hasState(PROCESSING);
    }

    @Test
    protected void testOptimisticLockingOnSaveJob() {
        Job job = anEnqueuedJobWithName().build();
        Job createdJob = storageProvider.save(job);
        Job fetchedJob = storageProvider.getJobById(createdJob.getId());

        Job job1 = jobMapper.deserializeJob(jobMapper.serializeJob(fetchedJob));
        Job job2 = jobMapper.deserializeJob(jobMapper.serializeJob(fetchedJob));

        job1.startProcessingOn(backgroundJobServer);
        job2.startProcessingOn(backgroundJobServer);

        storageProvider.save(job1);
        assertThatThrownBy(() -> storageProvider.save(job2)).isInstanceOf(ConcurrentJobModificationException.class);

        assertThat(job1).hasVersion(2);
        assertThat(job2).hasVersion(1);
    }

    @Test
    void testOptimisticLockingOnSaveJobForJobThatWasDeleted() {
        Job job = anEnqueuedJobWithName().build();
        storageProvider.save(job);
        storageProvider.deleteJobsPermanently(aJobSearchRequest().withJobId(job.getId()).build());
        job.succeeded();
        assertThatThrownBy(() -> storageProvider.save(job))
                .isInstanceOf(ConcurrentJobModificationException.class);
    }

    @Test
    void testExceptionOnSaveJob() {
        Job job = anEnqueuedJobWithName().build();
        Job enqueuedJob = storageProvider.save(job);

        job.startProcessingOn(backgroundJobServer);
        try (ThrowingStorageProvider ignored = makeThrowingStorageProvider(storageProvider)) {
            assertThatThrownBy(() -> storageProvider.save(enqueuedJob))
                    .isInstanceOf(StorageException.class);
        }

        job.updateProcessing();
        assertThatCode(() -> storageProvider.save(enqueuedJob)).doesNotThrowAnyException();
    }

    @Test
    void onUpdateAlsoUpdatesJobSignatureAndFingerprintSoThatJobsCanBeMigrated() {
        Job job = aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build();
        storageProvider.save(job);

        final Job updatedJob = aCopyOf(job).withJobDetails(() -> testService.doWork()).withMetadata(FIELD_METADATA_PREVIOUS_JOB_SIGNATURE, getJobSignature(job)).build();
        storageProvider.save(updatedJob);

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(SCHEDULED, getJobSignature(job)), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(0);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withStateName(SCHEDULED).withJobFingerprint(getJobFingerprint(job)).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(0);
        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(SCHEDULED, getJobSignature(updatedJob)), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(1);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withStateName(SCHEDULED).withJobFingerprint(getJobFingerprint(updatedJob)).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(1);
    }

    @Test
    void onSaveAlsoUpdatesJobPrioritySoJobsCanBeRequeuedOnDifferentQueues() {
        // GIVEN
        Job job = aScheduledJob()
                .withPriority(2)
                .withJobDetails(() -> testService.doWork()).build();
        storageProvider.save(job);

        // WHEN
        final Job updatedJob1 = aCopyOf(job).withPriority(0).build();
        storageProvider.save(updatedJob1);

        // THEM
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withPriority(2).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(0);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withPriority(0).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(1);

        // WHEN
        final Job updatedJob2 = aCopyOf(updatedJob1).withPriority(1).build();
        storageProvider.save(List.of(updatedJob2));

        // THEN
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withPriority(0).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(0);
        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withPriority(1).build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(1);
    }

    @Test
    protected void testOptimisticLockingOnSaveJobs() {
        Job job = aJobInProgress().build();
        Job createdJob1 = storageProvider.save(aCopyOf(job).withId().build());
        Job createdJob2 = storageProvider.save(aCopyOf(job).withId().build());
        Job createdJob3 = storageProvider.save(aCopyOf(job).withId().build());
        Job createdJob4 = storageProvider.save(aCopyOf(job).withId().build());

        storageProvider.save(aCopyOf(createdJob2).withSucceededState().build());
        storageProvider.save(aCopyOf(createdJob3).withDeletedState().build());

        createdJob1.updateProcessing();
        createdJob2.updateProcessing();
        createdJob3.updateProcessing();
        createdJob4.updateProcessing();

        assertThatThrownBy(() -> storageProvider.save(asList(createdJob1, createdJob2, createdJob3, createdJob4)))
                .isInstanceOf(ConcurrentJobModificationException.class)
                .has(failedJob(createdJob2))
                .has(failedJob(createdJob3));

        assertThat(asList(createdJob1, createdJob4)).allMatch(dbJob -> dbJob.getVersion() == 2);
        assertThat(asList(createdJob2, createdJob3)).allMatch(dbJob -> dbJob.getVersion() == 1); // as we don't know the version in the DB, we keep the original version

        // due to autocommit, all jobs have version 2 in the database
        assertThat(storageProvider.getJobById(createdJob1.getId())).hasVersion(2);
        assertThat(storageProvider.getJobById(createdJob2.getId())).hasVersion(2);
        assertThat(storageProvider.getJobById(createdJob3.getId())).hasVersion(2);
        assertThat(storageProvider.getJobById(createdJob4.getId())).hasVersion(2);
    }

    @Test
    protected void testGetDistinctJobSignatures() {
        TestService testService = new TestService();
        Job job1 = aScheduledJob().withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();
        Job job2 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWork(2)).build();
        Job job3 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWork(2)).build();
        Job job4 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWorkThatTakesLong(5)).build();
        Job job5 = aJobInProgress().withJobDetails(() -> testService.doWork(2, 5)).build();
        Job job6 = aSucceededJob().withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();

        storageProvider.save(asList(job1, job2, job3, job4, job5, job6));

        Set<String> distinctJobSignaturesForScheduledJobs = storageProvider.getDistinctJobSignatures(SCHEDULED);
        assertThat(distinctJobSignaturesForScheduledJobs)
                .hasSize(1)
                .containsOnly("org.jobrunr.stubs.TestService.doWork(java.util.UUID)");

        Set<String> distinctJobSignaturesForEnqueuedJobs = storageProvider.getDistinctJobSignatures(ENQUEUED);
        assertThat(distinctJobSignaturesForEnqueuedJobs)
                .hasSize(2)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer)");

        Set<String> distinctJobSignaturesForJobsInProgress = storageProvider.getDistinctJobSignatures(PROCESSING);
        assertThat(distinctJobSignaturesForJobsInProgress)
                .hasSize(1)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer, java.lang.Integer)");

        Set<String> distinctJobSignaturesForSucceededJobs = storageProvider.getDistinctJobSignatures(SUCCEEDED);
        assertThat(distinctJobSignaturesForSucceededJobs)
                .hasSize(1)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWork(java.util.UUID)");

        Set<String> distinctJobSignaturesForScheduledAndEnqueuedJobs = storageProvider.getDistinctJobSignatures(SCHEDULED, ENQUEUED);
        assertThat(distinctJobSignaturesForScheduledAndEnqueuedJobs)
                .hasSize(3)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWork(java.util.UUID)",
                        "org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer)");

        Set<String> allDistinctJobSignatures = storageProvider.getDistinctJobSignatures(StateName.values());
        assertThat(allDistinctJobSignatures)
                .hasSize(4)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWork(java.util.UUID)",
                        "org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer, java.lang.Integer)");
    }

    @Test
    protected void testGetJobSignatureFacet() {
        TestService testService = new TestService();
        Job job1 = aScheduledJob().withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();
        Job job2 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWork(2)).build();
        Job job3 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWork(2)).build();
        Job job4 = anEnqueuedJobWithName().withJobDetails(() -> testService.doWorkThatTakesLong(5)).build();
        Job job5 = aJobInProgress().withJobDetails(() -> testService.doWork(2, 5)).build();
        Job job6 = aFailedJob().withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();

        storageProvider.save(asList(job1, job2, job3, job4, job5, job6));

        Map<String, Long> jobSignatureFacet = storageProvider.getJobSignatureFacet(aJobSearchRequest().build());
        assertThat(jobSignatureFacet)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("org.jobrunr.stubs.TestService.doWork(java.util.UUID)", 2L);
                            put("org.jobrunr.stubs.TestService.doWork(java.lang.Integer)", 2L);
                            put("org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)", 1L);
                            put("org.jobrunr.stubs.TestService.doWork(java.lang.Integer, java.lang.Integer)", 1L);
                        }}
                );

        Map<String, Long> jobSignatureFacetForEnqueuedJobs = storageProvider.getJobSignatureFacet(aJobSearchRequest()
                .withStateName(ENQUEUED).build());
        assertThat(jobSignatureFacetForEnqueuedJobs)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("org.jobrunr.stubs.TestService.doWork(java.lang.Integer)", 2L);
                            put("org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)", 1L);
                        }}
                );

        Map<String, Long> jobSignatureFacetFilteredOnFailedJob = storageProvider.getJobSignatureFacet(aJobSearchRequest()
                .withJobExceptionType("java.lang.IllegalStateException").build());
        assertThat(jobSignatureFacetFilteredOnFailedJob)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("org.jobrunr.stubs.TestService.doWork(java.util.UUID)", 1L);
                        }}
                );

        Map<String, Long> jobSignatureFacetFilteredOnNonExistentJob = storageProvider.getJobSignatureFacet(aJobSearchRequest()
                .withJobName("Non existent job").build());
        assertThat(jobSignatureFacetFilteredOnNonExistentJob)
                .hasSize(0);
    }

    @Test
    protected void testGetJobExceptionTypeFacet() {
        Job job1 = aFailedJob().build();
        Job job2 = aFailedJob().withName("renamed failed job").build();
        Job job3 = aFailedJob().withFailedState().withJobDetails(() -> new TestService().doWork(2)).build();
        Job job4 = aFailedBatchJob().withState(new FailedBatchJobState()).build();

        storageProvider.save(asList(job1, job2, job3, job4));

        Map<String, Long> jobExceptionFacet = storageProvider.getJobExceptionTypeFacet(aJobSearchRequest().build());
        assertThat(jobExceptionFacet)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("java.lang.Exception", 1L);
                            put("java.lang.IllegalStateException", 2L);
                            put("org.jobrunr.jobs.BatchChildJobFailedException", 1L);
                        }}
                );

        Map<String, Long> jobExceptionFacetFilteredOnJobName = storageProvider.getJobExceptionTypeFacet(aJobSearchRequest()
                .withJobName("renamed failed job").build());
        assertThat(jobExceptionFacetFilteredOnJobName)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("java.lang.IllegalStateException", 1L);
                        }}
                );

        Map<String, Long> jobExceptionFacetFilteredOnJobSignature = storageProvider.getJobExceptionTypeFacet(aJobSearchRequest()
                .withJobSignature("org.jobrunr.stubs.TestService.doWork(java.lang.Integer)").build());
        assertThat(jobExceptionFacetFilteredOnJobSignature)
                .containsExactlyEntriesOf(
                        new TreeMap<>() {{
                            put("java.lang.Exception", 1L);
                        }}
                );
    }

    @Test
    protected void testSaveListUpdateListAndGetListOfJobs() {
        assertThatCode(() -> storageProvider.save(emptyList())).doesNotThrowAnyException();

        final List<Job> jobs = asList(
                aJob().withName("1").withEnqueuedState(now().minusSeconds(30)).build(),
                aJob().withName("2").withEnqueuedState(now().minusSeconds(20)).build(),
                aJob().withName("3").withEnqueuedState(now().minusSeconds(10)).build());
        final List<Job> savedJobs = storageProvider.save(jobs);

        assertThat(storageProvider)
                .hasJobs(ENQUEUED, 3)
                .hasJobs(PROCESSING, 0);

        savedJobs.forEach(job -> {
            job.startProcessingOn(backgroundJobServer);
            sleep(100);
        });
        storageProvider.save(savedJobs);

        assertThat(storageProvider)
                .hasJobs(ENQUEUED, 0)
                .hasJobs(PROCESSING, 3);

        List<Job> fetchedJobsAsc = storageProvider.getJobList(new JobSearchRequest(PROCESSING), AmountBasedList.ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(fetchedJobsAsc)
                .hasSize(3)
                .containsAll(savedJobs);
        assertThat(fetchedJobsAsc).extracting("jobName").containsExactly("1", "2", "3");

        List<Job> fetchedJobsDesc = storageProvider.getJobList(new JobSearchRequest(PROCESSING), AmountBasedList.descOnUpdatedAt(100));
        assertThatJobs(fetchedJobsDesc)
                .hasSize(3)
                .containsAll(savedJobs);
        assertThat(fetchedJobsDesc).extracting("jobName").containsExactly("3", "2", "1");
    }


    @Test
    void testExceptionOnSaveListOfJobs() {
        final List<Job> jobs = asList(
                aJob().withName("1").withEnqueuedState(now().minusSeconds(30)).build(),
                aJob().withName("2").withEnqueuedState(now().minusSeconds(20)).build(),
                aJob().withName("3").withEnqueuedState(now().minusSeconds(10)).build());
        final List<Job> savedJobs = storageProvider.save(jobs);
        savedJobs.forEach(job -> job.startProcessingOn(backgroundJobServer));

        try (ThrowingStorageProvider ignored = makeThrowingStorageProvider(storageProvider)) {
            assertThatThrownBy(() -> storageProvider.save(savedJobs))
                    .isInstanceOf(StorageException.class);
        }

        savedJobs.forEach(Job::updateProcessing);
        storageProvider.save(savedJobs);
    }

    @Test
    protected void updateJobListAlsoUpdatesMutex() {
        // GIVEN
        final Job awaitingJob = aJob().withAwaitingRateLimiterState("my-rate-limiter").withoutMutex().build();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> awaitingBatchChildJobs = storageProvider.getJobs(aJobSearchRequest().withStateName(AWAITING).build(), OffsetBasedPage.ascOnUpdatedAt(1000));
        assertThat(awaitingBatchChildJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);

        // WHEN
        awaitingJob.setMutex("my-mutex");
        awaitingJob.enqueue();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> enqueuedBatchChildJobs = storageProvider.getJobs(aJobSearchRequest().withStateName(ENQUEUED).withMutex("my-mutex").build(), OffsetBasedPage.ascOnUpdatedAt(1000));
        assertThat(enqueuedBatchChildJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);
    }

    @Test
    protected void updateJobListDoesNotAlterAwaitingOn() {
        // GIVEN
        final Job batchJob = anEnqueuedBatchJob().build();
        storageProvider.save(batchJob);
        final Job awaitingJob = aJob().withAwaitingBatchJobState(batchJob.getId()).withServerTag("DEFAULT").withMutex("some-mutex").build();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> awaitingBatchChildJobs = storageProvider.getJobs(aJobSearchRequest().withAwaitingOn(batchJob.getId()).withStateName(AWAITING).build(), OffsetBasedPage.ascOnUpdatedAt(1000));
        assertThat(awaitingBatchChildJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);

        // WHEN
        awaitingJob.enqueue();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> enqueuedBatchChildJobs = storageProvider.getJobs(aJobSearchRequest().withAwaitingOn(batchJob.getId()).withStateName(ENQUEUED).build(), OffsetBasedPage.ascOnUpdatedAt(1000));
        assertThat(enqueuedBatchChildJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);
    }

    @Test
    protected void updateJobListDoesNotAlterRateLimiter() {
        // GIVEN
        final Job awaitingJob = aJob().withAwaitingRateLimiterState("rate-limiter-name").build();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> awaitingJobs = storageProvider.getJobs(aJobSearchRequest().withStateName(AWAITING).withRateLimiter("rate-limiter-name").build(), OffsetBasedPage.ascOnUpdatedAt(100));
        assertThat(awaitingJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);

        // WHEN
        awaitingJob.enqueue();
        storageProvider.save(singletonList(awaitingJob));

        // THEN
        final Page<Job> enqueuedJobs = storageProvider.getJobs(aJobSearchRequest().withStateName(ENQUEUED).withRateLimiter("rate-limiter-name").build(), OffsetBasedPage.ascOnUpdatedAt(100));
        assertThat(enqueuedJobs)
                .hasTotal(1L)
                .containsExactly(awaitingJob);
    }

    @Test
    protected void testCountJobsBySearchRequestNoFilter() {
        storageProvider.save(aScheduledJob().build());
        storageProvider.save(anEnqueuedJobWithName().build());
        storageProvider.save(aJobInProgress().build());

        assertThat(storageProvider.countJobs(aJobSearchRequest().build())).isEqualTo(3L);
        assertThat(storageProvider.countJobs(aJobSearchRequest().withStateName(SCHEDULED).build())).isEqualTo(1L);
        assertThat(storageProvider.countJobs(aJobSearchRequest().withStateName(FAILED).build())).isEqualTo(0L);
    }

    @Test
    protected void testGetJobsBySearchRequestNoFilter() {
        Job scheduledJob = aScheduledJob().build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobs).hasItems(1);
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnState() {
        Job scheduledJob = aScheduledJob().build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withStateName(SCHEDULED).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withStateName(ENQUEUED).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnStates() {
        storageProvider.save(asList(
                aJob().withAwaitingRateLimiterState("my-rate-limiter").build(),
                aScheduledJob().build(),
                aScheduledJob().build(),
                aJobInProgress().build(),
                aSucceededJob().build()));

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withStateNames(SCHEDULED, ENQUEUED, PROCESSING).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobs).hasItems(3);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withStateName(FAILED).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnPriority() {
        Job scheduledJob = aScheduledJob().withPriority(1).build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withPriority(1).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withPriority(2).build(), ascOnPriorityAndUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnJobId() {
        Job scheduledJob = aScheduledJob().withName("Some job with 56").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withJobId(scheduledJob.getId()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withJobId(UUID.randomUUID()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnJobIds() {
        Job job1 = aScheduledJob().withName("Some job with 56").build();
        Job job2 = aScheduledJob().withName("Some job with 57").build();
        Job job3 = aScheduledJob().withName("Some job with 58").build();
        storageProvider.save(asList(job1, job2, job3));

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withJobIds(job2.getId(), job3.getId()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(2);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withJobId(UUID.randomUUID()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnDisplayNameWorksCaseInsensitive() {
        Job scheduledJob = aScheduledJob().withName("Some job with 56").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withJobName("job with 56").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withJobName("job with 58").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnLabelWorksCaseInsensitive() {
        Job scheduledJob = aScheduledJob().withLabels("CORRECT label").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withLabel("correct label").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withLabel("incorrect label").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnJobSignature() {
        Job scheduledJob = aScheduledJob().withJobDetails(() -> testService.doWork()).build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withJobSignature("org.jobrunr.stubs.TestService.doWork()").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withJobSignature("org.jobrunr.stubs.TestService.methodThatDoesNotExist()").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnJobExceptionType() {
        Job failedJob = aFailedJob().withJobDetails(() -> testService.doWork()).build();
        Job failedBatchJob = aBatchJob().withState(new FailedBatchJobState()).build();
        storageProvider.save(asList(failedJob, failedBatchJob));

        final Page<Job> failedJobsDueToIllegalState = storageProvider.getJobs(aJobSearchRequest().withJobExceptionType("java.lang.IllegalStateException").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(failedJobsDueToIllegalState).hasItems(1);

        final Page<Job> jobsThatMatchNonExistentExceptionType = storageProvider.getJobs(aJobSearchRequest().withJobSignature("java.lang.Exception").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatMatchNonExistentExceptionType).hasNoItems();

        final Page<Job> failedBatchJobs = storageProvider.getJobs(aJobSearchRequest().withJobExceptionType("org.jobrunr.jobs.BatchChildJobFailedException").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(failedBatchJobs).hasItems(1);
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnJobFingerprint() {
        Job scheduledJob = aScheduledJob().withJobDetails(() -> testService.doWork(5, 6)).build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobsByExactMatch = storageProvider.getJobs(aJobSearchRequest().withJobFingerprint("org.jobrunr.stubs.TestService.doWork(5, 6)").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsByExactMatch).hasItems(1);

        final Page<Job> jobsByMatchPartially = storageProvider.getJobs(aJobSearchRequest().withJobFingerprint("testService.doWork(5, 6)").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsByMatchPartially).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withJobFingerprint("org.jobrunr.stubs.TestService.doWork(7, 8)").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnServerTag() {
        Job scheduledJob = aScheduledJob().withServerTag("LINUX").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withServerTag("LINUX").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withServerTag("WINDOWS").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnMutex() {
        Job scheduledJob = aScheduledJob().withMutex("virusscanner/LINUX").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withMutex("LINUX").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withMutex("WINDOWS").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnRecurringJobId() {
        RecurringJob recurringJob = aDefaultRecurringJob().withId("my-recurring-job-id").build();
        Job scheduledJob = recurringJob.toScheduledJob();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withRecurringJobId("my-recurring-job-id").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withRecurringJobId("another-recurring-job-id").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnAwaitingOn() {
        UUID someOtherJob = UUID.randomUUID();

        storageProvider.save(asList(
                aJob().withAwaitingState(someOtherJob).build(),
                aJob().withAwaitingState(someOtherJob).build(),
                aJob().withAwaitingState(someOtherJob).build()
        ));

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withAwaitingOn(someOtherJob).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(3);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withAwaitingOn(UUID.randomUUID()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnRateLimiter() {
        String rateLimiterName = "rate-limiter-name";
        storageProvider.save(asList(
                aJob().withAwaitingRateLimiterState(rateLimiterName).build(),
                aJob().withAwaitingRateLimiterState(rateLimiterName).build(),
                aJob().withAwaitingRateLimiterState(rateLimiterName).build()
        ));

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withRateLimiter(rateLimiterName).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(3);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withRateLimiter("some-other-rate-limiter").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsAwaitingBatchJobAndAwaitingRateLimiter() {
        BatchJob batchJob = aBatchJobInProgress().build();
        Job waitingForBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).withRateLimiter("my-rate-limiter").build();
        storageProvider.save(asList(batchJob, waitingForBatchJob));

        List<Job> awaitingJobsOnOtherJobWithStateA = storageProvider.getAwaitingJobsOnOtherJobWithState(PROCESSED, AmountBasedList.ascOnUpdatedAt(10));
        assertThat(awaitingJobsOnOtherJobWithStateA).isEmpty();
        List<Job> awaitingJobsWithRateLimiterA = storageProvider.getJobList(aJobSearchRequest().withStateName(AWAITING).withRateLimiter("my-rate-limiter").build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10));
        assertThat(awaitingJobsWithRateLimiterA).isEmpty();

        batchJob.succeeded();
        storageProvider.save(batchJob);

        List<Job> awaitingJobsOnOtherJobWithStateB = storageProvider.getAwaitingJobsOnOtherJobWithState(PROCESSED, AmountBasedList.ascOnUpdatedAt(10));
        assertThat(awaitingJobsOnOtherJobWithStateB).hasSize(1);
        List<Job> awaitingJobsWithRateLimiterB = storageProvider.getJobList(aJobSearchRequest().withStateName(AWAITING).withRateLimiter("my-rate-limiter").build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10));
        assertThat(awaitingJobsWithRateLimiterB).isEmpty();

        awaitingJobsOnOtherJobWithStateB.forEach(job -> ((AwaitingState) job.getJobState()).moveToNextState(job));
        storageProvider.save(awaitingJobsOnOtherJobWithStateB);

        // WHY: we don't want jobs awaiting a previous job (e.g. batch job or other job)
        List<Job> awaitingJobsOnOtherJobWithStateC = storageProvider.getAwaitingJobsOnOtherJobWithState(PROCESSED, AmountBasedList.ascOnUpdatedAt(10));
        assertThat(awaitingJobsOnOtherJobWithStateC).hasSize(0);
        List<Job> awaitingJobsWithRateLimiterC = storageProvider.getJobList(aJobSearchRequest().withStateName(AWAITING).withRateLimiter("my-rate-limiter").build(), AmountBasedList.ascOnPriorityAndUpdatedAt(10));
        assertThat(awaitingJobsWithRateLimiterC).hasSize(1);
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnBatchJobOnlyRetrievesJobsAndBatchJobsWhenBatchJobOnlyIsNull() {
        BatchJob batchJob = anEnqueuedBatchJob().build();
        storageProvider.save(batchJob);

        Job anotherJob = aScheduledJob().build();
        storageProvider.save(anotherJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThatJobs(jobs).hasSize(2).containsExactly(batchJob, anotherJob);
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnScheduledAtCanBeSortedOnScheduledAt() {
        Job scheduledJob1 = aJob().withScheduledState(now().plusSeconds(20)).build();
        Job scheduledJob2 = aJob().withScheduledState(now().plusSeconds(15)).build();
        Job scheduledJob3 = aJob().withScheduledState(now().plusSeconds(10)).build();
        storageProvider.save(asList(scheduledJob1, scheduledJob2, scheduledJob3));

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withScheduledAt(now(), now().plusSeconds(20)).build(), OffsetBasedPage.ascOnScheduledAt(10));
        assertThat(jobs)
                .hasTotal(3)
                .containsExactly(scheduledJob3, scheduledJob2, scheduledJob1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withScheduledAt(now().minusSeconds(20), now().minusSeconds(5)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnCreatedAt() {
        Job enqueuedJob = aJob().withEnqueuedState(now()).build();
        storageProvider.save(enqueuedJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withCreatedAt(now().minusSeconds(10), now().plusSeconds(10)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withCreatedAt(now().minusSeconds(20), now().minusSeconds(10)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnUpdatedAt() {
        Job succeededJob = aJob().withEnqueuedState(now().minusSeconds(100)).withSucceededState(now().minusSeconds(5)).build();
        storageProvider.save(succeededJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withUpdatedAt(now().minusSeconds(10), now().plusSeconds(10)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withUpdatedAt(now().minusSeconds(20), now().minusSeconds(10)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnStateAndUpdatedAt() {
        Job succeededJob = aJob().withEnqueuedState(now().minusSeconds(100)).withSucceededState(now().minusSeconds(5)).build();
        storageProvider.save(succeededJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withStateName(SUCCEEDED).withUpdatedAt(now().minusSeconds(10), now().plusSeconds(10)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> notMatchingByState = storageProvider.getJobs(aJobSearchRequest().withStateName(PROCESSING).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(notMatchingByState).hasNoItems();

        final Page<Job> notMatchingByUpdatedAt = storageProvider.getJobs(aJobSearchRequest().withUpdatedAt(now().minusSeconds(40), now().minusSeconds(30)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(notMatchingByUpdatedAt).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnDeleteAt() {
        Instant deleteAt = now().minusSeconds(1);
        storageProvider.save(asList(
                anEnqueuedJobWithName().withDeleteAt(deleteAt).build(),
                aSucceededJob().build(),
                aSucceededJob().withDeleteAt(deleteAt).build(),
                aFailedJob().withDeleteAt(deleteAt).build())
        );

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withStateNames(SUCCEEDED, FAILED).withDeleteAtTo(deleteAt.plusMillis(100)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(2);

        final Page<Job> notMatchingByState = storageProvider.getJobs(aJobSearchRequest().withStateNames(PROCESSING).withDeleteAtTo(deleteAt.plusMillis(100)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(notMatchingByState).hasNoItems();

        final Page<Job> notMatchingByUpdatedAt = storageProvider.getJobs(aJobSearchRequest().withStateNames(SUCCEEDED, FAILED).withDeleteAtTo(deleteAt.minusMillis(100)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(notMatchingByUpdatedAt).hasNoItems();
    }

    @Test
    @Because("used in JobResultProvider")
    protected void testGetJobsBySearchRequestFilterOnJobIdAndStates() {
        Job scheduledJob = aSucceededJob().withName("Some job with a result").build();
        storageProvider.save(scheduledJob);

        final Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withStateNames(SUCCEEDED, FAILED, DELETED).withJobId(scheduledJob.getId()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs).hasItems(1);

        final Page<Job> jobsThatDontMatch = storageProvider.getJobs(aJobSearchRequest().withStateNames(SCHEDULED, ENQUEUED, PROCESSING).withJobId(scheduledJob.getId()).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetJobsBySearchRequestFilterOnBatch() {
        BatchJob batchJob = anEnqueuedBatchJob().build();
        storageProvider.save(batchJob);

        Job anotherJob = aScheduledJob().build();
        storageProvider.save(anotherJob);

        final Page<Job> allJobs = storageProvider.getJobs(aJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThatJobs(allJobs).hasSize(2).containsExactly(batchJob, anotherJob);

        final Page<Job> batchJobs = storageProvider.getJobs(aJobSearchRequest().withOnlyBatchJobs(true).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThatJobs(batchJobs).hasSize(1).containsExactly(batchJob);

        final Page<Job> otherJobs = storageProvider.getJobs(aJobSearchRequest().withOnlyBatchJobs(false).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThatJobs(otherJobs).hasSize(1).containsExactly(anotherJob);
    }

    @Test
    protected void longValuesDoNotCauseExceptionsWhenCreatingJobs() {
        Job job = anEnqueuedJobWithName()
                .withName("A very long display name".repeat(50))
                .withJobDetails(defaultJobDetails()
                        .withClassName("some.class.in.a.really.long.package.with.a.long.parameter.OneHellOfAJob")
                        .withMethodName("someMethodName")
                        .withJobParameter("A very long paramater. ".repeat(50))
                )
                .build();
        assertThatCode(() -> storageProvider.save(job)).doesNotThrowAnyException();
    }

    @Test
    void testGetJobsToProcessReturnsJobInProcessingStateAndCallFilters() {
        // GIVEN
        Job scheduledJob = aScheduledJob().build();
        Job enqueuedJob1 = aJob().withEnqueuedState(now().minusSeconds(20)).build();
        Job enqueuedJob2 = aJob().withEnqueuedState(now().minusSeconds(15)).build();
        Job enqueuedJob3 = aJob().withEnqueuedState(now().minusSeconds(10)).build();
        Job enqueuedJob4 = aJob().withEnqueuedState(now().minusSeconds(5)).build();
        Job jobInProgress = aJobInProgress().build();
        Job succeededJob = aSucceededJob().build();
        Job failedJob = aFailedJob().build();
        Job deletedJob = aDeletedJob().build();
        storageProvider.save(asList(scheduledJob, enqueuedJob1, enqueuedJob2, enqueuedJob3, enqueuedJob4, jobInProgress, succeededJob, failedJob, deletedJob));

        LogAllStateChangesFilter logAllStateChangesFilter = new LogAllStateChangesFilter();
        backgroundJobServer.setJobFilters(asList(logAllStateChangesFilter));

        // WHEN
        List<Job> jobsToProcess1 = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(3));

        // THEN
        assertThatJobs(jobsToProcess1)
                .hasSize(3)
                .allMatch(job -> job.hasState(PROCESSING))
                .extracting("id")
                .contains(enqueuedJob1.getId(), enqueuedJob2.getId(), enqueuedJob3.getId());
        assertThat(logAllStateChangesFilter.getAllStateChanges()).containsOnly("ENQUEUED->PROCESSING");

        // WHEN
        List<Job> jobsToProcess2 = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(3));

        // THEN
        assertThatJobs(jobsToProcess2)
                .hasSize(1)
                .allMatch(job -> job.hasState(PROCESSING))
                .containsExactlyComparingById(enqueuedJob4);
        assertThat(logAllStateChangesFilter.getAllStateChanges()).containsOnly("ENQUEUED->PROCESSING");
    }

    @Test
    void testGetJobsToProcessTakesStateElectionFiltersIntoAccount() {
        // GIVEN
        Job scheduledJob = aScheduledJob().build();
        Job enqueuedJob1 = aJob().withEnqueuedState(now().minusSeconds(20)).build();
        Job enqueuedJob2 = aJob().withJobDetails(TestService::tryToDoWorkButDontBecauseOfSomeBusinessRuleDefinedInTheOnStateElectionFilter).withEnqueuedState(now().minusSeconds(15)).build();
        Job enqueuedJob3 = aJob().withEnqueuedState(now().minusSeconds(10)).build();
        Job enqueuedJob4 = aJob().withEnqueuedState(now().minusSeconds(5)).build();
        Job jobInProgress = aJobInProgress().build();
        Job succeededJob = aSucceededJob().build();
        Job failedJob = aFailedJob().build();
        Job deletedJob = aDeletedJob().build();
        storageProvider.save(asList(scheduledJob, enqueuedJob1, enqueuedJob2, enqueuedJob3, enqueuedJob4, jobInProgress, succeededJob, failedJob, deletedJob));

        LogAllStateChangesFilter logAllStateChangesFilter = new LogAllStateChangesFilter();
        backgroundJobServer.setJobFilters(asList(logAllStateChangesFilter));

        // WHEN
        List<Job> jobsToProcess = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(3));

        // THEN
        assertThatJobs(jobsToProcess)
                .hasSize(2)
                .allMatch(job -> job.hasState(PROCESSING))
                .extracting("id")
                .contains(enqueuedJob1.getId(), enqueuedJob3.getId());
        assertThat(logAllStateChangesFilter.getStateChanges(enqueuedJob1))
                .containsOnly("ENQUEUED->PROCESSING");
        assertThat(logAllStateChangesFilter.getStateChanges(enqueuedJob2))
                .containsOnly("ENQUEUED->PROCESSING", "PROCESSING->DELETED", "DELETED->SCHEDULED");
        assertThat(logAllStateChangesFilter.getStateChanges(enqueuedJob3))
                .containsOnly("ENQUEUED->PROCESSING");
    }

    @Test
    void testGetJobsToProcessOnExceptionReturnsJobInProcessingStateAndCallFilters() {
        // GIVEN
        UUID backgroundJobServerId = UUID.randomUUID();
        Job scheduledJob = aScheduledJob().build();
        Job enqueuedJob1 = aJob().withEnqueuedState(now().minusSeconds(20)).build();
        Job enqueuedJob2 = aJob().withEnqueuedState(now().minusSeconds(15)).build();
        Job enqueuedJob3 = aJob().withEnqueuedState(now().minusSeconds(10)).build();
        Job enqueuedJob4 = aJob().withEnqueuedState(now().minusSeconds(5)).build();
        Job jobInProgress = aJobInProgress().build();
        Job succeededJob = aSucceededJob().build();
        Job failedJob = aFailedJob().build();
        Job deletedJob = aDeletedJob().build();
        storageProvider.save(asList(scheduledJob, enqueuedJob1, enqueuedJob2, enqueuedJob3, enqueuedJob4, jobInProgress, succeededJob, failedJob, deletedJob));

        LogAllStateChangesFilter logAllStateChangesFilter = new LogAllStateChangesFilter();
        backgroundJobServer.setJobFilters(asList(logAllStateChangesFilter));
        // simulate concurrent JobModification Exception
        when(backgroundJobServerConfiguration.getId())
                .thenReturn(backgroundJobServerId)
                .thenReturn(backgroundJobServerId)
                .thenThrow(new ConcurrentJobModificationException(enqueuedJob3));

        // WHEN
        List<Job> jobsToProcess = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(3));

        // THEN
        assertThatJobs(jobsToProcess)
                .hasSize(2)
                .allMatch(job -> job.hasState(PROCESSING))
                .extracting("id")
                .contains(enqueuedJob1.getId(), enqueuedJob2.getId());
        assertThat(logAllStateChangesFilter.getAllStateChanges()).containsOnly("ENQUEUED->PROCESSING");
    }

    @Test
    protected void getJobsToProcessAreOrderedOnPriorityUpdatedAt() {
        final List<Job> jobs = asList(
                aJob().withName("included 2").withPriority(4).withEnqueuedState(now().minus(10, SECONDS)).withServerTag("LINUX").build(),
                aJob().withName("excluded due to server tag").withPriority(4).withEnqueuedState(now().minus(9, SECONDS)).withServerTag("WINDOWS").build(),
                aJob().withName("excluded due to server tag").withPriority(0).withEnqueuedState(now().minus(8, SECONDS)).withServerTag("MACOS").build(),
                aJob().withName("included 0").withPriority(0).withEnqueuedState(now().minus(7, SECONDS)).withServerTag("DEFAULT").build(),
                aJob().withName("included 1").withPriority(0).withEnqueuedState(now().minus(6, SECONDS)).withoutServerTag().build()
        );
        final List<Job> savedJobs = storageProvider.save(jobs);

        final List<Job> actualJobs = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(actualJobs)
                .hasSize(3)
                .containsExactlyComparingById(savedJobs.get(3), savedJobs.get(4), savedJobs.get(0));
        assertThat(storageProvider.countJobs(new JobSearchRequest(PROCESSING))).isEqualTo(3);
        assertThat(storageProvider.countJobs(new JobSearchRequest(ENQUEUED))).isEqualTo(2);
    }

    @Test
    protected void getJobsToProcessTakesMutexIntoAccount() {
        final List<Job> savedJobs = storageProvider.save(asList(
                aJobInProgress().withMutex("resource-0").build(),
                aJobInProgress().withMutex("resource-a").build(),
                aJob().withEnqueuedState(now().minus(10, SECONDS)).withMutex("resource-a").build(),
                aJob().withEnqueuedState(now().minus(9, SECONDS)).withMutex("resource-a").build(),
                aJob().withEnqueuedState(now().minus(8, SECONDS)).withMutex("resource-a").build(),
                aJob().withEnqueuedState(now().minus(7, SECONDS)).withMutex("resource-b").build(),
                aJob().withEnqueuedState(now().minus(6, SECONDS)).withMutex("resource-b").build(),
                aJob().withEnqueuedState(now().minus(5, SECONDS)).withMutex("resource-c").build(),
                aJob().withEnqueuedState(now().minus(4, SECONDS)).withoutMutex().build(),
                aJob().withEnqueuedState(now().minus(3, SECONDS)).withoutMutex().build()
        ));

        storageProvider.save(singletonList(savedJobs.get(0).succeeded()));

        final List<Job> jobsToEnqueue = storageProvider.getJobsToProcess(backgroundJobServer, null, AmountBasedList.ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueue)
                .hasSize(4)
                .containsExactlyComparingById(savedJobs.get(5), savedJobs.get(7), savedJobs.get(8), savedJobs.get(9));
    }

    @Test
    protected void getJobsToProcessTakesQueuesAndMutexesIntoAccount() {
        final List<Job> jobs = asList(
                aJobInProgress().withName("excluded, already in progress").withMutex("resource-a").withPriority(1).build(),
                aJob().withName("excluded, mutex already in use").withEnqueuedState(now().minus(10, SECONDS)).withMutex("resource-a").build(),
                aJob().withName("excluded, mutex already selected by high prio").withEnqueuedState(now().minus(9, SECONDS)).withPriority(2).withMutex("resource-b").build(),
                aJob().withName("included, 1").withEnqueuedState(now().minus(8, SECONDS)).withPriority(1).withMutex("resource-b").build(),
                aJob().withName("excluded, mutex already selected by high prio").withEnqueuedState(now().minus(7, SECONDS)).withPriority(2).withMutex("resource-c").build(),
                aJob().withName("included, 2").withEnqueuedState(now().minus(6, SECONDS)).withPriority(1).withMutex("resource-c").build(),
                aJob().withName("included, 5").withEnqueuedState(now().minus(4, SECONDS)).withPriority(2).withMutex("resource-d").build(),
                aJob().withName("included, 4").withEnqueuedState(now().minus(5, SECONDS)).withPriority(2).withoutMutex().build(),
                aJob().withName("included, 3").withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build()
        );
        final List<Job> savedJobs = storageProvider.save(jobs);

        final List<Job> jobsToEnqueue = storageProvider.getJobsToProcess(backgroundJobServer, null, ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueue)
                .hasSize(5)
                .containsExactlyComparingById(savedJobs.get(3), savedJobs.get(5), savedJobs.get(8), savedJobs.get(7), savedJobs.get(6));
    }

    @Test
    protected void getJobsToProcessTakesDynamicQueuesPriorityQueuesAndMutexesIntoAccount() {
        final List<Job> jobs = asList(
                aJobInProgress().withName("excluded, already in progress").withDynamicQueue("tenant-a").withMutex("resource-a").withPriority(1).build(),
                aJob().withName("excluded, mutex already in use").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(10, SECONDS)).withMutex("resource-a").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(9, SECONDS)).withPriority(2).withMutex("resource-b").build(),
                aJob().withName("included, tenant-a, 1").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(8, SECONDS)).withPriority(1).withMutex("resource-b").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(7, SECONDS)).withPriority(2).withMutex("resource-c").build(),
                aJob().withName("included, tenant-b, 1").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(6, SECONDS)).withPriority(1).withMutex("resource-c").build(),
                aJob().withName("included, tenant-a, 3").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(4, SECONDS)).withPriority(2).withMutex("resource-d").build(),
                aJob().withName("included, tenant-a, 2").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(5, SECONDS)).withPriority(2).withoutMutex().build(),
                aJob().withName("included, tenant-b, 2").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build(),
                aJob().withName("included, tenant-less").withoutDynamicQueue().withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build()
        );
        final List<Job> savedJobs = storageProvider.save(jobs);

        Set<String> dynamicQueues = storageProvider.getDistinctDynamicQueues();
        assertThat(dynamicQueues)
                .hasSize(3)
                .contains("tenant-a", "tenant-b", null);

        final List<Job> jobsToEnqueueForTenantA = storageProvider.getJobsToProcess(backgroundJobServer, Optional.of("tenant-a"), ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueueForTenantA)
                .hasSize(3)
                .containsExactlyComparingById(savedJobs.get(3), savedJobs.get(7), savedJobs.get(6));

        final List<Job> jobsToEnqueueForTenantB = storageProvider.getJobsToProcess(backgroundJobServer, Optional.of("tenant-b"), ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueueForTenantB)
                .hasSize(2)
                .containsExactlyComparingById(savedJobs.get(5), savedJobs.get(8));

        final List<Job> jobsToEnqueueWithoutTenant = storageProvider.getJobsToProcess(backgroundJobServer, Optional.empty(), ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueueWithoutTenant)
                .hasSize(1)
                .containsExactlyComparingById(savedJobs.get(9));
    }

    @Test
    protected void getJobsToProcessOmitsDynamicQueuesIfNotRequestedButTakesPriorityQueuesAndMutexesIntoAccount() {
        final List<Job> jobs = asList(
                aJobInProgress().withName("excluded, already in progress").withDynamicQueue("tenant-a").withMutex("resource-a").withPriority(1).build(),
                aJob().withName("excluded, mutex already in use").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(10, SECONDS)).withMutex("resource-a").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(9, SECONDS)).withPriority(2).withMutex("resource-b").build(),
                aJob().withName("included, tenant-a, 1").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(8, SECONDS)).withPriority(1).withMutex("resource-b").build(),
                aJob().withName("excluded, mutex already selected by high prio").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(7, SECONDS)).withPriority(2).withMutex("resource-c").build(),
                aJob().withName("included, tenant-b, 1").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(6, SECONDS)).withPriority(1).withMutex("resource-c").build(),
                aJob().withName("included, tenant-a, 3").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(4, SECONDS)).withPriority(2).withMutex("resource-d").build(),
                aJob().withName("included, tenant-a, 2").withDynamicQueue("tenant-a").withEnqueuedState(now().minus(5, SECONDS)).withPriority(2).withoutMutex().build(),
                aJob().withName("included, tenant-b, 2").withDynamicQueue("tenant-b").withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build(),
                aJob().withName("included, tenant-less").withoutDynamicQueue().withEnqueuedState(now().minus(3, SECONDS)).withPriority(1).withoutMutex().build()
        );
        final List<Job> savedJobs = storageProvider.save(jobs);

        final List<Job> jobsToEnqueueWithoutFiltering = storageProvider.getJobsToProcess(backgroundJobServer, null, ascOnPriorityAndUpdatedAt(100));
        assertThatJobs(jobsToEnqueueWithoutFiltering)
                .hasSize(6)
                .containsExactlyComparingById(savedJobs.get(3), savedJobs.get(5), savedJobs.get(8), savedJobs.get(9), savedJobs.get(7), savedJobs.get(6));
    }

    @Test
    void saveJobThrowsMutexInUseException() {
        Job job1 = anEnqueuedJobWithName().withMutex("mutex").build();
        Job job2 = anEnqueuedJobWithName().withMutex("mutex").build();
        storageProvider.save(job1);
        storageProvider.save(job2);

        job1.startProcessingOn(backgroundJobServer);
        storageProvider.save(job1);

        job2.startProcessingOn(backgroundJobServer);
        assertThatThrownBy(() -> storageProvider.save(job2)).isInstanceOf(MutexInUseException.class);
    }

    @Test
    void saveJobsThrowsMutexInUseException() {
        Job job1 = anEnqueuedJobWithName().withMutex("mutex").build();
        Job job2 = anEnqueuedJobWithName().withMutex("mutex").build();
        storageProvider.save(job1);
        storageProvider.save(job2);

        job1.startProcessingOn(backgroundJobServer);
        storageProvider.save(asList(job1));

        job2.startProcessingOn(backgroundJobServer);
        assertThatThrownBy(() -> storageProvider.save(asList(job2))).isInstanceOf(MutexInUseException.class);
    }

    @Test
    void jobsWithSameMutexCannotBeProcessedSimultaneouslyAndMutexesAreReleased() {
        // GIVEN
        Job job1 = anEnqueuedJobWithName().withMutex("mutex").build();
        Job job2 = anEnqueuedJobWithName().withMutex("mutex").build();
        Job createdJob1 = storageProvider.save(job1);
        Job createdJob2 = storageProvider.save(job2);

        // WHEN
        createdJob1.startProcessingOn(backgroundJobServer);
        storageProvider.save(createdJob1);

        // THEN MutexInUseException
        createdJob2.startProcessingOn(backgroundJobServer);
        assertThatThrownBy(() -> storageProvider.save(createdJob2)).isInstanceOf(MutexInUseException.class);
        assertThatThrownBy(() -> storageProvider.save(asList(createdJob2))).isInstanceOf(MutexInUseException.class);

        // WHEN
        createdJob1.succeeded();
        storageProvider.save(createdJob1);

        // THEN No MutexInUseException
        Job createdJob2FromDB = storageProvider.getJobById(createdJob2.getId());
        createdJob2FromDB.startProcessingOn(backgroundJobServer);
        Job processingJob2 = storageProvider.save(createdJob2FromDB);

        // WHEN
        processingJob2.succeeded();

        // THEN
        assertThatCode(() -> storageProvider.save(processingJob2)).doesNotThrowAnyException();
    }

    @Test
    void jobsToProcessTakesIntoAccountMutex() {
        // GIVEN
        UUID backgroundJobServerId = UUID.randomUUID();
        Job job1 = anEnqueuedJob().withName("job 1").withMutex("mutex-1").build();
        Job job2 = anEnqueuedJob().withName("job 2").withMutex("mutex-1").build();
        Job job3 = anEnqueuedJob().withName("job 3").withoutMutex().build();
        Job job4 = anEnqueuedJob().withName("job 4").withMutex("mutex-2").build();
        Job job5 = anEnqueuedJob().withName("job 5").withMutex("mutex-3").build();
        storageProvider.save(asList(job1, job2, job3, job4, job5));

        // simulate MutexInUseException by another server for mutex-1 and mutex-3
        when(backgroundJobServerConfiguration.getId())
                .thenReturn(backgroundJobServerId)
                .thenReturn(backgroundJobServerId)
                .thenReturn(backgroundJobServerId)
                .thenThrow(new MutexInUseException(asList(job1, job5)));

        // WHEN
        List<Job> jobsToProcess = storageProvider.getJobsToProcess(backgroundJobServer, null, ascOnPriorityAndUpdatedAt(100));

        // THEN
        assertThatJobs(jobsToProcess)
                .hasSize(2)
                .containsExactlyComparingById(job3, job4);
    }

    @Test
    protected void testGetJobsCanPageRespectingQueuePriorityUsingOffsetBasedPageRequest() {
        final List<Job> jobs = asList(
                aJob().withPriority(2).withEnqueuedState(now().minusSeconds(10)).build(),
                aJob().withPriority(2).withEnqueuedState(now().minusSeconds(8)).build(),
                aJob().withPriority(2).withEnqueuedState(now().minusSeconds(6)).build(),
                aJob().withPriority(1).withEnqueuedState(now().minusSeconds(4)).build(),
                aJob().withPriority(2).withEnqueuedState(now().minusSeconds(2)).build()
        );

        storageProvider.save(jobs);

        Page<Job> fetchedJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(2, 2));

        assertThat(fetchedJobs)
                .hasItems(2)
                .containsExactly(jobs.get(1), jobs.get(2));
    }

    @Test
    protected void testGetJobPageCanPageRespectingQueuePriorityUsingCursorBasedPageRequest() {
        final List<Job> jobs = asList(
                aJob().withPriority(2).withName("job 0").withEnqueuedState(now().minusSeconds(10)).build(),
                aJob().withPriority(2).withName("job 1").withEnqueuedState(now().minusSeconds(8)).build(),
                aJob().withPriority(2).withName("job 2").withEnqueuedState(now().minusSeconds(6)).build(),
                aJob().withPriority(1).withName("job 3").withEnqueuedState(now().minusSeconds(4)).build(),
                aJob().withPriority(2).withName("job 4").withEnqueuedState(now().minusSeconds(2)).build()
        );

        storageProvider.save(jobs);
        Page<Job> fetchedJobs1 = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.ascOnPriorityAndUpdatedAt(2));
        Page<Job> fetchedJobs2 = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.next(fetchedJobs1));

        assertThatJobs(fetchedJobs2.getItems())
                .hasSize(2)
                .containsExactly(jobs.get(1), jobs.get(2));
    }

    @Test
    protected void testGetJobPageCanBeSortedAndPagedOnNameAndUpdatedAtUsingOffsetBasedPageRequest() {
        // GIVEN
        final List<Job> jobs = asList(
                aJob().withPriority(2).withName("prio 2, minus 10 sec B").withEnqueuedState(now().minusSeconds(10)).build(),
                aJob().withPriority(1).withName("prio 1, minus 8 sec").withEnqueuedState(now().minusSeconds(8)).build(),
                aJob().withPriority(1).withName("prio 1, minus 6 sec").withEnqueuedState(now().minusSeconds(6)).build(),
                aJob().withPriority(1).withName("prio 1, minus 4 sec").withEnqueuedState(now().minusSeconds(4)).build(),
                aJob().withPriority(2).withName("prio 2, minus 10 sec A").withEnqueuedState(now().minusSeconds(2)).build()
        );

        storageProvider.save(jobs);

        // WHEN sorted jobName:ASC
        Page<Job> fetchedJobsPage1AscOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), OffsetBasedPage.ascOnName(3));
        assertThat(fetchedJobsPage1AscOnJobName)
                .hasTotal(5)
                .hasItems(3)
                .containsExactly(jobs.get(3), jobs.get(2), jobs.get(1));

        Page<Job> fetchedJobsPage2AscOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), OffsetBasedPage.next(fetchedJobsPage1AscOnJobName));
        assertThat(fetchedJobsPage2AscOnJobName)
                .hasTotal(5)
                .hasItems(2)
                .containsExactly(jobs.get(4), jobs.get(0));

        // WHEN sorted jobName:DESC
        Page<Job> fetchedJobsPage1DescOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), OffsetBasedPage.descOnName(3));
        assertThat(fetchedJobsPage1DescOnJobName)
                .hasTotal(5)
                .hasItems(3)
                .containsExactly(jobs.get(0), jobs.get(4), jobs.get(1));

        Page<Job> fetchedJobsPage2DescOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), OffsetBasedPage.next(fetchedJobsPage1DescOnJobName));
        assertThat(fetchedJobsPage2DescOnJobName)
                .hasTotal(5)
                .hasItems(2)
                .containsExactly(jobs.get(2), jobs.get(3));

        // WHEN sorted updatedAt:ASC
        Page<Job> fetchedJobsAscOnPriorityAndAscOnCreated = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), ascOnPriorityAndUpdatedAt(50));
        assertThat(fetchedJobsAscOnPriorityAndAscOnCreated)
                .hasTotal(5)
                .containsExactly(jobs.get(1), jobs.get(2), jobs.get(3), jobs.get(0), jobs.get(4));

        // WHEN sorted updatedAt:DESC
        Page<Job> fetchedJobsDescOnUpdatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), OffsetBasedPage.descOnUpdatedAt(50));
        assertThat(fetchedJobsDescOnUpdatedAt)
                .hasTotal(5)
                .containsExactly(jobs.get(4), jobs.get(3), jobs.get(2), jobs.get(1), jobs.get(0));
    }

    @Test
    protected void testGetJobPageCanBeSortedAndPagedOnNameAndUpdatedAtUsingCursorBasedPageRequest() {
        // GIVEN
        final List<Job> jobs = asList(
                aJob().withPriority(2).withName("prio 2, minus 10 sec B").withEnqueuedState(now().minusSeconds(10)).build(),
                aJob().withPriority(1).withName("prio 1, minus 8 sec").withEnqueuedState(now().minusSeconds(8)).build(),
                aJob().withPriority(1).withName("prio 1, minus 6 sec").withEnqueuedState(now().minusSeconds(6)).build(),
                aJob().withPriority(1).withName("prio 1, minus 4 sec").withEnqueuedState(now().minusSeconds(4)).build(),
                aJob().withPriority(2).withName("prio 2, minus 10 sec A").withEnqueuedState(now().minusSeconds(2)).build()
        );

        storageProvider.save(jobs);

        // WHEN sorted jobName:ASC
        Page<Job> fetchedJobsPage1AscOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.ascOnName(3));
        assertThat(fetchedJobsPage1AscOnJobName)
                .hasTotal(5)
                .hasItems(3)
                .containsExactly(jobs.get(3), jobs.get(2), jobs.get(1));

        Page<Job> fetchedJobsPage2AscOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.next(fetchedJobsPage1AscOnJobName));
        assertThat(fetchedJobsPage2AscOnJobName)
                .hasTotal(5)
                .hasItems(2)
                .containsExactly(jobs.get(4), jobs.get(0));

        // WHEN sorted jobName:DESC
        Page<Job> fetchedJobsPage1DescOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.descOnName(3));
        assertThat(fetchedJobsPage1DescOnJobName)
                .hasTotal(5)
                .hasItems(3)
                .containsExactly(jobs.get(0), jobs.get(4), jobs.get(1));

        Page<Job> fetchedJobsPage2DescOnJobName = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.next(fetchedJobsPage1DescOnJobName));
        assertThat(fetchedJobsPage2DescOnJobName)
                .hasTotal(5)
                .hasItems(2)
                .containsExactly(jobs.get(2), jobs.get(3));

        // WHEN sorted updatedAt:ASC
        Page<Job> fetchedJobsAscOnPriorityAndAscOnCreated = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.ascOnPriorityAndUpdatedAt(50));
        assertThat(fetchedJobsAscOnPriorityAndAscOnCreated)
                .hasTotal(5)
                .containsExactly(jobs.get(1), jobs.get(2), jobs.get(3), jobs.get(0), jobs.get(4));

        // WHEN sorted updatedAt:DESC
        Page<Job> fetchedJobsDescOnUpdatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED), Paging.CursorBasedPage.descOnUpdatedAt(50));
        assertThat(fetchedJobsDescOnUpdatedAt)
                .hasTotal(5)
                .containsExactly(jobs.get(4), jobs.get(3), jobs.get(2), jobs.get(1), jobs.get(0));
    }

    @Test
    protected void testJobPageFiltersByQueueAndCanBeSortedUsingOffsetBasedPageRequest() {
        final List<Job> jobs = asList(
                aJob().withEnqueuedState(now().minusSeconds(10)).withPriority(3).build(),
                aJob().withEnqueuedState(now().minusSeconds(8)).withPriority(3).build(),
                aJob().withEnqueuedState(now().minusSeconds(6)).withPriority(1).build(),
                aJob().withEnqueuedState(now().minusSeconds(4)).withPriority(2).build(),
                aJob().withEnqueuedState(now().minusSeconds(2)).withPriority(1).build()
        );

        storageProvider.save(jobs);

        Page<Job> fetchedJobsPrio1SortedAscOnCreatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 1), ascOnPriorityAndUpdatedAt(10));
        assertThat(fetchedJobsPrio1SortedAscOnCreatedAt)
                .hasTotal(2)
                .containsExactly(jobs.get(2), jobs.get(4));

        Page<Job> fetchedJobsPrio1SortedDescOnUpdatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 1), OffsetBasedPage.descOnUpdatedAt(10));
        assertThat(fetchedJobsPrio1SortedDescOnUpdatedAt)
                .hasTotal(2)
                .containsExactly(jobs.get(4), jobs.get(2));

        Page<Job> fetchedJobsPrio2SortedAscOnCreatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 2), ascOnPriorityAndUpdatedAt(10));
        assertThat(fetchedJobsPrio2SortedAscOnCreatedAt)
                .hasTotal(1)
                .containsExactly(jobs.get(3));

        Page<Job> fetchedJobsPrio3SortedAscOnCreatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 3), ascOnPriorityAndUpdatedAt(10));
        assertThat(fetchedJobsPrio3SortedAscOnCreatedAt)
                .hasTotal(2)
                .containsExactly(jobs.get(0), jobs.get(1));

        Page<Job> fetchedJobsPrio3SortedDescOnUpdatedAt = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 3), OffsetBasedPage.descOnUpdatedAt(10));
        assertThat(fetchedJobsPrio3SortedDescOnUpdatedAt)
                .hasTotal(2)
                .containsExactly(jobs.get(1), jobs.get(0));
    }

    @Test
    protected void testGetJobPageFiltersByQueueAndCanBeSortedUsingCursorBasedPageRequest() {
        final List<Job> jobs = asList(
                aJob().withEnqueuedState(now().minusSeconds(10)).withPriority(3).build(),
                aJob().withEnqueuedState(now().minusSeconds(8)).withPriority(3).build(),
                aJob().withEnqueuedState(now().minusSeconds(6)).withPriority(1).build(),
                aJob().withEnqueuedState(now().minusSeconds(4)).withPriority(2).build(),
                aJob().withEnqueuedState(now().minusSeconds(2)).withPriority(1).build()
        );

        storageProvider.save(jobs);

        Page<Job> p1AscJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 1), Paging.CursorBasedPage.ascOnPriorityAndUpdatedAt(10));
        assertThat(p1AscJobs.getTotal()).isEqualTo(2);
        assertThat(p1AscJobs.hasNextPage()).isFalse();
        assertThatJobs(p1AscJobs.getItems())
                .hasSize(2)
                .containsExactly(jobs.get(2), jobs.get(4));

        Page<Job> p1DescJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 1), Paging.CursorBasedPage.descOnUpdatedAt(10));
        assertThat(p1DescJobs.getTotal()).isEqualTo(2);
        assertThat(p1DescJobs.hasNextPage()).isFalse();
        assertThatJobs(p1DescJobs.getItems())
                .hasSize(2)
                .containsExactly(jobs.get(4), jobs.get(2));

        Page<Job> p2AscJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 2), Paging.CursorBasedPage.ascOnCreatedAt(10));
        assertThat(p2AscJobs.getTotal()).isEqualTo(1);
        assertThat(p2AscJobs.hasNextPage()).isFalse();
        assertThatJobs(p2AscJobs.getItems())
                .hasSize(1)
                .containsExactly(jobs.get(3));

        Page<Job> p3AscJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 3), Paging.CursorBasedPage.ascOnPriorityAndUpdatedAt(10));
        assertThat(p3AscJobs.getTotal()).isEqualTo(2);
        assertThat(p3AscJobs.hasNextPage()).isFalse();
        assertThatJobs(p3AscJobs.getItems())
                .hasSize(2)
                .containsExactly(jobs.get(0), jobs.get(1));

        Page<Job> p3DescJobs = storageProvider.getJobs(new JobSearchRequest(ENQUEUED, 3), Paging.CursorBasedPage.descOnUpdatedAt(10));
        assertThat(p3DescJobs.getTotal()).isEqualTo(2);
        assertThat(p3DescJobs.hasNextPage()).isFalse();
        assertThatJobs(p3DescJobs.getItems())
                .hasSize(2)
                .containsExactly(jobs.get(1), jobs.get(0));
    }

    @Test
    protected void testGetListOfJobsUpdatedBefore() {
        final List<Job> jobs = asList(
                aJob().withEnqueuedState(now().minus(24, HOURS)).build(),
                aJob().withEnqueuedState(now().minus(12, HOURS)).build(),
                aJob().withEnqueuedState(now().minus(2, HOURS)).build(),
                aJob().withEnqueuedState(now()).build()
        );
        storageProvider.save(jobs);

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(ENQUEUED, now().minus(3, HOURS)), AmountBasedList.ascOnUpdatedAt(100)))
                .hasSize(2)
                .containsExactly(jobs.get(0), jobs.get(1));

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(ENQUEUED, now().minus(1, HOURS)), AmountBasedList.ascOnUpdatedAt(100)))
                .hasSize(3)
                .containsExactly(jobs.get(0), jobs.get(1), jobs.get(2));

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(ENQUEUED, now().minus(1, HOURS)), AmountBasedList.descOnUpdatedAt(100)))
                .hasSize(3)
                .containsExactly(jobs.get(2), jobs.get(1), jobs.get(0));

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(PROCESSING, now().minus(1, HOURS)), AmountBasedList.ascOnUpdatedAt(100)))
                .isEmpty();
    }

    @Test
    protected void testDeleteJobs() {
        final List<Job> jobs = asList(
                anEnqueuedJobWithName().withDeleteAt(now().minus(4, HOURS)).build(),
                anEnqueuedJobWithName().withDeleteAt(now().minus(3, HOURS)).build(),
                anEnqueuedJobWithName().withDeleteAt(now().minus(2, HOURS)).build(),
                anEnqueuedJobWithName().withDeleteAt(now()).build()
        );

        storageProvider.save(jobs);

        storageProvider.deleteJobsPermanently(aJobSearchRequest(ENQUEUED).withDeleteAtTo(now().minus(1, HOURS)).build());

        List<Job> fetchedJobs = storageProvider.getJobList(new JobSearchRequest(ENQUEUED), AmountBasedList.ascOnPriorityAndUpdatedAt(100));

        assertThat(fetchedJobs).hasSize(1);
    }

    @Test
    protected void testScheduledJobsCanBeSortedByScheduledAtAsc() {
        Job job1 = anEnqueuedJobWithName().withState(new ScheduledState(now().minusSeconds(3))).build();
        Job job2 = anEnqueuedJobWithName().withState(new ScheduledState(now())).build();
        Job job3 = anEnqueuedJobWithName().withState(new ScheduledState(now().plus(20, HOURS))).build();

        storageProvider.save(asList(job1, job2, job3));

        assertThatJobs(storageProvider.getJobList(aJobSearchRequest().withScheduledAtTo(now()).build(), OffsetBasedPage.ascOnScheduledAt(1000)))
                .hasSize(2)
                .containsExactly(job1, job2);
    }

    @Test
    void testGetRecurringJobIdsOfJobsWithState() {
        JobDetails jobDetails = defaultJobDetails().build();
        RecurringJob recurringJob1 = aDefaultRecurringJob().withId("id1").withJobDetails(jobDetails).build();
        RecurringJob recurringJob2 = aDefaultRecurringJob().withId("id2").withJobDetails(jobDetails).build();
        Job enqueuedJob1 = recurringJob1.toEnqueuedJob("For testing");
        Job scheduledJob1 = recurringJob1.toScheduledJob();
        Job scheduledJob2 = recurringJob2.toScheduledJob();
        Job anEnqueuedJobThatIsNotComingFromARecurringJob = anEnqueuedJobWithName().build();

        storageProvider.save(enqueuedJob1);
        storageProvider.save(scheduledJob1);
        storageProvider.save(scheduledJob2);
        storageProvider.save(anEnqueuedJobThatIsNotComingFromARecurringJob);

        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED)).containsOnly("id1", "id1", "id2");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(ENQUEUED)).containsOnly("id1");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED)).containsOnly("id1", "id2");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(PROCESSING, SUCCEEDED)).isEmpty();

        scheduledJob1.enqueue();
        storageProvider.save(scheduledJob1);
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED)).containsOnly("id1", "id1", "id2");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED)).containsOnly("id2");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(ENQUEUED)).containsOnly("id1", "id1");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(PROCESSING, SUCCEEDED)).isEmpty();

        scheduledJob1.delete("For test");
        storageProvider.save(scheduledJob1);
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED, PROCESSING, SUCCEEDED)).containsOnly("id2");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(ENQUEUED)).containsOnly("id1");
        assertThat(storageProvider.getRecurringJobIdsOfJobsWithState(DELETED)).containsOnly("id1");
    }

    @Test
    protected void getAwaitingJobsThatCanBeEnqueued() {
        // GIVEN
        final Job enqueuedJob1 = storageProvider.save(anEnqueuedJobWithName().build());
        final Job enqueuedJob2 = storageProvider.save(anEnqueuedJobWithName().build());
        final Job enqueuedJob3 = storageProvider.save(aJobInProgress().build());
        final Job enqueuedJob4 = storageProvider.save(aJobInProgress().build());
        final Job enqueuedJob5 = storageProvider.save(aJobInProgress().build());
        final Job job1WaitingForEnqueuedJob1 = aJob().withState(new AwaitingState(enqueuedJob1.getId())).build();
        final Job job2WaitingForEnqueuedJob1 = aJob().withState(new AwaitingState(enqueuedJob1.getId())).build();
        final Job job3WaitingForEnqueuedJob2 = aJob().withState(new AwaitingState(enqueuedJob2.getId())).build();
        final Job job4WaitingForSucceededJob4 = aJob().withState(new AwaitingState(enqueuedJob4.getId())).build();
        final Job job5WaitingForSucceededJob4 = aJob().withState(new AwaitingState(enqueuedJob4.getId())).build();
        final Job job6WaitingForSucceededJob5 = aJob().withState(new AwaitingState(enqueuedJob5.getId())).build();
        storageProvider.save(asList(
                job1WaitingForEnqueuedJob1, job2WaitingForEnqueuedJob1, job3WaitingForEnqueuedJob2,
                job4WaitingForSucceededJob4, job5WaitingForSucceededJob4, job6WaitingForSucceededJob5
        ));

        // THEN
        assertThatJobs(storageProvider.getAwaitingJobsOnOtherJobWithState(SUCCEEDED, AmountBasedList.ascOnUpdatedAt(1000))).isEmpty();

        // WHEN
        asList(enqueuedJob4, enqueuedJob5).forEach(job -> {
            job.succeeded();
            storageProvider.save(job);
        });

        // THEN
        assertThatJobs(storageProvider.getAwaitingJobsOnOtherJobWithState(SUCCEEDED, AmountBasedList.ascOnUpdatedAt(1000)))
                .hasSize(3)
                .contains(job4WaitingForSucceededJob4, job5WaitingForSucceededJob4, job6WaitingForSucceededJob5)
                .doesNotContain(enqueuedJob1, enqueuedJob2, enqueuedJob3, enqueuedJob4,
                        enqueuedJob5, job1WaitingForEnqueuedJob1, job2WaitingForEnqueuedJob1, job3WaitingForEnqueuedJob2);

        asList(job4WaitingForSucceededJob4, job5WaitingForSucceededJob4, job6WaitingForSucceededJob5).forEach(job -> {
            job.enqueue();
            job.succeeded();
            storageProvider.save(job);
        });

        assertThat(storageProvider.getAwaitingJobsOnOtherJobWithState(SUCCEEDED, AmountBasedList.ascOnUpdatedAt(1000))).isEmpty();
    }

    @Test
    protected void testBatchChildJobs() {
        //GIVEN
        final BatchJob batchJob = (BatchJob) storageProvider.save(aBatchJobInProgress().build());

        Job batchChildJob1 = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        storageProvider.save(batchChildJob1);
        batchChildJob1.enqueue();
        storageProvider.save(batchChildJob1);

        Job batchChildJob2 = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        storageProvider.save(batchChildJob2);
        batchChildJob2.enqueue();
        storageProvider.save(batchChildJob2);

        //WHEN
        final Page<Job> batchChildJobs = storageProvider.getJobs(aJobSearchRequest().withStateName(ENQUEUED).withAwaitingOn(batchJob.getId()).build(), ascOnPriorityAndUpdatedAt(1000));

        //THEN
        assertThat(batchChildJobs)
                .hasTotal(2)
                .hasItems(2)
                .containsExactly(batchChildJob1, batchChildJob2);
    }

    @Test
    protected void testCRUDBatchJobLifeCycle() {
        //GIVEN
        final BatchJob batchJob1 = (BatchJob) storageProvider.save(aBatchJobInProgress().build());
        final BatchJob batchJob2 = (BatchJob) storageProvider.save(aBatchJobInProgress().build());

        //THEN
        assertThatJobs(storageProvider.getBatchJobs(PROCESSING)).hasSize(2).contains(batchJob1, batchJob2);
        BatchJobChildStats batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 0L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 0L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //GIVEN
        Job batchJob1ChildJob1 = aJob().withAwaitingBatchJobState(batchJob1.getId()).build();
        storageProvider.save(batchJob1ChildJob1);

        Job batchJob1ChildJob2 = aJob().withAwaitingBatchJobState(batchJob1.getId()).build();
        storageProvider.save(batchJob1ChildJob2);

        Job batchJob1ChildJob3 = aJob().withAwaitingStateAndAwaitingBatchJobState(batchJob1ChildJob2.getId(), batchJob1.getId()).build();
        storageProvider.save(batchJob1ChildJob3);

        //THEN
        assertThatJobs(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), AWAITING).build(), ascOnPriorityAndUpdatedAt(100))).hasSize(3).contains(batchJob1ChildJob1, batchJob1ChildJob2, batchJob1ChildJob3);
        assertThatJobs(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), ENQUEUED).build(), ascOnPriorityAndUpdatedAt(100))).isEmpty();

        batchJob1.succeeded();

        //WHEN
        BatchJob savedBatchJob = (BatchJob) storageProvider.save(batchJob1);
        //THEN
        assertThatJobs(storageProvider.getBatchJobs(PROCESSED)).hasSize(1).contains(batchJob1);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 0L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1ChildJob1.enqueue();
        batchJob1ChildJob1.startProcessingOn(backgroundJobServer);
        batchJob1ChildJob1.succeeded();
        storageProvider.save(batchJob1ChildJob1);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        batchJob1.updateChildJobStatus(batchJob1ChildStats.getTotalChildCount(), batchJob1ChildStats.getSucceededChildCount(), batchJob1ChildStats.getFailedChildCount());
        storageProvider.save(List.of(batchJob1));

        //THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), SUCCEEDED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob1);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), AWAITING).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(2).containsExactly(batchJob1ChildJob2, batchJob1ChildJob3);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 1L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1ChildJob2.enqueue();
        batchJob1ChildJob2.startProcessingOn(backgroundJobServer);
        batchJob1ChildJob2.failed("An exception", new Exception("Boem"));
        storageProvider.save(batchJob1ChildJob2);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        batchJob1.updateChildJobStatus(batchJob1ChildStats.getTotalChildCount(), batchJob1ChildStats.getSucceededChildCount(), batchJob1ChildStats.getFailedChildCount());
        storageProvider.save(List.of(batchJob1));

        //THEN
        assertThat(storageProvider.getBatchJobs(PROCESSED, FAILED)).hasSize(1);
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(FAILED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), SUCCEEDED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob1);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), FAILED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob2);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), AWAITING).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob3);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 1L)
                .hasFieldOrPropertyWithValue("failedChildCount", 1L);

        //WHEN
        batchJob1ChildJob2.enqueue();
        batchJob1ChildJob2.startProcessingOn(backgroundJobServer);
        storageProvider.save(batchJob1ChildJob2);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        batchJob1.updateChildJobStatus(batchJob1ChildStats.getTotalChildCount(), batchJob1ChildStats.getSucceededChildCount(), batchJob1ChildStats.getFailedChildCount());
        storageProvider.save(List.of(batchJob1));

        //THEN
        assertThat(storageProvider.getJobById(batchJob1ChildJob2.getId())).hasState(PROCESSING);
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);

        //WHEN
        batchJob1ChildJob2.succeeded();
        storageProvider.save(batchJob1ChildJob2);

        //THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), SUCCEEDED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(2).containsExactly(batchJob1ChildJob1, batchJob1ChildJob2);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), AWAITING).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob3);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 2L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1ChildJob2.delete("Deleted via Dashboard");
        storageProvider.save(batchJob1ChildJob2);

        // THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), DELETED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob2);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 2L) // as DELETED jobs count as succeededChildCount
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1ChildJob3.enqueue();
        batchJob1ChildJob3.startProcessingOn(backgroundJobServer);
        batchJob1ChildJob3.succeeded();
        storageProvider.save(batchJob1ChildJob3);

        //THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), SUCCEEDED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(2).containsExactly(batchJob1ChildJob1, batchJob1ChildJob3);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), DELETED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(1).containsExactly(batchJob1ChildJob2);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 3L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1ChildJob2.enqueue("Enqueued again via Dashboard");
        batchJob1ChildJob2.startProcessingOn(backgroundJobServer);
        batchJob1ChildJob2.succeeded();
        storageProvider.save(batchJob1ChildJob2);

        // THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(PROCESSED);
        assertThat(storageProvider.getJobs(aJobSearchRequestForBatchJobs(batchJob1.getId(), SUCCEEDED).build(), ascOnPriorityAndUpdatedAt(100))).hasTotal(3).containsExactly(batchJob1ChildJob1, batchJob1ChildJob3, batchJob1ChildJob2);
        batchJob1ChildStats = storageProvider.getBatchJobsChildStats(asList(batchJob1.getId(), batchJob2.getId())).get(0);
        assertThat(batchJob1ChildStats)
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 3L) // as DELETED jobs count as succeededChildCount
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        //WHEN
        batchJob1.updateChildJobStatus(batchJob1ChildStats.getTotalChildCount(), batchJob1ChildStats.getSucceededChildCount(), batchJob1ChildStats.getFailedChildCount());
        storageProvider.save(List.of(batchJob1));

        //THEN
        assertThat(storageProvider.getJobById(batchJob1.getId())).hasState(SUCCEEDED);
        assertThat(storageProvider.getBatchJobsChildStats(asList(savedBatchJob.getId())).get(0))
                .hasFieldOrPropertyWithValue("totalChildCount", 3L)
                .hasFieldOrPropertyWithValue("succeededChildCount", 3L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);

        // WHEN (child job can still be requeued)
        batchJob1ChildJob2.enqueue();
        batchJob1ChildJob2.startProcessingOn(backgroundJobServer);
        batchJob1ChildJob2.succeeded();
        storageProvider.save(batchJob1ChildJob2);
    }

    @Test
    protected void testCRUDAbortedBatchJobLifeCycle() {
        // GIVEN
        final BatchJob batchJob = (BatchJob) storageProvider.save(aBatchJobInProgress().build());
        Job batchJobChildJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        storageProvider.save(batchJobChildJob);
        batchJob.succeeded();
        storageProvider.save(batchJob);

        batchJobChildJob.enqueue();
        batchJobChildJob.succeeded();
        storageProvider.save(batchJobChildJob);

        // WHEN BATCH JOB IS DELETED BEFORE SUCCEEDING
        batchJob.delete("Deleting");
        storageProvider.save(batchJob);

        // THEN
        assertThat(storageProvider.getBatchJobsChildStats(asList(batchJob.getId())).get(0))
                .hasFieldOrPropertyWithValue("succeededChildCount", 1L)
                .hasFieldOrPropertyWithValue("failedChildCount", 0L);
    }

    @Test
    protected void testCRUDRecurringJobLifeCycle() {
        assertThat(storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500))).hasNoItems();

        // CREATE
        RecurringJob recurringJobv1 = aDefaultRecurringJob().withId("my-job").withCronExpression(Cron.daily()).build();
        storageProvider.saveRecurringJob(recurringJobv1);
        RecurringJob savedRecurringJobv1 = storageProvider.getRecurringJobById("my-job");
        assertThat(savedRecurringJobv1).isEqualTo(recurringJobv1);
        Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500));
        assertThat(recurringJobsPage1)
                .hasItems(1)
                .<RecurringJob>hasItem(0, rj -> assertThat(rj).hasVersion(1).hasPaused(false));


        // UPDATE
        savedRecurringJobv1.setPaused(true);
        storageProvider.saveRecurringJob(savedRecurringJobv1);
        Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500));
        assertThat(recurringJobsPage2)
                .hasItems(1)
                .<RecurringJob>hasItem(0, rj -> assertThat(rj).hasVersion(2).hasPaused(true));

        // DELETE
        storageProvider.deleteRecurringJob("my-job");
        Page<RecurringJob> recurringJobsPage3 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500));
        assertThat(recurringJobsPage3)
                .hasNoItems();

        assertThatCode(() -> storageProvider.getRecurringJobById("my-job")).isInstanceOf(RecurringJobNotFoundException.class);
    }

    @Test
    void testSaveRecurringJobs() {
        assertThatCode(() -> storageProvider.saveRecurringJobs(emptyList())).doesNotThrowAnyException();

        // GIVEN
        RecurringJob recurringJobAv1 = aDefaultRecurringJob().withId("my-job-A").withCronExpression(Cron.daily()).build();
        RecurringJob recurringJobBv1 = aDefaultRecurringJob().withId("my-job-B").withCronExpression(Cron.daily()).build();
        RecurringJob recurringJobCv1 = aDefaultRecurringJob().withId("my-job-C").withCronExpression(Cron.daily()).build();

        List<RecurringJob> savedRecurringJobs = storageProvider.saveRecurringJobs(asList(recurringJobAv1, recurringJobBv1, recurringJobCv1));
        assertThat(savedRecurringJobs).hasSize(3);

        // WHEN recurring jobs are updated with lastUpdate
        RecurringJob recurringJobAv2 = aCopyOf(recurringJobAv1).withLastRun(now().minusSeconds(5)).build();
        RecurringJob recurringJobBv2 = aCopyOf(recurringJobBv1).withLastRun(now().minusSeconds(5)).build();
        RecurringJob recurringJobCv2 = aCopyOf(recurringJobCv1).withLastRun(now().minusSeconds(5)).build();

        storageProvider.saveRecurringJobs(asList(recurringJobAv2, recurringJobBv2, recurringJobCv2));

        // THEN
        Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500));
        assertThat(recurringJobsPage1).hasItems(3);

        // GIVEN 2 jobs are paused
        RecurringJob savedRecurringJobAv2 = recurringJobsPage1.getItems().get(0);
        RecurringJob savedRecurringJobBv2 = recurringJobsPage1.getItems().get(1);
        savedRecurringJobAv2.setPaused(true);
        savedRecurringJobBv2.setPaused(true);
        storageProvider.saveRecurringJobs(asList(savedRecurringJobAv2, savedRecurringJobBv2));

        // THEN
        Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.descOnUpdatedAt(500));
        assertThat(recurringJobsPage2)
                .hasItems(3)
                .<RecurringJob>hasItem(0, rj -> assertThat(rj).hasPaused(true))
                .<RecurringJob>hasItem(1, rj -> assertThat(rj).hasPaused(true))
                .<RecurringJob>hasItem(2, rj -> assertThat(rj).hasPaused(false));
    }

    @Test
    void testSaveRecurringJobOptimisticLocking() {
        // GIVEN a new recurring job
        RecurringJob recurringJobv1 = aDefaultRecurringJob().withId("my-job").withCronExpression(Cron.daily()).build();

        // WHEN / THEN
        assertThatCode(() -> storageProvider.saveRecurringJob(recurringJobv1)).doesNotThrowAnyException();
        assertThat(storageProvider.getRecurringJobById("my-job"))
                .isNotNull()
                .hasScheduleExpression(Cron.daily());

        // GIVEN the same recurring job is created again (updated / overwritten) via API or annotation
        RecurringJob recurringJobv2 = aDefaultRecurringJob().withId("my-job").withCronExpression(Cron.hourly()).build();

        // WHEN / THEN
        assertThatCode(() -> storageProvider.saveRecurringJob(recurringJobv2)).doesNotThrowAnyException();
        assertThat(storageProvider.getRecurringJobById("my-job"))
                .isNotNull()
                .hasScheduleExpression(Cron.hourly());

        // GIVEN the same job is updated concurrently
        aCopyOf(recurringJobv2).withIsPaused().build();
        RecurringJob recurringJobv3A = aCopyOf(recurringJobv2).withIsPaused().build();
        RecurringJob recurringJobv3B = aCopyOf(recurringJobv2).withIsPaused().build();

        // THEN
        assertThatCode(() -> storageProvider.saveRecurringJob(recurringJobv3A)).doesNotThrowAnyException();
        assertThatCode(() -> storageProvider.saveRecurringJob(recurringJobv3B)).isInstanceOf(ConcurrentRecurringJobModificationException.class);
    }

    @Test
    void testSaveRecurringJobsOptimisticLocking() {
        // GIVEN
        RecurringJob recurringJobAv1 = aDefaultRecurringJob().withId("my-job-A").withCronExpression(Cron.daily()).build();
        RecurringJob recurringJobBv1 = aDefaultRecurringJob().withId("my-job-B").withCronExpression(Cron.daily()).build();

        storageProvider.saveRecurringJobs(asList(recurringJobAv1, recurringJobBv1));
        assertThat(recurringJobAv1).hasVersion(1);
        assertThat(recurringJobBv1).hasVersion(1);

        // WHEN
        RecurringJob illegalRecurringJobA = aCopyOf(recurringJobAv1).withVersion(99).withIsPaused(true).build();
        RecurringJob recurringJobBv2 = aCopyOf(recurringJobBv1).withIsPaused(true).build();

        // THEN
        assertThatThrownBy(() -> storageProvider.saveRecurringJobs(asList(illegalRecurringJobA, recurringJobBv2)))
                .isInstanceOf(ConcurrentRecurringJobModificationException.class);

        Page<RecurringJob> recurringJobsPage = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(500));
        assertThat(recurringJobsPage)
                .hasItems(2)
                .<RecurringJob>hasItem(0, rj -> assertThat(rj).hasPaused(false));
        assertThat(illegalRecurringJobA).hasVersion(99);
        assertThat(recurringJobBv2).hasVersion(2);
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestNoFilterCanPageUsingOffsetBasedPageRequest() {
        List<RecurringJob> recurringJobsToSave = new ArrayList<>();
        for (int i = 0; i < 23; i++) {
            recurringJobsToSave.add(aDefaultRecurringJob().withId("my-job-" + i).withCronExpression(Cron.daily()).build());
        }
        storageProvider.saveRecurringJobs(recurringJobsToSave);

        final Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsPage1)
                .hasItems(10)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(0, 10));

        final Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.next(recurringJobsPage1));
        assertThat(recurringJobsPage2)
                .hasItems(10)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(10, 20));

        final Page<RecurringJob> recurringJobsPage3 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.next(recurringJobsPage2));
        assertThat(recurringJobsPage3)
                .hasItems(3)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(20, 23));
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestNoFilterCanPageUsingCursorBasedPageRequest() {
        List<RecurringJob> recurringJobsToSave = new ArrayList<>();
        for (int i = 0; i < 23; i++) {
            recurringJobsToSave.add(aDefaultRecurringJob().withId("my-job-" + i).withName("my-job-" + i).withUpdatedAt(now().plusSeconds(i)).withCronExpression(Cron.daily()).build());
        }
        storageProvider.saveRecurringJobs(recurringJobsToSave);

        final Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), Paging.CursorBasedPage.ascOnPriorityAndUpdatedAt(10));
        assertThat(recurringJobsPage1)
                .hasItems(10)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(0, 10));

        final Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), Paging.CursorBasedPage.next(recurringJobsPage1));
        assertThat(recurringJobsPage2)
                .hasItems(10)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(10, 20));

        final Page<RecurringJob> recurringJobsPage3 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), Paging.CursorBasedPage.next(recurringJobsPage2));
        assertThat(recurringJobsPage3)
                .hasItems(3)
                .hasTotal(23)
                .containsExactly(recurringJobsToSave.subList(20, 23));
    }

    @Test
    void testGetRecurringJobsByRecurringJobSearchRequestCanSortByName() {
        List<RecurringJob> recurringJobsToSave = new ArrayList<>();
        for (int i = 23; i >= 0; i--) {
            recurringJobsToSave.add(aDefaultRecurringJob().withId("my-job-" + String.format("%03d", i)).withName("my-job-" + String.format("%03d", i)).withCronExpression(Cron.daily()).build());
        }
        storageProvider.saveRecurringJobs(recurringJobsToSave);

        final Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnName(10));
        assertThat(recurringJobsPage1)
                .hasItems(10)
                .hasTotal(24)
                .hasItem(0, item -> assertThat(item).hasJobName("my-job-000"))
                .hasItem(9, item -> assertThat(item).hasJobName("my-job-009"));

        final Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.next(recurringJobsPage1));
        assertThat(recurringJobsPage2)
                .hasItems(10)
                .hasTotal(24)
                .hasItem(0, item -> assertThat(item).hasJobName("my-job-010"))
                .hasItem(9, item -> assertThat(item).hasJobName("my-job-019"));
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnRecurringJobId() {
        RecurringJob recurringJob = aDefaultRecurringJob().withId("my-job").build();

        storageProvider.saveRecurringJobs(List.of(recurringJob));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withId("my-job").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJob);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withId("unknown-job").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnRecurringJobIds() {
        RecurringJob recurringJob1 = aDefaultRecurringJob().withId("my-job-1").build();
        RecurringJob recurringJob2 = aDefaultRecurringJob().withId("my-job-2").build();
        RecurringJob recurringJob3 = aDefaultRecurringJob().withId("my-job-3").build();

        storageProvider.saveRecurringJobs(List.of(recurringJob1, recurringJob2, recurringJob3));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withIds("my-job-1", "my-job-3").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(2).containsExactly(recurringJob1, recurringJob3);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withIds("unknown-job-1", "unknown-job-2").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnRecurringJobNameWorksCaseInsensitive() {
        RecurringJob recurringJobAv1 = aDefaultRecurringJob().withName("my RECUrring job").build();

        storageProvider.saveRecurringJobs(List.of(recurringJobAv1));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withJobName("my recurring job").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJobAv1);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withJobName("name that does not match").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnLabelWorksCaseInsensitive() {
        RecurringJob recurringJobAv1 = aDefaultRecurringJob().withLabels("CORRECT label").build();

        storageProvider.saveRecurringJobs(List.of(recurringJobAv1));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withLabel("correct label").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJobAv1);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withJobName("name that does not match").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnJobSignature() {
        RecurringJob recurringJobAv1 = aDefaultRecurringJob().withJobDetails(() -> testService.doWork()).build();

        storageProvider.saveRecurringJobs(List.of(recurringJobAv1));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withJobSignature("org.jobrunr.stubs.TestService.doWork()").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJobAv1);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withJobSignature("org.jobrunr.stubs.TestService.methodThatDoesNotExist()").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnRunsMoreThanOncePerMinute() {
        RecurringJob recurringJobA = aDefaultRecurringJob().withId("my-job-a").withCronExpression(Cron.every30seconds()).build();

        sleep(1); // for SQLITE as no microsecond precision
        RecurringJob recurringJobB = aDefaultRecurringJob().withId("my-job-b").withCronExpression(Cron.minutely()).build();

        storageProvider.saveRecurringJobs(List.of(recurringJobA, recurringJobB));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(2).containsExactly(recurringJobA, recurringJobB);

        final Page<RecurringJob> recurringJobsRunningMoreThanOncePerMinute = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withRunsMoreThanOncePerMinute(true).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsRunningMoreThanOncePerMinute).hasItems(1).containsExactly(recurringJobA);

        final Page<RecurringJob> recurringJobsRunningLessThanOncePerMinute = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withRunsMoreThanOncePerMinute(false).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsRunningLessThanOncePerMinute).hasItems(1).containsExactly(recurringJobB);
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnPriority() {
        RecurringJob recurringJobA = aDefaultRecurringJob().withPriority(1).build();

        storageProvider.saveRecurringJobs(List.of(recurringJobA));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withPriority(1).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJobA);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withPriority(2).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnServerTag() {
        RecurringJob recurringJobA = aDefaultRecurringJob().withServerTag("LINUX").build();
        storageProvider.saveRecurringJobs(List.of(recurringJobA));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withServerTag("LINUX").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJobA);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withServerTag("WINDOWS").build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnPaused() {
        RecurringJob recurringJobA = aDefaultRecurringJob().withId("my-job-a").withIsPaused(false).build();
        RecurringJob recurringJobB = aDefaultRecurringJob().withId("my-job-b").withIsPaused(true).build();
        storageProvider.saveRecurringJobs(List.of(recurringJobA, recurringJobB));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(2).containsExactly(recurringJobA, recurringJobB);

        final Page<RecurringJob> recurringJobsThatAreNotPaused = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withPaused(false).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatAreNotPaused).hasItems(1).containsExactly(recurringJobA);

        final Page<RecurringJob> recurringJobsThatArePaused = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withPaused(true).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatArePaused).hasItems(1).containsExactly(recurringJobB);
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnNextRun() {
        RecurringJob recurringJobA = aDefaultRecurringJob().withId("my-job-a").withLastRun(now().minus(20, SECONDS)).withNextRun(now()).withUpdatedAt(now().minusSeconds(3)).build();
        RecurringJob recurringJobB = aDefaultRecurringJob().withId("my-job-b").withCronExpression("*/5 * * * * *").withNextRun(now().minus(1, HOURS)).withUpdatedAt(now().minusSeconds(2)).build();
        RecurringJob recurringJobC = aDefaultRecurringJob().withId("my-job-c").withNextRun(now().plus(7, DAYS)).withUpdatedAt(now().minusSeconds(1)).build();
        storageProvider.saveRecurringJobs(List.of(recurringJobA, recurringJobB, recurringJobC));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(3).containsExactly(recurringJobA, recurringJobB, recurringJobC);

        final Page<RecurringJob> recurringJobsPage1 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withNextRunFrom(now().plus(1, DAYS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsPage1).hasItems(1).containsExactly(recurringJobC);

        final Page<RecurringJob> recurringJobsPage2 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withNextRunTo(now().plus(1, DAYS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsPage2).hasItems(2).containsExactly(recurringJobA, recurringJobB);

        final Page<RecurringJob> recurringJobsPage3 = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withNextRunTo(now().plus(15, SECONDS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsPage3).hasItems(2).containsExactly(recurringJobA, recurringJobB);
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnCreatedAt() {
        RecurringJob recurringJob = aDefaultRecurringJob().withId("my-job-a").withCreatedAt(now().minus(5, HOURS)).build();
        storageProvider.saveRecurringJobs(List.of(recurringJob));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withCreatedAt(now().minus(6, HOURS), now().minus(4, HOURS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJob);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withCreatedAt(now().minus(4, HOURS), now().minus(2, HOURS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetRecurringJobsByRecurringJobSearchRequestFilterOnUpdatedAt() {
        RecurringJob recurringJob = aDefaultRecurringJob().withId("my-job-a").withUpdatedAt(now().minus(5, HOURS)).build();
        storageProvider.saveRecurringJobs(List.of(recurringJob));

        final Page<RecurringJob> recurringJobs = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withUpdatedAt(now().minus(6, HOURS), now().minus(4, HOURS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobs).hasItems(1).containsExactly(recurringJob);

        final Page<RecurringJob> recurringJobsThatDontMatch = storageProvider.getRecurringJobs(aRecurringJobSearchRequest().withUpdatedAt(now().minus(4, HOURS), now().minus(2, HOURS)).build(), OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(recurringJobsThatDontMatch).hasNoItems();
    }

    @Test
    protected void testGetDistinctRecurringJobSignatures() {
        TestService testService = new TestService();
        RecurringJob job1 = aDefaultRecurringJob().withId("rj-1").withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();
        RecurringJob job2 = aDefaultRecurringJob().withId("rj-2").withJobDetails(() -> testService.doWork(2)).build();
        RecurringJob job3 = aDefaultRecurringJob().withId("rj-3").withJobDetails(() -> testService.doWork(2)).build();
        RecurringJob job4 = aDefaultRecurringJob().withId("rj-4").withJobDetails(() -> testService.doWorkThatTakesLong(5)).build();
        RecurringJob job5 = aDefaultRecurringJob().withId("rj-5").withJobDetails(() -> testService.doWork(2, 5)).build();

        storageProvider.saveRecurringJobs(asList(job1, job2, job3, job4, job5));

        Set<String> distinctRecurringJobSignatures = storageProvider.getDistinctRecurringJobSignatures();
        assertThat(distinctRecurringJobSignatures)
                .hasSize(4)
                .containsOnly(
                        "org.jobrunr.stubs.TestService.doWork(java.util.UUID)",
                        "org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer)",
                        "org.jobrunr.stubs.TestService.doWork(java.lang.Integer, java.lang.Integer)");
    }

    @Test
    void jobsWithAResultCanBeSavedAndFetched() {
        TestService.Work aJobResult = new TestService.Work(5, "some string", UUID.randomUUID());

        Job job = aSucceededJob().withJobResult(aJobResult).build();
        Job savedJob = storageProvider.save(job);

        Job actualJob = storageProvider.getJobById(savedJob.getId());
        assertThat(actualJob.hasResult()).isTrue();
        assertThat(actualJob.<TestService.Work>getResult()).usingRecursiveComparison().isEqualTo(aJobResult);
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    protected void testOnChangeListenerForSaveAndDeleteJob() {
        final SimpleJobStorageOnChangeListener onChangeListener = new SimpleJobStorageOnChangeListener();
        storageProvider.addJobStorageOnChangeListener(onChangeListener);

        Job job = anEnqueuedJobWithName().build();
        storageProvider.save(job);
        await().untilAsserted(() -> assertThat(onChangeListener.changes).hasSize(1));

        job.delete("For test");
        storageProvider.save(job);
        await().untilAsserted(() -> assertThat(onChangeListener.changes).hasSize(2));
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    protected void testOnChangeListenerForSaveJobList() {
        final SimpleJobStorageOnChangeListener onChangeListener = new SimpleJobStorageOnChangeListener();
        storageProvider.addJobStorageOnChangeListener(onChangeListener);

        final List<Job> jobs = asList(anEnqueuedJobWithName().build(), anEnqueuedJobWithName().build());
        storageProvider.save(jobs);
        await().untilAsserted(() -> assertThat(onChangeListener.changes).hasSize(1));

        jobs.forEach(job -> job.startProcessingOn(backgroundJobServer));
        storageProvider.save(jobs);
        await().untilAsserted(() -> assertThat(onChangeListener.changes).hasSize(2));
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    protected void testOnChangeListenerForDeleteJobsByState() {
        storageProvider.save(asList(
                aSucceededJob().withDeleteAt(now().minusSeconds(5)).build(),
                aSucceededJob().withDeleteAt(now().minusSeconds(5)).build()));

        final SimpleJobStorageOnChangeListener onChangeListener = new SimpleJobStorageOnChangeListener();
        storageProvider.addJobStorageOnChangeListener(onChangeListener);

        storageProvider.deleteJobsPermanently(aJobSearchRequest(SUCCEEDED).withDeleteAtTo(now()).build());

        await().untilAsserted(() -> assertThat(onChangeListener.changes).hasSize(1));
    }

    @Test
    protected void testJobStats() {
        storageProvider.announceBackgroundJobServer(backgroundJobServer.getServerStatus());

        assertThatCode(() -> storageProvider.getJobStats()).doesNotThrowAnyException();

        storageProvider.save(aSucceededJob().withDeletedState().build());
        storageProvider.save(asList(
                aSucceededJob().withDeletedState().build(),
                aSucceededJob().withDeletedState().build()));
        storageProvider.save(asList(
                anEnqueuedJobWithName().build(),
                anEnqueuedJobWithName().build(),
                anEnqueuedJobWithName().build(),
                anEnqueuedJobWithName().withPriority(0).build(),
                anEnqueuedJobWithName().withPriority(1).build(),
                anEnqueuedJobWithName().withPriority(1).build(),
                anEnqueuedJobWithName().withPriority(2).build(),
                anEnqueuedJobWithName().withPriority(3).build(),
                anEnqueuedJobWithName().withPriority(3).build(),
                anEnqueuedJobWithName().withPriority(4).build(),
                aJobInProgress().build(),
                aScheduledJob().build(),
                aFailedJob().build(),
                aFailedJob().build(),
                aSucceededJob().build(),
                aDeletedJob().build()
        ));
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("id1").build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("id2").build());
        storageProvider.save(anEnqueuedBatchJob().build());

        final JobStats jobStats = storageProvider.getJobStats();
        assertThat(jobStats.getScheduled()).isEqualTo(1);
        assertThat(jobStats.getEnqueued()).isEqualTo(11);
        assertThat(jobStats.getEnqueuedQueue0()).isEqualTo(5);
        assertThat(jobStats.getEnqueuedQueue1()).isEqualTo(2);
        assertThat(jobStats.getEnqueuedQueue2()).isEqualTo(1);
        assertThat(jobStats.getEnqueuedQueue3()).isEqualTo(2);
        assertThat(jobStats.getEnqueuedQueue4()).isEqualTo(1);
        assertThat(jobStats.getProcessing()).isEqualTo(1);
        assertThat(jobStats.getFailed()).isEqualTo(2);
        assertThat(jobStats.getSucceeded()).isEqualTo(1);
        assertThat(jobStats.getAllTimeSucceeded()).isEqualTo(3);
        assertThat(jobStats.getDeleted()).isEqualTo(4);
        assertThat(jobStats.getRecurringJobs()).isEqualTo(2);
        assertThat(jobStats.getBatchJobs()).isEqualTo(1);
        assertThat(jobStats.getBackgroundJobServers()).isEqualTo(1);
    }

    @Test
    @Disabled
    void testPerformance() {
        int amount = 1000000;
        IntStream.range(0, amount)
                .peek(i -> {
                    if (i % 10000 == 0) {
                        System.out.println("Saving job " + i);
                    }
                })
                .mapToObj(i -> anEnqueuedJobWithName().withJobDetails(systemOutPrintLnJobDetails("this is test " + i)).build())
                .collect(batchCollector(1000, storageProvider::save));

        AtomicInteger atomicInteger = new AtomicInteger();
        storageProvider.getJobList(new JobSearchRequest(ENQUEUED), AmountBasedList.ascOnPriorityAndUpdatedAt(10000))
                .stream()
                .parallel()
                .peek(job -> {
                    job.startProcessingOn(backgroundJobServer);
                    storageProvider.save(job);
                    if (atomicInteger.get() % 100 == 0) {
                        System.out.println("Retrieved job " + atomicInteger.get());
                    }
                })
                .forEach(job -> atomicInteger.incrementAndGet());

        assertThat(atomicInteger).hasValue(10000);
    }

    private boolean isSavingSucceededJobsCounterInMetadata() {
        return storageProvider instanceof SqlStorageProvider
                || storageProvider instanceof InMemoryStorageProvider;
    }

    private static class SimpleJobStorageOnChangeListener implements JobStatsChangeListener {

        private final List<JobStats> changes = new ArrayList<>();

        @Override
        public void onChange(JobStats jobStats) {
            this.changes.add(jobStats);
        }
    }

    private static class SimpleMetadataOnChangeListener implements MetadataChangeListener {

        private final List<List<JobRunrMetadata>> changes = new ArrayList<>();

        @Override
        public String listenForChangesOfMetadataName() {
            return "metadata-name";
        }

        @Override
        public void onChange(List<JobRunrMetadata> metadata) {
            this.changes.add(metadata);
        }
    }

    public static abstract class ThrowingStorageProvider implements AutoCloseable {

        private final StorageProvider storageProvider;
        private final String fieldNameForReset;
        private Object originalState;

        public ThrowingStorageProvider(StorageProvider storageProvider, String fieldNameForReset) {
            this.storageProvider = storageProvider;
            this.fieldNameForReset = fieldNameForReset;

            try {
                saveInternalStorageProviderState(storageProvider);
                makeStorageProviderThrowException(storageProvider);
            } catch (Exception e) {
                throw new RuntimeException("Exception setting up ThrowingStorageProvider", e);
            }
        }

        public void close() {
            resetStorageProviderUsingInternalState(storageProvider);
        }

        protected void saveInternalStorageProviderState(StorageProvider storageProvider) {
            this.originalState = getInternalState(storageProvider, fieldNameForReset);
        }

        protected abstract void makeStorageProviderThrowException(StorageProvider storageProvider) throws Exception;

        protected void resetStorageProviderUsingInternalState(StorageProvider storageProvider) {
            setInternalState(storageProvider, fieldNameForReset, originalState);
        }
    }

    protected JsonMapper getJsonMapper() {
        return new JacksonJsonMapper();
    }
}
