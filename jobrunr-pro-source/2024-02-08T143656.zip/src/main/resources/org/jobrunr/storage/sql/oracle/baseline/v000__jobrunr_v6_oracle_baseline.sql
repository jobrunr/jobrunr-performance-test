-- ==========================================
-- JobRunr Jobs
-- ==========================================
create table JOBRUNR_JOBS
(
    ID             NCHAR(36)        not null primary key,
    VERSION        NUMBER(10) not null,
    JOBASJSON      CLOB             not null,
    JOBSIGNATURE   NVARCHAR2(512) not null,
    STATE          NVARCHAR2(36) not null,
    CREATEDAT      TIMESTAMP(6)     not null,
    UPDATEDAT      TIMESTAMP(6)     not null,
    SCHEDULEDAT    TIMESTAMP(6),
    PRIORITY       NUMBER default 2 not null,
    SERVERTAG      NVARCHAR2(128) default 'DEFAULT' not null,
    MUTEX          NVARCHAR2(128),
    MUTEXINUSE     VARCHAR2(128),
    AWAITINGON     NCHAR(36),
    ISBATCH        NUMBER default 0 not null,
    RECURRINGJOBID NVARCHAR2(128),
    DELETEAT       TIMESTAMP(6),
    JOBNAME        NVARCHAR2(512) default '' not null,
    JOBFINGERPRINT NVARCHAR2(512) default '' not null,
    LABELS         NVARCHAR2(196)
);


create index JOBRUNR_STATE_IDX on JOBRUNR_JOBS (STATE);
create index JOBRUNR_JOB_SIGNATURE_IDX on JOBRUNR_JOBS (JOBSIGNATURE);
create index JOBRUNR_JOB_CREATED_AT_IDX on JOBRUNR_JOBS (CREATEDAT);
create index JOBRUNR_JOB_UPDATED_AT_IDX on JOBRUNR_JOBS (UPDATEDAT);
create index JOBRUNR_JOB_SCHEDULED_AT_IDX on JOBRUNR_JOBS (SCHEDULEDAT);
create index JOBRUNR_JOB_PRIORITY_IDX on JOBRUNR_JOBS (PRIORITY);
create index JOBRUNR_JOB_SERVERTAG_IDX on JOBRUNR_JOBS (SERVERTAG);
create index JOBRUNR_JOB_MUTEX_IDX on JOBRUNR_JOBS (MUTEX);
create unique index JOBRUNR_JOB_MUTEXINUSE_IDX on JOBRUNR_JOBS (MUTEXINUSE);
create index JOBRUNR_JOB_RCI_IDX on JOBRUNR_JOBS (RECURRINGJOBID);
create index JOBRUNR_JOB_DELETE_AT_IDX on JOBRUNR_JOBS (DELETEAT);
create index JOBRUNR_JOB_JOBNAME_IDX on JOBRUNR_JOBS (JOBNAME);
create index JOBRUNR_JOB_JOBFINGERPRINT_IDX on JOBRUNR_JOBS (JOBFINGERPRINT);
create index JOBRUNR_JOB_PRIO_UPDTAT_ST_IDX on JOBRUNR_JOBS (PRIORITY, UPDATEDAT, STATE);
create index JOBRUNR_JOB_ISBATCH_IDX on JOBRUNR_JOBS (ISBATCH);
create index JOBRUNR_JOB_STATE_PRIO_IDX on JOBRUNR_JOBS (STATE, PRIORITY);
create index JOBRUNR_JOB_WAITING_ON_IDX on JOBRUNR_JOBS (AWAITINGON, STATE);
create index JOBRUNR_JOB_JOBLABELS_IDX on JOBRUNR_JOBS (LABELS);


-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
create table JOBRUNR_BACKGROUNDJOBSERVERS
(
    ID                         NCHAR(36)    not null primary key,
    WORKERPOOLSIZE             NUMBER       not null,
    POLLINTERVALINSECONDS      NUMBER       not null,
    SERVERTAGS                 NVARCHAR2(255) not null,
    FIRSTHEARTBEAT             TIMESTAMP(6) not null,
    LASTHEARTBEAT              TIMESTAMP(6) not null,
    RUNNING                    NUMBER       not null,
    SYSTEMTOTALMEMORY          NUMBER(19) not null,
    SYSTEMFREEMEMORY           NUMBER(19) not null,
    SYSTEMCPULOAD              NUMBER(3, 2) not null,
    PROCESSMAXMEMORY           NUMBER(19) not null,
    PROCESSFREEMEMORY          NUMBER(19) not null,
    PROCESSALLOCATEDMEMORY     NUMBER(19) not null,
    PROCESSCPULOAD             NUMBER(3, 2) not null,
    DELETESUCCEEDEDJOBSAFTER   NVARCHAR2(32),
    PERMANENTLYDELETEJOBSAFTER NVARCHAR2(32),
    NAME                       NVARCHAR2(128)
);

create index JOBRUNR_BGJOBSRVRS_FSTHB_IDX on JOBRUNR_BACKGROUNDJOBSERVERS (FIRSTHEARTBEAT);
create index JOBRUNR_BGJOBSRVRS_LSTHB_IDX on JOBRUNR_BACKGROUNDJOBSERVERS (LASTHEARTBEAT);

-- ==========================================
-- JobRunr Metadata
-- ==========================================
create table JOBRUNR_METADATA
(
    ID        NVARCHAR2(156) not null primary key,
    NAME      NVARCHAR2(92) not null,
    OWNER     NVARCHAR2(64) not null,
    VALUE     CLOB         not null,
    CREATEDAT TIMESTAMP(6) not null,
    UPDATEDAT TIMESTAMP(6) not null
);
INSERT INTO jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0',
        TIMESTAMP '2023-01-1 00:00:00.000000', TIMESTAMP '2023-01-1 00:00:00.000000');

-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
create table JOBRUNR_RECURRING_JOBS
(
    ID                        NVARCHAR2(128) not null primary key,
    VERSION                   NUMBER(10) not null,
    PAUSED                    NUMBER                                                                       not null,
    CREATEDAT                 TIMESTAMP(6)                                                                 not null,
    UPDATEDAT                 TIMESTAMP(6)                                                                 not null,
    JOBASJSON                 CLOB                                                                         not null,
    JOBNAME                   NVARCHAR2(512) default '' not null,
    JOBSIGNATURE              NVARCHAR2(512) default '' not null,
    LABELS                    NVARCHAR2(196),
    PRIORITY                  NUMBER       default 2                                                       not null,
    SERVERTAG                 NVARCHAR2(128) default 'DEFAULT' not null,
    RUNSMORETHANONCEPERMINUTE NUMBER       default 0                                                       not null,
    NEXTRUNAT                 TIMESTAMP(6) default TO_DATE('2020-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') not null
);

create index JOBRUNR_RJ_IDX on JOBRUNR_RECURRING_JOBS (UPDATEDAT, RUNSMORETHANONCEPERMINUTE, PAUSED, NEXTRUNAT);


-- ==========================================
-- JobRunr Job Stats View
-- ==========================================
create view JOBRUNR_JOBS_STATS as
with job_stat_results as (SELECT state, priority, count(*) as count
    FROM jobrunr_jobs
    GROUP BY ROLLUP (state, priority)
)
select coalesce((select count from job_stat_results where state IS NULL), 0)                             as total,
       coalesce((select count from job_stat_results where state = 'AWAITING' and priority IS NULL), 0)   as awaiting,
       coalesce((select count from job_stat_results where state = 'SCHEDULED' and priority IS NULL), 0)  as scheduled,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority IS NULL), 0)   as enqueued,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 0), 0)       as enqueued_queue_0,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 1), 0)       as enqueued_queue_1,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 2), 0)       as enqueued_queue_2,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 3), 0)       as enqueued_queue_3,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 4), 0)       as enqueued_queue_4,
       coalesce((select count from job_stat_results where state = 'PROCESSING' and priority IS NULL), 0) as processing,
       coalesce((select count from job_stat_results where state = 'FAILED' and priority IS NULL), 0)     as failed,
       coalesce((select count from job_stat_results where state = 'SUCCEEDED' and priority IS NULL), 0)  as succeeded,
       coalesce((select cast(cast(value as char(10)) as decimal(10, 0))
                 from jobrunr_metadata jm
                 where jm.id = 'succeeded-jobs-counter-cluster'), 0)                                     as allTimeSucceeded,
       coalesce((select count from job_stat_results where state = 'DELETED' and priority IS NULL), 0)    as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                               as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                                     as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                                   as nbrOfBatchJobs
from DUAL;

