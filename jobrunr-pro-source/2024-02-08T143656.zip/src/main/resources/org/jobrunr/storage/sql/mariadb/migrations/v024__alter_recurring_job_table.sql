DROP INDEX jobrunr_recurring_job_updated_at_idx ON jobrunr_recurring_jobs;
ALTER TABLE jobrunr_recurring_jobs DROP COLUMN updatedAtMillis;

ALTER TABLE jobrunr_recurring_jobs ADD jobName VARCHAR(512) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_recurring_jobs ADD jobSignature VARCHAR(512) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_recurring_jobs ADD labels VARCHAR(196);
ALTER TABLE jobrunr_recurring_jobs ADD priority INT NOT NULL default 2;
ALTER TABLE jobrunr_recurring_jobs ADD serverTag VARCHAR(128) NOT NULL DEFAULT 'DEFAULT';
ALTER TABLE jobrunr_recurring_jobs ADD runsMoreThanOncePerMinute INT NOT NULL DEFAULT 0;
ALTER TABLE jobrunr_recurring_jobs ADD nextRunAt TIMESTAMP(6) NOT NULL DEFAULT '2020-01-01 00:00:00';

CREATE INDEX jobrunr_rj_idx ON jobrunr_recurring_jobs (updatedAt, runsMoreThanOncePerMinute, paused, nextRunAt);