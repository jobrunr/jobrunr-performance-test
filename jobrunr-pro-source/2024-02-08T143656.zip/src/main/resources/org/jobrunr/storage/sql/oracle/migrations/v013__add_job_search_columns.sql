ALTER TABLE jobrunr_jobs
    ADD jobName NVARCHAR2(512) DEFAULT '' NOT NULL;
ALTER TABLE jobrunr_jobs
    ADD jobFingerprint NVARCHAR2(512) DEFAULT '' NOT NULL;

CREATE INDEX jobrunr_job_jobName_idx ON jobrunr_jobs (jobName);
CREATE INDEX jobrunr_job_jobFingerprint_idx ON jobrunr_jobs (jobFingerprint);
