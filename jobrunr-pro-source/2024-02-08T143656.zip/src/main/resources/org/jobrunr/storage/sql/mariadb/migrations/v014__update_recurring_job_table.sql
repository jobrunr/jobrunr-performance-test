DROP TABLE jobrunr_recurring_jobs;

CREATE TABLE jobrunr_recurring_jobs
(
    id        NCHAR(128) PRIMARY KEY,
    version   INT         NOT NULL,
    paused    INT         NOT NULL,
    createdAt DATETIME(6) NOT NULL,
    updatedAt DATETIME(6) NOT NULL,
    jobAsJson text        NOT NULL
);