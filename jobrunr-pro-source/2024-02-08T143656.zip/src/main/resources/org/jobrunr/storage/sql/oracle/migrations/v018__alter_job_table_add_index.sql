CREATE INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs (state, priority ASC);
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs (isBatch);