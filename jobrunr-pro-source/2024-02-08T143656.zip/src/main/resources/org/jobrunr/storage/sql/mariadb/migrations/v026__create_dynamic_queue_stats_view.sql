CREATE VIEW jobrunr_dynamic_queue_stats
as
(SELECT dynamicQueue,
        state,
        count(*) as count
    FROM jobrunr_jobs
    GROUP BY dynamicQueue, state WITH ROLLUP)