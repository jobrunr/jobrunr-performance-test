DROP INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs;

CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (awaitingOn ASC, state ASC);