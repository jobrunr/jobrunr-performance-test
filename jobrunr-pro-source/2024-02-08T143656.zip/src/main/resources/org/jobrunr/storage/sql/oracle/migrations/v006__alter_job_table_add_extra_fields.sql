ALTER TABLE jobrunr_jobs
    ADD (priority int default 2 NOT NULL);
ALTER TABLE jobrunr_jobs
    ADD (serverTag NVARCHAR2(128) DEFAULT 'DEFAULT' NOT NULL);
ALTER TABLE jobrunr_jobs
    ADD (mutex NVARCHAR2(128));
ALTER TABLE jobrunr_jobs
    ADD mutexInUse VARCHAR(128);
ALTER TABLE jobrunr_jobs
    ADD (awaitingOn NCHAR(36));
ALTER TABLE jobrunr_jobs
    ADD (isBatch int DEFAULT 0 NOT NULL);

CREATE INDEX jobrunr_job_priority_idx ON jobrunr_jobs (priority);
CREATE INDEX jobrunr_job_serverTag_idx ON jobrunr_jobs (serverTag);
CREATE INDEX jobrunr_job_mutex_idx ON jobrunr_jobs (mutex);
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs (mutexInUse);
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (awaitingOn);