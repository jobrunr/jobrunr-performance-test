DROP INDEX jobrunr_rj_updated_at_idx;
ALTER TABLE jobrunr_recurring_jobs DROP COLUMN updatedAtMillis;

ALTER TABLE jobrunr_recurring_jobs ADD jobName NVARCHAR2(512) DEFAULT '' NOT NULL;
ALTER TABLE jobrunr_recurring_jobs ADD jobSignature NVARCHAR2(512) DEFAULT '' NOT NULL;
ALTER TABLE jobrunr_recurring_jobs ADD labels NVARCHAR2(196);
ALTER TABLE jobrunr_recurring_jobs ADD priority INT default 2 NOT NULL;
ALTER TABLE jobrunr_recurring_jobs ADD serverTag NVARCHAR2(128) DEFAULT 'DEFAULT' NOT NULL;
ALTER TABLE jobrunr_recurring_jobs ADD runsMoreThanOncePerMinute INT DEFAULT 0 NOT NULL;
ALTER TABLE jobrunr_recurring_jobs ADD nextRunAt TIMESTAMP(6) DEFAULT TO_DATE('2020-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') NOT NULL;

CREATE INDEX jobrunr_rj_idx ON jobrunr_recurring_jobs (updatedAt, runsMoreThanOncePerMinute, paused, nextRunAt);