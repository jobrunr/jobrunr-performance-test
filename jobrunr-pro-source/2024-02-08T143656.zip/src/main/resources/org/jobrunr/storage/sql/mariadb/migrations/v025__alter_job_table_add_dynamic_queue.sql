DROP INDEX jobrunr_job_priority_updatedAt_state_idx ON jobrunr_jobs;
ALTER TABLE jobrunr_jobs
    ADD dynamicQueue VARCHAR(64);

CREATE INDEX jobrunr_job_to_process_idx ON jobrunr_jobs (priority ASC, updatedAt ASC, state, serverTag, dynamicQueue, mutex);