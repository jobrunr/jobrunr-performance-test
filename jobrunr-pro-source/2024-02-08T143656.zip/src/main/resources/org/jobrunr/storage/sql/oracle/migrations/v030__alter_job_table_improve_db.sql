DROP INDEX jobrunr_job_priority_idx;
DROP INDEX jobrunr_state_idx;
DROP INDEX jobrunr_job_created_at_idx;
DROP INDEX jobrunr_job_updated_at_idx;
DROP INDEX jobrunr_job_scheduled_at_idx;
DROP INDEX jobrunr_job_delete_at_idx;
DROP INDEX jobrunr_job_signature_idx;
DROP INDEX jobrunr_job_to_process_idx;
DROP INDEX jobrunr_job_isBatch_idx;
DROP INDEX jobrunr_job_rci_idx;
DROP INDEX jobrunr_job_mutex_idx;
DROP INDEX jobrunr_job_mutexInUse_idx;
DROP INDEX jobrunr_job_waiting_on_idx;
DROP INDEX jobrunr_job_rate_limiter_idx;
DROP INDEX jobrunr_job_state_exception_type_idx;

-- below indices can't be used (move to GIN indices)?
DROP INDEX jobrunr_job_jobfingerprint_idx;
DROP INDEX jobrunr_job_jobname_idx;
DROP INDEX jobrunr_job_joblabels_idx;


CREATE INDEX jobrunr_job_created_at_idx ON jobrunr_jobs(createdAt);
CREATE INDEX jobrunr_job_updated_at_idx ON jobrunr_jobs(updatedAt,state);
CREATE INDEX jobrunr_job_scheduled_at_idx ON jobrunr_jobs(scheduledAt ASC,priority ASC,state);
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs(deleteAt,state);
CREATE INDEX jobrunr_job_signature_idx ON jobrunr_jobs(state,jobSignature);
CREATE INDEX jobrunr_job_to_process_idx ON jobrunr_jobs(priority ASC,updatedAt ASC,state,serverTag,mutex,dynamicQueue);
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs(isBatch,state);
CREATE INDEX jobrunr_job_rci_idx ON jobrunr_jobs(recurringJobId);
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs(mutexInUse);
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs(updatedAt,state,awaitingOn,rateLimiter);
CREATE INDEX jobrunr_job_rate_limiter_idx ON jobrunr_jobs(priority ASC,updatedAt ASC,state,rateLimiter);
CREATE INDEX jobrunr_job_state_exception_type_idx ON jobrunr_jobs(state,jobExceptionType);