DROP TABLE jobrunr_recurring_jobs;

CREATE TABLE jobrunr_recurring_jobs
(
    id        NVARCHAR2(128) NOT NULL,
    version   number(10)     NOT NULL,
    paused    INT            NOT NULL,
    createdAt TIMESTAMP(6)   NOT NULL,
    updatedAt TIMESTAMP(6)   NOT NULL,
    jobasjson clob           NOT NULL,
    PRIMARY KEY (id)
);