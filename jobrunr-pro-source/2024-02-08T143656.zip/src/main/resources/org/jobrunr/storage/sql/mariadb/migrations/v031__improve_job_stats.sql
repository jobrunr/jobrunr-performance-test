DROP VIEW jobrunr_jobs_stats;

CREATE VIEW jobrunr_jobs_stats
as
with job_stat_results as (SELECT state, priority, count(*) as count
    FROM jobrunr_jobs
    GROUP BY state, priority)
select coalesce((select sum(job_stat_results.count) from job_stat_results), 0)                             as total,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'AWAITING'), 0)   as awaiting,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'SCHEDULED'), 0)  as scheduled,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED'), 0)   as enqueued,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED' and priority = 0), 0)       as enqueued_queue_0,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED' and priority = 1), 0)       as enqueued_queue_1,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED' and priority = 2), 0)       as enqueued_queue_2,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED' and priority = 3), 0)       as enqueued_queue_3,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'ENQUEUED' and priority = 4), 0)       as enqueued_queue_4,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'PROCESSING'), 0) as processing,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'FAILED'), 0)     as failed,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'SUCCEEDED'), 0)  as succeeded,
       coalesce((select cast(cast(value as char(10)) as decimal(10, 0))
                 from jobrunr_metadata jm
                 where jm.id = 'succeeded-jobs-counter-cluster'), 0)                                     as allTimeSucceeded,
       coalesce((select sum(job_stat_results.count) from job_stat_results where state = 'DELETED'), 0)    as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                               as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                                     as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                                   as nbrOfBatchJobs;