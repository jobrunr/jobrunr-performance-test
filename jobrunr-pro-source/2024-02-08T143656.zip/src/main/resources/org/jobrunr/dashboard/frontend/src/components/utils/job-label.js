import Chip from "@mui/material/Chip";
import {Link} from "react-router-dom";

const JobLabel = (props) => {
    const backgroundColor = getRandomColor(props?.text);
    const foregroundColor = getContrastYIQ(backgroundColor);

    if (props.to == null || props.disabled) {
        return <Chip label={props?.text}
                     style={{
                         backgroundColor: backgroundColor,
                         color: foregroundColor,
                         marginRight: '0.5rem',
                         height: '22px'
                     }}
                     size="small"/>;
    }
    return (<Link to={props.to} style={{textDecoration: 'none'}}>
        <Chip label={props?.text}
              style={{
                  backgroundColor: backgroundColor,
                  color: foregroundColor,
                  cursor: 'pointer',
                  marginRight: '0.5rem',
                  height: '22px'
              }}
              size="small"/>
    </Link>);
}

function getRandomColor(text) {
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = text.charCodeAt(i) + ((hash << 5) - hash);
    }
    const c = (hash & 0x00FFFFFF)
        .toString(16)
        .toUpperCase();

    return "#" + "00000".substring(0, 6 - c.length) + c;
}

function getContrastYIQ(hexColor) {
    const hexColorWithoutHash = hexColor.replace("#", "");
    const r = parseInt(hexColorWithoutHash.substring(0, 2), 16);
    const g = parseInt(hexColorWithoutHash.substring(2, 4), 16);
    const b = parseInt(hexColorWithoutHash.substring(4, 6), 16);
    const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    return (yiq >= 128) ? 'black' : 'white';
}

export default JobLabel;