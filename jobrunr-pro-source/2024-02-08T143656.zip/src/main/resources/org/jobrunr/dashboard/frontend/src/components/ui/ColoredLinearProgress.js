import {styled} from "@mui/material/styles";
import LinearProgress, {linearProgressClasses} from "@mui/material/LinearProgress";

export const ColoredLinearProgress = styled(LinearProgress)(() => ({
    height: '7px',
    [`& .${linearProgressClasses.barColorPrimary}`]: {
        backgroundColor: '#78b869'
    }
}));