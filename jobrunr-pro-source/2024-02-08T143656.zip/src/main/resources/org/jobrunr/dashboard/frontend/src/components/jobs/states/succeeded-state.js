import {styled} from "@mui/material/styles";
import {JobState} from "./job-state";
import Highlight from "../../utils/highlighter";
import {humanReadableISO8601Duration} from "../../../utils/helper-functions";

const JobResult = styled("div")`
    padding: 0;

    & > pre {
        margin: 0.75em 0 0;

        & > code {
            padding: 0 1em;
        }
    }

    & > strong {
        margin: 1em;
    }
`;

const Succeeded = ({job, jobState}) => {
    return (
        <JobState
            state="success"
            title="Job processing succeeded"
            date={jobState.createdAt}
        >
            <ul style={{margin: 0, padding: 0, listStylePosition: "inside"}}>
                <li>Latency duration: {humanReadableISO8601Duration(jobState.latencyDuration)}</li>
                <li>Process duration: {humanReadableISO8601Duration(jobState.processDuration)}</li>
            </ul>
            {job.jobResult && job.jobResult.object &&
                <JobResult>
                    <strong>Job result:</strong>
                    <Highlight language="json">
                        {JSON.stringify(job.jobResult.object, null, 4)}
                    </Highlight>
                </JobResult>
            }
        </JobState>
    )
};

export default Succeeded;