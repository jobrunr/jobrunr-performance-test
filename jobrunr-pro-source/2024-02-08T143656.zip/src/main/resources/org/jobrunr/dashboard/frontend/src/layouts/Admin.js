import {useCallback, useEffect, useState} from 'react';
import {createTheme, styled, ThemeProvider} from '@mui/material/styles';
import {FeatureContext} from "../FeaturesContext";
import {prefixWithContextPath} from "../utils/helper-functions";
import {JobRunrInfoContext} from "../JobRunrInfoContext";
import {RecurringJobSignaturesContext} from "../components/recurring-jobs/recurring-job-signatures-context";
import {App, Main} from "./App";
import LoadingIndicator from "../components/LoadingIndicator";
import {defaultUser, UserContext} from "../UserContext";

const Content = styled("main")(({theme}) => ({
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
}));

const theme = createTheme({
    palette: {
        primary: {
            main: '#000'
        },
        secondary: {
            main: '#f50057'
        }
    },
    components: {
        MuiLink: {
            styleOverrides: {
                root: {
                    color: "#26a8ed"
                }
            }
        }
    }
});

const AdminUI = function () {
    const [isLoading, setIsLoading] = useState(true);
    const [user, setUser] = useState(defaultUser);
    const [features, setCurrentFeatures] = useState({});
    const [jobRunrInfo, setJobRunrInfo] = useState({
        version: '0.0.0-SNAPSHOT',
        clusterId: undefined,
        storageProviderType: undefined
    });
    const [recurringJobSignatures, setRecurringJobSignatures] = useState([]);

    const loadGlobalData = useCallback(async () => {
        try {
            const [user, jobRunrInfo, features, recurringJobSignatures] = await Promise.all([
                fetch(prefixWithContextPath(`/api/current-user`)).then(res => res.json()),
                fetch(prefixWithContextPath(`/api/version`)).then(res => res.json()),
                fetch(prefixWithContextPath(`/api/features`)).then(res => res.json()),
                fetch(prefixWithContextPath(`/api/recurring-job-signatures`)).then(res => res.json()),
            ])
            setUser(user);
            setJobRunrInfo(jobRunrInfo);
            setCurrentFeatures(features);
            setRecurringJobSignatures(recurringJobSignatures);
        } catch (error) {
            console.log('Error retrieving global info', error);
        }
    }, [])

    useEffect(() => {
        setIsLoading(true);
        loadGlobalData().finally(() => setIsLoading(false));
    }, [loadGlobalData]);

    const userHasNoAccess = (
        !user.authorizationRules.canAccessJobs
        && !user.authorizationRules.canAccessRecurringJobs
        && !user.authorizationRules.canAccessBackgroundJobServers
    );

    return (
        <ThemeProvider theme={theme}>
            {window.trialExpirationDate && window.trialExpirationDate < new Date()
                ?
                <Main>
                    <Content>
                        <h1>Your JobRunr Pro Trial has expired</h1>
                        <p>
                            Please <a
                            href="mailto:hello@jobrunr.io?subject=JobRunr%20Pro%20License&body=Hi%2C%0D%0A%0D%0Awe%27re%20interested%20in%20a%20JobRunr%20Pro%20License.%0D%0A%0D%0AOur%20company%20is%3A%20%3Cplease%20enter%20your%20company%20name%20here%3E%0D%0AOur%20VAT%20number%20is%3A%20%3Cplease%20enter%20your%20VAT%20number%20here%3E%0D%0AOur%20address%20is%3A%20%3Cplease%20enter%20your%20address%20here%3E%0D%0A%0D%0ARegards!">buy</a>&nbsp;
                            a JobRunr Pro License to continue using it.
                        </p>
                        <p>By doing so, you help open-source software development and <a
                            href="https://www.jobrunr.io/en/about/#eco-friendly-software"
                            target="_blank" rel="noreferrer">our planet</a>.</p>
                    </Content>
                </Main>
                : <> {isLoading
                    ? <LoadingIndicator/>
                    : <>{userHasNoAccess
                        ? <Main>
                            <Content>
                                <h2>You do not have access to the JobRunr Pro Dashboard.</h2>
                            </Content>
                        </Main>
                        : <UserContext.Provider value={user}>
                            <JobRunrInfoContext.Provider value={jobRunrInfo}>
                                <FeatureContext.Provider value={features}>
                                    <RecurringJobSignaturesContext.Provider value={recurringJobSignatures}>
                                        <App/>
                                    </RecurringJobSignaturesContext.Provider>
                                </FeatureContext.Provider>
                            </JobRunrInfoContext.Provider>
                        </UserContext.Provider>
                    }
                    </>
                }
                </>
            }
        </ThemeProvider>
    );
};

export default AdminUI;