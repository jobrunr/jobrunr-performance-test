import {createContext} from 'react';

export const RecurringJobSignaturesContext = createContext([]);