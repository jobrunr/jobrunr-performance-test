import {Fragment, useEffect, useState} from 'react';
import {Link, useLocation} from "react-router-dom";
import {styled} from "@mui/material/styles";
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Chip from '@mui/material/Chip';
import {Schedule} from "@mui/icons-material";
import {AlertCircleOutline, Check, Cogs, Delete, LockClock, TimerSand} from "mdi-material-ui";
import statsState from "../../StatsStateContext";
import priorityQueuesState from '../../PriorityQueuesStateContext';
import {prefixWithPublicUrl} from "../../utils/helper-functions";

const categories = [
    {name: "awaiting", state: "AWAITING", label: "Pending", icon: <LockClock/>},
    {name: "scheduled", state: "SCHEDULED", label: "Scheduled", icon: <Schedule/>},
    {name: "enqueued", state: "ENQUEUED", label: "Enqueued", icon: <TimerSand/>},
    {name: "processing", state: "PROCESSING", label: "Processing", icon: <Cogs/>},
    {name: "succeeded", state: "SUCCEEDED", label: "Succeeded", icon: <Check/>},
    {name: "failed", state: "FAILED", label: "Failed", icon: <AlertCircleOutline/>},
    {name: "deleted", state: "DELETED", label: "Deleted", icon: <Delete/>},
];

const NestListItem = styled(ListItemButton)(({theme}) => ({
    paddingLeft: theme.spacing(4)
}));

const Sidebar = () => {
    const location = useLocation();

    const urlSearchParams = new URLSearchParams(location.search);
    const priorityQueues = priorityQueuesState.usePriorityQueues();
    const [stats, setStats] = useState(statsState.getStats());
    useEffect(() => {
        statsState.addListener(setStats);
        return () => statsState.removeListener(setStats);
    }, [])

    const getURLSearchParams = (state) => {
        const newUrlSearchParams = new URLSearchParams();
        newUrlSearchParams.set('state', state);
        for (let key of urlSearchParams.keys()) {
            if (key.endsWith('!')) {
                newUrlSearchParams.set(key, urlSearchParams.get(key));
            }
        }
        return newUrlSearchParams;
    }

    const getQueryString = (state) => getURLSearchParams(state).toString();

    const getQueryStringForPriorityQueue = (state, priority) => {
        const urlSearchParams = getURLSearchParams(state);
        if (urlSearchParams.has("priority!")) urlSearchParams.set("priority!", priority);
        else urlSearchParams.set("priority", priority);
        return urlSearchParams.toString();
    }

    return (
        <List component="div">
            {categories.map(({name, state, label, icon}) => (
                <Fragment key={label}>
                    <ListItemButton id={`${name}-menu-btn`} title={label} component={Link}
                                    to={prefixWithPublicUrl(`/jobs?${getQueryString(state)}`)}>
                        <ListItemIcon>{icon}</ListItemIcon>
                        <ListItemText primary={label}/>
                        <Chip label={stats[name]}/>
                    </ListItemButton>
                    {name === 'enqueued' && priorityQueues.length > 1 &&
                        <List component="div">
                            {priorityQueues.map((queue, index) => (
                                <NestListItem
                                    id={`${index}-queue-menu-btn`} key={queue}
                                    component={Link}
                                    to={prefixWithPublicUrl(`/jobs?${getQueryStringForPriorityQueue(state, index)}`)}
                                >
                                    <ListItemIcon><Cogs/></ListItemIcon>
                                    <ListItemText primary={queue}/><Chip label={stats['enqueuedQueue' + index]}/>
                                </NestListItem>
                            ))}
                        </List>
                    }
                </Fragment>
            ))}
        </List>
    );
};

export default Sidebar;