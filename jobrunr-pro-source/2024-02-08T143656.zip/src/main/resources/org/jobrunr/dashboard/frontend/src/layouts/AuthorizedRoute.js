import {Navigate} from "react-router-dom";

export const AuthorizedRoute = ({hasAccess = false, component: Component}) =>
    hasAccess ? <Component/> : <Navigate to='overview' replace/>;