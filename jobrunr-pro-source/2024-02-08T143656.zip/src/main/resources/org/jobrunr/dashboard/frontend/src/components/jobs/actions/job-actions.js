import {useEffect, useState} from "react";
import ButtonGroup from "@mui/material/ButtonGroup";
import Button from "@mui/material/Button";
import {prefixWithContextPath} from "../../../utils/helper-functions";
import {Alert, FormControlLabel, Snackbar} from "@mui/material";
import {useLocation, useNavigate, useParams} from "react-router-dom";
import Checkbox from "@mui/material/Checkbox";
import {DeleteJobsDialog} from "../../ui/DeleteDialog";
import {RequeueWithOptionsDialog} from "../../ui/RequeueDialog";

export const JobActions = (props) => {
    const location = useLocation();
    const navigate = useNavigate();

    const {jobId: batchJobId} = useParams();
    const selectedState = props.selectedState;
    const selectedJobs = props.selectedJobs;
    const actionsDisabled = selectedJobs.length < 1;
    const showSelectAllJobsNotification = props.allJobsSelected && selectedJobs.length >= props.jobPage.limit;

    const [allJobsSelected, setAllJobsSelected] = useState(false);
    const [totalAmountOfSelectedJobs, setTotalAmountOfSelectedJobs] = useState(selectedJobs.length);

    const [showRequeueDialog, setShowRequeueDialog] = useState(false);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);

    const [apiStatus, setApiStatus] = useState(null);

    const urlSearchParams = new URLSearchParams(location.search);
    const action = urlSearchParams.get('action');

    useEffect(() => {
        if (allJobsSelected) {
            setTotalAmountOfSelectedJobs(props.jobPage.total);
        } else {
            setTotalAmountOfSelectedJobs(selectedJobs.length);
        }
    }, [allJobsSelected, props.jobPage.total, selectedJobs.length]);

    useEffect(() => {
        if (action) {
            if (action === 'requeue') {
                setApiStatus({type: 'requeue', severity: 'success', message: 'Successfully requeued jobs'});
            } else if (action === 'delete') {
                setApiStatus({type: 'delete', severity: 'success', message: 'Successfully deleted jobs'});
            }
        }
    }, [action]);

    const refreshPage = (action) => {
        urlSearchParams.set('action', action);
        navigate(`?${urlSearchParams.toString()}`, {replace: true});
    };

    const handleCloseAlert = () => {
        setApiStatus(null);
    };

    const queueSelectedJobs = ({selectedRequeueOption, selectedQueue, selectedScheduleDelta}) => {
        let queryString = '';
        if (selectedRequeueOption === "spread-out") {
            queryString += `schedule-delta=${selectedScheduleDelta}`;
        } else if (selectedRequeueOption === "different-queue") {
            queryString += `queue=${selectedQueue}`;
        }
        fetch(getJobApiUrlForSelectedJobs('/api/jobs/requeue', queryString), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 204) {
                    refreshPage('requeue');
                } else {
                    setApiStatus({type: 'requeue', severity: 'error', message: 'Error requeueing jobs'});
                }
            })
            .catch(error => console.error(error))
            .finally(() => handleClose());
    };

    const deleteSelectedJobs = () => {
        fetch(getJobApiUrlForSelectedJobs('/api/jobs'), {
            method: 'DELETE',
        })
            .then(res => {
                if (res.status === 204) {
                    refreshPage('delete');
                } else {
                    setApiStatus({type: 'delete', severity: 'error', message: 'Error deleting jobs'});
                }
            })
            .catch(error => console.error(error));
    };

    const handleClose = () => {
        setShowRequeueDialog(false);
        setShowDeleteDialog(false);
    }

    const getJobApiUrlForSelectedJobs = (url, queryString = '') => {
        const queryStringSuffix = queryString ? `&${queryString}` : ``;
        if (allJobsSelected) {
            if (batchJobId) {
                const selectedChildStateTabKey = Array.from(urlSearchParams.keys()).find(key => key.startsWith('processing-child-job-state'));
                const apiSearchParams = new URLSearchParams(queryStringSuffix);
                apiSearchParams.set('parentId', batchJobId);
                apiSearchParams.set('state', urlSearchParams.has(selectedChildStateTabKey) ? urlSearchParams.get(selectedChildStateTabKey) : 'ENQUEUED');
                return prefixWithContextPath(`${url}?${apiSearchParams.toString()}`);
            } else {
                const apiSearchParams = new URLSearchParams(location.search + queryStringSuffix);
                if (!apiSearchParams.has('state')) {
                    apiSearchParams.set('state', 'ENQUEUED');
                }
                return prefixWithContextPath(`${url}?${apiSearchParams.toString()}`);
            }
        } else {
            const apiSearchParams = new URLSearchParams(queryStringSuffix);
            apiSearchParams.set('jobIds', selectedJobs.join());
            return prefixWithContextPath(`${url}?${apiSearchParams.toString()}`);
        }
    }

    return (
        <div>
            <ButtonGroup style={{margin: '1rem 0 -0.5rem 1rem'}} disabled={actionsDisabled}>
                {props.showDeleteButton &&
                    <Button variant="outlined" color="primary" onClick={() => setShowDeleteDialog(true)}>
                        Delete
                    </Button>
                }
                {props.showEnqueueButton &&
                    <Button variant="outlined" color="primary" onClick={() => setShowRequeueDialog(true)}>
                        {selectedState === 'SCHEDULED' ? 'Enqueue' : 'Requeue'}
                    </Button>
                }
            </ButtonGroup>
            {showSelectAllJobsNotification &&
                <FormControlLabel
                    style={{marginLeft: '1rem'}}
                    control={<Checkbox checked={allJobsSelected}
                                       onChange={(evt) => setAllJobsSelected(evt.target.checked)}
                                       name="selectAllJobs"/>}
                    label="Select all jobs on other pages too?"
                />
            }

            {apiStatus &&
                <Snackbar open={true} autoHideDuration={3000} onClose={handleCloseAlert}
                          anchorOrigin={{vertical: "bottom", horizontal: "center"}}>
                    <Alert severity={apiStatus.severity}>
                        {apiStatus.message}
                    </Alert>
                </Snackbar>
            }
            <RequeueWithOptionsDialog
                open={showRequeueDialog}
                handleClose={handleClose}
                handleRequeue={queueSelectedJobs}
                amount={totalAmountOfSelectedJobs}
                multiple/>
            <DeleteJobsDialog
                open={showDeleteDialog}
                handleClose={handleClose}
                handleDelete={deleteSelectedJobs}
                amount={totalAmountOfSelectedJobs}/>
        </div>
    )
}