export function prefixWithPublicUrl(url) {
    return `${getPublicUrl()}${url}`;
}

export function getPublicUrl() {
    return window.publicUrl ?? '/dashboard';
}

export function replacePublicUrl(url) {
    return url.replace("%PUBLIC_URL%", getPublicUrl());
}

export function prefixWithContextPath(url) {
    return `${window.contextPath ?? ''}${url}`;
}

export function humanFileSize(bytes, si) {
    const thresh = si ? 1000 : 1024;
    if (Math.abs(bytes) < thresh) {
        return bytes + ' B';
    }
    const units = si
        ? ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
        : ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'];
    let u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while (Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1) + ' ' + units[u];
}

export function humanReadableMillis(ms) {
    let seconds = (ms / 1000).toFixed(0);
    let minutes = (ms / (1000 * 60)).toFixed(0);
    let hours = (ms / (1000 * 60 * 60)).toFixed(0);
    let days = (ms / (1000 * 60 * 60 * 24)).toFixed(0);
    if (seconds < 60) return seconds + " sec";
    else if (minutes < 60) return minutes + " min";
    else if (hours < 24) return hours + " hrs";
    else return days + " days"
}

export function convertISO8601DurationToSeconds(durationString) {
    const iso8601TimePattern = /^PT(?:(\d+)D)?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d{1,6})?)S)?$/;
    const stringParts = iso8601TimePattern.exec(durationString);
    return (
        (
            (
                (stringParts[1] === undefined ? 0 : stringParts[1] * 1)  /* Days */
                * 24 + (stringParts[2] === undefined ? 0 : stringParts[2] * 1) /* Hours */
            )
            * 60 + (stringParts[3] === undefined ? 0 : stringParts[3] * 1) /* Minutes */
        )
        * 60 + (stringParts[4] === undefined ? 0 : stringParts[4] * 1) /* Seconds */
    );
}

const getHoursMinutesAndSecondsFromDuration = (duration) => {
    const actualDuration = duration.toString().startsWith('PT') ? convertISO8601DurationToSeconds(duration) : duration;
    const totalSeconds = actualDuration.toFixed(2);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);
    const seconds = totalSeconds - (hours * 3600) - (minutes * 60);
    return {hours, minutes, seconds};
}

export const humanReadableISO8601Duration = (duration) => {
    try {
        const {hours, minutes, seconds} = getHoursMinutesAndSecondsFromDuration(duration)

        let result = "";
        if (hours > 0) {
            result += hours + " hours, "
        }
        if (minutes > 0) {
            result += minutes + ((minutes > 1) ? " minutes" : " minute")
        }
        if (minutes > 0 && seconds > 0) {
            result += " and "
        }
        if (seconds > 0) {
            result += seconds.toFixed(2) + " seconds"
        } else if (result === '') {
            result += "less than 10ms"
        }
        return result;
    } catch (e) {
        console.warn("Could not parse " + duration + ". If you want pretty dates in the succeeded view, your durations must be formatted as either seconds or ISO8601 duration format (e.g. PT5M33S). This is a settings in Jackson.");
        return duration + " (unsupported duration format - see console)";
    }
}


export const shortHumanReadableISO8601Duration = (duration) => {
    try {
        const {hours, minutes, seconds} = getHoursMinutesAndSecondsFromDuration(duration)

        let result = "";
        if (hours > 0) {
            result += hours + "hr "
        }
        if (minutes > 0) {
            result += minutes + "min "
        }
        if (seconds > 0) {
            result += seconds.toFixed(result ? 1 : 2) + "sec"
        } else if (result === '') {
            result += "< 10ms"
        }
        return result;
    } catch (e) {
        return "";
    }
}

export function isCron(scheduleExpression) {
    return /^\s*(?:[0-9*_,/-]+\s+)?([0-9*_,/-]+\s+)(?:\S+\s+){3}(\S+)\s*$/.test(scheduleExpression);
}