import {createContext} from "react";

export const defaultUser = {
    email: undefined,
    id: undefined,
    authorizationRules: {
        canAccessJobs: false,
        canAccessUnredactedJobs: false,
        canEnqueueJobs: false,
        canDeleteJobs: false,
        canAccessRecurringJobs: false,
        canControlRecurringJobs: false,
        canDeleteRecurringJobs: false,
        canAccessBackgroundJobServers: false,
        canControlBackgroundJobServers: false,
    }
};

export const UserContext = createContext(defaultUser);