import {IconButton, InputAdornment, TextField} from "@mui/material";
import {Magnify} from "mdi-material-ui";

const SearchField = (props) => {

    const search = (ev) => {
        if (ev.key === 'Enter') {
            props.onSearch(ev.target.value);
        } else if (ev.type === 'click') {
            let element = ev.target.parentElement;
            console.log(element);
            while (element.previousSibling === null || element.previousSibling.nodeName !== 'INPUT') {
                element = element.parentElement;
            }
            console.log(element);
            props.onSearch(element.previousSibling.value);
        }
    }

    return (
        <TextField
            variant="standard"
            id={props.id}
            label={props.label}
            onKeyPress={search}
            error={props.hasError}
            helperText={props.hasError ? props.errorText : null}
            defaultValue={props.defaultValue}
            InputProps={{
                endAdornment: <InputAdornment position="end"><IconButton aria-label="search" onClick={search} edge="end" size="large"><Magnify/></IconButton></InputAdornment>
            }}
            fullWidth />
    );
};

export default SearchField;