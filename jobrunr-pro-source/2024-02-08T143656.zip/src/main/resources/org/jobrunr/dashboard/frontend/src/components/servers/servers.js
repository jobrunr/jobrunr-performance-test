import {memo, useContext, useEffect, useState} from 'react';
import {keyframes, styled} from "@mui/material/styles";
import Link from '@mui/material/Link';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import TimeAgo from "react-timeago/lib";
import Box from "@mui/material/Box";
import {Alert, Button, ButtonGroup, Grid, IconButton, Snackbar} from "@mui/material";
import {CogClockwise, CogPauseOutline} from "mdi-material-ui";
import Dialog from '@mui/material/Dialog';
import MuiDialogTitle from '@mui/material/DialogTitle';
import MuiDialogContent from '@mui/material/DialogContent';
import {humanFileSize, prefixWithContextPath} from "../../utils/helper-functions";
import VersionFooter from "../utils/version-footer";
import serversState from "../../ServersStateContext";
import {UserContext} from "../../UserContext";
import {ItemsNotFound} from "../utils/items-not-found";

const spin = keyframes`
    from {
        transform: rotate(0deg)
    }
    to {
        transform: rotate(360deg)
    }
`;

const StyledCogClockwise = styled(CogClockwise)(() => ({
    animationName: spin,
    animationDuration: '5000ms',
    animationIterationCount: 'infinite',
    animationTimingFunction: 'linear'
}));

const IdColumn = styled(TableCell)`
    width: 15%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
`;

const Servers = memo(() => {
    const [apiStatus, setApiStatus] = useState(null);
    const [servers, setServers] = useState([]);
    const [currentServer, setCurrentServer] = useState(null);

    const {authorizationRules: {canControlBackgroundJobServers}} = useContext(UserContext);

    const handleOpen = (server) => {
        setCurrentServer(server);
    };

    const handleClose = () => {
        setCurrentServer(null);
    };

    const pauseProcessing = (server) => {
        fetch(prefixWithContextPath(`/api/servers/${server.id}/pause`), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 200) {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully paused job processing on server ' + server.id
                    });
                    res.json().then(servers => setServers(servers));
                } else {
                    setApiStatus({type: 'paused', severity: 'error', message: 'Error pausing job processing'});
                }
            });
    }

    const resumeProcessing = (server) => {
        fetch(prefixWithContextPath(`/api/servers/${server.id}/resume`), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 200) {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully resumed job processing on server ' + server.id
                    });
                    res.json().then(servers => setServers(servers));
                } else {
                    setApiStatus({type: 'paused', severity: 'error', message: 'Error pausing job processing'});
                }
            });
    }

    const pauseAllProcessing = () => {
        fetch(prefixWithContextPath(`/api/servers/pause`), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 200) {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully paused job processing on all servers.'
                    });
                    res.json().then(servers => setServers(servers));
                } else {
                    setApiStatus({type: 'paused', severity: 'error', message: 'Error pausing job processing'});
                }
            });
    }

    const resumeAllProcessing = () => {
        fetch(prefixWithContextPath(`/api/servers/resume`), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 200) {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully resumed job processing on all servers.'
                    });
                    res.json().then(servers => setServers(servers));
                } else {
                    setApiStatus({type: 'paused', severity: 'error', message: 'Error pausing job processing'});
                }
            });
    }

    const handleCloseAlert = (event, reason) => {
        setApiStatus(null);
    };

    useEffect(() => {
        serversState.addListener(setServers);
        return () => serversState.removeListener(setServers);
    }, []);

    return (
        <div>
            <Box my={3}>
                <Typography variant="h4">Background Job Servers</Typography>
            </Box>
            <>
                <Paper>
                    {servers.length < 1
                        ? <ItemsNotFound>No servers found</ItemsNotFound>
                        : <>
                            {canControlBackgroundJobServers &&
                                <Grid item xs={12} container>
                                    <Grid item xs={6}>
                                        <ButtonGroup style={{margin: '1rem'}}>
                                            <Button id="pause-all-processing-btn" variant="outlined" color="primary"
                                                    onClick={pauseAllProcessing}>
                                                Pause all processing
                                            </Button>
                                            <Button id="resume-all-processing-btn" variant="outlined" color="primary"
                                                    onClick={resumeAllProcessing}>
                                                Resume all processing
                                            </Button>
                                        </ButtonGroup>
                                    </Grid>
                                </Grid>
                            }
                            <TableContainer>
                                <Table style={{width: "100%"}} aria-label="servers overview">
                                    <TableHead>
                                        <TableRow>
                                            <IdColumn style={{cursor: "initial"}}>Id</IdColumn>
                                            <TableCell>Name</TableCell>
                                            <TableCell>Server Tags</TableCell>
                                            <TableCell>Workers</TableCell>
                                            <TableCell>Created</TableCell>
                                            <TableCell>Last heartbeat</TableCell>
                                            <TableCell>Free memory</TableCell>
                                            <TableCell>Cpu load</TableCell>
                                            <TableCell>Running?</TableCell>
                                            {/*<TableCell>JobActions</TableCell>*/}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {servers.map(server => (
                                            <TableRow key={server.id}>
                                                <IdColumn component="th" scope="row">
                                                    <Link onClick={() => handleOpen(server)} underline="hover">
                                                        {server.id}
                                                    </Link>
                                                </IdColumn>
                                                <TableCell style={{cursor: 'pointer'}}>
                                                    <Link onClick={() => handleOpen(server)} underline="hover">
                                                        {server.name}
                                                    </Link>
                                                </TableCell>
                                                <TableCell style={{maxWidth: '15em'}}>
                                                    {[...server.serverTags].sort().join(', ')}
                                                </TableCell>
                                                <TableCell>
                                                    {server.workerPoolSize}
                                                </TableCell>
                                                <TableCell>
                                                    <TimeAgo date={new Date(server.firstHeartbeat)}
                                                             title={new Date(server.firstHeartbeat).toString()}/>
                                                </TableCell>
                                                <TableCell>
                                                    <TimeAgo date={new Date(server.lastHeartbeat)}
                                                             title={new Date(server.lastHeartbeat).toString()}/>
                                                </TableCell>
                                                <TableCell>
                                                    {humanFileSize(server.processFreeMemory, true)}
                                                </TableCell>
                                                <TableCell>
                                                    {(server.systemCpuLoad * 100).toFixed(2)} %
                                                </TableCell>
                                                <TableCell>
                                                    {server.running
                                                        ? <IconButton
                                                            disabled={!canControlBackgroundJobServers}
                                                            onClick={() => pauseProcessing(server)}
                                                            size="large">
                                                            <StyledCogClockwise/>
                                                        </IconButton>
                                                        : <IconButton
                                                            disabled={!canControlBackgroundJobServers}
                                                            onClick={() => resumeProcessing(server)}
                                                            size="large">
                                                            <CogPauseOutline/>
                                                        </IconButton>
                                                    }
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </>
                    }
                </Paper>
                <VersionFooter/>
            </>

            {currentServer &&
                <Dialog fullWidth={true} maxWidth="sm" scroll="paper" onClose={handleClose}
                        aria-labelledby="customized-dialog-title" open={true}>
                    <MuiDialogTitle id="customized-dialog-title" onClose={handleClose}>
                        Server info <code>{currentServer.id}</code>
                    </MuiDialogTitle>
                    <MuiDialogContent dividers>
                        <TableContainer>
                            <Table style={{width: "100%"}} aria-label="simple table">
                                <TableBody>
                                    <TableRow>
                                        <TableCell>
                                            Name
                                        </TableCell>
                                        <TableCell>
                                            {currentServer.name}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell style={{verticalAlign: 'top'}}>
                                            Server Tags
                                        </TableCell>
                                        <TableCell>
                                            {[...currentServer.serverTags].sort().map(serverTag => <span
                                                key={serverTag}>{serverTag},<br/></span>)}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            WorkerPoolSize
                                        </TableCell>
                                        <TableCell>
                                            {currentServer.workerPoolSize}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            PollIntervalInSeconds
                                        </TableCell>
                                        <TableCell>
                                            {currentServer.pollIntervalInSeconds}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            FirstHeartbeat
                                        </TableCell>
                                        <TableCell>
                                            <TimeAgo date={new Date(currentServer.firstHeartbeat)}
                                                     title={new Date(currentServer.firstHeartbeat).toString()}/>
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            LastHeartbeat
                                        </TableCell>
                                        <TableCell>
                                            <TimeAgo date={new Date(currentServer.lastHeartbeat)}
                                                     title={new Date(currentServer.lastHeartbeat).toString()}/>
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            SystemTotalMemory
                                        </TableCell>
                                        <TableCell>
                                            {humanFileSize(currentServer.systemTotalMemory, true)}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            SystemFreeMemory
                                        </TableCell>
                                        <TableCell>
                                            {humanFileSize(currentServer.systemFreeMemory, true)}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            SystemCpuLoad
                                        </TableCell>
                                        <TableCell>
                                            {(currentServer.systemCpuLoad * 100).toFixed(2)} %
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            ProcessFreeMemory
                                        </TableCell>
                                        <TableCell>
                                            {humanFileSize(currentServer.processFreeMemory, true)}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            ProcessAllocatedMemory
                                        </TableCell>
                                        <TableCell>
                                            {humanFileSize(currentServer.processAllocatedMemory, true)}
                                        </TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>
                                            ProcessCpuLoad
                                        </TableCell>
                                        <TableCell>
                                            {(currentServer.processCpuLoad * 100).toFixed(2)} %
                                        </TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </MuiDialogContent>
                </Dialog>
            }
            {apiStatus &&
                <Snackbar open={true} autoHideDuration={3000} onClose={handleCloseAlert}
                          anchorOrigin={{vertical: "bottom", horizontal: "center"}}>
                    <Alert severity={apiStatus.severity}>
                        {apiStatus.message}
                    </Alert>
                </Snackbar>
            }
        </div>
    );
});

export default Servers;