export const AWAITING = "AWAITING";
export const SCHEDULED = "SCHEDULED";
export const ENQUEUED = "ENQUEUED";
export const PROCESSING = "PROCESSING";
export const PROCESSED = "PROCESSED";
export const SUCCEEDED = "SUCCEEDED";
export const FAILED = "FAILED";
export const DELETED = "DELETED";