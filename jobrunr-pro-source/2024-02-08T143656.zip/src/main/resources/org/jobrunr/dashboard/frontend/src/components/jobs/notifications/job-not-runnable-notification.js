import {useEffect, useState} from "react";
import {Link} from "react-router-dom";
import serversState from "../../../ServersStateContext";
import {prefixWithPublicUrl} from "../../../utils/helper-functions";
import {JobNotification} from "./job-notification";

const JobNotRunnableNotification = ({job}) => {
    const [displayNotification, setDisplayNotification] = useState(false);
    const [servers, setServers] = useState(serversState.getServers());
    const [serverTags, setServerTags] = useState([]);

    useEffect(() => {
        serversState.addListener(setServers);
        const allServerTags = servers.flatMap(server => server.serverTags).sort();
        setServerTags(allServerTags);

        if (!servers.flatMap(server => server.serverTags).includes(job.serverTag)) {
            setDisplayNotification(true);
        }

        return () => serversState.removeListener(setServers);
    }, [job.serverTag, servers]);


    return (
        <>{displayNotification &&
            <JobNotification severity="error">
                <strong>Job will not be executed!</strong>&nbsp;This job will not be executed as no
                BackgroundJobServer has a serverTag '{job.serverTag}'.
                The available serverTags are {serverTags.map(s => `'${s}'`).join(', ')}.<br/>More info about the
                BackgroundJobServer(s) and their
                serverTags can be found on the <Link
                to={prefixWithPublicUrl(`/servers`)}>servers</Link> tab of the dashboard.
            </JobNotification>
        }
        </>
    )
};

export default JobNotRunnableNotification;