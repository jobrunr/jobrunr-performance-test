import {AWAITING, DELETED, ENQUEUED, FAILED, PROCESSED, PROCESSING, SCHEDULED, SUCCEEDED} from "./state-names";

export function jobStateToHumanReadableName(jobState) {
    switch (jobState.toUpperCase()) {
        case AWAITING:
            return 'pending jobs';
        case SCHEDULED:
            return 'scheduled jobs';
        case ENQUEUED:
            return 'enqueued jobs';
        case PROCESSING:
            return 'jobs in progress';
        case PROCESSED:
            return 'jobs in progress';
        case SUCCEEDED:
            return 'succeeded jobs';
        case FAILED:
            return 'failed jobs';
        case DELETED:
            return 'deleted jobs';
        default:
            return 'Unknown state'
    }
}

export function jobStateToHumanReadableTitle(jobState) {
    switch (jobState.toUpperCase()) {
        case AWAITING:
            return 'Pending jobs';
        case SCHEDULED:
            return 'Scheduled jobs';
        case ENQUEUED:
            return 'Enqueued jobs';
        case PROCESSING:
            return 'Jobs being processed';
        case PROCESSED:
            return 'Jobs being processed';
        case SUCCEEDED:
            return 'Succeeded jobs';
        case FAILED:
            return 'Failed jobs';
        case DELETED:
            return 'Deleted jobs';
        default:
            return 'Unknown state'
    }
}

export function batchJobStateToHumanReadableTitle(jobState) {
    switch (jobState.toUpperCase()) {
        case AWAITING:
            return 'Batch jobs waiting for other jobs to succeed';
        case SCHEDULED:
            return 'Scheduled batch jobs';
        case ENQUEUED:
            return 'Enqueued batch jobs';
        case PROCESSING:
            return 'Batch jobs being processed';
        case PROCESSED:
            return 'Batch jobs being processed';
        case SUCCEEDED:
            return 'Succeeded batch jobs';
        case FAILED:
            return 'Failed batch jobs';
        case DELETED:
            return 'Deleted batch jobs';
        default:
            return 'Unknown state'
    }
}

export const getJobFirstState = (job) => job?.jobHistory[0];
const getJobPreviousState = (job) => job?.jobHistory[job.jobHistory.length - 2];
const getJobMostRecentState = (job) => job?.jobHistory[job.jobHistory.length - 1];
export {getJobPreviousState, getJobMostRecentState};

export const getExceptionSimpleClassName = (exceptionType) => exceptionType.split('.').pop();
export const getShortJobSignature = (jobSignature) => {
    const shortenedClassNameAndMethodName = shortenJobSignatureClassNameAndMethodName(jobSignature);
    const shortenedParameterTypes = shortenJobSignatureParameterTypes(jobSignature);
    return `${shortenedClassNameAndMethodName}(${shortenedParameterTypes})`;
}
export const getShortJobExceptionType = (jobExceptionType) => {
    const {packageNames, classAndMethodNames} = separatePackageNamesFromClassAndMethodNames(jobExceptionType);
    return `${shortenPackageNames(packageNames)}(${classAndMethodNames})`;
}
export const getProgressBar = (job) => {
    let progressBar = undefined;
    for (let key in job.metadata) {
        if (key.indexOf('jobRunrDashboardProgressBar-') > -1) {
            progressBar = job.metadata[key];
        }
    }
    return progressBar;
}

export const getJobProcessDuration = (job) => {
    const jobState = getJobMostRecentState(job);
    const stateName = jobState.state;
    if ([FAILED, SUCCEEDED].includes(stateName)) return jobState.processDuration;
    if (stateName === DELETED) {
        const previousState = getJobPreviousState(job);
        return previousState?.processDuration;
    }
}

export const getJobLatencyDuration = (job) => {
    const jobState = getJobMostRecentState(job);
    const stateName = jobState.state;
    if ([FAILED, SUCCEEDED].includes(stateName)) return jobState.latencyDuration;
    if (stateName === DELETED) {
        const previousState = getJobPreviousState(job);
        if (previousState.state === PROCESSING) {
            return getEnqueuedToProcessingLatency(
                previousState,
                job?.jobHistory[job.jobHistory.length - 3]
            );
        }
        return previousState?.latencyDuration;
    }
    if (stateName === PROCESSING) return getEnqueuedToProcessingLatency(jobState, getJobPreviousState(job));
}

const getEnqueuedToProcessingLatency = (processingState, enqueuedState) => {
    if (enqueuedState.state !== ENQUEUED) return;
    return (new Date(processingState.createdAt).getTime() - new Date(enqueuedState.createdAt).getTime()) / 1000
}

const shortenJobSignatureClassNameAndMethodName = (jobSignature) => {
    const openingParenthesisIndex = jobSignature.indexOf('(');
    const classAndMethodName = jobSignature.substring(0, openingParenthesisIndex);

    const {packageNames, classAndMethodNames} = separatePackageNamesFromClassAndMethodNames(classAndMethodName);
    const shortenedPackageNames = shortenPackageNames(packageNames);

    if (!shortenedPackageNames) return classAndMethodName;

    return `${shortenedPackageNames}.${classAndMethodNames}`;
}

const shortenJobSignatureParameterTypes = (jobSignature) => {
    const openingParenthesisIndex = jobSignature.indexOf('(');
    const parameterTypes = jobSignature.substring(openingParenthesisIndex + 1, jobSignature.length - 1)
        .split(", ").map(shortenParameterType);

    return parameterTypes.join(", ");
}

const shortenParameterType = (parameterType) => {
    if (!parameterType) return "";
    const {packageNames, classAndMethodNames} = separatePackageNamesFromClassAndMethodNames(parameterType);
    const shortenedPackageNames = shortenPackageNames(packageNames);
    if (!shortenedPackageNames) return classAndMethodNames;
    return `${shortenedPackageNames}.${classAndMethodNames}`;
}

const shortenPackageNames = (packageNames) => {
    return packageNames.split(".").map(x => x[0]).join(".")
}

const separatePackageNamesFromClassAndMethodNames = (string) => {
    const classNamePosition = findFirstUppercaseCharacterPosition(string);
    return {
        packageNames: string.substring(0, classNamePosition - 1),
        classAndMethodNames: string.substring(classNamePosition)
    };
}

const findFirstUppercaseCharacterPosition = (string) => {
    return /[A-Z]/.exec(string)?.index ?? 0;
}