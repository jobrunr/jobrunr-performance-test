import {useCallback, useEffect, useMemo, useState} from 'react';
import {useLocation} from "react-router-dom";
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Box from "@mui/material/Box";
import LoadingIndicator from "../LoadingIndicator";
import JobsTable from "./jobs-table";
import {jobStateToHumanReadableTitle} from "../utils/job-utils";
import VersionFooter from "../utils/version-footer";
import JobsFilterPanel from "./jobs-filter-panel";
import {prefixWithContextPath} from "../../utils/helper-functions";
import {ENQUEUED, FAILED, SUCCEEDED} from "../utils/state-names";


const JobsView = () => {
    const location = useLocation();

    const urlSearchParams = new URLSearchParams(location.search);
    const page = urlSearchParams.get('page');
    const jobState = urlSearchParams.get('state') ?? ENQUEUED;
    const queuePriority = urlSearchParams.get('priority');
    const itemsPerPage = urlSearchParams.get('itemsPerPage') || 20;
    const [isLoadingJobs, setIsLoadingJobs] = useState(true);
    const [jobPage, setJobPage] = useState({total: 0, limit: itemsPerPage, currentPage: 0, items: []});
    const [jobPageWithoutState, setJobPageWithoutState] = useState({
        total: 0,
        limit: itemsPerPage,
        currentPage: 0,
        items: []
    });
    const [jobSignatures, setJobSignatures] = useState({});
    const [jobExceptionTypes, setJobExceptionTypes] = useState({})
    const [isLoadingJobSignaturesAndExceptionTypes, setIsLoadingJobSignaturesAndExceptionTypes] = useState(true);
    const [sortedField, setSortedField] = useState()

    const loadJobSignatureAndJobExceptionTypes = useCallback(async () => {
        const jobSignatureFacetParams = new URLSearchParams(location.search);
        const jobExceptionTypeParams = new URLSearchParams(location.search);
        jobSignatureFacetParams.delete('jobSignature');
        jobExceptionTypeParams.delete('jobExceptionType');

        if (!jobSignatureFacetParams.has('state')) {
            jobSignatureFacetParams.set('state', ENQUEUED);
            jobExceptionTypeParams.set('state', ENQUEUED);
        }

        try {
            const [jobSignatures, jobExceptionTypes] = await Promise.all([
                fetch(prefixWithContextPath(`/api/job-signatures?${jobSignatureFacetParams}`)).then(res => res.json()),
                jobExceptionTypeParams.get("state") === FAILED ?
                    fetch(prefixWithContextPath(`/api/job-exception-types?${jobExceptionTypeParams}`)).then(res => res.json()) : {},
            ])
            setJobSignatures(jobSignatures);
            setJobExceptionTypes(jobExceptionTypes);
        } catch (error) {
            console.log('Error retrieving job signatures and exception types', error);
        }
    }, [location.search])

    useEffect(() => {
        setIsLoadingJobSignaturesAndExceptionTypes(true);
        loadJobSignatureAndJobExceptionTypes().finally(() => setIsLoadingJobSignaturesAndExceptionTypes(false));
    }, [loadJobSignatureAndJobExceptionTypes]);

    const defaultSort = useMemo(() => {
        switch (jobState.toUpperCase()) {
            case ENQUEUED:
                return 'priority:ASC,updatedAt:ASC';
            case SUCCEEDED:
            case FAILED:
                return 'updatedAt:DESC';
            default:
                return 'updatedAt:ASC';
        }
    }, [jobState])

    const sort = urlSearchParams.has('sort') ? urlSearchParams.get('sort') : defaultSort;

    useEffect(() => {
        setIsLoadingJobs(true);
        const offset = (page) * itemsPerPage;
        const limit = itemsPerPage;
        const apiSearchParams = new URLSearchParams();
        for (let key of urlSearchParams.keys()) {
            if (key.endsWith('!')) {
                apiSearchParams.set(key.slice(0, -1), urlSearchParams.get(key));
            } else {
                apiSearchParams.set(key, urlSearchParams.get(key));
            }
        }
        apiSearchParams.set('offset', offset);
        apiSearchParams.set('limit', limit);
        apiSearchParams.set('order', sort);
        apiSearchParams.set('state', jobState);
        fetch(prefixWithContextPath(`/api/jobs?${apiSearchParams.toString()}`))
            .then(response => response.json())
            .then(response => {
                setJobPage(response);
                setIsLoadingJobs(false);
                if (response.total < 1) {
                    let apiWithoutStateSearchParams = new URLSearchParams(apiSearchParams.toString());
                    apiWithoutStateSearchParams.delete('state');
                    apiWithoutStateSearchParams.set("offset", 0);
                    apiWithoutStateSearchParams.set("limit", 20);
                    apiWithoutStateSearchParams.set("order", sort);
                    fetch(prefixWithContextPath(`/api/jobs?${apiWithoutStateSearchParams.toString()}`))
                        .then(res => res.json())
                        .then(response => {
                            setJobPageWithoutState(response);
                        })
                        .catch(error => console.log(error));
                }
            })
            .catch(error => {
                console.log(error);
                window.location.reload();
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, jobState, sort, queuePriority, location.key]);

    useEffect(() => {
        setSortedField(undefined)
    }, [jobState]);

    const isLoading = isLoadingJobs || isLoadingJobSignaturesAndExceptionTypes;

    return (
        <main style={{width: '100%', overflowX: "hidden"}}>
            <Box my={1} style={{marginBottom: '1rem'}}>
                <Typography id="title" variant="h4">{jobStateToHumanReadableTitle(jobState)}</Typography>
            </Box>
            {isLoading
                ? <LoadingIndicator/>
                :
                <>
                    <JobsFilterPanel jobSignatures={jobSignatures} jobExceptionTypes={jobExceptionTypes}/>
                    <div>&nbsp;</div>
                    <Paper>
                        <JobsTable
                            jobPage={jobPage}
                            jobPageWithoutState={jobPageWithoutState}
                            jobState={jobState}
                            defaultSort={defaultSort}
                            sortedField={sortedField}
                            onSortChange={setSortedField}
                        />
                    </Paper>
                    <VersionFooter/>
                </>
            }
        </main>
    );
};

export default JobsView;