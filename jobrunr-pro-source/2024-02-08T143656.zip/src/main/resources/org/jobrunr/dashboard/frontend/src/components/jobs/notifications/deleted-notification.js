import TimeAgo from "react-timeago/lib";
import {JobNotification} from "./job-notification";

const DeletedNotification = ({job}) => {
    const deleteDate = job.deleteAt;

    return (
        <>
            {deleteDate &&
                <JobNotification>
                    <strong>This job is deleted.</strong> It will automatically be removed in <TimeAgo
                    date={new Date(deleteDate)} title={deleteDate.toString()}/>.
                </JobNotification>
            }
        </>
    )
};

export default DeletedNotification;