import {DataGrid as MuiDataGrid, gridClasses, GridToolbar} from '@mui/x-data-grid';
import {styled} from "@mui/material/styles";

const StyledDataGrid = styled(MuiDataGrid)(() => ({
    border: "none",
    [`& .${gridClasses.columnHeaderTitle}`]: {
        fontWeight: 'bold'
    },
    [`& .${gridClasses.row}`]: {
        backgroundColor: 'transparent!important'
    },
    [`& .${gridClasses.columnHeader}, & .${gridClasses.cell}`]: {
        outline: 'transparent'
    },
    [`& .${gridClasses.columnHeader}:focus-within, & .${gridClasses.cell}:focus-within`]: {
        outline: 'none'
    }
}));

const CustomToolbar = ({actionsComponent: Actions, actionsProps, ...rest}) => {
    return (
        <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            minHeight: "60px"
        }}>
            {Actions ? <Actions {...actionsProps} /> : <div></div>}
            <GridToolbar style={{margin: '1rem 1rem -0.5rem 0'}} {...rest}/>
        </div>
    );
}

export const DataGrid = ({
                             rows,
                             columns,
                             initialSortModel,
                             handleSortModelChange,
                             handlePaginationModelChange,
                             actionsComponent,
                             actionsProps,
                             ...rest
                         }) => {
    const onSortModelChange = (sortModel) => {
        handleSortModelChange(sortModel[0]);
    }

    return (
        <StyledDataGrid
            rows={rows}
            columns={columns}
            sortingOrder={['desc', 'asc']}
            sortingMode="server"
            onSortModelChange={onSortModelChange}
            sortModel={initialSortModel}
            paginationMode="server"
            onPaginationModelChange={handlePaginationModelChange}
            initialState={{
                pagination: {
                    paginationModel: {pageSize: 20},
                },
            }}
            disableRowSelectionOnClick
            pageSizeOptions={[20, 50, 100]}
            disableColumnFilter
            disableDensitySelector
            slots={{
                toolbar: CustomToolbar,
            }}
            slotProps={{
                toolbar: {
                    printOptions: {disableToolbarButton: true},
                    csvOptions: {disableToolbarButton: true},
                    actionsProps,
                    actionsComponent
                },
                footer: {id: "jobs-table-pagination"}
            }}
            {...rest}
        />
    );
}