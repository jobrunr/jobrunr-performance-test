import TimeAgo from "react-timeago/lib";
import {JobNotification} from "./job-notification";

const SucceededNotification = ({job}) => {
    const deleteDate = job.deleteAt;

    return (
        <>
            {deleteDate &&
                <JobNotification>
                    <strong>This job has succeeded.</strong> It will automatically go to the deleted state in <TimeAgo
                    date={new Date(deleteDate)} title={deleteDate.toString()}/>.
                </JobNotification>
            }
        </>
    )
};

export default SucceededNotification;