import {useEffect, useState} from 'react';
import {useLocation, useNavigate} from "react-router-dom";
import Typography from '@mui/material/Typography';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Autocomplete,
    Box,
    Checkbox,
    Chip,
    FormControl,
    FormControlLabel,
    Grid,
    InputLabel,
    MenuItem,
    Select,
    TextField
} from "@mui/material";
import {styled} from "@mui/material/styles";
import {ExpandMoreOutlined} from "@mui/icons-material";
import {DeleteForever, LockOpenVariantOutline, LockOutline} from "mdi-material-ui";
import priorityQueuesState from "../../PriorityQueuesStateContext";
import SearchField from "../utils/search-field";
import serversState from "../../ServersStateContext";
import {DateTimePicker} from "../ui/DateTimePicker";
import {getShortJobExceptionType, getShortJobSignature} from "../utils/job-utils";

const Heading = styled(Typography)(({theme}) => ({
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '8%',
    flexShrink: 0,
    margin: theme.spacing(1)
}))

const SecondaryHeading = styled("div")(({theme}) => ({
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary
}))

const NoFiltersSelected = styled("span")(({theme}) => ({
    display: 'inline-block',
    margin: theme.spacing(1)
}));

const ExtendedChip = (props) => <Chip {...props} size="small" style={{marginLeft: "8px"}}/>

const JobsFilterPanel = ({jobSignatures, jobExceptionTypes}) => {
    const location = useLocation();
    const navigate = useNavigate();

    const priorityQueues = priorityQueuesState.usePriorityQueues();
    const [servers, setServers] = useState(serversState.getServers());
    const isFailedJobsView = new URLSearchParams(location.search).get("state") === "FAILED";

    useEffect(() => {
        serversState.addListener(setServers);
        return () => serversState.removeListener(setServers);
    }, []);

    const urlSearchParams = new URLSearchParams(location.search);

    const setFilter = (filterName, filterValue, hasError) => {
        urlSearchParams.delete('action');
        let actualFilterName = filterName;
        if (urlSearchParams.has(filterName + "!")) actualFilterName = filterName + "!";
        if (filterValue !== null && filterValue !== undefined) {
            if (hasError) {
                urlSearchParams.delete(actualFilterName);
                urlSearchParams.set(actualFilterName + 'Error', true);
            } else {
                urlSearchParams.set(actualFilterName, filterValue);
                urlSearchParams.delete(actualFilterName + 'Error');
            }

            navigate(`?${urlSearchParams.toString()}`);
        } else {
            removeFilter(actualFilterName);
        }
    }

    const setDateFilter = (filterName, filterValue) => {
        let parsedDate = Date.parse(filterValue);
        if (!isNaN(parsedDate)) {
            filterValue.setUTCSeconds(0, 0);
            setFilter(filterName, filterValue.toISOString());
        }
    }

    const getFilterValue = (filterName, defaultValueIfNotFound = '') => {
        if (urlSearchParams.has(filterName)) return urlSearchParams.get(filterName);
        if (urlSearchParams.has(filterName + '!')) return urlSearchParams.get(filterName + '!');
        return defaultValueIfNotFound;
    }

    const removeFilter = (filterName) => {
        urlSearchParams.delete('action');
        const actualFilterName = urlSearchParams.has(filterName + '!') ? filterName + '!' : filterName;
        urlSearchParams.delete(actualFilterName);
        navigate(`?${urlSearchParams.toString()}`);
    }

    const toggleFilterLock = (filterName) => {
        const value = urlSearchParams.get(filterName);
        if (filterName.endsWith('!')) {
            urlSearchParams.delete(filterName);
            urlSearchParams.set(filterName.slice(0, -1), value);
        } else {
            urlSearchParams.delete(filterName);
            urlSearchParams.set(filterName + '!', value);
        }
        navigate(`?${urlSearchParams.toString()}`);
    }

    const isInvalidUUID = (value) => {
        return value.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i) === null;
    }

    const getActiveFilters = () => {
        const labelMapping = (urlParam) => {
            const actualUrlParam = urlParam.endsWith('!') ? urlParam.slice(0, -1) : urlParam;
            switch (actualUrlParam) {
                case 'jobId':
                    return `Job id: ${urlSearchParams.get(urlParam)}`;
                case 'jobName':
                    return `Job name: ${urlSearchParams.get(urlParam)}`;
                case 'rateLimiter':
                    return `Rate limiter: ${urlSearchParams.get(urlParam)}`;
                case 'label':
                    return `Label: ${urlSearchParams.get(urlParam)}`;
                case 'recurringJobId':
                    return `Recurring job id: ${urlSearchParams.get(urlParam)}`;
                case 'jobFingerprint':
                    return `Job fingerprint: ${urlSearchParams.get(urlParam)}`;
                case 'jobSignature':
                    return `Job signature: ${urlSearchParams.get(urlParam)}`;
                case 'jobExceptionType':
                    return `Job exception type: ${urlSearchParams.get(urlParam)}`;
                case 'priority':
                    return `Job queue: ${priorityQueues[urlSearchParams.get(urlParam)]}`;
                case 'serverTag':
                    return `Server tag: ${urlSearchParams.get(urlParam)}`;
                case 'awaitingOn':
                    return `Awaiting on: ${urlSearchParams.get(urlParam)}`;
                case 'createdAtFrom':
                    return `Created after: ${urlSearchParams.get(urlParam)}`;
                case 'createdAtTo':
                    return `Created before: ${urlSearchParams.get(urlParam)}`;
                case 'updatedAtFrom':
                    return `Updated after: ${urlSearchParams.get(urlParam)}`;
                case 'updatedAtTo':
                    return `Updated before: ${urlSearchParams.get(urlParam)}`;
                case 'onlyBatchJobs':
                    return urlSearchParams.get(urlParam) === 'true' ? "Batch jobs only" : "Non batch jobs only";
                default:
                    return "Unknown filter";
            }
        }

        const lockIcon = (key) => {
            if (key.endsWith('!')) return (<LockOutline/>);
            return (<LockOpenVariantOutline/>);
        }

        let filterKeys = Array.from(urlSearchParams.keys())
            .filter(key => !['state', 'page', 'queuePriority', 'itemsPerPage', 'action', 'sort'].includes(key));

        return (
            <>
                {filterKeys.length > 0
                    ? <>
                        {filterKeys.map((key) => (
                            <Chip key={key}
                                  icon={lockIcon(key)}
                                  label={labelMapping(key)}
                                  onClick={(evt) => {
                                      toggleFilterLock(key);
                                      evt.stopPropagation();
                                  }}
                                  onDelete={() => removeFilter(key)}
                                  deleteIcon={<DeleteForever/>}
                                  sx={{margin: 0.5}}
                            />
                        ))}
                    </>
                    : <NoFiltersSelected>No filters selected</NoFiltersSelected>
                }
            </>
        )
    }

    return (
        <Accordion>
            <AccordionSummary
                expandIcon={<ExpandMoreOutlined/>}
                aria-controls="job-filter-panel-content"
                id="job-filter-panel-header"
            >
                <Heading>Filters</Heading>
                <SecondaryHeading>{getActiveFilters()}</SecondaryHeading>
            </AccordionSummary>
            <AccordionDetails>
                <Grid container>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3} style={{marginBottom: '1em'}}>
                        <Grid item xs={4}>
                            <SearchField id="job-name" label="Job name" defaultValue={getFilterValue('jobName')}
                                         onSearch={value => setFilter('jobName', value)}/>
                        </Grid>
                        <Grid item xs={4}>
                            <SearchField id="job-id" label="Job id" defaultValue={getFilterValue('jobId')}
                                         onSearch={value => setFilter('jobId', value)}/>
                        </Grid>
                        <Grid item xs={4}>
                            <SearchField id="job-id" label="Rate limiter" defaultValue={getFilterValue('rateLimiter')}
                                         onSearch={value => setFilter('rateLimiter', value)}/>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3} style={{marginBottom: '1em'}}>
                        <Grid item xs={isFailedJobsView ? 4 : 6}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <Autocomplete
                                    disablePortal
                                    id="job-signature-select"
                                    value={getFilterValue('jobSignature', null)}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params} label="Job signature"
                                            variant="standard"
                                            id="job-signature-select-label"
                                        />
                                    )}
                                    onChange={(event, newValue) => {
                                        setFilter('jobSignature', newValue?.[0])
                                    }}
                                    options={Object.entries(jobSignatures)}
                                    renderOption={(props, [jobSignature, amountOfJobs]) => (
                                        <Box component="li" {...props}>
                                            {getShortJobSignature(jobSignature)}
                                            <ExtendedChip label={amountOfJobs + " jobs"}/>
                                        </Box>
                                    )}
                                    getOptionLabel={(option) => Array.isArray(option) ? option[0] : option}
                                    isOptionEqualToValue={(option, value) => option[0] === value}
                                    slotProps={{
                                        popper: {
                                            placement: 'bottom-start',
                                            style: {minWidth: "100%", width: "fit-content"}
                                        }
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        {isFailedJobsView && (
                            <Grid item xs={4}>
                                <FormControl variant="standard" style={{width: '100%'}}>
                                    <Autocomplete
                                        disablePortal
                                        id="job-exception-select"
                                        value={getFilterValue('jobExceptionType', null)}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params} label="Job exception type"
                                                variant="standard"
                                                id="job-exception-select-label"
                                            />
                                        )}
                                        onChange={(event, newValue) => {
                                            setFilter('jobExceptionType', newValue?.[0])
                                        }}
                                        options={Object.entries(jobExceptionTypes)}
                                        renderOption={(props, [jobExceptionType, amountOfJobs]) => (
                                            <Box component="li" {...props}>
                                                {getShortJobExceptionType(jobExceptionType)}
                                                <ExtendedChip label={amountOfJobs + " jobs"}/>
                                            </Box>
                                        )}
                                        getOptionLabel={(option) => Array.isArray(option) ? option[0] : option}
                                        isOptionEqualToValue={(option, value) => option[0] === value}
                                        slotProps={{
                                            popper: {
                                                placement: 'bottom-start',
                                                style: {minWidth: "100%", width: "fit-content"}
                                            }
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                        )}
                        <Grid item xs={isFailedJobsView ? 4 : 6}>
                            <SearchField id="job-fingerprint" label="Job fingerprint"
                                         defaultValue={getFilterValue('jobFingerprint')}
                                         onSearch={value => setFilter('jobFingerprint', value)}/>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3} style={{marginBottom: '1em'}}>
                        <Grid item xs={3}>
                            <SearchField id="recurring-job-id" label="Recurring job id"
                                         defaultValue={getFilterValue('recurringJobId')}
                                         onSearch={value => setFilter('recurringJobId', value)}/>
                        </Grid>
                        <Grid item xs={3}>
                            <SearchField id="awaiting-on-job-id" label="Awaiting on id"
                                         defaultValue={getFilterValue('awaitingOn')}
                                         onSearch={value => setFilter('awaitingOn', value, isInvalidUUID(value))}
                                         hasError={urlSearchParams.has('awaitingOnError')}
                                         errorText="Not a valid UUID"/>
                        </Grid>
                        <Grid item xs={2}>
                            <SearchField id="job-label" label="Job label" defaultValue={getFilterValue('label')}
                                         onSearch={value => setFilter('label', value)}/>
                        </Grid>
                        <Grid item xs={2}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <InputLabel id="queue-select-label">Queue</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="queue-select-label"
                                    id="queue-select"
                                    value={getFilterValue('priority')}
                                    onChange={ev => setFilter('priority', ev.target.value)}>
                                    {priorityQueues.map((queue, index) => (
                                        <MenuItem key={index} value={index}>{queue}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <InputLabel id="server-tags-select-label">Server tag</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="server-tags-select-label"
                                    id="server-tags-select"
                                    value={getFilterValue('serverTag')}
                                    onChange={ev => setFilter('serverTag', ev.target.value)}>
                                    {servers.flatMap(server => server.serverTags).map((serverTag, index) => (
                                        <MenuItem key={index} value={serverTag}>{serverTag}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3}>
                        <Grid item xs={2.4}>
                            <DateTimePicker
                                label="Created after"
                                maxDate={getFilterValue('createdAtTo', null)}
                                value={getFilterValue('createdAtFrom', null)}
                                onChange={value => setDateFilter('createdAtFrom', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('createdAtFrom')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={2.4}>
                            <DateTimePicker
                                label="Created before"
                                minDate={getFilterValue('createdAtFrom', null)}
                                value={getFilterValue('createdAtTo', null)}
                                onChange={value => setDateFilter('createdAtTo', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('createdAtTo')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={2.4}>
                            <DateTimePicker
                                label="Updated after"
                                maxDate={getFilterValue('updatedAtTo', null)}
                                value={getFilterValue('updatedAtFrom', null)}
                                onChange={value => setDateFilter('updatedAtFrom', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('updatedAtFrom')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={2.4}>
                            <DateTimePicker
                                label="Updated before"
                                minDate={getFilterValue('updatedAtFrom', null)}
                                value={getFilterValue('updatedAtTo', null)}
                                onChange={value => setDateFilter('updatedAtTo', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('updatedAtTo')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={2.4}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <FormControlLabel
                                    style={{paddingTop: '0.75em', color: 'rgba(0, 0, 0, 0.54)'}}
                                    control={
                                        <Checkbox
                                            id="batch-jobs-only-checkbox"
                                            onChange={e => {
                                                const onlyBatchJobs = getFilterValue("onlyBatchJobs");
                                                if (onlyBatchJobs === 'true') {
                                                    setFilter('onlyBatchJobs', 'false');
                                                } else if (onlyBatchJobs === 'false') {
                                                    removeFilter('onlyBatchJobs');
                                                } else {
                                                    setFilter('onlyBatchJobs', 'true');
                                                }
                                            }}
                                            checked={getFilterValue("onlyBatchJobs") === "true"}
                                            indeterminate={!getFilterValue("onlyBatchJobs")}
                                        />
                                    }
                                    label="Batch jobs only"
                                />
                            </FormControl>
                        </Grid>
                    </Grid>
                </Grid>

            </AccordionDetails>
        </Accordion>
    );
};

export default JobsFilterPanel;