import {DesktopDateTimePicker} from "@mui/x-date-pickers";
import {renderTimeViewClock} from '@mui/x-date-pickers/timeViewRenderers';
import {isEqual, isValid, parse} from "date-fns";

export const DateTimePicker = ({minDate, maxDate, value, format, onChange, ...rest}) => {
    const dateTimeFormat = format || "yyyy/MM/dd HH:mm";
    const currentDate = value && new Date(value);
    const onBlur = ({target}) => {
        const date = parse(target.value, dateTimeFormat, new Date());
        if (isValid(date) && !isEqual(currentDate, date)) onChange(date);
    }
    return (
        <DesktopDateTimePicker
            ampm={false}
            closeOnSelect={false}
            onAccept={onChange}
            slotProps={{
                textField: {variant: "standard", onBlur: onBlur},
                actionBar: {actions: ['today', 'cancel', 'accept']}
            }}
            viewRenderers={{
                hours: renderTimeViewClock,
                minutes: renderTimeViewClock,
            }}
            minDateTime={minDate && new Date(minDate)}
            maxDateTime={maxDate && new Date(maxDate)}
            value={currentDate}
            format={dateTimeFormat}
            {...rest}  />
    )
};