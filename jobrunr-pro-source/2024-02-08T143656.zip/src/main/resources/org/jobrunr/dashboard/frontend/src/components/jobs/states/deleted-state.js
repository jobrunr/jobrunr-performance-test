import {JobState} from "./job-state";

const Deleted = ({jobState}) => {
    return (
        <JobState
            title="Job deleted"
            state="deleted"
            date={jobState.createdAt}
            canExpand={!!jobState.reason}
        >
            {jobState.reason &&
                <div>{jobState.reason}
                    {(jobState.user && jobState.user.email) &&
                        <> (by <a href={`mailto:${jobState.user.email}`}>{jobState.user.email}</a>)</>
                    }
                </div>
            }
        </JobState>
    )
};

export default Deleted;