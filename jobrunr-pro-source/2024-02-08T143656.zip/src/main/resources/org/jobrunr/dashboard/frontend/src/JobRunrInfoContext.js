import {createContext} from 'react';

export const JobRunrInfoContext = createContext({
    version: '0.0.0-SNAPSHOT',
    clusterId: undefined,
    storageProviderType: undefined
});