import MuiDialogTitle from "@mui/material/DialogTitle";
import MuiDialogContent from "@mui/material/DialogContent";
import MuiDialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";

const DeleteDialog = ({handleDelete, handleClose, open = false, children}) => {
    return (
        <Dialog fullWidth={true} maxWidth="sm" scroll="paper" onClose={handleClose}
                aria-labelledby="customized-dialog-title" open={open}>
            {children}
            <MuiDialogActions>
                <Button onClick={handleClose} color="primary">
                    Cancel
                </Button>
                <Button onClick={handleDelete} color="primary">
                    Delete
                </Button>
            </MuiDialogActions>
        </Dialog>
    )
}

export const DeleteJobDialog = (props) => {
    return (
        <DeleteDialog {...props}>
            <MuiDialogTitle id="customized-dialog-title">
                Delete the job?
            </MuiDialogTitle>
            <MuiDialogContent dividers>
                <p>Are you sure you want to delete the job?</p>
            </MuiDialogContent>
        </DeleteDialog>
    )
}

export const DeleteJobsDialog = ({amount = 0, ...rest}) => {
    return (
        <DeleteDialog {...rest}>
            <MuiDialogTitle id="customized-dialog-title">
                Delete selected jobs?
            </MuiDialogTitle>
            <MuiDialogContent dividers>
                <p>Are you sure you want to delete {amount} job(s)?</p>
            </MuiDialogContent>
        </DeleteDialog>
    )
}

export const DeleteRecurrentJobsDialog = ({all = false, amount = 0, ...rest}) => {
    return (
        <DeleteDialog {...rest}>
            <MuiDialogTitle id="customized-dialog-title">
                Delete selected recurrent jobs?
            </MuiDialogTitle>
            <MuiDialogContent dividers>
                <p>Are you sure you want to delete {all ? <>all selected</> : <>{amount}</>} recurrent job(s)?</p>
            </MuiDialogContent>
        </DeleteDialog>
    )
}