import {useContext, useEffect, useState} from "react";
import ButtonGroup from "@mui/material/ButtonGroup";
import Button from "@mui/material/Button";
import {prefixWithContextPath} from "../../../utils/helper-functions";
import {Alert, FormControlLabel, Snackbar} from "@mui/material";
import {useLocation, useNavigate} from "react-router-dom";
import Checkbox from "@mui/material/Checkbox";
import {DeleteRecurrentJobsDialog} from "../../ui/DeleteDialog";
import {UserContext} from "../../../UserContext";

const RecurringJobActions = (props) => {
    const location = useLocation();
    const navigate = useNavigate();
    const selectedRecurringJobs = props.selectedRecurringJobs;
    const actionsDisabled = selectedRecurringJobs.length < 1;
    const showSelectAllRecurringJobsNotification = props.allRecurringJobsSelected && selectedRecurringJobs.length >= props.pageSize;

    const [allRecurringJobsSelected, setAllRecurringJobsSelected] = useState(false);
    const [apiStatus, setApiStatus] = useState(null);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);

    const urlSearchParams = new URLSearchParams(location.search);
    const action = urlSearchParams.get('action');

    const {authorizationRules: {canControlRecurringJobs, canDeleteRecurringJobs}} = useContext(UserContext);

    useEffect(() => {
        if (action) {
            if (action === 'trigger') {
                setApiStatus({type: 'requeue', severity: 'success', message: 'Successfully triggered recurring jobs'});
            } else if (action === 'pause') {
                setApiStatus({type: 'pause', severity: 'success', message: 'Successfully paused recurring jobs'});
            } else if (action === 'resume') {
                setApiStatus({type: 'resume', severity: 'success', message: 'Successfully resumed recurring jobs'});
            } else if (action === 'delete') {
                setApiStatus({type: 'delete', severity: 'success', message: 'Successfully deleted recurring jobs'});
            } else if (action === 'edit') {
                setApiStatus({type: "edit", severity: 'success', message: 'Successfully edited recurring job'});
            }
        }
    }, [action]);

    const refreshPage = (action) => {
        urlSearchParams.set('action', action);
        navigate(`?${urlSearchParams.toString()}`, {replace: true});
    };

    const handleCloseAlert = () => {
        setApiStatus(null);
    };

    const triggerSelectedRecurringJobs = () => {
        fetch(getRecurringJobApiUrlForSelectedRecurringJobs('/api/recurring-jobs/trigger'), {method: 'POST'})
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({
                        type: 'triggered',
                        severity: 'success',
                        message: 'Successfully triggered recurring jobs'
                    });
                    refreshPage('trigger');
                } else {
                    setApiStatus({
                        type: 'triggered',
                        severity: 'error',
                        message: 'Error triggering recurring jobs - please refresh the page'
                    });
                }
            })
            .catch(error => console.error(error));
    };

    const pauseSelectedRecurringJobs = () => {
        fetch(getRecurringJobApiUrlForSelectedRecurringJobs('/api/recurring-jobs/pause'), {method: 'POST'})
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully paused recurring jobs'
                    });
                    refreshPage('pause');
                } else {
                    setApiStatus({
                        type: 'paused',
                        severity: 'success',
                        message: 'Successfully paused recurring jobs'
                    });
                }
            })
            .catch(error => console.error(error));
    };

    const resumeSelectedRecurringJobs = () => {
        fetch(getRecurringJobApiUrlForSelectedRecurringJobs('/api/recurring-jobs/resume'), {method: 'POST'})
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({
                        type: 'resumed',
                        severity: 'success',
                        message: 'Successfully resumed recurring jobs'
                    });
                    refreshPage('resume');
                } else {
                    setApiStatus({
                        type: 'resumed',
                        severity: 'error',
                        message: 'Error resuming recurring jobs - please refresh the page'
                    });
                }
            })
            .catch(error => console.error(error));
    };

    const deleteSelectedRecurringJobs = () => {
        fetch(getRecurringJobApiUrlForSelectedRecurringJobs('/api/recurring-jobs'), {
            method: 'DELETE',
        })
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({
                        type: 'deleted',
                        severity: 'success',
                        message: 'Successfully deleted recurring jobs'
                    });
                    refreshPage('delete');
                } else {
                    setApiStatus({
                        type: 'delete',
                        severity: 'error',
                        message: 'Error deleting recurring jobs - please refresh the page'
                    });
                }
            })
            .catch(error => console.error(error));
    };

    const getRecurringJobApiUrlForSelectedRecurringJobs = (url) => {
        if (allRecurringJobsSelected) {
            const apiSearchParams = new URLSearchParams(location.search);
            return prefixWithContextPath(`${url}?${apiSearchParams.toString()}`);

        } else {
            const recurringJobIds = selectedRecurringJobs.map(recurringJob => recurringJob.id).join();
            return prefixWithContextPath(`${url}?ids=${recurringJobIds}`);
        }
    };

    const toggleDeleteDialog = () => {
        setShowDeleteDialog(prev => !prev);
    }

    return (
        <>
            <ButtonGroup variant="outlined" style={{margin: '1rem 0 -0.5rem 1rem'}}>
                {canControlRecurringJobs &&
                    <Button disabled={actionsDisabled} color="primary" onClick={triggerSelectedRecurringJobs}>
                        Trigger
                    </Button>
                }
                {canControlRecurringJobs &&
                    <Button disabled={actionsDisabled} color="primary" onClick={pauseSelectedRecurringJobs}>
                        Pause
                    </Button>
                }
                {canControlRecurringJobs &&
                    <Button disabled={actionsDisabled} color="primary" onClick={resumeSelectedRecurringJobs}>
                        Resume
                    </Button>
                }
                {canDeleteRecurringJobs &&
                    <Button disabled={actionsDisabled} color="primary" onClick={toggleDeleteDialog}>
                        Delete
                    </Button>
                }
            </ButtonGroup>
            {showSelectAllRecurringJobsNotification &&
                <FormControlLabel
                    style={{marginLeft: '1rem'}}
                    control={<Checkbox checked={allRecurringJobsSelected}
                                       onChange={(evt) => setAllRecurringJobsSelected(evt.target.checked)}
                                       name="selectAllRecurringJobs"/>}
                    label="Select all jobs on other pages too?"
                />
            }

            {apiStatus &&
                <Snackbar open={true} autoHideDuration={3000} onClose={handleCloseAlert}
                          anchorOrigin={{vertical: "bottom", horizontal: "center"}}>
                    <Alert severity={apiStatus.severity}>
                        {apiStatus.message}
                    </Alert>
                </Snackbar>
            }

            <DeleteRecurrentJobsDialog
                open={showDeleteDialog}
                handleClose={toggleDeleteDialog}
                handleDelete={deleteSelectedRecurringJobs}
                all={showSelectAllRecurringJobsNotification} amount={selectedRecurringJobs.length}/>
        </>
    )
}

export default RecurringJobActions;