import {JobState} from "./job-state";


const EnqueuedChildJobs = ({jobState}) => {
    return (
        <JobState state="enqueued-child" title="Enqueueing child jobs" date={jobState.createdAt} canExpand={false}/>
    )
};

export default EnqueuedChildJobs;