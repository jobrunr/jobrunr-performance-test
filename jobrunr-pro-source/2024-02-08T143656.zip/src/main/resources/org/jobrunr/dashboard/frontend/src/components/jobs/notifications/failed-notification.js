import TimeAgo from "react-timeago/lib";
import {JobNotification} from "./job-notification";

const FailedNotification = ({job}) => {
    const deleteDate = job.deleteAt;

    return (
        <>
            {deleteDate &&
                <JobNotification severity="warning">
                    <strong>This job has failed.</strong> It will automatically go to the deleted state
                    in <TimeAgo date={new Date(deleteDate)} title={deleteDate.toString()}/>.
                </JobNotification>
            }
        </>
    )
};

export default FailedNotification;