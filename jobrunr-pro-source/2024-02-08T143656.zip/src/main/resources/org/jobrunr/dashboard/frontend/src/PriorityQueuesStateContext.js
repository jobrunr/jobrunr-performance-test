import {prefixWithContextPath} from "./utils/helper-functions";

class PriorityQueues {
    constructor() {
        this._data = {};
        this._data.queues = [];
    }

    setPriorityQueues(queues) {
        this._data.queues = queues;
    }

    getQueues() {
        return this._data.queues;
    }

    usePriorityQueues() {
        return this.getQueues();
    }
}

const priorityQueuesState = new PriorityQueues();
Object.freeze(priorityQueuesState);

fetch(prefixWithContextPath(`/api/priority-queues`))
    .then(res => res.json())
    .then(response => {
        priorityQueuesState.setPriorityQueues(response);
    })
    .catch(error => console.log(error));

export default priorityQueuesState;