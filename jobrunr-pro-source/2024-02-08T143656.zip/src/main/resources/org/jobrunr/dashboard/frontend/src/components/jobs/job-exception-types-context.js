import {createContext} from 'react';

export const JobExceptionTypesContext = createContext({});