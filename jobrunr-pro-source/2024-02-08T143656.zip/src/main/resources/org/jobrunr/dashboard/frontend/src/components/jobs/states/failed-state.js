import {useContext} from "react";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import {Bug} from "mdi-material-ui";
import {JobState} from "./job-state";
import {FeatureContext} from "../../../FeaturesContext";
import {prefixWithContextPath} from "../../../utils/helper-functions";

const Failed = ({index, job, jobState, redacted}) => {
    const features = useContext(FeatureContext);
    const isBatch = job['@class'] === 'org.jobrunr.jobs.BatchJob';
    const isProcessedBatchJob = isBatch && job.jobHistory.filter(s => s.state === 'PROCESSED').length > 0;
    const title = (isBatch && !isProcessedBatchJob)
        ? `Enqueueing child jobs failed - ${jobState.message}`
        : `Job processing failed - ${jobState.message}`;

    return (
        <JobState
            title={title}
            state="failed"
            date={jobState.createdAt}
        >
            {isProcessedBatchJob
                ? <>
                    <Typography variant="body1" style={{marginTop: '1rem'}} gutterBottom>
                        {jobState.failedChildJobs > 1
                            ? <>There are {jobState.failedChildJobs} <a
                                href={`?processing-child-job-state-${index - 1}=FAILED`}>failed child jobs</a>.</>
                            : <>There is one <a href={`?processing-child-job-state-${index - 1}=FAILED`}>failed child
                                job</a>.</>
                        }
                    </Typography>
                </>
                : <>
                    <Typography variant="h6" style={{textTransform: "none"}} gutterBottom>
                        {jobState.exceptionType}
                        {features['issue-tracking'] &&
                            <>
                                <Button
                                    style={{
                                        float: 'right',
                                        margin: '0.35em -0.4em 0 0',
                                        color: 'rgb(97, 26, 21)',
                                        backgroundColor: 'rgb(253, 236, 234)'
                                    }}
                                    variant="contained" color="secondary"
                                    startIcon={<Bug/>}
                                    target="_blank" rel="noopener"
                                    href={prefixWithContextPath(`/api/integration?name=${features['issue-tracking']}&id=${job.id}`)}>
                                    Create issue
                                </Button>
                            </>

                        }
                    </Typography>
                    <Typography component={'pre'} style={{
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word",
                        fontFamily: "monospace",
                        fontSize: "1em"
                    }}>
                        {redacted ?
                            jobState.stackTrace.replace(
                                /\{\{redacted-exception-message\}\}/g,
                                "Actual message redacted by JobRunr due to insufficient rights"
                            ) : jobState.stackTrace
                        }
                    </Typography>
                </>
            }
        </JobState>
    );
};

export default Failed;