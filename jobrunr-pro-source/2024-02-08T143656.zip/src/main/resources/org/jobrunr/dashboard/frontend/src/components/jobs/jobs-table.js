import {Fragment, useCallback, useContext, useState} from 'react';
import {useLocation, useNavigate} from "react-router-dom";
import {Link as UILink} from '@mui/material';
import LoadingIndicator from "../LoadingIndicator";
import {JobActions} from "./actions/job-actions";
import {getJobMostRecentState, jobStateToHumanReadableName} from "../utils/job-utils";
import {UserContext} from "../../UserContext";
import {ItemsNotFound} from "../utils/items-not-found";
import {DataGrid} from "../ui/DataGrid";
import {useJobColumnInfo} from "./useJobColumnInfo";
import {AWAITING, DELETED, ENQUEUED} from "../utils/state-names";
import {useLocalStorage} from "usehooks-ts";


const JobsTable = (props) => {
    const location = useLocation();
    const navigate = useNavigate();
    const isLoading = props.isLoading;
    const jobPage = props.jobPage;
    const jobState = props.jobState;

    const columnInfo = useJobColumnInfo(location, navigate, jobState.toUpperCase(),
        props.defaultSort, props.sortedField, props.onSortChange, props.canSort ?? true);
    const {authorizationRules: {canDeleteJobs, canEnqueueJobs}} = useContext(UserContext);
    const showDeleteButton = !([DELETED].includes(jobState)) && canDeleteJobs;
    const showEnqueueButton = !([AWAITING, ENQUEUED].includes(jobState)) && canEnqueueJobs;
    const hasWriteAccess = showDeleteButton || showEnqueueButton;

    const [selectedJobIds, setSelectedJobIds] = useState([]);
    const [columnVisibilityModel, setColumnVisibilityModel] = useLocalStorage(
        `${jobState.toLowerCase()}-jobs-column-visibility-model`,
        columnInfo.columns.reduce((acc, cur) => ({...acc, [cur.field]: !cur.hide}), {})
    );

    const handlePaginationModelChange = useCallback((paginationModel) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.set('page', paginationModel.page);
        urlSearchParams.set('itemsPerPage', paginationModel.pageSize);
        navigate(`?${urlSearchParams.toString()}`);
    }, [location.search, navigate]);

    const jobsMatchingFiltersWithoutState = () => {
        const toUrl = (state) => {
            let urlSearchParams = new URLSearchParams(location.search);
            urlSearchParams.set("state", state);
            return (
                <UILink
                    component="button"
                    variant="body1"
                    style={{color: '#26a8ed'}}
                    onClick={() => navigate(`?${urlSearchParams.toString()}`)}
                    underline="hover">{state}</UILink>
            );
        }

        if (props.jobPageWithoutState && props.jobPageWithoutState.total > 0) {
            const matchingStates = [...new Set(props.jobPageWithoutState.items.map(job => getJobMostRecentState(job).state))];
            return <> - there are jobs matching your filters with the
                {matchingStates.map((state, index) => (
                    <Fragment
                        key={index}>{matchingStates[index - 1] ? matchingStates[index + 1] ? ', ' : ' and ' : ''} {toUrl(state)}</Fragment>
                ))}&nbsp;state.
            </>
        }
        return <></>;
    }

    const actions = hasWriteAccess ? {
        actionsComponent: JobActions, actionsProps: {
            selectedState: jobState,
            allJobsSelected: jobPage?.items.length === selectedJobIds.length,
            selectedJobs: selectedJobIds,
            jobPage: jobPage,
            showDeleteButton: showDeleteButton,
            showEnqueueButton: showEnqueueButton,
        }
    } : {}

    return (
        <> {isLoading
            ? <LoadingIndicator/>
            : <div id="jobs-table-container" style={{maxWidth: "100%", overflowX: "hidden"}}> {jobPage.items < 1
                ? <ItemsNotFound id="no-jobs-found-message">
                    No {jobStateToHumanReadableName(jobState)} found{jobsMatchingFiltersWithoutState()}
                </ItemsNotFound>
                :
                <DataGrid
                    columns={columnInfo.columns}
                    rows={jobPage.items}
                    rowCount={jobPage.total}
                    checkboxSelection={hasWriteAccess}
                    onRowSelectionModelChange={setSelectedJobIds}
                    rowSelectionModel={selectedJobIds}
                    handleSortModelChange={columnInfo.handleSortModelChange}
                    initialSortModel={columnInfo.sortModel}
                    handlePaginationModelChange={handlePaginationModelChange}
                    paginationModel={{page: jobPage.currentPage, pageSize: jobPage.limit}}
                    columnVisibilityModel={columnVisibilityModel}
                    onColumnVisibilityModelChange={setColumnVisibilityModel}
                    {...actions}
                />
            }
            </div>
        }
        </>
    );
}

export default JobsTable;