import {Link} from "react-router-dom";
import {prefixWithPublicUrl, shortHumanReadableISO8601Duration} from "../../utils/helper-functions";
import JobLabel from "../utils/job-label";
import {
    getExceptionSimpleClassName,
    getJobFirstState,
    getJobLatencyDuration,
    getJobMostRecentState,
    getJobProcessDuration,
    getProgressBar,
    getShortJobSignature
} from "../utils/job-utils";
import SwitchableTimeAgo from "../utils/time-ago";
import {ColoredLinearProgress} from "../ui/ColoredLinearProgress";
import {styled} from "@mui/material/styles";
import {PROCESSING} from "../utils/state-names";


const TextContainer = styled("span")`
    overflow-x: hidden;
    text-overflow: ellipsis;
`

const LabelsContainer = styled("div")`
    overflow-x: auto;
    scrollbar-width: none;

    &::-webkit-scrollbar {
        display: none;
    }
`

export const RenderJobLink = ({children, job, title}) => (
    <Link to={prefixWithPublicUrl(`/jobs/${job.id}`)} state={{job: job}} title={title}>
        {children}
    </Link>
);

export const RenderText = ({text, title}) => {
    return (
        text &&
        <TextContainer title={title ?? text}>
            {text}
        </TextContainer>
    )
}

export const RenderTextLink = ({job, text, title}) => {
    return (
        text &&
        <TextContainer><RenderJobLink job={job} title={title ?? text}>
            {text}
        </RenderJobLink></TextContainer>
    )
}

export const RenderJobLabels = ({value: labels}) => {
    return labels?.length > 0 &&
        <LabelsContainer>
            {labels.map((label) => (
                <JobLabel key={label} to={prefixWithPublicUrl(`/jobs?label=${label}`)} text={label}/>)
            )}
        </LabelsContainer>
}

export const RenderJobName = ({row: job}) => (
    <RenderTextLink job={job} text={job.jobName}/>
);

export const RenderJobSignature = ({row: job}) => (
    <RenderTextLink job={job} title={job.jobSignature} text={getShortJobSignature(job.jobSignature)}/>
);

export const RenderException = ({row: job}) => {
    const failedState = getJobMostRecentState(job);
    const exceptionType = failedState.exceptionType;
    return <RenderTextLink job={job} title={exceptionType} text={getExceptionSimpleClassName(exceptionType)}/>
}

export const RenderExceptionMessage = ({row: job}) => {
    const failedState = getJobMostRecentState(job);
    return <RenderTextLink job={job} text={failedState.message}/>
}

export const RenderReason = ({row: job}) => {
    const state = getJobMostRecentState(job);
    const reason = state.reason ?? state.message;
    return (<RenderJobLink text={reason} job={job}/>)
}

export const RenderDate = ({value: date}) => {
    return date && <TextContainer><SwitchableTimeAgo date={new Date(date)}/></TextContainer>;
}

export const RenderUpdatedAt = ({job}) => {
    const jobState = getJobMostRecentState(job);
    const date = jobState.state === PROCESSING ? jobState.updatedAt : jobState.createdAt;
    return <RenderDate value={date}/>;
}

export const RenderDuration = ({duration}) => {
    return <>{shortHumanReadableISO8601Duration(duration)}</>;
}

export const RenderLatencyDuration = ({job}) => {
    const duration = getJobLatencyDuration(job);
    return <RenderDuration duration={duration}/>;
}

export const RenderProcessDuration = ({job}) => {
    const duration = getJobProcessDuration(job);
    return <RenderDuration duration={duration}/>;
}

export const RenderProgressBar = ({row: job}) => {
    const progress = getProgressBar(job);
    return progress && <div style={{width: "100%"}}>
        <ColoredLinearProgress variant="determinate" value={progress.progress}/>
    </div>
}

export const RenderParentJob = ({row: job}) => {
    const parentJobId = getJobFirstState(job).parentJobId;
    return parentJobId && <RenderTextLink job={job} text={parentJobId}/>
}

export const RenderAwaitingOn = ({row: job}) => {
    const jobState = getJobMostRecentState(job);
    if (jobState.id) return <RenderTextLink job={job} text={jobState.id}/>
    return <RenderText job={job} text={jobState.rateLimiterName}/>
}

export const RenderRateLimiter = ({row: job}) => {
    return <RenderText text={job.rateLimiter ?? job.mutex}/>
}