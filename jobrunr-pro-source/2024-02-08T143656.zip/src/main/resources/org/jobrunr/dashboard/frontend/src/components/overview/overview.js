import {useEffect, useState} from "react";
import Box from "@mui/material/Box";
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import RealtimeGraph from "./cards/realtime-graph";
import EstimatedProcessingTimeCard from "./cards/estimated-processing-time-card";
import UptimeCard from "./cards/uptime-card";
import NbrOfBackgroundJobServersCard from "./cards/number-of-background-job-servers-card";
import AvgSystemCpuLoadCard from "./cards/avg-system-cpu-load-card";
import AvgProcessMemoryUsageCard from "./cards/avg-process-memory-usage-card";
import AvgProcessFreeMemoryCard from "./cards/avg-process-free-memory-card";
import Problems from "./problems/problems-notifications";
import VersionFooter from "../utils/version-footer";
import serversState from "../../ServersStateContext";
import JobRunrProTrialNotification from "./jobrunr-pro-trial-notification";
import {ItemsNotFound} from "../utils/items-not-found";

const Overview = () => {
    const [servers, setServers] = useState(serversState.getServers());

    useEffect(() => {
        serversState.addListener(setServers);
        return () => serversState.removeListener(setServers);
    }, []);

    return (
        <div className="app">
            <div className="row">
                <Box my={3}>
                    <Typography id="title" variant="h4">Dashboard</Typography>
                </Box>
            </div>
            <JobRunrProTrialNotification/>
            <Problems/>
            <div style={{display: "flex"}}>
                {servers.length > 0
                    ? <>
                        <EstimatedProcessingTimeCard/>
                        <UptimeCard servers={servers}/>
                        <NbrOfBackgroundJobServersCard servers={servers}/>
                        <AvgSystemCpuLoadCard servers={servers}/>
                        <AvgProcessMemoryUsageCard servers={servers}/>
                        <AvgProcessFreeMemoryCard servers={servers}/>
                    </>
                    : <Paper style={{marginTop: '1rem', width: '100%'}}>
                        <ItemsNotFound id="no-servers-found-message">
                            No background job server available - jobs will not be processed.
                        </ItemsNotFound>
                    </Paper>
                }
            </div>
            <RealtimeGraph/>
            <VersionFooter/>
        </div>
    );
};

export default Overview;