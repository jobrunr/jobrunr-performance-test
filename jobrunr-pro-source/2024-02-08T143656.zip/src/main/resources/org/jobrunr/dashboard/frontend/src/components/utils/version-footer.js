import {useContext, useEffect} from 'react';
import {Typography} from "@mui/material";
import statsState from "../../StatsStateContext";
import {JobRunrInfoContext} from "../../JobRunrInfoContext";

export default function VersionFooter() {
    const stats = statsState.getStats();
    const jobRunrInfo = useContext(JobRunrInfoContext);

    useEffect(() => {
        if (stats.backgroundJobServers) {
            const usageDataSent = localStorage.getItem('anonymousUsageDataSent');
            if (!usageDataSent || Math.abs(new Date() - Date.parse(usageDataSent)) > (1000 * 60 * 60 * 4)) {
                let url = `https://api.jobrunr.io/api/analytics/jobrunr-pro${window.trialExpirationDate ? '-trial' : ''}/report`;
                url += `?clusterId=${jobRunrInfo.clusterId}&currentVersion=${jobRunrInfo.version}&storageProviderType=${jobRunrInfo.storageProviderType}`;
                url += `&env=${jobRunrInfo.environment}&rootPackage=${jobRunrInfo.rootPackage}&usingWorkflow=${jobRunrInfo.usingWorkflow}&usingBatches=${jobRunrInfo.usingBatches}`;
                url += `&amountOfBackgroundJobServers=${stats.backgroundJobServers}&succeededJobCount=${(stats.succeeded + stats.allTimeSucceeded)}`;
                url += `&trialExpirationDate=${window.trialExpirationDate ? window.trialExpirationDate.toISOString() : ''}`;
                fetch(url)
                    .then(res => localStorage.setItem('anonymousUsageDataSent', new Date().toISOString()))
                    .catch(error => console.log(`JobRunr Pro ${jobRunrInfo.version} - Could not share usage data :-(!`));
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jobRunrInfo]);

    return (
        <>
            <Typography
                align="center"
                style={{paddingTop: '1rem', width: '100%', display: 'inline-block'}}
                variant="caption">
                Processed {(stats.succeeded + stats.allTimeSucceeded)} jobs with <span
                style={{color: 'red'}}>♥</span> using JobRunr
                Pro {jobRunrInfo.version}.<br/>
                {window.trialExpirationDate
                    ? <>Thank you for trying out <a href="https://www.jobrunr.io/en/pricing/" target="_blank"
                                                    rel="noreferrer">JobRunr Pro</a> (your trial ends
                        on {window.trialExpirationDate.toLocaleDateString()}).</>
                    : <>Thank you for buying a <a href="https://www.jobrunr.io/en/pricing/" target="_blank"
                                                  rel="noreferrer">JobRunr Pro</a> license and
                        supporting <a href="https://www.jobrunr.io/en/about/#eco-friendly-software" target="_blank"
                                      rel="noreferrer">our planet</a> and
                        open-source development. You rock!</>
                }
            </Typography>
        </>
    )
}