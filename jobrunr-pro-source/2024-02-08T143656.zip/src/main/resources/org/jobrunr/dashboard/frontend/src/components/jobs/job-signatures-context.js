import {createContext} from 'react';

export const JobSignaturesContext = createContext({});