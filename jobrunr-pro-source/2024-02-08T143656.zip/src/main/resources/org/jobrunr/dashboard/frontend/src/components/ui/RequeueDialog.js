import {useState} from "react";
import MuiDialogTitle from "@mui/material/DialogTitle";
import MuiDialogContent from "@mui/material/DialogContent";
import MuiDialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import {
    FormControl,
    FormControlLabel,
    FormHelperText,
    FormLabel,
    InputAdornment,
    InputLabel,
    MenuItem,
    Radio,
    RadioGroup,
    Select,
    TextField
} from "@mui/material";
import priorityQueuesState from "../../PriorityQueuesStateContext";
import {humanReadableMillis} from "../../utils/helper-functions";

const RequeueDialog = ({handleRequeue, handleClose, open = false, children}) => {
    return (
        <Dialog fullWidth={true} maxWidth="sm" scroll="paper" onClose={handleClose}
                aria-labelledby="customized-dialog-title" open={open}>
            {children}
            <MuiDialogActions>
                <Button onClick={handleClose} color="primary">
                    Cancel
                </Button>
                <Button onClick={handleRequeue} color="primary">
                    Requeue
                </Button>
            </MuiDialogActions>
        </Dialog>
    )
}

export const RequeueWithOptionsDialog = ({handleRequeue, multiple = false, amount, ...rest}) => {
    const priorityQueues = priorityQueuesState.usePriorityQueues();

    const [selectedRequeueOption, setSelectedRequeueOption] = useState('immediately');
    const [selectedScheduleDelta, setSelectedScheduleDelta] = useState(500);
    const [selectedQueue, setSelectedQueue] = useState(priorityQueues.length - 1);

    const queueSelectedJobs = () => {
        handleRequeue({selectedRequeueOption, selectedQueue, selectedScheduleDelta})
    }

    return (
        <RequeueDialog handleRequeue={queueSelectedJobs} {...rest}>
            <MuiDialogTitle id="customized-dialog-title">
                {multiple ? 'Requeue selected jobs?' : 'Requeue job?'}
            </MuiDialogTitle>
            <MuiDialogContent dividers>
                <FormControl variant="standard" component="fieldset">
                    <FormLabel component="legend">
                        {multiple ? "How do you want to requeue the selected jobs?" : "How do you want to requeue the job?"}
                    </FormLabel>
                    <RadioGroup aria-label="requeue-option" name="requeueOption" value={selectedRequeueOption}
                                onChange={(e, v) => setSelectedRequeueOption(v)}>
                        <FormControlLabel value="immediately" control={<Radio/>}
                                          label={multiple ? "Enqueue the selected jobs immediately." : 'Enqueue the job immediately.'}/>
                        <FormControlLabel value="different-queue" control={<Radio/>}
                                          label={multiple ? "Enqueue the selected jobs on a different queue." : "Enqueue the job on a different queue."}/>
                        {'different-queue' === selectedRequeueOption &&
                            <FormControl variant="standard" style={{width: '80%', margin: '0 0 2rem 2rem'}}>
                                <InputLabel id="demo-simple-select-label">Queue</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    value={selectedQueue}
                                    onChange={(ev) => setSelectedQueue(ev.target.value)}>
                                    {priorityQueues.map((queue, index) => (
                                        <MenuItem key={index} value={index}>{queue}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        }
                        <FormControlLabel value="spread-out" control={<Radio/>}
                                          label={`Schedule the selected ${multiple ? 'jobs' : 'job'} spread out over time so other ENQUEUED jobs still can be processed.`}/>
                        {'spread-out' === selectedRequeueOption &&
                            <>
                                <TextField
                                    variant="standard"
                                    id="schedule-delta-in-millis"
                                    label="Milliseconds"
                                    type="number"
                                    value={selectedScheduleDelta}
                                    InputProps={{endAdornment: <InputAdornment position="end">ms</InputAdornment>}}
                                    onChange={(ev) => setSelectedScheduleDelta(ev.target.value)}
                                    style={{width: '30%', margin: '0.5rem 0 1rem 2rem'}}
                                    InputLabelProps={{
                                        shrink: true,
                                    }} />
                                <FormHelperText id="standard-weight-helper-text" style={{marginLeft: '2rem'}}>
                                    {multiple ? "The amount of milliseconds between each selected job."
                                        : "The amount of milliseconds to wait for."}
                                    {multiple && <>The total time to schedule all jobs is
                                        around {humanReadableMillis(selectedScheduleDelta * amount)}.</>}
                                </FormHelperText>
                            </>
                        }
                    </RadioGroup>
                </FormControl>
            </MuiDialogContent>
        </RequeueDialog>
    );
}

export const RequeueImmediatelyDialog = (props) => {
    return (
        <RequeueDialog  {...props}>
            <MuiDialogTitle id="customized-dialog-title">
                Enqueue the job?
            </MuiDialogTitle>
            <MuiDialogContent dividers>
                <p>Are you sure you want to enqueue the job?</p>
            </MuiDialogContent>
        </RequeueDialog>
    )
}
