import TimeAgo from "react-timeago/lib";
import {useLocalStorage} from "usehooks-ts";

const SwitchableTimeAgo = ({date}) => {

    const possibleStyles = {defaultStyle: 'defaultStyle', readableStyle: 'readableStyle', iso8601Style: 'iso8601Style'};

    const [style, setStyle] = useLocalStorage("switchableTimeAgoStyle", possibleStyles.defaultStyle)

    const setNewStyle = (e, style) => {
        e.stopPropagation();
        setStyle(style);
    }

    let result = <TimeAgo onClick={e => setNewStyle(e, possibleStyles.readableStyle)} date={date}
                          title={date.toString()}/>

    if (style === possibleStyles.readableStyle) {
        const dateAsString = date.toString();
        result = (
            <span onClick={e => setNewStyle(e, possibleStyles.iso8601Style)}>
                {dateAsString.substring(0, dateAsString.indexOf(' ('))}
            </span>
        )
    }
    if (style === possibleStyles.iso8601Style) {
        result = (
            <span onClick={e => setNewStyle(e, possibleStyles.defaultStyle)}>
                {date.toISOString()}
            </span>
        )
    }

    return <span style={{cursor: "pointer"}}>{result}</span>;
}

export default SwitchableTimeAgo;