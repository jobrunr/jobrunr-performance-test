context('Actions', () => {
    before(() => {
        cy.visit('http://localhost:8000/dashboard/jobs');
        cy.viewport(1280, 800);
        waitForSSE();
    });

    const config = {retries: 2};

    const jobsTabBtn = () => cy.get('#jobs-btn');
    const batchJobsTabBtn = () => cy.get('#batch-jobs-btn');
    const recurringJobsTabBtn = () => cy.get('#recurring-jobs-btn');
    const serversTabBtn = () => cy.get('#servers-btn');


    const scheduledMenuBtn = () => cy.get('#scheduled-menu-btn');
    const enqueuedMenuBtn = () => cy.get('#enqueued-menu-btn');
    const processingMenuBtn = () => cy.get('#processing-menu-btn');
    const succeededMenuBtn = () => cy.get('#succeeded-menu-btn');
    const failedMenuBtn = () => cy.get('#failed-menu-btn');

    const jobsSearchPanel = () => cy.get('#job-filter-panel-header');
    const jobsSearchByJobNameInput = () => cy.get('#job-name');
    const jobsBatchJobsOnlyCheckbox = () => cy.get('#batch-jobs-only-checkbox');

    const recurringJobsSearchPanel = () => cy.get('#recurring-job-filter-panel-header');
    const recurringJobsSearchByJobNameInput = () => cy.get('#job-id');
    const recurringJobsTable = () => cy.get('#recurring-jobs-table');
    const recurringJobTableRows = () => recurringJobsTable().get('tbody>tr');

    const breadcrumb = () => cy.get('#breadcrumb');
    const title = () => cy.get('#title');

    const jobTable = () => cy.get('#jobs-table-container [role=grid]');
    const jobTableRows = () => jobTable().get('div[role=grid] div[role=presentation]:nth-of-type(2) div[role=row]');
    const noJobsFoundMessage = () => cy.get('#no-jobs-found-message');

    const batchJobTableRows = () => cy.get('#jobs-table tbody>tr');

    const jobIdTitle = () => cy.get('#job-id-title');
    const jobNameTitle = () => cy.get('#job-name-title');

    const jobHistoryPanel = () => cy.get('#job-history-panel');
    const jobHistoryPanelItems = () => jobHistoryPanel().find('div.MuiAccordion-root');
    const jobHistorySortAscBtn = () => cy.get('#jobhistory-sort-asc-btn');
    const jobHistorySortDescBtn = () => cy.get('#jobhistory-sort-desc-btn');

    const pauseAllProcessingBtn = () => cy.get('#pause-all-processing-btn');
    const resumeAllProcessingBtn = () => cy.get('#resume-all-processing-btn');

    it('It opens the jobs dashboard page', config, () => {
        jobsTabBtn().get('span.MuiChip-label').should('contain', '34');
        title().should('contain', 'Enqueued jobs');

        jobTableRows().should('have.length', 20);
        jobTableRows().eq(0).should('contain', 'an enqueued job');
        jobTablePagination().should('contain', '1–20 of 34');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.enabled');
    });


    it('It can navigate to the scheduled jobs', config, () => {
        scheduledMenuBtn().should('contain', '1');
        scheduledMenuBtn().click();
        title().should('contain', 'Scheduled jobs');

        jobTableRows().should('have.length', 1);
        jobTableRows().eq(0).should('contain', 'the job');
        jobTablePagination().should('contain', '1–1 of 1');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.disabled');
    });

    it('It can navigate to the enqueued jobs', config, () => {
        enqueuedMenuBtn().should('contain', '34');
        enqueuedMenuBtn().click();
        title().should('contain', 'Enqueued jobs');

        jobTableRows().should('have.length', 20);
        jobTableRows().eq(0).should('contain', 'an enqueued job');
        jobTablePagination().should('contain', '1–20 of 34');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.enabled');
    });

    it('It can navigate to the processing jobs', config, () => {
        processingMenuBtn().should('contain', '0');
        processingMenuBtn().click();
        title().should('contain', 'Jobs being processed');

        noJobsFoundMessage().should('be.visible')
        jobTable().should('not.exist');
    });

    it('It can navigate to the succeeded jobs', config, () => {
        succeededMenuBtn().should('contain', '2');
        succeededMenuBtn().click();
        title().should('contain', 'Succeeded jobs');

        jobTableRows().should('have.length', 2);
        jobTableRows().eq(0).should('contain', 'a succeeded job');
        jobTablePagination().should('contain', '1–2 of 2');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.disabled');
    });

    it('It can navigate to the failed jobs', config, () => {
        failedMenuBtn().should('contain', '1');
        failedMenuBtn().click();
        title().should('contain', 'Failed jobs');

        jobTableRows().should('have.length', 1);
        jobTableRows().eq(0).should('contain', 'failed job');
        jobTablePagination().should('contain', '1–1 of 1');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.disabled');
    });

    it('It can navigate to the details of a job', config, () => {
        failedMenuBtn().click();
        title().should('contain', 'Failed jobs');
        jobTableRows().should('have.length', 1);

        jobTableRows().eq(0).should('contain', 'failed job');
        jobTableRows().eq(0).find('div[role=cell] a').eq(0).click();
        jobIdTitle().should('be.visible');

        breadcrumb().should('contain', 'Failed jobs');
        jobNameTitle().should('contain', 'failed job');
        jobHistoryPanel().should('be.visible');

        jobHistoryPanelItems().should('have.length', 44);
        jobHistoryPanelItems().eq(0).should('contain', 'Job scheduled');
        jobHistorySortDescBtn().click();
        jobHistoryPanelItems().eq(0).should('contain', 'Job processing failed');
    });

    it('It can display batch jobs only and navigate to the detail of a batch job', config, () => {
        enqueuedMenuBtn().click();
        title().should('contain', 'Enqueued jobs');
        jobsSearchPanel().click();
        jobsBatchJobsOnlyCheckbox().click();

        jobTableRows().should('have.length', 1);

        jobTableRows().eq(0).should('contain', 'An enqueued batch job');
        jobTableRows().eq(0).find('div[role=cell] a').eq(0).click();
        jobIdTitle().should('be.visible');

        breadcrumb().should('contain', 'Enqueued jobs');
        jobNameTitle().should('contain', 'An enqueued batch job');
    });

    it('It can navigate to the servers page', config, () => {
        serversTabBtn().click();
        serversTabBtn().get('span.MuiChip-label').should('contain', '1');

        pauseAllProcessingBtn().should('be.visible');
        resumeAllProcessingBtn().should('be.visible');
    });

    it('It can search for a job by job name', config, () => {
        jobsTabBtn().click();
        jobsSearchPanel().click();
        jobsSearchByJobNameInput().type("an enqueued job{enter}");
        jobTableRows().should('have.length', 20);
        jobTableRows().eq(0).should('contain', 'an enqueued job');
        jobTablePagination().should('contain', '1–20 of 33');
        jobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        jobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.enabled');

        jobsTabBtn().click();
        jobsSearchPanel().click();
        jobsSearchByJobNameInput().type("unknown job{enter}");
        noJobsFoundMessage().should('be.visible');
    });

    it('It can navigate to and search for a recurring job by id', config, () => {
        recurringJobsTabBtn().click();
        recurringJobsTabBtn().get('span.MuiChip-label').should('contain', '2');
        recurringJobsSearchPanel().click();
        recurringJobsSearchByJobNameInput().type("generate-sales-reports{enter}");
        recurringJobTableRows().should('have.length', 1);
        recurringJobTableRows().eq(0).should('contain', 'generate-sales-reports');
        recurringJobTablePagination().should('contain', '1–1 of 1');
        recurringJobTablePagination().previousButton().should('have.attr', 'title', 'Go to previous page').and('be.disabled');
        recurringJobTablePagination().nextButton().should('have.attr', 'title', 'Go to next page').and('be.disabled');
    });

    const jobTablePagination = function () {
        let paginationSelector = cy.get('#jobs-table-pagination');
        Object.assign(Object.getPrototypeOf(paginationSelector), {
            previousButton() {
                return paginationSelector.find('button').eq(0);
            },
            nextButton() {
                return paginationSelector.find('button').eq(1);
            }
        });
        return paginationSelector;
    }

    const recurringJobTablePagination = function () {
        let paginationSelector = cy.get('#recurring-jobs-table-pagination-footer');
        Object.assign(Object.getPrototypeOf(paginationSelector), {
            previousButton() {
                return paginationSelector.find('button').eq(0);
            },
            nextButton() {
                return paginationSelector.find('button').eq(1);
            }
        });
        return paginationSelector;
    }

    const waitForSSE = function () {
        jobsTabBtn().get('span.MuiChip-label', {timeout: 20000}).should(($chip) => {
            expect($chip.text()).contains('34');
        });
    }
});
