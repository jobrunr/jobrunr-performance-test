import {memo, useContext, useEffect, useState} from 'react';
import {Link} from "react-router-dom";
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Box from "@mui/material/Box";
import {styled} from '@mui/material/styles';
import VersionFooter from "../utils/version-footer";
import {prefixWithContextPath, prefixWithPublicUrl} from "../../utils/helper-functions";
import TableContainer from "@mui/material/TableContainer";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from '@mui/material/TableCell';
import {FeatureContext} from "../../FeaturesContext";

const StyledTable = styled(Table)`
    width: 100%;

    & tr td, & tr th {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        text-align: right;
    }
`;

const DynamicQueuesView = memo(() => {
    const features = useContext(FeatureContext);
    const dynamicQueueConfiguration = features['dynamicQueues'];
    const [dynamicQueues, setDynamicQueues] = useState({defaultQueue: {jobStats: {}}, allQueues: []});

    useEffect(() => {
        fetch(prefixWithContextPath(`/api/dynamic-queues/stats`))
            .then(res => {
                if (res.status === 200) {
                    res.json().then(details => setDynamicQueues(details));
                } else {
                    console.error('Could not load dynamic queue info', res.status);
                }
            });
    }, []);

    if (!dynamicQueueConfiguration) {
        return (<div>Loading...</div>)
    }

    return (
        <div>
            <Box my={3}>
                <Typography variant="h4">{dynamicQueueConfiguration.title}</Typography>
            </Box>
            <>
                <Paper>
                    <TableContainer>
                        <StyledTable aria-label="servers overview">
                            <TableHead>
                                <TableRow>
                                    <TableCell style={{textAlign: 'left'}}>&nbsp;</TableCell>
                                    <TableCell>Awaiting</TableCell>
                                    <TableCell>Scheduled</TableCell>
                                    <TableCell>Enqueued</TableCell>
                                    <TableCell>Processing</TableCell>
                                    <TableCell>Succeeded</TableCell>
                                    <TableCell>Failed</TableCell>
                                    <TableCell>Deleted</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {dynamicQueues.defaultQueue &&
                                    <TableRow key={dynamicQueues.defaultQueue.name}>
                                        <TableCell component="th" scope="row" style={{textAlign: 'left'}}>
                                            {dynamicQueues.defaultQueue.label
                                                ? <Link
                                                    to={{
                                                        pathname: prefixWithPublicUrl(`/jobs`),
                                                        search: `?label!=${dynamicQueues.defaultQueue.label}`
                                                    }}>
                                                    <>{dynamicQueues.defaultQueue.name}</>
                                                </Link>
                                                : <>{dynamicQueues.defaultQueue.name}</>
                                            }
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['AWAITING']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['SCHEDULED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['ENQUEUED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['PROCESSING']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['SUCCEEDED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['FAILED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueues.defaultQueue.jobStats['DELETED']}
                                        </TableCell>
                                    </TableRow>
                                }
                                {dynamicQueues.allQueues.map(dynamicQueueStats => (
                                    <TableRow key={dynamicQueueStats.name}>
                                        <TableCell component="th" scope="row" style={{textAlign: 'left'}}>
                                            {dynamicQueueStats.label
                                                ? <Link
                                                    to={{
                                                        pathname: prefixWithPublicUrl(`/jobs`),
                                                        search: `?label!=${dynamicQueueStats.label}`
                                                    }}>
                                                    <>{dynamicQueueStats.name}</>
                                                </Link>
                                                : <>{dynamicQueueStats.name}</>
                                            }

                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['AWAITING']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['SCHEDULED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['ENQUEUED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['PROCESSING']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['SUCCEEDED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['FAILED']}
                                        </TableCell>
                                        <TableCell>
                                            {dynamicQueueStats.jobStats['DELETED']}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </StyledTable>
                    </TableContainer>
                </Paper>
                <VersionFooter/>
            </>
        </div>
    );
});

export default DynamicQueuesView;