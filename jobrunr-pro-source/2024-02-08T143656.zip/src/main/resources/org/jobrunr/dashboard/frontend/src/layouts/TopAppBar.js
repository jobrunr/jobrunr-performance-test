import {useContext, useEffect, useState} from 'react';
import {styled} from "@mui/material/styles";
import AppBar from '@mui/material/AppBar';
import Chip from '@mui/material/Chip';
import Toolbar from '@mui/material/Toolbar';
import GitHubIcon from '@mui/icons-material/GitHub';
import IconButton from '@mui/material/IconButton';
import Button from '@mui/material/Button';
import {Link as RouterLink} from 'react-router-dom';
import statsState from 'StatsStateContext.js';
import logo from '../assets/jobrunr-logo-white.png';
import {prefixWithPublicUrl, replacePublicUrl} from "../utils/helper-functions";
import {FeatureContext} from "../FeaturesContext";
import {AlertBoxOutline} from "mdi-material-ui";
import {JobRunrInfoContext} from "../JobRunrInfoContext";
import {UserContext} from "../UserContext";

const logoUrl = replacePublicUrl(logo);

const StyledAppBar = styled(AppBar)(({theme}) => ({
    zIndex: theme.zIndex.drawer + 1
}));

const Buttons = styled("div")(({theme}) => ({
    '& > *': {
        margin: `${theme.spacing(2)}!important`,
    },
    '& div.MuiChip-root': {
        height: 'initial',
        marginLeft: '6px',
        fontSize: '0.75rem'
    },
    '& div span.MuiChip-label': {
        padding: '0 8px'
    },
    margin: "0 50px",
    flexGrow: 1,
}));

const TopAppBar = () => {
    const jobRunrInfo = useContext(JobRunrInfoContext);
    const features = useContext(FeatureContext);

    const jobRunrAPIBackend = process.env.REACT_APP_JOBRUNR_API_BASE_URL;
    //const jobRunrAPIBackend = 'http://localhost:8080';

    const [stats, setStats] = useState(statsState.getStats());
    const [canCreatePanicAlert, setCanCreatePanicAlert] = useState({canCreateAlert: false});
    const {authorizationRules} = useContext(UserContext);

    useEffect(() => {
        statsState.addListener(setStats);
        return () => statsState.removeListener(setStats);
    }, []);

    useEffect(() => {
        if (jobRunrInfo.clusterId) {
            fetch(`${jobRunrAPIBackend}/api/panic/test-panic-alert?clusterId=${jobRunrInfo.clusterId}&currentVersion=${jobRunrInfo.version}&rootPackage=${jobRunrInfo.rootPackage}&storageProviderType=${jobRunrInfo.storageProviderType}`)
                .then(res => res.json())
                .then(json => setCanCreatePanicAlert(json))
                .catch(error => console.log('Error retrieving panic alert settings: ', error.message));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jobRunrInfo]);


    return (
        <StyledAppBar position="fixed">
            <Toolbar style={{display: "flex", alignItems: "center"}}>
                <img style={{width: 'auto', height: '35px'}} src={logoUrl} alt="JobRunr"/>
                <Buttons>
                    <Button id="dashboard-btn" color="inherit" component={RouterLink}
                            to={prefixWithPublicUrl('/overview')}>
                        Dashboard
                    </Button>
                    {authorizationRules.canAccessJobs && features['dynamicQueues'] &&
                        <Button id="dynamic-queues-btn" color="inherit" component={RouterLink}
                                to={prefixWithPublicUrl('/dynamic-queues')}>
                            {features['dynamicQueues'].title}
                        </Button>
                    }
                    {authorizationRules.canAccessJobs &&
                        <Button id="jobs-btn" color="inherit" component={RouterLink} to={prefixWithPublicUrl('/jobs')}>
                            Jobs <Chip color="secondary" label={stats.enqueued}/>
                        </Button>
                    }
                    {authorizationRules.canAccessRecurringJobs &&
                        <Button id="recurring-jobs-btn" color="inherit" component={RouterLink}
                                to={prefixWithPublicUrl('/recurring-jobs')}>
                            Recurring Jobs <Chip color="secondary" label={stats.recurringJobs}/>
                        </Button>
                    }
                    {authorizationRules.canAccessBackgroundJobServers &&
                        <Button id="servers-btn" color="inherit" component={RouterLink}
                                to={prefixWithPublicUrl('/servers')}>
                            Servers <Chip color="secondary" label={stats.backgroundJobServers}/>
                        </Button>
                    }
                </Buttons>
                {canCreatePanicAlert.canCreateAlert &&
                    <IconButton
                        edge="start"
                        sx={{marginRight: 2}}
                        color="inherit"
                        aria-label="menu"
                        component={RouterLink}
                        to={prefixWithPublicUrl('/panic')}
                        size="large">
                        <AlertBoxOutline/>
                    </IconButton>
                }
                <IconButton
                    edge="start"
                    sx={{marginRight: 2}}
                    color="inherit"
                    aria-label="menu"
                    target="_blank"
                    href="https://github.com/jobrunr/jobrunr"
                    size="large">
                    <GitHubIcon/>
                </IconButton>
            </Toolbar>
        </StyledAppBar>
    );
}

export default TopAppBar;