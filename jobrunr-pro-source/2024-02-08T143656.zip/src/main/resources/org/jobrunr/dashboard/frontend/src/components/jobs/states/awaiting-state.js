import {prefixWithPublicUrl} from "../../../utils/helper-functions";
import {JobState} from "./job-state";

const Awaiting = ({jobState}) => {
    return (
        <JobState title="Pending" state="awaiting" date={new Date(jobState.createdAt)}>
            {jobState.id &&
                <div>Waiting for job&nbsp;<a
                    href={prefixWithPublicUrl(`/jobs/${jobState.id}`)}>{jobState.id}</a>&nbsp;to finish
                    before enqueueing.
                </div>
            }
            {jobState.rateLimiterName &&
                <div>Waiting for rate limiter '{jobState.rateLimiterName}' to allow
                    enqueueing.
                </div>
            }
        </JobState>
    )
};

export default Awaiting;