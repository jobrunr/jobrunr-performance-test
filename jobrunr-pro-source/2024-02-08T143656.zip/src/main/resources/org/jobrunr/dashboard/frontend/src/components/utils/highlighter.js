import {Light as Highlight} from 'react-syntax-highlighter';
import java from 'react-syntax-highlighter/dist/esm/languages/hljs/java';
import json from 'react-syntax-highlighter/dist/esm/languages/hljs/json';
import yaml from 'react-syntax-highlighter/dist/esm/languages/hljs/yaml';
import style from 'react-syntax-highlighter/dist/esm/styles/hljs/androidstudio';

Highlight.registerLanguage('java', java);
Highlight.registerLanguage('json', json);
Highlight.registerLanguage('yaml', yaml);

const Highlighter = ({language, children}) => (<Highlight language={language} style={style}>{children}</Highlight>);
export default Highlighter;