import {getJobFirstState, getJobMostRecentState} from "../utils/job-utils";
import {capitalize} from "../utils/string-utils";
import {useMemo} from "react";
import {
    RenderAwaitingOn,
    RenderDate,
    RenderException,
    RenderExceptionMessage,
    RenderJobLabels,
    RenderJobName,
    RenderJobSignature,
    RenderLatencyDuration,
    RenderParentJob,
    RenderProcessDuration,
    RenderProgressBar,
    RenderRateLimiter,
    RenderReason,
    RenderTextLink,
    RenderUpdatedAt
} from "./grid-cells";
import {AWAITING, DELETED, ENQUEUED, FAILED, PROCESSING, SCHEDULED, SUCCEEDED} from "../utils/state-names";

const getSortedColumn = (sortQueryParam, columns) => {
    if (sortQueryParam.includes(columns.jobName.field)) return columns.jobName.field;
    if (sortQueryParam.includes(columns.deleteAt?.field)) return columns.deleteAt.field;
    if (sortQueryParam.includes(columns.createdAt?.field)) return columns.createdAt.field;
    if (sortQueryParam.includes(columns.updatedAt.field) && !sortQueryParam.includes(",")) return columns.updatedAt.field;
    return columns.jobInStateSince.field;
}

export const useJobColumnInfo = (location, navigate, jobState, defaultSort, sortedField, onSortChange, canSort) => {
    const urlSearchParams = new URLSearchParams(location.search);
    const sortQueryParam = urlSearchParams.get('sort') || defaultSort || '';

    const handleSort = (newSort) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.delete('page');
        urlSearchParams.set('sort', newSort);
        navigate(`?${urlSearchParams.toString()}`);
    };

    const order = sortQueryParam.includes('ASC') ? 'asc' : 'desc'
    const isAscending = order === 'asc';

    const getJobInStateSince = (job) => {
        const jobMostRecentState = getJobMostRecentState(job);
        return jobState === SCHEDULED ? jobMostRecentState.scheduledAt : jobMostRecentState.createdAt;
    }

    let pos = 1;

    const columns = {
        id: {
            field: 'id', hide: false, sortable: false, width: 300, headerName: "Id",
            renderCell: ({value, row}) => (<RenderTextLink job={row} text={value}/>),
            pos: pos++,
        },
        labels: {
            field: "labels",
            hide: true,
            sortable: false,
            minWidth: 300,
            flex: 1,
            headerName: "Labels",
            renderCell: RenderJobLabels,
            pos: pos++
        },
        jobName: {
            field: "jobName",
            hide: false,
            minWidth: 400,
            flex: 1,
            headerName: "Job name",
            renderCell: RenderJobName,
            sortable: canSort,
            onSort: () => isAscending ? handleSort('jobName:DESC') : handleSort('jobName:ASC'),
            pos: pos++
        },
        jobSignature: {
            field: "jobSignature",
            hide: true,
            width: 400,
            headerName: "Job signature",
            sortable: false,
            renderCell: RenderJobSignature,
            pos: pos++
        },
        exceptionType: {
            field: "exceptionType", hide: true, headerName: "Exception", width: 300, sortable: false,
            renderCell: RenderException,
            pos: pos++
        },
        exceptionMessage: {
            field: "exceptionMessage", hide: true, headerName: "Exception message", width: 300, sortable: false,
            renderCell: RenderExceptionMessage,
            pos: pos++
        },
        jobInStateSince: {
            field: 'jobInStateSince', hide: false, width: 250,
            headerName: jobState === AWAITING ? 'Created' : jobState === PROCESSING ? 'Started' : capitalize(jobState),
            renderCell: ({row: job}) => <RenderDate value={getJobInStateSince(job)}/>,
            sortable: canSort,
            onSort: () => {
                if (jobState === ENQUEUED) return !isAscending ? handleSort('priority:ASC,updatedAt:ASC') : handleSort('updatedAt:DESC');
                else if (jobState === SCHEDULED) return !isAscending ? handleSort('scheduledAt:ASC') : handleSort('scheduledAt:DESC');
                else !isAscending ? handleSort('updatedAt:ASC') : handleSort('updatedAt:DESC')
            },
            pos: pos++
        },
        reason: {
            field: "reason", hide: true, headerName: "Reason", width: 350, sortable: false,
            renderCell: RenderReason,
            pos: pos++
        },
        updatedAt: {
            field: 'updatedAt', hide: true, sortable: canSort, width: 250, headerName: "Updated",
            renderCell: ({row: job}) => <RenderUpdatedAt job={job}/>,
            onSort: () => isAscending ? handleSort('updatedAt:DESC') : handleSort('updatedAt:ASC'),
            pos: pos++
        },
        createdAt: {
            field: 'createdAt', hide: true, sortable: canSort, width: 250, headerName: "Created",
            renderCell: ({row: job}) => <RenderDate value={getJobFirstState(job).createdAt}/>,
            onSort: () => isAscending ? handleSort('updatedAt:DESC') : handleSort('updatedAt:ASC'),
            pos: pos++
        },
        processDuration: {
            field: "processDuration", hide: true, headerName: "Process duration", width: 150, sortable: false,
            renderCell: ({row: job}) => (<RenderProcessDuration job={job}/>),
            pos: pos++
        },
        latency: {
            field: "latency", hide: true, headerName: "Latency", width: 150, sortable: false,
            description: "Time spent in enqueued state",
            renderCell: ({row: job}) => (<RenderLatencyDuration job={job}/>),
            pos: pos++
        },
        deleteAt: {
            field: "deleteAt", hide: true, headerName: "Delete", width: 250, sortable: true,
            renderCell: RenderDate,
            onSort: () => isAscending ? handleSort('deleteAt:DESC') : handleSort('deleteAt:ASC'),
            pos: pos++
        },
        progressBar: {
            field: "progressBar", hide: true, headerName: "Progress", width: 100, sortable: false,
            renderCell: RenderProgressBar,
            pos: pos++
        },
        parentJob: {
            field: "parentJob", hide: true, headerName: "Parent job", width: 300, sortable: false,
            renderCell: RenderParentJob,
            pos: pos++
        },
        awaitingOn: {
            field: "awaitingOn", hide: true, headerName: "Awaiting", width: 300, sortable: false,
            renderCell: RenderAwaitingOn,
            pos: pos++
        },
        rateLimiter: {
            field: "rateLimiter", hide: true, headerName: "Rate limiter", width: 300, sortable: false,
            renderCell: RenderRateLimiter,
            pos: pos++
        }
    }
    if (jobState !== AWAITING) {
        delete columns.awaitingOn;
    }
    if (jobState !== PROCESSING) {
        delete columns.progressBar;
    }
    if (jobState !== FAILED) {
        delete columns.exceptionType;
        delete columns.exceptionMessage;
    }
    if (jobState !== SCHEDULED) delete columns.reason;
    if (![DELETED, FAILED, SUCCEEDED].includes(jobState)) {
        delete columns.processDuration;
        delete columns.deleteAt;
    }
    if (![DELETED, FAILED, SUCCEEDED, PROCESSING].includes(jobState)) delete columns.latency;
    if (jobState === AWAITING) delete columns.createdAt;
    if (jobState === DELETED) {
        columns.deleteAt = {...columns.deleteAt, headerName: "Purge", pos: 5}
    }

    const columnList = Object.values(columns);
    columnList.sort((a, b) => (a.pos ?? 100) - (b.pos ?? 100));

    const handleSortModelChange = (sortModel) => {
        onSortChange(sortModel.field);
        columns[sortModel.field].onSort?.();
    }

    return useMemo(() => ({
        columns: columnList,
        sortModel: canSort ? [{
            field: sortedField ?? getSortedColumn(sortQueryParam, columns),
            sort: order
        }] : [],
        handleSortModelChange
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }), [location.search])
};
