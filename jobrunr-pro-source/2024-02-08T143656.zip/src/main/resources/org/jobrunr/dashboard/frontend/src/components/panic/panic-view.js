import {useContext, useState} from "react";
import {useNavigate} from 'react-router-dom';
import {
    Backdrop,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Link,
    TextField
} from "@mui/material";
import {dialogClasses} from "@mui/material/Dialog"
import {AlertBoxOutline} from "mdi-material-ui";
import {styled} from "@mui/material/styles";
import {prefixWithPublicUrl} from "../../utils/helper-functions";
import {JobRunrInfoContext} from "../../JobRunrInfoContext";

const StyledTextField = styled(TextField)`
    margin-bottom: 1rem
`

const StyledDialog = styled(Dialog)`
    ${dialogClasses.paper} {
        padding: 2rem;
    }
`

const Panic = () => {
    const jobRunrAPIBackend = process.env.REACT_APP_JOBRUNR_API_BASE_URL;
    //const jobRunrAPIBackend = 'http://localhost:8080';
    const navigate = useNavigate();

    const jobRunrInfo = useContext(JobRunrInfoContext);
    const [currentStep, setCurrentStep] = useState(0);
    const [panicData, setPanicData] = useState({
        title: undefined,
        description: undefined,
        email: undefined
    });
    const [panicDataErrors, setPanicDataErrors] = useState({
        titleError: undefined,
        descriptionError: undefined,
        emailError: undefined
    });
    const [panicDataResult, setPanicDataResult] = useState({});

    const goToNextStep = () => {
        setCurrentStep(currentStep => currentStep + 1);
    }

    const goToPreviousStep = () => {
        setCurrentStep(currentStep => currentStep - 1);
    }

    const cancel = async () => {
        setCurrentStep(currentStep => 0);
        setPanicData({title: undefined, description: undefined, email: undefined});
        navigate(prefixWithPublicUrl('/overview'));
    }

    const validateEmail = (email) => {
        return email.match(/^\S+@\S+\.\S+$/);
    };

    const validatePanicAlert = () => {
        if (panicData.title && panicData.description && panicData.email && validateEmail(panicData.email)) {
            goToNextStep();
        } else {
            let errors = {...panicDataErrors};
            if (!panicData.title) {
                errors = {...errors, ...{titleError: 'Title is missing'}};
            } else {
                errors = {...errors, ...{titleError: undefined}};
            }
            if (!panicData.description) {
                errors = {...errors, ...{descriptionError: 'Description is missing'}};
            } else {
                errors = {...errors, ...{descriptionError: undefined}};
            }
            if (!panicData.email) {
                errors = {...errors, ...{emailError: 'Email is missing'}};
            } else if (!validateEmail(panicData.email)) {
                errors = {...errors, ...{emailError: 'Email is not valid'}};
            } else {
                errors = {...errors, ...{emailError: undefined}};
            }
            setPanicDataErrors(errors);
        }
    }

    const sendPanicAlert = () => {
        goToNextStep();
        const allPanicAlertData = {...panicData, ...jobRunrInfo};
        const {allowAnonymousDataUsage, usingBatches, usingWorkflow, ...panicDataToSend} = allPanicAlertData;
        fetch(`${jobRunrAPIBackend}/api/panic/create-panic-alert`, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(panicDataToSend)
        })
            .then(res => res.json())
            .then(json => {
                if (json.githubIssueUrl) {
                    setPanicDataResult(json);
                    goToNextStep();
                } else {
                    setCurrentStep(-1)
                }
            })
            .catch(error => setCurrentStep(-1));
    }

    const cannotContactJobRunrAPI = (
        <StyledDialog key="step-error" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>JobRunr Pro Backend API not reachable</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <center>
                    <p>It appears your browser cannot contact the JobRunr Pro Backend<br/>(e.g. due to firewall reasons,
                        ...).</p>
                    <p>You are unable to create a Panic Alert at this time.</p>
                    <p>You can however try to contact our lead engineer, Ronald Dehuysser,<br/>
                        using the following mobile number: <a href={"tel:+32487717535"}>+32 487 717 535</a></p>
                    <p><strong>Note:</strong>&nbsp;the amount of panic alerts is defined in your JobRunr Pro license.
                        Exceeding this amount may result in additional costs.</p>
                </center>
            </DialogContent>
        </StyledDialog>
    );

    const steps = [
        <StyledDialog key="step-1" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>Please use Panic Alert only for severe outages</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <center>
                    <p>This will alert, me - Ronald Dehuysser, the lead JobRunr Pro Developer.<br/>Worldwide - 24/7/365.
                    </p>
                    <p>I will try to join you as soon as possible (typically within a couple of minutes, worst-case a
                        couple of hours) and try to help you
                        resolve the<br/><strong>production issue</strong> you're encountering.</p>
                    <p><strong>Note:</strong>&nbsp;the amount of panic alerts is defined in your JobRunr Pro
                        subscription.
                        Exceeding this amount may result in additional costs.</p>
                </center>
            </DialogContent>
            <DialogActions>
                <Button id="cancel-alert-btn" color="inherit" variant="outlined" onClick={() => navigate(-1)}>
                    Cancel
                </Button>
                <Button id="create-alert-btn" color="inherit" variant="outlined" onClick={goToNextStep}>
                    Create Panic Alert
                </Button>
            </DialogActions>
        </StyledDialog>,
        <StyledDialog key="step-2" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>Please use Panic Alert only for severe outages</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <center><p>Panic Alert will notify Ronald Dehuysser.<br/>Worldwide - 24/7/365.</p></center>

                <form noValidate autoComplete="off">
                    <StyledTextField id="title" name="title" label="Issue Title" fullWidth
                                     required
                                     onChange={(e) => setPanicData({...panicData, ...{title: e.target.value}})}
                                     value={panicData.title}
                                     placeholder="What is wrong?"
                                     error={panicDataErrors.titleError !== undefined}
                                     helperText={panicDataErrors.titleError}/>
                    <StyledTextField id="description" name="description"
                                     label="Issue Description" fullWidth required multiline
                                     minRows={4}
                                     onChange={(e) => setPanicData({...panicData, ...{description: e.target.value}})}
                                     value={panicData.description}
                                     placeholder="Describe shortly what is currently and let us know how to reach you (e.g. Teams call, Zoom meeting link, ...). "
                                     error={panicDataErrors.descriptionError !== undefined}
                                     helperText={panicDataErrors.descriptionError ?? 'Do not forget to add how we can reach you quickly.'}/>
                    <StyledTextField id="email" name="email" label="Your email address"
                                     fullWidth required
                                     onChange={(e) => setPanicData({...panicData, ...{email: e.target.value}})}
                                     value={panicData.email}
                                     placeholder="Your email address"
                                     error={panicDataErrors.emailError !== undefined}
                                     helperText={panicDataErrors.emailError}/>
                </form>
            </DialogContent>
            <DialogActions>
                <Button id="cancel-create-alert-btn" color="inherit" variant="outlined" onClick={cancel}>
                    Cancel
                </Button>
                <Button id="continue-create-alert-btn" color="inherit" variant="outlined" onClick={validatePanicAlert}>
                    Continue
                </Button>
            </DialogActions>
        </StyledDialog>,
        <StyledDialog key="step-3" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>Please use Panic Alert only for severe outages</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <p>
                    <center>Confirm to send panic alert to Ronald Dehuysser,<br/>the lead JobRunr Pro developer.
                    </center>
                </p>
            </DialogContent>
            <DialogActions>
                <Link style={{cursor: 'pointer'}} onClick={goToPreviousStep} underline="hover">← edit issue</Link>
                &nbsp;
                <Button id="cancel-create-alert-btn" color="inherit" variant="outlined" onClick={cancel}>
                    Cancel
                </Button>
                &nbsp;
                <Button id="continue-create-alert-btn" color="inherit" variant="outlined" onClick={sendPanicAlert}>
                    Send Panic Alert
                </Button>
            </DialogActions>
        </StyledDialog>,
        <StyledDialog key="step-4" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>Creating Panic Alert!</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <center>
                    <p>Paging Ronald Dehuysser...</p>
                    <CircularProgress/>
                </center>
            </DialogContent>
        </StyledDialog>,
        <StyledDialog key="step-5" open={true}>
            <DialogTitle>
                <center>
                    <AlertBoxOutline style={{color: "red", fontSize: '80'}}/>
                    <div>Panic Alert created!</div>
                </center>
            </DialogTitle>
            <DialogContent>
                <center>
                    <p>Ronald Dehuysser has been paged to join the discussion.</p>
                    <p>Please share extra details about the issue here:<br/>
                        <a target="_blank" rel="noreferrer"
                           href={panicDataResult.githubIssueUrl}>{panicDataResult.githubIssueUrl}</a>
                    </p>
                </center>
            </DialogContent>
        </StyledDialog>,
    ];

    return (
        <Backdrop open={true}>
            {currentStep >= 0
                ? steps[currentStep]
                : cannotContactJobRunrAPI
            }
        </Backdrop>
    )
}

export default Panic;