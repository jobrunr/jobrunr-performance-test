import {useContext, useEffect, useState} from 'react';
import Typography from '@mui/material/Typography';
import Table from '@mui/material/Table';
import Checkbox from '@mui/material/Checkbox';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import TimeAgo from "react-timeago/lib";
import Box from "@mui/material/Box";
import Alert from '@mui/material/Alert'
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    IconButton,
    Snackbar,
    TablePagination,
    TableSortLabel,
    TextField,
    Tooltip
} from "@mui/material";
import {styled} from "@mui/material/styles";
import EditIcon from '@mui/icons-material/Edit';
import WarningRoundedIcon from '@mui/icons-material/WarningRounded';
import SaveIcon from "@mui/icons-material/Save";
import {History} from "mdi-material-ui";
import cronstrue from 'cronstrue';
import {useLocation, useNavigate} from "react-router-dom";
import LoadingIndicator from "../LoadingIndicator";
import VersionFooter from "../utils/version-footer";
import {isCron, prefixWithContextPath, prefixWithPublicUrl} from "../../utils/helper-functions";
import {allItemsSelected, selectAllItems, selectedItems, selectItem} from "../utils/job-selections";
import JobLabel from "../utils/job-label";
import RecurringJobsFilterPanel from "./recurring-jobs-filter-panel";
import RecurringJobActions from "./actions/recurring-job-actions";
import {UserContext} from "../../UserContext";
import {ItemsNotFound} from "../utils/items-not-found";

const IdColumn = styled(TableCell)`
    width: 15rem;
    max-width: 15rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
`;

const NameColumn = styled(TableCell)`
    width: 45rem;
    max-width: 45rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
`;

const RecurringJobs = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const urlSearchParams = new URLSearchParams(location.search);
    const sortQueryParam = urlSearchParams.get('sort') || 'jobName:ASC';
    const page = urlSearchParams.get('page');
    const itemsPerPage = urlSearchParams.get('itemsPerPage') || 20;
    const [isLoading, setIsLoading] = useState(true);
    const [recurringJobPage, setRecurringJobPage] = useState({total: 0, limit: 20, currentPage: 0, items: []});
    const [recurringJobs, setRecurringJobs] = useState([{}]);
    const [apiStatus, setApiStatus] = useState(null);

    const [warningDialogRecurringJob, setWarningDialogRecurringJob] = useState(null);
    const [editableRecurringJob, setEditableRecurringJob] = useState(null);
    const [editedScheduleExpression, setEditedScheduleExpression] = useState(null);
    const [editScheduleExpressionHasError, setEditScheduleExpressionHasError] = useState(false);
    const [scheduleExpressionErrorText, setScheduleExpressionErrorText] = useState(null);

    const {
        authorizationRules: {
            canDeleteRecurringJobs,
            canControlRecurringJobs,
            canAccessJobs
        }
    } = useContext(UserContext);
    const hasWriteAccess = canDeleteRecurringJobs || canControlRecurringJobs;
    const canEditOrViewJobs = canAccessJobs || canControlRecurringJobs;

    useEffect(() => {
        getRecurringJobs();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, itemsPerPage, location.key]);

    const getRecurringJobs = () => {
        setIsLoading(true);
        const offset = (page) * itemsPerPage;
        const limit = itemsPerPage;

        const apiSearchParams = new URLSearchParams(location.search);
        apiSearchParams.set('order', sortQueryParam);
        apiSearchParams.set('offset', offset);
        apiSearchParams.set('limit', limit);
        fetch(prefixWithContextPath(`/api/recurring-jobs?${apiSearchParams.toString()}`))
            .then(res => res.json())
            .then(response => {
                setRecurringJobPage(response);
                setRecurringJobs(response.items.map(recurringJob => ({...recurringJob, selected: false})));
                setIsLoading(false);
            })
            .catch(error => console.log(error));
    };

    const handleSort = (newSort) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.delete('page');
        urlSearchParams.set('sort', newSort);
        navigate(`?${urlSearchParams.toString()}`);
    };

    const handleChangePage = (event, newPage) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action')
        urlSearchParams.set('page', newPage);
        navigate(`?${urlSearchParams.toString()}`);
    };

    const handleChangeRowsPerPage = (event) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.set('itemsPerPage', event.target.value);
        navigate(`?${urlSearchParams.toString()}`);
    }

    const handleCloseAlert = (event, reason) => {
        setApiStatus(null);
    };

    const navigateToPreviousRuns = (recurringJob) => {
        navigate(prefixWithPublicUrl(`/jobs?recurringJobId=${recurringJob.id}`));
    }

    const handleOpenWarningDialog = (recurringJob) => {
        setWarningDialogRecurringJob(recurringJob);
    }

    const handleCloseWarningDialog = () => {
        setWarningDialogRecurringJob(null);
    }
    const handleOpenEditDialog = (recurringJob) => {
        setEditableRecurringJob(recurringJob);
    }

    const handleCloseEditDialog = () => {
        setEditableRecurringJob(null);
        setEditScheduleExpressionHasError(false);
        setScheduleExpressionErrorText(null);
    }

    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            handleSubmitDialog();
        }
    }

    const handleSubmitDialog = () => {
        setEditScheduleExpressionHasError(false);
        let apiSearchParams = new URLSearchParams(location.search);
        apiSearchParams.set('id', editableRecurringJob.id);
        apiSearchParams.set('scheduleExpression', editedScheduleExpression);
        fetch(prefixWithContextPath(`/api/recurring-jobs/edit?${apiSearchParams.toString()}`), {method: 'POST'})
            .then(res => res.json())
            .then(() => {
                handleCloseEditDialog();
                urlSearchParams.set('action', "edit");
                navigate(`?${urlSearchParams.toString()}`, {replace: true});
            })
            .catch(() => {
                if (editableRecurringJob.scheduleJobsSkippedDuringDowntime === true) {
                    setScheduleExpressionErrorText("Failed to update schedule. Input can not be parsed to cron or duration, or change is not allowed.");
                } else {
                    setScheduleExpressionErrorText("Input can not be parsed to cron or duration.");
                }
                setEditScheduleExpressionHasError(true);
            });
    }

    return (
        <div>
            <Box my={3}>
                <Typography variant="h4">Recurring Jobs</Typography>
            </Box>

            {isLoading
                ? <LoadingIndicator/>
                : <>
                    <RecurringJobsFilterPanel/>
                    <div>&nbsp;</div>
                    <Paper>
                        {recurringJobs.length < 1
                            ? <ItemsNotFound>No recurring jobs found</ItemsNotFound>
                            : <>
                                <Grid item xs={12} container style={{minHeight: "60px"}}>
                                    <Grid item xs={6}>
                                        {hasWriteAccess &&
                                            <RecurringJobActions
                                                allRecurringJobsSelected={allItemsSelected(recurringJobs)}
                                                selectedRecurringJobs={selectedItems(recurringJobs)}
                                                pageSize={recurringJobPage.limit}/>
                                        }
                                    </Grid>
                                    <Grid item xs={6}>
                                        <TablePagination
                                            id="recurring-jobs-table-pagination-header"
                                            component="div"
                                            rowsPerPageOptions={[20, 50, 100]}
                                            count={recurringJobPage.total}
                                            rowsPerPage={recurringJobPage.limit}
                                            page={recurringJobPage.currentPage}
                                            onPageChange={handleChangePage}
                                            onRowsPerPageChange={handleChangeRowsPerPage}
                                        />
                                    </Grid>
                                </Grid>
                                <TableContainer>
                                    <Table id="recurring-jobs-table" aria-label="recurring jobs overview">
                                        <TableHead>
                                            <TableRow>
                                                {hasWriteAccess &&
                                                    <TableCell padding="checkbox">
                                                        <Checkbox
                                                            checked={allItemsSelected(recurringJobs)}
                                                            onClick={(evt) => selectAllItems(evt, setRecurringJobs, recurringJobs)}/>
                                                    </TableCell>
                                                }
                                                <IdColumn style={{fontWeight: 'bold'}}>Id</IdColumn>
                                                <NameColumn style={{fontWeight: 'bold'}}>
                                                    <TableSortLabel active={sortQueryParam.startsWith('jobName')}
                                                                    direction={sortQueryParam.endsWith('ASC') ? 'asc' : 'desc'}
                                                                    onClick={() => sortQueryParam.includes('jobName:ASC') ? handleSort('jobName:DESC') : handleSort('jobName:ASC')}>
                                                        Job name
                                                    </TableSortLabel>
                                                </NameColumn>
                                                <TableCell style={{fontWeight: 'bold'}}>Schedule</TableCell>
                                                <TableCell style={{fontWeight: 'bold'}}>Time zone</TableCell>
                                                <TableCell style={{fontWeight: 'bold'}}>Next run</TableCell>
                                                {canEditOrViewJobs &&
                                                    <TableCell style={{fontWeight: 'bold'}}>Actions</TableCell>}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {recurringJobs.map(recurringJob => (
                                                <TableRow key={recurringJob.id}>
                                                    {hasWriteAccess &&
                                                        <TableCell padding="checkbox">
                                                            <Checkbox checked={recurringJob.selected}
                                                                      onClick={() => selectItem(recurringJob, setRecurringJobs, recurringJobs)}/>
                                                        </TableCell>
                                                    }
                                                    <IdColumn component="th" scope="row" title={recurringJob.id}>
                                                        {recurringJob.id}
                                                    </IdColumn>
                                                    <TableCell>
                                                        {recurringJob.labels?.map((label) => (
                                                            <JobLabel key={label}
                                                                      disabled={!canAccessJobs}
                                                                      to={prefixWithPublicUrl(`/jobs?label=${label}`)}
                                                                      text={label}/>))}
                                                        {recurringJob.jobName}
                                                    </TableCell>
                                                    <TableCell>
                                                        <div style={{display: "flex", alignItems: "center"}}>
                                                            <Tooltip title={recurringJob.scheduleExpression}>
                                                                <div style={{
                                                                    maxWidth: "150px",
                                                                    overflow: "hidden",
                                                                    textOverflow: "ellipsis",
                                                                    display: "inline-block"
                                                                }}>
                                                                    {isCron(recurringJob.scheduleExpression)
                                                                        ? cronstrue.toString(recurringJob.scheduleExpression)
                                                                        : recurringJob.scheduleExpression}
                                                                </div>
                                                            </Tooltip>
                                                            {recurringJob.scheduleUpdated &&
                                                                <Tooltip
                                                                    title="Schedule may change on server restart. Click for more info."
                                                                    style={{marginLeft: '1em'}}>
                                                                    <IconButton size="small"
                                                                                onClick={() => handleOpenWarningDialog(recurringJob)}>
                                                                        <WarningRoundedIcon fontSize="small"/>
                                                                    </IconButton>
                                                                </Tooltip>
                                                            }
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>
                                                        {recurringJob.zoneId}
                                                    </TableCell>
                                                    <TableCell>
                                                        {recurringJob.isPaused
                                                            ? <>Paused</>
                                                            : <TimeAgo date={new Date(recurringJob.nextRunAt)}
                                                                       title={new Date(recurringJob.nextRunAt).toString()}/>
                                                        }
                                                    </TableCell>
                                                    {canEditOrViewJobs && <TableCell>
                                                        {canControlRecurringJobs && <Tooltip
                                                            title="Edit schedule">
                                                            <IconButton size="small"
                                                                        onClick={() => handleOpenEditDialog(recurringJob)}>
                                                                <EditIcon/>
                                                            </IconButton>
                                                        </Tooltip>}
                                                        {canAccessJobs && <Tooltip
                                                            title="Go to previous runs.">
                                                            <IconButton size="small"
                                                                        onClick={() => navigateToPreviousRuns(recurringJob)}>
                                                                <History/>
                                                            </IconButton>
                                                        </Tooltip>}
                                                    </TableCell>}
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                                <TablePagination
                                    id="recurring-jobs-table-pagination-footer"
                                    component="div"
                                    rowsPerPageOptions={[20, 50, 100]}
                                    count={recurringJobPage.total}
                                    rowsPerPage={recurringJobPage.limit}
                                    page={recurringJobPage.currentPage}
                                    onPageChange={handleChangePage}
                                    onRowsPerPageChange={handleChangeRowsPerPage}
                                />
                            </>
                        }
                    </Paper>
                    {warningDialogRecurringJob &&
                        <Dialog open={true}
                                onClose={handleCloseWarningDialog}
                                aria-labelledby="warning-label-dialog-title"
                                aria-describedby="warning-label-dialog-description">
                            <DialogTitle id="warning-label-dialog-title">
                                Your schedule may change unexpectedly!
                            </DialogTitle>
                            <DialogContent dividers>
                                <DialogContentText>
                                    The schedule for recurring job with id '{warningDialogRecurringJob.id}' was changed
                                    from the dashboard. <br/> <br/>
                                    If this recurring job was created by your application on start-up (.e.g. by using
                                    the <code>@Recurring</code> annotation),
                                    then the schedule will be overridden again if another instance of the application
                                    starts or the application restarts.
                                </DialogContentText>
                            </DialogContent>
                        </Dialog>}
                    {editableRecurringJob &&
                        <Dialog open={true}
                                onClose={handleCloseEditDialog}
                                aria-labelledby="edit-schedule-dialog-title"
                                aria-describedby="edit-schedule-dialog-description">
                            <DialogTitle id="edit-schedule-dialog-title">
                                Edit Recurring Job with id {editableRecurringJob.id}
                            </DialogTitle>
                            <DialogContent dividers>
                                <TextField
                                    variant="standard"
                                    id="edit-schedule-dialog-content"
                                    label="Schedule expression"
                                    error={editScheduleExpressionHasError}
                                    helperText={editScheduleExpressionHasError ? scheduleExpressionErrorText : undefined}
                                    placeholder={editableRecurringJob.scheduleExpression}
                                    onChange={(e) => setEditedScheduleExpression(e.target.value)}
                                    autoFocus={true}
                                    onKeyDown={handleKeyPress}
                                    fullWidth />
                                {editableRecurringJob.scheduleJobsSkippedDuringDowntime &&
                                    <DialogContentText>
                                        <br/>
                                        <small>
                                            This recurring job is configured to schedule jobs that were missed due to
                                            downtime (by means
                                            of <code>scheduleJobsSkippedDuringDowntime</code>).
                                            Therefore it's not allowed to put a schedule of smaller than 1 minute.
                                        </small>
                                    </DialogContentText>
                                }
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={handleCloseEditDialog} color="inherit">
                                    Cancel
                                </Button>
                                <Button type={"submit"} onClick={handleSubmitDialog} color="inherit"
                                        startIcon={<SaveIcon/>}>
                                    Save
                                </Button>
                            </DialogActions>
                        </Dialog>
                    }
                    <VersionFooter/>
                </>
            }
            {apiStatus &&
                <Snackbar open={true}
                          autoHideDuration={3000}
                          onClose={handleCloseAlert}
                          anchorOrigin={{vertical: "bottom", horizontal: "center"}}
                >
                    <Alert severity={apiStatus.severity}>
                        {apiStatus.message}
                    </Alert>
                </Snackbar>
            }
        </div>
    );
};

export default RecurringJobs;