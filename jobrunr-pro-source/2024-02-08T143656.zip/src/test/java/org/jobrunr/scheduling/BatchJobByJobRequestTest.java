package org.jobrunr.scheduling;

import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestEnqueueNewWorkJobRequest;
import org.jobrunr.stubs.TestEnqueueNewWorkWithoutAnnotationJobRequest;
import org.jobrunr.stubs.TestJobRequest;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static java.time.Duration.ofMillis;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.FIVE_SECONDS;
import static org.awaitility.Durations.TEN_SECONDS;
import static org.awaitility.Durations.TWO_MINUTES;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.scheduling.JobBuilder.aBatchJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LINUX;
import static org.jobrunr.stubs.TestService.LowPrioQueue;

public class BatchJobByJobRequestTest {

    private TestService testService;
    private StorageProvider storageProvider;
    private BackgroundJobServer backgroundJobServer;

    @BeforeEach
    void setUpTests() {
        testService = new TestService();
        testService.reset();

        storageProvider = new InMemoryStorageProvider();
        JobRunrPro.configure()
                .useStorageProvider(storageProvider)
                .useQueues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue)
                .useBackgroundJobServer(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofMillis(500)).andTags(LINUX).andWorkerCount(2))
                .initialize();

        backgroundJobServer = JobRunrPro.getBackgroundJobServer();
    }

    @AfterEach
    void cleanUp() {
        MDC.clear();
        backgroundJobServer.stop();
    }

    @Test
    void testBatchJobChaining() {
        JobRequestId jobRequestId = BackgroundJobRequest
                .startBatch(new TestEnqueueNewWorkJobRequest(3))
                .continueWith(new TestJobRequest("Job numero uno"));
        await().atMost(TWO_MINUTES).until(() -> storageProvider.getJobById(jobRequestId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobRequestId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testBatchJobChildJobsDoNotStartUnlessParentSucceeds() {
        JobRequestId jobId = BackgroundJobRequest
                .startBatch(new TestEnqueueNewWorkJobRequest(4500, 150, 3));
        await().atMost(FIVE_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).getJobStatesOfType(FailedState.class).count() == 1);
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isEqualTo(150);
        await().atMost(FIVE_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).getJobStatesOfType(FailedState.class).count() == 2);
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isEqualTo(150);
        await().pollInterval(50, MILLISECONDS)
                .atMost(20, SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasState(PROCESSED));
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isGreaterThan(3000);
    }

    @Test
    void testBatchJobChildJobsStartWhenParentSucceeds() {
        JobRequestId jobId = BackgroundJobRequest
                .startBatch(new TestEnqueueNewWorkJobRequest(500));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(500));
    }

    @Test
    void testBatchJobSucceedsWhenAllChildJobsSucceed() {
        JobRequestId jobId = BackgroundJobRequest
                .startBatch(new TestEnqueueNewWorkJobRequest(100));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(100));
        await().atMost(TEN_SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(SUCCEEDED)
                        .hasDeletedAtNotNull());
    }

    @Test
    void testBatchJobCreatedByJobBuilderSucceedsWhenAllChildJobsSucceed() {
        JobRequestId jobId = BackgroundJobRequest
                .create(aBatchJob().withJobRequest(new TestEnqueueNewWorkWithoutAnnotationJobRequest(100)));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(100));
        await().atMost(TEN_SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(SUCCEEDED)
                        .hasDeletedAtNotNull());
    }
}
