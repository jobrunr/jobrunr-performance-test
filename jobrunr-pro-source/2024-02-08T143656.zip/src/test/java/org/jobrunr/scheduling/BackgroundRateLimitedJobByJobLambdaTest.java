package org.jobrunr.scheduling;

import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.util.UUID;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.time.Duration.ofSeconds;
import static java.util.UUID.randomUUID;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.ONE_MINUTE;
import static org.awaitility.Durations.TEN_SECONDS;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThatJobs;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.scheduling.JobBuilder.aJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.stubs.TestService.CONCURRENT_JOB_RATE_LIMITER;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LINUX;
import static org.jobrunr.stubs.TestService.LowPrioQueue;

public class BackgroundRateLimitedJobByJobLambdaTest {

    private TestService testService;
    private StorageProvider storageProvider;
    private BackgroundJobServer backgroundJobServer;

    @BeforeEach
    void setUpTests() {
        testService = new TestService();
        testService.reset();

        storageProvider = new InMemoryStorageProvider();
        JobRunrPro.configure()
                .useStorageProvider(storageProvider)
                .useRateLimiter(concurrentJobRateLimiter(CONCURRENT_JOB_RATE_LIMITER, 2))
                .useQueues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue)
                .useBackgroundJobServer(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofSeconds(2)).andTags(LINUX).andWorkerCount(2))
                .initialize();

        backgroundJobServer = JobRunrPro.getBackgroundJobServer();
    }

    @AfterEach
    void cleanUp() {
        MDC.clear();
        backgroundJobServer.stop();
    }

    @Test
    void testRateLimiterWhenEnqueueingJobPerJob() {
        final JobProId jobId1 = BackgroundJob.enqueue(() -> testService.doWorkWithRateLimiter());
        final JobProId jobId2 = BackgroundJob.enqueue(() -> testService.doWorkWithRateLimiter());

        await().atMost(7, SECONDS).until(() -> storageProvider.getJobById(jobId1).hasState(SUCCEEDED) && storageProvider.getJobById(jobId2).hasState(SUCCEEDED));

        assertThat(storageProvider.getJobById(jobId1))
                .hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);

        assertThat(storageProvider.getJobById(jobId2))
                .hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRateLimiterWhenEnqueueingStreamOfJobs() {
        Stream<Integer> intStream = IntStream.range(0, 2).boxed();
        BackgroundJob.enqueue(intStream, i -> testService.doWorkWithRateLimiter());

        await().atMost(7, SECONDS).until(() -> storageProvider.getJobList(new JobSearchRequest(SUCCEEDED), Paging.AmountBasedList.ascOnUpdatedAt(10)).size() == 2);

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(SUCCEEDED), Paging.AmountBasedList.ascOnUpdatedAt(10)))
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testRateLimiterWhenCreatingJobUsingJobBuilderPerJob() {
        final JobProId jobId1 = BackgroundJob.create(aJob().withRateLimiter(CONCURRENT_JOB_RATE_LIMITER).withDetails(() -> testService.doWork(randomUUID())));
        final JobProId jobId2 = BackgroundJob.create(aJob().withRateLimiter(CONCURRENT_JOB_RATE_LIMITER).withDetails(() -> testService.doWork(randomUUID())));

        await().atMost(7, SECONDS).until(() -> storageProvider.getJobById(jobId1).hasState(SUCCEEDED) && storageProvider.getJobById(jobId2).hasState(SUCCEEDED));

        assertThat(storageProvider.getJobById(jobId1))
                .hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);

        assertThat(storageProvider.getJobById(jobId2))
                .hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRateLimiterWhenCreatingStreamOfJobsUsingJobBuilder() {
        Stream<JobBuilder> jobBuilderStream = IntStream.range(0, 2).boxed()
                .map(i -> aJob()
                        .withRateLimiter(CONCURRENT_JOB_RATE_LIMITER)
                        .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID())));
        BackgroundJob.create(jobBuilderStream);

        await().atMost(7, SECONDS).until(() -> storageProvider.getJobList(new JobSearchRequest(SUCCEEDED), Paging.AmountBasedList.ascOnUpdatedAt(10)).size() == 2);

        assertThatJobs(storageProvider.getJobList(new JobSearchRequest(SUCCEEDED), Paging.AmountBasedList.ascOnUpdatedAt(10)))
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testBatchJobSucceedsWhenAllChildJobsSucceedUsingRateLimiter() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewRateLimitedBatchWork(5));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(ONE_MINUTE)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(5));
        await().atMost(TEN_SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(SUCCEEDED)
                        .hasDeletedAtNotNull());

        Page<Job> childJobs = storageProvider.getJobs(aJobSearchRequest().withJobSignature("org.jobrunr.stubs.TestService.doWorkWithRateLimiter()").build(), Paging.OffsetBasedPage.ascOnUpdatedAt(10));
        assertThatJobs(childJobs).allSatisfy(job -> assertThat(job).hasStates(AWAITING, AWAITING, ENQUEUED, PROCESSING, SUCCEEDED));
    }
}
