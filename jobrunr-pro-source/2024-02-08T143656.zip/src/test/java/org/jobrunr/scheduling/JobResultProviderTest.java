package org.jobrunr.scheduling;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.AbstractJobState;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.jobs.states.SucceededState;
import org.jobrunr.storage.JobNotFoundException;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static java.time.Duration.ofMillis;
import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.time.temporal.ChronoUnit.SECONDS;
import static java.util.Arrays.asList;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.scheduling.JobResultState.FAILED;
import static org.jobrunr.scheduling.JobResultState.SUCCEEDED;
import static org.jobrunr.scheduling.JobResultState.UNDETERMINED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JobResultProviderTest {

    @Mock
    StorageProvider storageProviderMock;

    JobResultProvider jobResultProvider;

    @BeforeEach
    void setUpJobResultProvider() {
        jobResultProvider = new JobResultProvider(storageProviderMock);
    }

    @Test
    void whenJobIfNotAvailableAJobNotFoundExceptionIsThrown() {
        doThrow(new JobNotFoundException("not important"))
                .when(storageProviderMock).getJobById(Mockito.any(UUID.class));

        assertThatThrownBy(() -> jobResultProvider.get(UUID.randomUUID()))
                .isInstanceOf(JobNotFoundException.class);
    }

    @Test
    void whenJobIsStillEnqueuedAnUndeterminedJobResultWithUnavailableIsReturned() {
        Job job = anEnqueuedJobWithName().build();
        mockStorageProvider(job, null);

        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(UNDETERMINED)
                .isUnavailable()
                .hasBackOffPeriod(Duration.ofSeconds(5));
    }

    @Test
    void whenJobIsEnqueuedForLongTimeAnUndeterminedJobResultWithUnavailableIsReturned() {
        Job job = anEnqueuedJobWithName().build();
        mockStorageProvider(job, null);
        jobResultProvider.get(job.getId());

        await().during(5, TimeUnit.SECONDS).until(() -> jobResultProvider.get(job.getId()).getState() == UNDETERMINED);
        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(UNDETERMINED)
                .isUnavailable()
                .hasBackOffPeriod(Duration.ofSeconds(10));
    }

    @Test
    void whenJobHasFailedAFailedJobResultIsReturned() {
        Job job = aFailedJob().build();
        mockStorageProvider(job, null);

        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(FAILED)
                .isUnavailable();
    }

    @Test
    void whenJobHasSucceededASucceededJobResultIsReturned() {
        Job job = aSucceededJob().withJobResult("Some String").build();
        mockStorageProvider(job, job);

        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(SUCCEEDED)
                .isAvailable()
                .hasResult("Some String");
    }

    @Test
    void whenJobIsDeletedButSucceededJobResultIsReturned() {
        Job job = aSucceededJob().withJobResult("Some String").withDeletedState().build();
        mockStorageProvider(job, job);

        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(SUCCEEDED)
                .isAvailable()
                .hasResult("Some String");
    }

    @Test
    void whenJobIsDeletedButFailedJobResultIsNotReturned() {
        Job job = aFailedJob().withDeletedState().build();
        mockStorageProvider(job, null);

        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(FAILED)
                .isUnavailable();
    }

    @Test
    void whenFailedJobIsRequestedAgainTheSameResultIsReturned() {
        Job job = aFailedJob().withDeletedState().build();
        mockStorageProvider(job, job);

        jobResultProvider.get(job.getId());
        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(FAILED)
                .isUnavailable();
    }

    @Test
    void whenSucceededJobIsRequestedAgainTheSameResultIsReturned() {
        Job job = aSucceededJob().withJobResult("Some String").build();
        mockStorageProvider(job, job);
        jobResultProvider.get(job.getId());
        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(SUCCEEDED)
                .isAvailable()
                .hasResult("Some String");
    }

    @Test
    void whenJobIsFirstEnqueuedAndThenSucceededTheSucceededJobResultIsReturned() {
        Job job = anEnqueuedJobWithName().build();
        Job succeededJob = aCopyOf(job).withSucceededState().withJobResult("Some String").build();
        mockStorageProvider(job, succeededJob);
        jobResultProvider.get(job.getId());

        await().until(() -> jobResultProvider.get(job.getId()).getState() == SUCCEEDED);
        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(SUCCEEDED)
                .isAvailable()
                .hasResult("Some String");
    }

    @Test
    void whenJobIsFirstEnqueuedAndThenFailedTheFailedJobResultIsReturned() {
        Job job = anEnqueuedJobWithName().build();
        Job failedJob = aCopyOf(job).withFailedState().build();
        mockStorageProvider(job, failedJob);
        jobResultProvider.get(job.getId());

        await().until(() -> jobResultProvider.get(job.getId()).getState() == FAILED);
        JobResultWithBackOffInfo result = jobResultProvider.get(job.getId());
        assertThat(result)
                .hasState(FAILED)
                .isUnavailable();
    }

    @Test
    void backOffPeriodTakesIntoAccountPreviousResults() {
        Job job1 = anEnqueuedJobWithName().build();
        waitUntilJob1FinishedSuccessfully(job1);

        Job job2 = aCopyOf(job1).withId().build();
        when(storageProviderMock.getJobById(job2.getId())).thenReturn(job2);
        JobResultWithBackOffInfo result2 = jobResultProvider.get(job2.getId());
        assertThat(result2)
                .hasState(UNDETERMINED)
                .hasBackOffPeriodGreaterThan(Duration.ofHours(2));
    }

    @Test
    void backOffPeriodDoesNotTakeIntoAccountPreviousFailedResults() {
        Job job1 = anEnqueuedJobWithName().build();
        waitUntilJob1Finished(job1, new FailedState("Some reason", new RuntimeException("Boem"), Duration.ZERO, Duration.ZERO), now().plus(2, ChronoUnit.HOURS));

        Job job2 = aCopyOf(job1).withId().build();
        when(storageProviderMock.getJobById(job2.getId())).thenReturn(job2);
        jobResultProvider.get(job2.getId());

        try (MockedStatic<Instant> instantMock = mockTime(now().plus(90, MINUTES))) {
            JobResultWithBackOffInfo result2 = jobResultProvider.get(job2.getId());
            assertThat(result2)
                    .hasState(UNDETERMINED)
                    .hasCheckAgainAfterBetween(now().minus(14, SECONDS), now().plus(16, SECONDS))
                    .hasBackOffPeriod(Duration.ofSeconds(10));
        }
    }

    @Test
    void backOffPeriodTakesIntoAccountPreviousSucceededResultsAndAdaptsTimeIfResultIsAlmostAvailable() {
        Job job1 = anEnqueuedJobWithName().build();
        waitUntilJob1FinishedSuccessfully(job1);

        Job job2 = aCopyOf(job1).withId().build();
        when(storageProviderMock.getJobById(job2.getId())).thenReturn(job2);
        jobResultProvider.get(job2.getId());

        try (MockedStatic<Instant> instantMock = mockTime(now().plus(90, MINUTES))) {
            JobResultWithBackOffInfo result2 = jobResultProvider.get(job2.getId());
            assertThat(result2)
                    .hasState(UNDETERMINED)
                    .hasCheckAgainAfterBetween(now().plus(29, MINUTES), now().plus(31, MINUTES))
                    .hasBackOffPeriodBetween(Duration.ofMinutes(29), Duration.ofMinutes(31));
        }
    }

    @Test
    void backOffPeriodAddsIncrementalBackoffTimeIfBackoffPeriodIsReached() {
        Job job1 = anEnqueuedJobWithName().build();
        waitUntilJob1FinishedSuccessfully(job1);

        Job job2 = aCopyOf(job1).withId().build();
        when(storageProviderMock.getJobById(job2.getId())).thenReturn(job2);
        jobResultProvider.get(job2.getId());

        try (MockedStatic<Instant> instantMock = mockTime(now().plus(121, MINUTES))) {
            JobResultWithBackOffInfo result2 = jobResultProvider.get(job2.getId());
            assertThat(result2)
                    .hasState(UNDETERMINED)
                    .hasCheckAgainAfterBefore(now().plus(1, MINUTES)) // 5 minutes + 15 sec added
                    .hasBackOffPeriodBetween(Duration.ofSeconds(55), Duration.ofSeconds(65));
        }

        try (MockedStatic<Instant> instantMock = mockTime(now().plus(125, MINUTES))) {
            JobResultWithBackOffInfo result2 = jobResultProvider.get(job2.getId());
            assertThat(result2)
                    .hasState(UNDETERMINED)
                    .hasCheckAgainAfterBefore(now().plus(5, MINUTES)) // 5 minutes + 15 sec added
                    .hasBackOffPeriodBetween(Duration.ofSeconds(295), Duration.ofSeconds(305));
        }
    }

    @Test
    void resultsAreCachedAndEvicted() {
        Map<String, Object> cache = Whitebox.getInternalState(jobResultProvider, "cache");

        Job job1 = anEnqueuedJobWithName().build();
        waitUntilJob1FinishedSuccessfully(job1);

        Job job2 = aCopyOf(job1).withId().build();
        when(storageProviderMock.getJobById(job2.getId())).thenReturn(job2);
        jobResultProvider.get(job2.getId());
        assertThat(cache).hasSize(2); // 2 results in cache

        try (MockedStatic<Instant> instantMock = mockTime(now().plus(125, MINUTES))) {
            jobResultProvider.get(job2.getId()); // result of job1 is evicted
            assertThat(cache).hasSize(1);
            jobResultProvider.get(job1.getId()); // result of job1 is fetched again and added to cache
            assertThat(cache).hasSize(2);
        }
    }

    private void waitUntilJob1FinishedSuccessfully(Job job1) {
        JobResultWithBackOffInfo result = waitUntilJob1Finished(job1, new SucceededState(ofMillis(10), ofMillis(3)), now().plus(2, ChronoUnit.HOURS));
        assertThat(result)
                .hasState(SUCCEEDED)
                .isAvailable()
                .hasResult("Some String");
    }

    private JobResultWithBackOffInfo waitUntilJob1Finished(Job job1, AbstractJobState state, Instant createdAt) {
        Job succeededJob = aCopyOf(job1)
                .withState(state, createdAt)
                .withJobResult("Some String")
                .build();
        mockStorageProvider(job1, succeededJob);
        jobResultProvider.get(job1.getId());

        await().until(() -> jobResultProvider.get(job1.getId()).getState() == SUCCEEDED || jobResultProvider.get(job1.getId()).getState() == FAILED);
        return jobResultProvider.get(job1.getId());
    }

    private void mockStorageProvider(Job job, Job jobWithResult) {
        when(storageProviderMock.getJobById(job.getId())).thenReturn(job);
        lenient().when(storageProviderMock.getJob(any(JobSearchRequest.class)))
                .thenAnswer(i -> {
                    JobSearchRequest jobSearchRequest = i.getArgument(0, JobSearchRequest.class);
                    if (jobWithResult != null
                            && jobSearchRequest.getStates().containsAll(asList(StateName.SUCCEEDED, StateName.FAILED, StateName.DELETED))
                            && jobSearchRequest.getJobId().equals(jobWithResult.getId())) {
                        return jobWithResult;
                    }
                    return null;
                })
                .thenReturn(null);
    }
}