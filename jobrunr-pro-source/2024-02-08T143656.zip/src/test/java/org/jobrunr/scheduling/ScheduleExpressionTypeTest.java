package org.jobrunr.scheduling;

import org.jobrunr.scheduling.cron.CronExpression;
import org.jobrunr.scheduling.custom.CustomScheduleTestImplementation;
import org.jobrunr.scheduling.interval.Interval;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneOffset;

import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.jobrunr.scheduling.custom.CustomScheduleTestImplementation.myCustomSchedule;

class ScheduleExpressionTypeTest {

    @Test
    void canParseScheduleFromCronExpression() {
        Schedule schedule = ScheduleExpressionType.getSchedule("* * * * *");
        assertThat(schedule)
                .isNotNull()
                .isInstanceOf(CronExpression.class);
    }

    @Test
    void canParseScheduleFromInterval() {
        Schedule schedule = ScheduleExpressionType.getSchedule("P5DT6H");
        assertThat(schedule)
                .isNotNull()
                .isInstanceOf(Interval.class);
    }

    @Test
    void canParseCustomSchedule() {
        Schedule schedule = ScheduleExpressionType.getSchedule(myCustomSchedule("2050-01-01T01:00:00.000Z"));

        assertThat(schedule).isNotNull();
        assertThat(schedule.next(now(), now(), ZoneOffset.UTC)).isEqualTo(Instant.parse("2050-01-01T01:00:00.000Z"));
    }

    @Test
    void customSchedulesAreCached() {
        Schedule schedule1 = ScheduleExpressionType.getSchedule(myCustomSchedule("2050-01-01T01:00:00.000Z"));
        Schedule schedule2 = ScheduleExpressionType.getSchedule(myCustomSchedule("2050-01-01T01:00:00.000Z"));

        assertThat(schedule1).isSameAs(schedule2);
    }

    @Test
    void newCustomScheduleIsCreatedWhenArgsChange() {
        Schedule schedule1 = ScheduleExpressionType.getSchedule(myCustomSchedule("2050-01-01T01:00:00.000Z"));
        Schedule schedule2 = ScheduleExpressionType.getSchedule(myCustomSchedule("2051-01-01T01:00:00.000Z"));

        assertThat(schedule1).isNotSameAs(schedule2);
    }

    @Test
    void tryToCreateACustomScheduleUsingNoArgConstructor() {
        Throwable thrown = catchThrowable(() -> {
            ScheduleExpressionType.getSchedule(CustomScheduleTestImplementation.class.getName() + "()");
        });
        assertThat(thrown).isInstanceOf(IllegalArgumentException.class);
    }


}