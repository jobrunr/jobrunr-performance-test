package org.jobrunr.scheduling;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import io.github.artsok.RepeatedIfExceptionsTest;
import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobTestBuilder;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.filters.JobCreationFilters;
import org.jobrunr.jobs.lambdas.JobLambda;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.ProcessingState;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.scheduling.custom.CustomScheduleTestImplementation;
import org.jobrunr.scheduling.exceptions.JobClassNotFoundException;
import org.jobrunr.scheduling.exceptions.JobMethodNotFoundException;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.LogAllStateChangesFilter;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobNotFoundException;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.StaticTestService;
import org.jobrunr.stubs.TestService;
import org.jobrunr.stubs.TestServiceForRecurringJobsIfStopTheWorldGCOccurs;
import org.jobrunr.utils.GCUtils;
import org.jobrunr.utils.annotations.Because;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.time.Instant.now;
import static java.time.ZoneId.systemDefault;
import static java.time.temporal.ChronoUnit.MINUTES;
import static java.util.Arrays.asList;
import static java.util.UUID.randomUUID;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.FIVE_HUNDRED_MILLISECONDS;
import static org.awaitility.Durations.FIVE_SECONDS;
import static org.awaitility.Durations.ONE_MINUTE;
import static org.awaitility.Durations.ONE_SECOND;
import static org.awaitility.Durations.TEN_SECONDS;
import static org.awaitility.Durations.TWO_SECONDS;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobAssert.scheduledNear;
import static org.jobrunr.jobs.JobDetailsTestBuilder.classThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.methodThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.scheduling.JobBuilder.aJob;
import static org.jobrunr.scheduling.RecurringJobBuilder.aRecurringJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.jobrunr.stubs.TestService.CONCURRENT_JOB_RATE_LIMITER;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LINUX;
import static org.jobrunr.stubs.TestService.LowPrioQueue;
import static org.jobrunr.utils.SleepUtils.sleep;

/**
 * Must be public as used as a background job
 * TODO: these tests should run for each StorageProvider!
 */
public class BackgroundJobByJobLambdaTest {

    private ListAppender<ILoggingEvent> jobFiltersLogger;
    private ListAppender<ILoggingEvent> testServiceLogger;
    private TestService testService;
    private StorageProvider storageProvider;
    private BackgroundJobServer backgroundJobServer;
    private static final String everySecond = "*/1 * * * * *";
    private LogAllStateChangesFilter logAllStateChangesFilter;

    @BeforeEach
    void setUpTests() {
        jobFiltersLogger = LoggerAssert.initFor(JobCreationFilters.class);
        testServiceLogger = LoggerAssert.initFor(TestService.class);

        testService = new TestService();
        testService.reset();

        logAllStateChangesFilter = new LogAllStateChangesFilter();

        storageProvider = new InMemoryStorageProvider();
        JobRunrPro.configure()
                .withJobFilter(logAllStateChangesFilter)
                .useStorageProvider(storageProvider)
                .useRateLimiter(concurrentJobRateLimiter(CONCURRENT_JOB_RATE_LIMITER, 2))
                .useQueues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue)
                .useBackgroundJobServer(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofMillis(200)).andTags(LINUX).andWorkerCount(2))
                .initialize();

        backgroundJobServer = JobRunrPro.getBackgroundJobServer();
    }

    @AfterEach
    void cleanUp() {
        MDC.clear();
        backgroundJobServer.stop();
    }

    @Test
    void ifBackgroundJobIsNotConfiguredCorrectlyAnExceptionIsThrown() {
        BackgroundJob.setJobScheduler(null);
        assertThatThrownBy(() -> BackgroundJob.enqueue(() -> System.out.println("Test")))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("The JobScheduler has not been initialized. Use the fluent JobRunrPro.configure() API to setup JobRunr or set the JobScheduler via the static setter method.");
    }

    @Test
    void testCreateViaBuilder() {
        UUID jobId = randomUUID();
        BackgroundJob.create(aJob()
                .withId(jobId)
                .withDetails(() -> testService.doWorkAndReturnResult("some string")));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testCreateViaBuilderAndAnnotationMustFail() {
        assertThatThrownBy(() -> BackgroundJob.create(aJob()
                .withDetails(() -> testService.doWorkWithAnnotation(3, "Jef Klak"))))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("You are combining the JobBuilder with the Job annotation which is not allowed. You can only use one of them.");
    }

    @Test
    void testEnqueueSystemOut() {
        JobProId jobId = BackgroundJob.enqueue(() -> System.out.println("this is a test"));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testEnqueue() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWork());
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testEnqueueWithResult() {
        UUID id = randomUUID();
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkWithUUID(id));
        assertThat(BackgroundJob.getJobResult(jobId)).isUnavailable();
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);

        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
        await().atMost(6, SECONDS).until(() -> BackgroundJob.getJobResult(jobId).isAvailable() && BackgroundJob.getJobResult(jobId).getResult().equals("The result " + id));
    }

    @Test
    void testEnqueueWithId() {
        UUID id = randomUUID();
        JobProId jobId1 = BackgroundJob.enqueue(id, () -> testService.doWork());
        JobProId jobId2 = BackgroundJob.enqueue(id, () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void testEnqueueReplace() {
        // fill queue so job to be replaced is still enqueued and not immediately processed
        asList("A", "B", "C", "D", "E", "F")
                .forEach(path -> BackgroundJob.enqueue(() -> testService.doWorkWithPath(Path.of("/tmp/folder-" + path))));

        UUID id = randomUUID();
        JobProId jobId1 = BackgroundJob.enqueueOrReplace(id, () -> testService.doWorkWithPath(Path.of("/tmp/wrong-folder")));
        JobProId jobId2 = BackgroundJob.enqueueOrReplace(id, () -> testService.doWorkWithPath(Path.of("/tmp/correct-folder")));
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));

        assertThat(testServiceLogger)
                .hasDebugMessageContaining("Doing some work... /tmp/correct-folder");
    }

    @Test
    void testScheduleReplaceAScheduledJob() {
        UUID id = randomUUID();
        storageProvider.save(aScheduledJob().withId(id).build());
        JobProId jobId = BackgroundJob.scheduleOrReplace(id, now().plusSeconds(2), () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(TEN_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testEnqueueReplaceAJobThatIsAlreadyProcessing() {
        UUID id = randomUUID();
        JobProId jobId1 = BackgroundJob.enqueueOrReplace(id, () -> testService.doWorkThatTakesLong(15));
        await().until(() -> storageProvider.getJobById(jobId1).getState() == PROCESSING);
        JobProId jobId2 = BackgroundJob.enqueueOrReplace(id, () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(TEN_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(jobId1).getLastJobStateOfType(EnqueuedState.class);
        assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @Test
    void testEnqueueReplaceAJobThatHasAlreadySucceeded() {
        UUID id = randomUUID();
        storageProvider.save(aSucceededJob().withId(id).build());
        JobProId jobId = BackgroundJob.enqueueOrReplace(id, () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(id)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(id).getLastJobStateOfType(EnqueuedState.class);
        assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @Test
    void testEnqueueReplaceAJobThatHasAlreadyFailed() {
        UUID id = randomUUID();
        storageProvider.save(aFailedJob().withId(id).build());
        JobProId jobId = BackgroundJob.enqueueOrReplace(id, () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(id)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(id).getLastJobStateOfType(EnqueuedState.class);
        assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void testEnqueueReplaceWithBuilder() {
        asList("A", "B", "C", "D", "E", "F")
                .forEach(jobName -> BackgroundJob.create(aJob().withName("Job " + jobName).withDetails(() -> System.out.println("Working..."))));

        UUID id = randomUUID();
        JobProId jobId1 = BackgroundJob.createOrReplace(aJob().withId(id).withName("Wrong Job").withDetails(() -> System.out.println("wrong job")));
        JobProId jobId2 = BackgroundJob.createOrReplace(aJob().withId(id).withName("Correct Job").withDetails(() -> System.out.println("correct job")));
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1))
                .hasStates(ENQUEUED, PROCESSING, SUCCEEDED)
                .hasJobName("Correct Job")
        );
    }

    @Test
    public void testEnqueueWithStaticMethod() {
        final JobProId jobId = BackgroundJob.enqueue(TestService::doStaticWork);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    public void testEnqueueWithStaticMethodWithArgument() {
        UUID id = randomUUID();
        final JobProId jobId = BackgroundJob.enqueue(() -> StaticTestService.doWorkInStaticMethod(id));
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testEnqueueWithInterfaceImplementationThrowsNiceException() {
        assertThatThrownBy(() -> BackgroundJob.enqueue(new JobImplementation()))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Please provide a lambda expression (e.g. BackgroundJob.enqueue(() -> myService.doWork()) instead of an actual implementation.");
    }

    @Test
    void testEnqueueWithCustomObject() {
        final TestService.Work work = new TestService.Work(2, "some string", randomUUID());
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWork(work));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testEnqueueWithPath() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkWithPath(Paths.get("/tmp/jobrunr/example.log")));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testEnqueueWithJobContextAndMetadata() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWork(5, JobContext.Null));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).getState() == PROCESSING);
        await().atMost(TWO_SECONDS).until(() -> !storageProvider.getJobById(jobId).getMetadata().isEmpty());
        assertThat(storageProvider.getJobById(jobId))
                .hasMetadata("test", "test");
        await().atMost(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId))
                .hasStates(ENQUEUED, PROCESSING, SUCCEEDED)
                .hasMetadataOnlyContainingObservabilityInfoJobProgressAndLogging();
    }

    @Test
    void testEnqueueStreamWithMultipleParameters() {
        Stream<UUID> workStream = getWorkStream();
        AtomicInteger atomicInteger = new AtomicInteger();
        BackgroundJob.enqueue(workStream, (uuid) -> testService.doWork(uuid.toString(), atomicInteger.incrementAndGet(), now()));

        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testEnqueueStreamWithWrappingObjectAsParameter() {
        AtomicInteger atomicInteger = new AtomicInteger();
        Stream<TestService.Work> workStream = getWorkStream()
                .map(uuid -> new TestService.Work(atomicInteger.incrementAndGet(), "some string " + uuid, uuid));

        BackgroundJob.enqueue(workStream, (work) -> testService.doWork(work));
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testEnqueueStreamWithParameterFromWrappingObject() {
        AtomicInteger atomicInteger = new AtomicInteger();
        Stream<TestService.Work> workStream = getWorkStream()
                .map(uuid -> new TestService.Work(atomicInteger.incrementAndGet(), "some string " + uuid, uuid));

        BackgroundJob.enqueue(workStream, (work) -> testService.doWork(work.getUuid()));
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testEnqueueStreamWithMethodReference() {
        BackgroundJob.enqueue(getWorkStream(), TestService::doWorkWithUUID);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testCreateStreamWithJobBuilder() {
        BackgroundJob.create(getWorkStream()
                .map(uuid -> aJob().withDetails(() -> System.out.println("this is a test")))
        );

        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void jobsCanEnqueueOtherJobsInTheSameClassUsingMethodReference() {
        JobProId jobId = BackgroundJob.enqueue(this::aNestedJob);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testFailedJobAddsFailedStateAndScheduledThanksToDefaultRetryFilter() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatFailsWithAnnotation());
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, FAILED, SCHEDULED));
        assertThat(logAllStateChangesFilter.getStateChanges(jobId)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->FAILED", "FAILED->SCHEDULED");
    }

    @Test
    void testScheduleWithId() {
        UUID id = randomUUID();
        JobProId jobId1 = BackgroundJob.schedule(id, now(), () -> testService.doWork());
        JobProId jobId2 = BackgroundJob.schedule(id, now().plusSeconds(20), () -> testService.doWork());
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testScheduleWithZonedDateTime() {
        JobProId jobId = BackgroundJob.schedule(ZonedDateTime.now().plus(ofMillis(1500)), () -> testService.doWork());
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithOffsetDateTime() {
        JobProId jobId = BackgroundJob.schedule(OffsetDateTime.now().plus(ofMillis(1500)), () -> testService.doWork());
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithLocalDateTime() {
        JobProId jobId = BackgroundJob.schedule(LocalDateTime.now().plus(ofMillis(1500)), () -> testService.doWork());
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithInstant() {
        JobProId jobId = BackgroundJob.schedule(now().plus(ofMillis(1500)), () -> testService.doWork());
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleUsingDateTimeInTheFutureIsNotEnqueued() {
        JobProId jobId = BackgroundJob.schedule(now().plusSeconds(100), () -> testService.doWork());
        await().during(TWO_SECONDS).atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED);
    }

    @Test
    void testScheduleThatSchedulesOtherJobs() {
        JobProId jobId = BackgroundJob.schedule(now().plusSeconds(1), () -> testService.enqueueNewBatchWork(5));
        await().atMost(ONE_MINUTE).until(() -> storageProvider.countJobs(new JobSearchRequest(SUCCEEDED)) == (5 + 1));
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleThatSchedulesOtherJobsSlowlyDoesNotBlockOtherWorkers() {
        JobProId jobId = BackgroundJob.schedule(now().plusSeconds(1), () -> testService.scheduleNewWorkSlowly(1));
        await().atMost(ofSeconds(2)).until(() -> (storageProvider.countJobs(new JobSearchRequest(PROCESSING)) + storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))) > 1);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING);
    }

    @Test
    void testRecurringCronJob() {
        BackgroundJob.scheduleRecurrently(everySecond, () -> testService.doWork(5));
        await().atMost(ofSeconds(25)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(3));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobFromBuilder() {
        BackgroundJob.createRecurrently(aRecurringJob()
                .withCron(everySecond)
                .withDetails(() -> testService.doWork(5)));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobFromBuilderWithDeleteOnSuccess() {
        BackgroundJob.createRecurrently(aRecurringJob()
                .withCron(everySecond)
                .withDeleteOnSuccess("!PT1S")
                .withDetails(() -> System.out.println("Should be deleted immediately")));

        await().atMost(1200, MILLISECONDS).until(() -> storageProvider.countJobs(new JobSearchRequest(DELETED)) == 1);
        sleep(1001);
        // why 1 again instead of 0: a new recurring job started and will got to DELETED state immediately
        await().atMost(1000, MILLISECONDS).until(() -> storageProvider.countJobs(new JobSearchRequest(DELETED)) == 1);
    }

    @Test
    void testRecurringCronJobWithJobContext() {
        BackgroundJob.scheduleRecurrently(everySecond, () -> testService.doWork(5, JobContext.Null));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobWithId() {
        BackgroundJob.scheduleRecurrently("theId", everySecond, () -> testService.doWork(5));
        BackgroundJob.scheduleRecurrently("theId", everySecond, () -> testService.doWork(5));
        // why: no exception should be thrown.

        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobWithIdAndTimezone() {
        BackgroundJob.scheduleRecurrently("theId", everySecond, systemDefault(), () -> testService.doWork(5));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @RepeatedIfExceptionsTest(repeats = 3, suspend = 10_000)
    void testRecurringCronJobDoesNotSkipRecurringJobsIfStopTheWorldGCOccurs() {
        TestServiceForRecurringJobsIfStopTheWorldGCOccurs testService = new TestServiceForRecurringJobsIfStopTheWorldGCOccurs();
        testService.resetProcessedJobs();
        ListAppender logger = LoggerAssert.initFor(testService);
        BackgroundJob.scheduleRecurrently(everySecond, testService::doWork);
        await().atMost(5, SECONDS).until(() -> storageProvider.countJobs(new JobSearchRequest(SUCCEEDED)) == 1);

        // WHEN
        GCUtils.simulateStopTheWorldGC(20000);

        // THEN
        await().atMost(65, SECONDS)
                .untilAsserted(() -> assertThat(logger).hasInfoMessageContaining("JobRunr recovered from long GC and all jobs were executed"));
    }

    @Test
    void testRecurringIntervalJob() {
        BackgroundJob.scheduleRecurrently(ofSeconds(1), () -> testService.doWork(5));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(storageProvider.getJobById(job.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringIntervalJobFromBuilder() {
        BackgroundJob.createRecurrently(aRecurringJob()
                .withInterval(ofSeconds(1))
                .withDetails(() -> testService.doWork(5)));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(storageProvider.getJobById(job.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringIntervalJobWithId() {
        BackgroundJob.scheduleRecurrently("theId", ofSeconds(1), () -> testService.doWork(5));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(storageProvider.getJobById(job.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCustomScheduleJob() {
        final String scheduledAt = now().plusSeconds(5).toString();
        BackgroundJob.scheduleRecurrently(CustomScheduleTestImplementation.myCustomSchedule(scheduledAt), () -> testService.doWork(5));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(storageProvider.getJobById(job.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCustomScheduleJobFromBuilder() {
        final String scheduledAt = now().plusSeconds(5).toString();
        BackgroundJob.createRecurrently(aRecurringJob()
                .withCustomSchedule(CustomScheduleTestImplementation.myCustomSchedule(scheduledAt))
                .withDetails(() -> testService.doWork(5)));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(storageProvider.getJobById(job.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void test2RecurringJobsWithSameMethodSignatureShouldBothBeRun() {
        BackgroundJob.scheduleRecurrently("recurring-job-1", everySecond, systemDefault(), () -> testService.doWork(5));
        BackgroundJob.scheduleRecurrently("recurring-job-2", everySecond, systemDefault(), () -> testService.doWork(5));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(2));

        final Job job1 = storageProvider.getJob(aJobSearchRequest().withRecurringJobId("recurring-job-1").build());
        final Job job2 = storageProvider.getJob(aJobSearchRequest().withRecurringJobId("recurring-job-2").build());

        assertThat(storageProvider.getJobById(job1.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
        assertThat(storageProvider.getJobById(job2.getId())).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testDeleteOfRecurringJob() {
        String jobId = BackgroundJob.scheduleRecurrently(Cron.minutely(), () -> testService.doWork(5));
        BackgroundJob.delete(jobId);
        assertThat(storageProvider.countRecurringJobs(aRecurringJobSearchRequest().build())).isEqualTo(0L);
    }

    @Test
    void testOrphanedJobsStuckInProcessingStateAreRescheduled() {
        Job orphanedJob = anEnqueuedJob().withState(new ProcessingState(backgroundJobServer), now().minus(15, MINUTES)).build();
        Job job = storageProvider.save(orphanedJob);
        await().atMost(3, SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(job.getId())).hasStates(ENQUEUED, PROCESSING, FAILED, SCHEDULED));
        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("PROCESSING->FAILED", "FAILED->SCHEDULED");
    }

    @Test
    void jobCanBeUpdatedInTheBackgroundAndThenGoToSucceededState() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLong(3));
        await().atMost(1, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(PROCESSING));
        await().atMost(2, SECONDS).untilAsserted(() -> {
            final Job job = storageProvider.getJobById(jobId);
            ProcessingState processingState = job.getJobState();
            assertThat(processingState.getUpdatedAt()).isAfter(processingState.getCreatedAt());
            assertThat(storageProvider.getJobById(jobId)).hasState(PROCESSING);
        });
        await().atMost(3, SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasState(SUCCEEDED));
        assertThat(logAllStateChangesFilter.getStateChanges(jobId)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->SUCCEEDED");
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void jobCanBeDeletedWhenEnqueued() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLong(12));
        BackgroundJob.delete(jobId);

        await().atMost(3, SECONDS).untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId))
                    .hasStates(ENQUEUED, DELETED)
                    .hasDeletedAtNotNull();
        });
    }

    @Test
    void jobCanBeDeletedWhenScheduled() {
        JobProId jobId = BackgroundJob.schedule(now().plusSeconds(10), () -> testService.doWorkThatTakesLong(12));
        BackgroundJob.delete(jobId);

        await().atMost(3, SECONDS).untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId))
                    .hasStates(SCHEDULED, DELETED)
                    .hasDeletedAtNotNull();
        });
    }

    @Test
    void jobCanBeDeletedDuringProcessingState_jobRethrowsInterruptedException() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLong(3));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).hasState(PROCESSING));

        BackgroundJob.delete(jobId);

        await().untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, DELETED);
        });

        await().during(1, SECONDS).untilAsserted(() -> {
            assertThat(storageProvider.getJobById(jobId)).doesNotHaveState(SUCCEEDED);
        });
    }

    @Test
    void jobCanBeDeletedDuringProcessingState_jobInterruptCurrentThread() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLongInterruptThread(3));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).hasState(PROCESSING));

        BackgroundJob.delete(jobId);

        await().untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, DELETED);
        });

        await().during(1, SECONDS).untilAsserted(() -> {
            assertThat(storageProvider.getJobById(jobId)).doesNotHaveState(SUCCEEDED);
        });
    }

    @Test
    void jobCanBeDeletedDuringProcessingStateIfInterruptible() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatCanBeInterrupted(3));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).hasState(PROCESSING));

        BackgroundJob.delete(jobId);

        await().untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, DELETED);
        });

        await().during(1, SECONDS).untilAsserted(() -> {
            assertThat(storageProvider.getJobById(jobId)).doesNotHaveState(SUCCEEDED);
        });
    }

    @Test
    void jobCanBeDeletedDuringProcessingState_InterruptedExceptionCatched() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLongCatchInterruptException(3));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).hasState(PROCESSING));

        BackgroundJob.delete(jobId);

        await().untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, DELETED);
        });

        await().during(1, SECONDS).untilAsserted(() -> {
            assertThat(storageProvider.getJobById(jobId)).doesNotHaveState(SUCCEEDED);
        });
    }

    @Test
    void processingCanBeSkippedUsingElectStateFilters() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.tryToDoWorkButDontBecauseOfSomeBusinessRuleDefinedInTheOnStateElectionFilter());
        await().during(1, SECONDS).atMost(2, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SCHEDULED));

        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, DELETED, SCHEDULED);
    }

    @Test
    void aJobMethodThatIsPackagePrivateCanStillBeExecuted() {
        Job job = storageProvider.save(JobTestBuilder.aJob()
                .withScheduledState()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("aPackagePrivateMethod"))
                .build());
        await().atMost(60, SECONDS).until(() -> storageProvider.getJobById(job.getId()).hasState(SUCCEEDED));
        Job succeededJob = storageProvider.getJobById(job.getId());
        assertThat(succeededJob).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void jobToClassThatDoesNotExistGoesToFailedState() {
        Job job = storageProvider.save(anEnqueuedJobWithName().withJobDetails(classThatDoesNotExistJobDetails()).build());
        await().atMost(3, SECONDS).until(() -> storageProvider.getJobById(job.getId()).hasState(FAILED));
        FailedState failedState = storageProvider.getJobById(job.getId()).getJobState();
        assertThat(failedState.getException()).isInstanceOf(JobClassNotFoundException.class);
        Job failedJob = storageProvider.getJobById(job.getId());
        assertThat(failedJob).hasStates(ENQUEUED, PROCESSING, FAILED);
    }

    @Test
    void jobToMethodThatDoesNotExistGoesToFailedState() {
        Job job = storageProvider.save(anEnqueuedJobWithName().withJobDetails(methodThatDoesNotExistJobDetails()).build());
        await().atMost(30, SECONDS).until(() -> storageProvider.getJobById(job.getId()).hasState(FAILED));
        FailedState failedState = storageProvider.getJobById(job.getId()).getJobState();
        assertThat(failedState.getException()).isInstanceOf(JobMethodNotFoundException.class);
        await().during(1, SECONDS).until(() -> storageProvider.getJobById(job.getId()).hasState(FAILED));
        Job failedJob = storageProvider.getJobById(job.getId());
        assertThat(failedJob).hasStates(ENQUEUED, PROCESSING, FAILED);
    }

    @Test
    void testJobInheritance() {
        SomeSysoutJobClass someSysoutJobClass = new SomeSysoutJobClass(Cron.daily());
        assertThatCode(() -> someSysoutJobClass.schedule()).doesNotThrowAnyException();
    }

    @Test
    void mdcContextIsAvailableInJob() {
        MDC.put("someKey", "someValue");

        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkWithMDC("someKey"));
        await().atMost(30, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    void mdcContextIsAvailableForDisplayName() {
        MDC.put("customer.id", "1");

        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkWithAnnotation(5, "John Doe"));
        assertThat(storageProvider.getJobById(jobId)).hasJobName("Doing some hard work for user John Doe (customerId: 1)");
    }

    @Test
    void testJobOnHighPrioQueueCutsJobsOnDefaultQueue() {
        for (int i = 0; i < 3; i++) {
            BackgroundJob.enqueue(() -> testService.startJobOnDefaultQueue());
        }
        final JobProId defaultPrioJob = BackgroundJob.enqueue(() -> testService.startJobOnDefaultQueue());
        final JobProId highPrioJob = BackgroundJob.enqueue(() -> testService.startJobOnHighPrioQueue());

        await().atMost(TEN_SECONDS).until(() ->
                storageProvider.getJobById(highPrioJob).hasState(PROCESSING) && storageProvider.getJobById(defaultPrioJob).hasState(ENQUEUED));
    }

    @Test
    void testJobOnLowPrioQueueGetsCutByJobsOnDefaultQueue() {
        for (int i = 0; i < 3; i++) {
            BackgroundJob.enqueue(() -> testService.startJobOnLowPrioQueue());
        }
        final JobProId lowPrioJob = BackgroundJob.enqueue(() -> testService.startJobOnLowPrioQueue());
        final JobProId defaultPrioJob = BackgroundJob.enqueue(() -> testService.startJobOnDefaultQueue());

        await().atMost(TEN_SECONDS).until(() ->
                storageProvider.getJobById(defaultPrioJob).hasState(PROCESSING) && storageProvider.getJobById(lowPrioJob).hasState(ENQUEUED));
    }

    @Test
    void testJobOnUnknownQueueThrowsException() {
        BackgroundJob.enqueue(() -> testService.startJobOnUnknownQueue());
        assertThat(jobFiltersLogger).hasErrorLogMessage(JobCreationFilters.class, "Error evaluating jobfilter org.jobrunr.jobs.filters.DefaultJobFilter");
    }

    @Test
    void testJobChaining() {
        JobProId jobId = BackgroundJob
                .enqueue(() -> System.out.println("Job numero uno"))
                .continueWith(() -> System.out.println("Job numero due"));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testJobChainingWithAwaitingJobLambda() {
        JobProId jobId = BackgroundJob
                .enqueue(() -> System.out.println("Job numero uno"))
                .continueWith(job -> System.out.println("Job numero due"));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testJobChainingWithDurationToWait() {
        JobProId jobId = BackgroundJob
                .enqueue(() -> System.out.println("Job numero uno"))
                .continueWith(Duration.ofDays(3), () -> System.out.println("Job numero due"));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SCHEDULED));
        assertThat(storageProvider.getJobById(jobId))
                .hasStates(AWAITING, SCHEDULED)
                .is(scheduledNear(now().plus(Duration.ofDays(3))));
    }

    @Test
    void testJobChainingUsingRunAfterFromBuilder() {
        JobProId firstJobId = BackgroundJob.create(aJob()
                .withDetails(() -> System.out.println("Job numero uno")));

        JobProId secondJobId = BackgroundJob.create(aJob()
                .runAfter(firstJobId)
                .withDetails(() -> System.out.println("Job numero due")));

        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(secondJobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(secondJobId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testJobChainingUsingRunAfterFromBuilderWithDurationToWait() {
        JobProId firstJobId = BackgroundJob.create(aJob()
                .withDetails(() -> System.out.println("Job numero uno")));

        JobProId secondJobId = BackgroundJob.create(aJob()
                .runAfter(firstJobId, Duration.ofDays(3))
                .withDetails(() -> System.out.println("Job numero due")));

        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(secondJobId).hasState(SCHEDULED));
        assertThat(storageProvider.getJobById(secondJobId))
                .hasStates(AWAITING, SCHEDULED)
                .is(scheduledNear(now().plus(Duration.ofDays(3))));
    }

    @Test
    void testRunOnServerWithTagSkippedAsTagsDontMatch() {
        final JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkOnServerThatDoesNotMatch());

        await().during(3, SECONDS).atMost(6, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(ENQUEUED));
    }

    @Test
    void testRunOnServerWithTagAsTagsMatch() {
        final JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkOnServerThatMatches());

        await().during(3, SECONDS).atMost(6, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    void testRunOnServerWithCurrentServerTagAsTagsMatch() {
        final JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkOnCurrentServerThatMatches());

        await().during(3, SECONDS).atMost(6, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    void testMutex() {
        final JobProId jobId1 = BackgroundJob.enqueue(() -> testService.doWork1WithMutexToPreventConcurrency());
        final JobProId jobId2 = BackgroundJob.enqueue(() -> testService.doWork2WithMutexToPreventConcurrency());

        await().during(2, SECONDS).atMost(3, SECONDS).until(() -> storageProvider.getJobById(jobId2).hasState(ENQUEUED));
        await().atMost(1, SECONDS).until(() -> storageProvider.getJobById(jobId1).hasState(PROCESSING));
        await().atMost(10, SECONDS).until(() -> storageProvider.getJobById(jobId2).hasState(SUCCEEDED));
    }

    @Test
    void testDeleteOnSuccess() {
        final JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkAndDeleteJobImmediately());

        await().atMost(2, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(DELETED));
        await().atMost(6, SECONDS).untilAsserted(() -> assertThatThrownBy(() -> storageProvider.getJobById(jobId)).isInstanceOf(JobNotFoundException.class));
    }

    @Test
    void testDeleteOnFailure() {
        final JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatFailsAndDeleteJob());

        await().atMost(2, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(DELETED));
        await().atMost(6, SECONDS).untilAsserted(() -> assertThatThrownBy(() -> storageProvider.getJobById(jobId)).isInstanceOf(JobNotFoundException.class));
    }

    @Test
    void testDeleteOnSuccessByBuilder() {
        JobProId jobId = BackgroundJob.create(aJob()
                .withDetails(() -> testService.doWork(1))
                .withDeleteOnSuccess(Duration.ZERO, ofSeconds(1)));

        await().atMost(2, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(DELETED));
        await().atMost(6, SECONDS).untilAsserted(() -> assertThatThrownBy(() -> storageProvider.getJobById(jobId)).isInstanceOf(JobNotFoundException.class));
    }

    @Test
    void testDeleteOnFailureByBuilder() {
        JobProId jobId = BackgroundJob.create(aJob()
                .withDetails(() -> testService.doWorkThatFails())
                .withAmountOfRetries(0)
                .withDeleteOnFailure(Duration.ZERO, ofSeconds(1)));

        await().atMost(2, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(DELETED));
        await().atMost(6, SECONDS).untilAsserted(() -> assertThatThrownBy(() -> storageProvider.getJobById(jobId)).isInstanceOf(JobNotFoundException.class));
    }

    @Test
    void testJobTimeoutByAnnotation() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkThatTakesLongButTimesOut());

        await().atMost(10, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(FAILED));
        assertThat(storageProvider.getJobById(jobId))
                .hasStates(ENQUEUED, PROCESSING, FAILED);
    }

    @Test
    void testJobTimeoutByBuilder() {
        JobProId jobId = BackgroundJob.create(aJob()
                .withDetails(() -> testService.doWorkThatTakesLong(30))
                .withAmountOfRetries(0)
                .withProcessTimeOut(ofSeconds(2))
                .withDeleteOnFailure(Duration.ZERO, Duration.ofDays(1)));

        await().atMost(10, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(DELETED));
        assertThat(storageProvider.getJobById(jobId))
                .hasStates(ENQUEUED, PROCESSING, FAILED, DELETED);
    }

    @Test
    void testIssue645() {
        TestService.GithubIssue645 githubIssue645 = new TestService.GithubIssue645();
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWorkForIssue645(githubIssue645.getId(), githubIssue645));
        await().atMost(30, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    @Because("https://github.com/jobrunr/jobrunr/issues/829")
    void jobRunrCallsJobFiltersUsingGlobalFilter() {
        JobProId jobId = BackgroundJob.enqueue(() -> testService.doWork("with input"));

        await().atMost(6, SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasState(SUCCEEDED));

        assertThat(logAllStateChangesFilter.onCreatingIsCalled(jobId)).isTrue();
        assertThat(logAllStateChangesFilter.onCreatedIsCalled(jobId)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(jobId)).isTrue();
    }

    interface SomeJobInterface {
        void doWork();
    }

    abstract static class SomeJobClass implements SomeJobInterface {

        private final String cron;

        public SomeJobClass(String cron) {
            this.cron = cron;
        }

        public void schedule() {
            BackgroundJob.scheduleRecurrently("test-id", cron, () -> doWork());
        }
    }

    public static class SomeSysoutJobClass extends SomeJobClass {

        public SomeSysoutJobClass(String cron) {
            super(cron);
        }

        @Override
        public void doWork() {
            System.out.println("In doWork method");
        }
    }

    public void aNestedJob() {
        System.out.println("Nothing else to do");
    }

    static class JobImplementation implements JobLambda {

        @Override
        public void run() {
            System.out.println("This should not be run");
        }
    }

    private Stream<UUID> getWorkStream() {
        return IntStream.range(0, 5)
                .mapToObj(i -> randomUUID());
    }

    static class SomeObjectWithAnId {

        public UUID getId() {
            return randomUUID();
        }

    }
}
