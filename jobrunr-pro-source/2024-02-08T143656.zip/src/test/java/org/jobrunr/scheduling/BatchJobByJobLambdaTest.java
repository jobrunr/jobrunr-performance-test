package org.jobrunr.scheduling;

import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.Paging.OffsetBasedPage;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static java.time.Duration.ofMillis;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.FIVE_SECONDS;
import static org.awaitility.Durations.ONE_MINUTE;
import static org.awaitility.Durations.TEN_SECONDS;
import static org.awaitility.Durations.TWO_MINUTES;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.scheduling.JobBuilder.aBatchJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.stubs.TestService.CONCURRENT_JOB_RATE_LIMITER;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LINUX;
import static org.jobrunr.stubs.TestService.LowPrioQueue;

public class BatchJobByJobLambdaTest {

    private TestService testService;
    private StorageProvider storageProvider;
    private BackgroundJobServer backgroundJobServer;

    @BeforeEach
    void setUpTests() {
        testService = new TestService();
        testService.reset();

        storageProvider = new InMemoryStorageProvider();
        JobRunrPro.configure()
                .useStorageProvider(storageProvider)
                .useRateLimiter(concurrentJobRateLimiter(CONCURRENT_JOB_RATE_LIMITER, 2))
                .useQueues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue)
                .useBackgroundJobServer(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofMillis(500)).andTags(LINUX).andWorkerCount(2))
                .initialize();

        backgroundJobServer = JobRunrPro.getBackgroundJobServer();
    }

    @AfterEach
    void cleanUp() {
        MDC.clear();
        backgroundJobServer.stop();
    }

    @Test
    void testBatchSucceedsIfNoChildJobs() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.scheduleNewWorkNothingToDo(JobContext.Null));
        await().atMost(ONE_MINUTE).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, PROCESSED, SUCCEEDED);
    }

    @Test
    void testBatchJobChaining() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWork(3))
                .continueWith(() -> System.out.println("Job numero due"));
        await().atMost(TWO_MINUTES).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testBatchJobChainedJobDoesNotStartUnlessBatchJobSucceeds() {
        // GIVEN
        JobProId batchJobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWork(3));
        JobProId jobId = batchJobId
                .continueWith(() -> System.out.println("Job numero due"));

        // WHEN
        await().atMost(ONE_MINUTE).until(() -> storageProvider.getJobById(batchJobId).hasState(PROCESSED));

        // THEN
        // make sure jobId is not started until batchJobId has SUCCEEDED
        await().during(200, MILLISECONDS)
                .atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(AWAITING));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testBatchJobChildJobsDoNotStartUnlessParentSucceeds() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWork(4500, 150, 3, JobContext.Null));
        await().atMost(FIVE_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).getJobStatesOfType(FailedState.class).count() == 1);
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isEqualTo(150);
        await().atMost(FIVE_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).getJobStatesOfType(FailedState.class).count() == 2);
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isEqualTo(150);
        await().pollInterval(50, MILLISECONDS)
                .atMost(20, SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasState(PROCESSED));
        assertThat(storageProvider.countJobs(new JobSearchRequest(AWAITING))).isGreaterThan(3000);
    }

    @Test
    void testBatchJobChildJobsStartWhenParentSucceeds() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWork(500));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(500));
    }

    @Test
    void testBatchJobSucceedsWhenAllChildJobsSucceed() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWork(100));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(100));
        await().atMost(TEN_SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(SUCCEEDED)
                        .hasDeletedAtNotNull());
    }

    @Test
    void testBatchJobCreatedByJobBuilderSucceedsWhenAllChildJobsSucceed() {
        JobProId jobId = BackgroundJob
                .create(aBatchJob().withDetails(() -> testService.enqueueNewBatchWork(100, 101, 101, JobContext.Null)));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(TWO_MINUTES)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(100));
        await().atMost(TEN_SECONDS)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(SUCCEEDED)
                        .hasDeletedAtNotNull());
    }

    @Test
    void testBatchJobFailsIfOneChildJobFailsAndGoesToProcessedIfChildJobStartsProcessingAgain() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewWorkWithChildJobThatFails(5, 4, JobContext.Null));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(ONE_MINUTE)
                .untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(4));
        await().atMost(ONE_MINUTE)
                .untilAsserted(() -> assertThat(storageProvider.getJobById(jobId))
                        .hasState(FAILED)
                        .hasDeletedAt(null)
                );

        storageProvider.getJobList(aJobSearchRequest().withAwaitingOn(jobId.asUUID()).withStateName(FAILED).build(), Paging.AmountBasedList.ascOnUpdatedAt(1000))
                .forEach(failedJob -> {
                    failedJob.enqueue();
                    storageProvider.save(failedJob);
                });

        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED) || storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    void testBatchJobChildJobsGetServerTagAndLabelsFromParent() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWorkWithServerTag(2));
        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));

        Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withParentId(jobId.asUUID()).build(), OffsetBasedPage.ascOnPriorityAndUpdatedAt(2));
        assertThat(jobs)
                .hasTotal(2)
                .hasItem(0, job0 -> assertThat(job0).hasServerTag(LINUX).hasLabels("my-batch-label", "label-0 - an argument"))
                .hasItem(1, job1 -> assertThat(job1).hasServerTag(LINUX).hasLabels("my-batch-label", "label-1 - an argument"));
    }

    @Test
    void testChainingWithinAndAfterBatchJobWorksCorrect() {
        JobProId jobId = BackgroundJob
                .startBatch(() -> testService.enqueueNewBatchWorkWithChainingWithinBatchJob());

        await().atMost(TEN_SECONDS)
                .until(() -> storageProvider.getJobById(jobId).hasState(PROCESSED));
        await().atMost(ONE_MINUTE)
                .until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));

        Page<Job> jobs = storageProvider.getJobs(new JobSearchRequest(SUCCEEDED), OffsetBasedPage.ascOnPriorityAndUpdatedAt(10));
        assertThat(jobs)
                .hasTotal(4)
                .hasItem(3, job -> assertThat(jobId.asUUID().equals(job.getId())).isTrue()); // batch job must be updated last.
    }


}
