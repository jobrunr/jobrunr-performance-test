package org.jobrunr.scheduling;

import org.jobrunr.jobs.AbstractJob;
import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobDetails;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.filters.ApplyStateFilter;
import org.jobrunr.jobs.filters.ElectStateFilter;
import org.jobrunr.jobs.filters.JobClientFilter;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.JobState;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.scheduling.cron.CronExpression;
import org.jobrunr.storage.ConcurrentRecurringJobModificationException;
import org.jobrunr.storage.DatabaseOptions;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.h2.H2StorageProvider;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.JobHolderContext;
import org.jobrunr.utils.annotations.Because;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.jobrunr.utils.multicast.JobEnqueuedMessagePublisher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.ZoneId;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJobInProgress;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.scheduling.cron.Cron.daily;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AbstractJobSchedulerTest {

    private final Queues queues = new Queues();
    @Mock
    StorageProvider storageProvider;

    @Mock
    JobEnqueuedMessagePublisher jobEnqueuedMessagePublisher;

    @Captor
    ArgumentCaptor<Job> jobCaptor;

    @Captor
    ArgumentCaptor<List<Job>> jobListCaptor;

    private AbstractJobScheduler jobScheduler;

    private JobClientLogFilter jobClientLogFilter;

    @BeforeEach
    void setUpJobScheduler() {
        jobClientLogFilter = new JobClientLogFilter();
        jobScheduler = createJobScheduler(jobEnqueuedMessagePublisher);

        lenient().doAnswer(invocation -> invocation.getArgument(0)).when(storageProvider).save(any(Job.class));
        lenient().doAnswer(invocation -> invocation.getArgument(0)).when(storageProvider).save(anyList());
    }

    @AfterEach
    void clearJobHolderContext() {
        JobHolderContext.clear();
    }

    @Test
    void scheduleRecurrentlyValidatesScheduleDoesNotThrowExceptionWhenUsingInMemoryStorageProvider() {
        AbstractJobScheduler jobScheduler = createJobSchedulerUsingInMemoryStorageProvider(jobEnqueuedMessagePublisher);
        RecurringJob recurringJob = aDefaultRecurringJob().withCronExpression("* * * * * *").build();
        assertThatCode(() -> jobScheduler.scheduleRecurrently(recurringJob)).doesNotThrowAnyException();
    }

    @Test
    void scheduleRecurrentlyValidatesScheduleDoesThrowExceptionWhenUsingNotAnInMemoryStorageProvider() {
        AbstractJobScheduler jobScheduler = createJobScheduler(new H2StorageProvider(null, new DatabaseOptions(true, true)), jobEnqueuedMessagePublisher);
        RecurringJob recurringJob = aDefaultRecurringJob().withCronExpression("* * * * * *").build();
        assertThatCode(() -> jobScheduler.scheduleRecurrently(recurringJob))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The smallest supported duration between recurring job instances is 5 seconds (because of the smallest supported pollInterval).");
    }

    @Test
    void whenJobIsNotEnqueuedFromABatchJobThenJobHasEnqueuedState() {
        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob);

        verify(storageProvider).save(jobCaptor.capture());

        assertThat(jobCaptor.getValue()).hasState(StateName.ENQUEUED);
    }

    @Test
    void whenJobIsEnqueuedFromABatchJobThenJobHasAwaitingState() {
        JobHolderContext.setJob(aBatchJobInProgress().build());
        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob);

        verify(storageProvider).save(jobCaptor.capture());

        assertThat(jobCaptor.getValue()).hasState(StateName.AWAITING);
    }

    @Test
    void whenStreamOfJobsIsNotEnqueuedFromABatchJobThenAllJobHaveEnqueuedState() {
        List<JobDetails> jobDetails = asList(defaultJobDetails().build(), defaultJobDetails().build());

        jobScheduler.enqueueAll(jobDetails.stream());

        verify(storageProvider).save(jobListCaptor.capture());

        jobListCaptor.getValue().forEach(job -> assertThat(job).hasState(StateName.ENQUEUED));
    }

    @Test
    void whenStreamOfJobsIsEnqueuedFromABatchJobThenJobHasAwaitingState() {
        BatchJob batchJob = aBatchJobInProgress().build();
        JobHolderContext.setJob(batchJob);
        List<JobDetails> jobDetails = asList(defaultJobDetails().build(), defaultJobDetails().build());

        jobScheduler.enqueueAll(jobDetails.stream());

        verify(storageProvider).save(jobListCaptor.capture());

        jobListCaptor.getValue().forEach(job -> assertThat(job).hasState(StateName.AWAITING));
    }

    @Test
    void onSaveJobMDCDataIsPutIntoJob() {
        ArgumentCaptor<Job> jobArgumentCaptor = ArgumentCaptor.forClass(Job.class);

        MDC.put("some-key", "some-value");
        when(storageProvider.save(jobArgumentCaptor.capture())).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob);

        Job job = jobArgumentCaptor.getValue();
        assertThat(job.getMetadata()).containsKey("mdc-some-key");
    }

    @Test
    void onSaveOrReplaceJobMDCDataIsPutIntoJob() {
        ArgumentCaptor<Job> jobArgumentCaptor = ArgumentCaptor.forClass(Job.class);

        MDC.put("some-key", "some-value");
        when(storageProvider.saveReplace(jobArgumentCaptor.capture())).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveOrReplaceJob);

        Job job = jobArgumentCaptor.getValue();
        assertThat(job.getMetadata()).containsKey("mdc-some-key");
    }

    @Test
    void onSaveJobCreatingAndCreatedAreCalled() {
        when(storageProvider.save(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob);

        assertThat(jobClientLogFilter.onCreating).isTrue();
        assertThat(jobClientLogFilter.onCreated).isTrue();
    }

    @Test
    void onSaveOrReplaceJobCreatingAndCreatedAreCalled() {
        when(storageProvider.saveReplace(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveOrReplaceJob);

        assertThat(jobClientLogFilter.onCreating).isTrue();
        assertThat(jobClientLogFilter.onCreated).isTrue();
    }

    @Test
    void onStreamOfJobsCreatingAndCreatedAreCalled() {
        when(storageProvider.save(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        List<JobDetails> jobDetails = asList(defaultJobDetails().build(), defaultJobDetails().build());
        jobScheduler.enqueueAll(jobDetails.stream());

        assertThat(jobClientLogFilter.onCreating).isTrue();
        assertThat(jobClientLogFilter.onCreated).isTrue();
    }

    @Test
    void onDeleteJobStateElectionAndStateAppliedAreCalled() {
        final Job enqueuedJob = anEnqueuedJobWithName().build();
        when(storageProvider.save(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(storageProvider.getJobById(enqueuedJob.getId())).thenReturn(enqueuedJob);

        jobScheduler.delete(enqueuedJob.getId());

        assertThat(jobClientLogFilter.onStateElection).isTrue();
        assertThat(jobClientLogFilter.onStateApplied).isTrue();
        verify(storageProvider).save(any(Job.class));
    }

    @Test
    void onSaveJobMulticastMessageIsPublished() {
        when(storageProvider.save(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob);

        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void onSaveOrReplaceJobMulticastMessageIsPublished() {
        when(storageProvider.saveReplace(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveOrReplaceJob);

        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void onStreamOfJobsMulticastMessageIsPublished() {
        when(storageProvider.save(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        List<JobDetails> jobDetails = asList(defaultJobDetails().build(), defaultJobDetails().build());
        jobScheduler.enqueueAll(jobDetails.stream());

        verify(jobEnqueuedMessagePublisher, times(1)).publishJobEnqueued();
    }

    @Test
    void onSaveJobsEmptyListMulticastMessageIsNotPublished() {
        List<JobDetails> jobDetails = List.of();

        jobScheduler.enqueueAll(jobDetails.stream());

        verify(storageProvider, never()).save(anyList());
    }

    @Test
    void onRecurringJobCreatingAndCreatedAreCalled() {
        when(storageProvider.saveRecurringJob(any(RecurringJob.class))).thenAnswer(invocation -> invocation.getArgument(0));

        jobScheduler.scheduleRecurrently(null, defaultJobDetails().build(), CronExpression.create(daily()), ZoneId.systemDefault());

        assertThat(jobClientLogFilter.onCreating).isTrue();
        assertThat(jobClientLogFilter.onCreated).isTrue();
    }

    @Test
    void onSaveJobWithoutJobEnqueuedMessagePublisherDoesNotThrowException() {
        jobScheduler = createJobScheduler(null);
        when(storageProvider.save(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        assertThatCode(() -> jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveJob)).doesNotThrowAnyException();
    }

    @Test
    void onSaveOrReplaceJobWithoutJobEnqueuedMessagePublisherDoesNotThrowException() {
        jobScheduler = createJobScheduler(null);
        when(storageProvider.saveReplace(any(Job.class))).thenAnswer(invocation -> invocation.getArgument(0));

        assertThatCode(() -> jobScheduler.enqueue(UUID.randomUUID(), defaultJobDetails().build(), this::saveOrReplaceJob)).doesNotThrowAnyException();
    }

    @Test
    void onStreamOfJobsWithoutJobEnqueuedMessagePublisherDoesNotThrowException() {
        jobScheduler = createJobScheduler(null);

        when(storageProvider.save(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        List<JobDetails> jobDetails = asList(defaultJobDetails().build(), defaultJobDetails().build());

        assertThatCode(() -> jobScheduler.enqueueAll(jobDetails.stream())).doesNotThrowAnyException();
    }

    @Test
    @Because(value = "https://github.com/jobrunr/jobrunr-pro/issues/136")
    void whenTwoRecurringJobsAtTheSameTimeAreSavedInAClusterNoConcurrentRecurringJobExceptionIsThrown() {
        when(storageProvider.saveRecurringJob(any(RecurringJob.class)))
                .thenAnswer(i -> {
                    throw new ConcurrentRecurringJobModificationException((RecurringJob) i.getArgument(0));
                });

        jobScheduler = createJobScheduler(null);

        assertThatCode(() -> jobScheduler.scheduleRecurrently(aDefaultRecurringJob().build())).doesNotThrowAnyException();
    }

    private static class JobClientLogFilter implements JobClientFilter, ElectStateFilter, ApplyStateFilter {

        private boolean onCreating;
        private boolean onCreated;
        private boolean onStateElection;
        private boolean onStateApplied;

        @Override
        public void onCreating(AbstractJob job) {
            onCreating = true;
        }

        @Override
        public void onCreated(AbstractJob job) {
            onCreated = true;
        }

        @Override
        public void onStateElection(Job job, JobState newState) {
            onStateElection = true;
        }

        @Override
        public void onStateApplied(Job job, JobState oldState, JobState newState) {
            onStateApplied = true;
        }
    }

    private JobProId saveJob(Object job) {
        return (JobProId) jobScheduler.saveJob((Job) job);
    }

    private JobProId saveOrReplaceJob(Object job) {
        return (JobProId) jobScheduler.saveOrReplaceJob((Job) job);
    }

    private AbstractJobScheduler createJobScheduler(JobEnqueuedMessagePublisher publisher) {
        return createJobScheduler(storageProvider, publisher);
    }

    private AbstractJobScheduler createJobSchedulerUsingInMemoryStorageProvider(JobEnqueuedMessagePublisher publisher) {
        InMemoryStorageProvider inMemoryStorageProvider = new InMemoryStorageProvider();
        inMemoryStorageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return createJobScheduler(inMemoryStorageProvider, publisher);
    }

    private AbstractJobScheduler createJobScheduler(StorageProvider storageProvider, JobEnqueuedMessagePublisher publisher) {
        return new AbstractJobScheduler<JobProId>(storageProvider, publisher, new JobDefaultFilters(null, asList(jobClientLogFilter), queues), queues) {

            @Override
            protected JobProId createJobId(UUID id) {
                return new JobProId(id);
            }

            @Override
            JobProId create(JobBuilder jobBuilder) {
                throw new UnsupportedOperationException();
            }

            @Override
            void create(Stream<JobBuilder> jobBuilderStream) {
                throw new UnsupportedOperationException();
            }

            @Override
            JobProId createOrReplace(JobBuilder jobBuilder) {
                throw new UnsupportedOperationException();
            }

            @Override
            String createRecurrently(RecurringJobBuilder recurringJobBuilder) {
                throw new UnsupportedOperationException();
            }
        };
    }

    private JobDetails jobDetailsWithRateLimiter() {
        return jobDetails()
                .withClassName(TestService.class)
                .withMethodName("doWorkWithRateLimiter")
                .build();
    }
}