package org.jobrunr.scheduling;

import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.details.JobDetailsAsmGenerator;
import org.jobrunr.jobs.details.JobDetailsGenerator;
import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.scheduling.custom.CustomScheduleTestImplementation;
import org.jobrunr.stubs.TestJobRequest;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.ZoneId;
import java.util.Set;
import java.util.UUID;

import static java.time.ZoneId.systemDefault;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.scheduling.RecurringJobBuilder.aRecurringJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_SERVER_TAG;

class RecurringJobBuilderTest {
    private enum MyQueues {
        HighPrio,
        Default,
        LowPrio
    }

    private static final String every5Seconds = "*/5 * * * * *";
    private static final String duration1Minute = "PT1M";

    private final JobDetailsGenerator jobDetailsGenerator = new JobDetailsAsmGenerator();
    private final JobRequest jobRequest = new TestJobRequest("Not important");
    private final Queues queues = new Queues();

    private TestService testService;

    @Test
    void testDefaultJobWithJobLambda() {
        RecurringJob recurringJob = aRecurringJob()
                .withDetails(() -> testService.doWork())
                .withCron(every5Seconds)
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasId()
                .hasScheduleExpression(every5Seconds)
                .hasJobDetails(TestService.class, "doWork");
    }

    @Test
    void testDefaultJobWithIoCJobLambda() {
        RecurringJob recurringJob = aRecurringJob()
                .<TestService>withDetails(x -> x.doWork())
                .withCron(every5Seconds)
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasId()
                .hasScheduleExpression(every5Seconds)
                .hasJobDetails(TestService.class, "doWork");
    }

    @Test
    void testDefaultJobWithJobRequest() {
        RecurringJob recurringJob = aRecurringJob()
                .withJobRequest(jobRequest)
                .withCron(every5Seconds)
                .build(queues);

        assertThat(recurringJob)
                .hasId()
                .hasScheduleExpression(every5Seconds)
                .hasJobDetails(TestJobRequest.TestJobRequestHandler.class, "run", jobRequest);
    }

    @Test
    void testWithId() {
        String id = UUID.randomUUID().toString();
        RecurringJob recurringJob = aRecurringJob()
                .withId(id)
                .withDetails(() -> testService.doWork())
                .withCron(every5Seconds)
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasId(id)
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithJobName() {
        RecurringJob recurringJob = aRecurringJob()
                .withDetails(() -> testService.doWork())
                .withCron(every5Seconds)
                .withName("My job name")
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasJobName("My job name")
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithAmountOfRetries() {
        RecurringJob recurringJob = aRecurringJob()
                .withAmountOfRetries(10)
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasRetries(10)
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithLabels() {
        RecurringJob recurringJob = aRecurringJob()
                .withLabels(Set.of("TestLabel", "Email"))
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasLabels(Set.of("TestLabel", "Email"))
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testMaxAmountOfLabels() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withLabels("TestLabel", "Email", "Automated", "Too many")
                        .withCron(every5Seconds)
                        .withDetails(() -> testService.doWork())
                        .build(jobDetailsGenerator, queues));
    }

    @Test
    void testMaxLengthOfLabel() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withLabels("Label longer than 45 characters should throw an exception")
                        .withCron(every5Seconds)
                        .withDetails(() -> testService.doWork())
                        .build(jobDetailsGenerator, queues));
    }

    @Test
    void testWithDuration() {
        RecurringJob recurringJob = aRecurringJob()
                .withInterval(Duration.ofMinutes(1))
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasId()
                .hasScheduleExpression(duration1Minute);
    }

    @Test
    void testWithCustomSchedule() {
        RecurringJob recurringJob = aRecurringJob()
                .withCustomSchedule(CustomScheduleTestImplementation.myCustomSchedule("2052-01-01T01:00:00.000Z"))
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasId()
                .hasScheduleExpression(CustomScheduleTestImplementation.class.getName() + "(2052-01-01T01:00:00.000Z)");
    }

    @Test
    void testWithZoneId() {
        RecurringJob recurringJob = aRecurringJob()
                .withZoneId(ZoneId.of("Europe/Brussels"))
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasZoneId("Europe/Brussels")
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithDefaultZoneId() {
        RecurringJob recurringJob = aRecurringJob()
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasZoneId(systemDefault().toString())
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testJobDetailsCanOnlyBeSet1Way() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withDetails(() -> testService.doWork())
                        .withJobRequest(jobRequest)
                        .withCron(every5Seconds)
                        .build(jobDetailsGenerator, queues));

        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withJobRequest(jobRequest)
                        .withDetails(() -> testService.doWork())
                        .withCron(every5Seconds)
                        .build(jobDetailsGenerator, queues));
    }

    @Test
    void testBuildWithIncorrectJobDetails() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withJobRequest(jobRequest)
                        .withCron(every5Seconds)
                        .build(jobDetailsGenerator, queues));

        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withDetails(() -> testService.doWork())
                        .withCron(every5Seconds)
                        .build(queues));
    }

    @Test
    void testBuildWithoutSchedule() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withJobRequest(jobRequest)
                        .build(queues));
    }

    @Test
    void scheduleCanOnlyBeSet1Way() {
        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withCron(every5Seconds)
                        .withInterval(Duration.ofMinutes(1))
                        .withJobRequest(jobRequest)
                        .build(queues));

        assertThatIllegalArgumentException()
                .isThrownBy(() -> aRecurringJob()
                        .withInterval(Duration.ofMinutes(1))
                        .withCron(every5Seconds)
                        .withJobRequest(jobRequest)
                        .build(queues));
    }

    @Test
    void testWithServerTag() {
        RecurringJob recurringJob = aRecurringJob()
                .withServerTag("My server tag")
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasServerTag("My server tag")
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithDefaultServerTag() {
        RecurringJob recurringJob = aRecurringJob()
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasServerTag(DEFAULT_SERVER_TAG)
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithMutex() {
        RecurringJob recurringJob = aRecurringJob()
                .withMutex("My mutex")
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasMutex("My mutex")
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithRateLimiter() {
        RecurringJob recurringJob = aRecurringJob()
                .withRateLimiter("my-rate-limiter")
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasRateLimiter("my-rate-limiter")
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithQueue() {
        Queues queues = new Queues("default", "default", "low-prio");
        RecurringJob recurringJob = aRecurringJob()
                .withQueue("low-prio")
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasPriority(1)
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithQueueFromEnum() {
        Queues queues = new Queues(MyQueues.values());
        RecurringJob recurringJob = aRecurringJob()
                .withQueue(MyQueues.LowPrio)
                .withCron(every5Seconds)
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasPriority(2)
                .hasId()
                .hasScheduleExpression(every5Seconds);
    }

    @Test
    void testWithScheduleJobsSkippedDuringDowntime() {
        RecurringJob recurringJob = aRecurringJob()
                .withScheduleJobsSkippedDuringDowntime()
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasScheduleJobsSkippedDuringDowntime(true)
                .hasScheduleExpression(Cron.minutely());
    }

    @Test
    void testWithMaxConcurrentJobs() {
        RecurringJob recurringJob = aRecurringJob()
                .withMaxConcurrentJobs(3)
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasMaxConcurrentJobs(3);
    }

    @Test
    void testWithPaused() {
        RecurringJob recurringJob = aRecurringJob()
                .withPaused(true)
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);

        assertThat(recurringJob)
                .hasPaused(true);
    }

    @Test
    void testWithDeleteOnSuccess() {
        RecurringJob recurringJob = aRecurringJob()
                .withDeleteOnSuccess("PT10S!PT20S")
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnSuccess("PT10S!PT20S");

        recurringJob = aRecurringJob()
                .withDeleteOnSuccess(Duration.ZERO)
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnSuccess("PT0S");

        recurringJob = aRecurringJob()
                .withDeleteOnSuccess(null, Duration.ofSeconds(5))
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnSuccess("!PT5S");

        recurringJob = aRecurringJob()
                .withDeleteOnSuccess(Duration.ofMinutes(2), Duration.ofSeconds(5))
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnSuccess("PT2M!PT5S");
    }

    @Test
    void testWithDeleteOnFailure() {
        RecurringJob recurringJob = aRecurringJob()
                .withDeleteOnFailure("PT10S!PT20S")
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnFailure("PT10S!PT20S");

        recurringJob = aRecurringJob()
                .withDeleteOnFailure(Duration.ZERO)
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnFailure("PT0S");

        recurringJob = aRecurringJob()
                .withDeleteOnFailure(null, Duration.ofSeconds(5))
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnFailure("!PT5S");

        recurringJob = aRecurringJob()
                .withDeleteOnFailure(Duration.ofMinutes(2), Duration.ofSeconds(5))
                .withCron(Cron.minutely())
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues);
        assertThat(recurringJob)
                .hasDeleteOnFailure("PT2M!PT5S");
    }
}