package org.jobrunr.scheduling;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import io.github.artsok.RepeatedIfExceptionsTest;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Condition;
import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.jobs.stubs.SimpleJobActivator;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.scheduling.custom.CustomScheduleTestImplementation;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestJobContextJobRequest;
import org.jobrunr.stubs.TestJobContextJobRequest.TestJobContextJobRequestHandler;
import org.jobrunr.stubs.TestJobRequest;
import org.jobrunr.stubs.TestJobRequest.TestJobRequestHandler;
import org.jobrunr.stubs.TestJobRequestThatTakesLong;
import org.jobrunr.stubs.TestJobRequestWithoutJobAnnotation;
import org.jobrunr.stubs.TestJobWithResultRequest;
import org.jobrunr.stubs.TestMDCJobRequest;
import org.jobrunr.utils.annotations.Because;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.time.Instant.now;
import static java.time.ZoneId.systemDefault;
import static java.util.Arrays.asList;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.FIVE_HUNDRED_MILLISECONDS;
import static org.awaitility.Durations.FIVE_SECONDS;
import static org.awaitility.Durations.ONE_SECOND;
import static org.awaitility.Durations.TEN_SECONDS;
import static org.awaitility.Durations.TWO_SECONDS;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobAssert.scheduledNear;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.scheduling.JobBuilder.aJob;
import static org.jobrunr.scheduling.RecurringJobBuilder.aRecurringJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;

public class BackgroundJobByJobRequestTest {

    private StorageProvider storageProvider;
    private BackgroundJobServer backgroundJobServer;

    private static final String everySecond = "*/1 * * * * *";

    @BeforeEach
    public void setUpTests() {
        storageProvider = new InMemoryStorageProvider();
        SimpleJobActivator jobActivator = new SimpleJobActivator(
                new TestJobRequestHandler(),
                new TestJobContextJobRequestHandler()
        );
        JobRunrPro.configure()
                .useJobActivator(jobActivator)
                .useStorageProvider(storageProvider)
                .useBackgroundJobServer(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofMillis(200)))
                .initialize();
        backgroundJobServer = JobRunrPro.getBackgroundJobServer();
    }

    @AfterEach
    public void cleanUp() {
        MDC.clear();
        JobRunrPro.destroy();
    }

    @Test
    void ifBackgroundJobIsNotConfiguredCorrectlyAnExceptionIsThrown() {
        BackgroundJobRequest.setJobRequestScheduler(null);
        assertThatThrownBy(() -> BackgroundJobRequest.enqueue(new TestJobRequest("not important")))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("The JobRequestScheduler has not been initialized. Use the fluent JobRunr.configure() API to setup JobRunr or set the JobRequestScheduler via the static setter method.");
    }

    @Test
    void testCreateViaBuilder() {
        UUID jobId = UUID.randomUUID();
        BackgroundJobRequest.create(aJob()
                .withId(jobId)
                .withJobRequest(new TestJobRequestWithoutJobAnnotation("not important")));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testCreateViaBuilderAndAnnotationMustFail() {
        assertThatThrownBy(() -> BackgroundJobRequest.create(aJob()
                .withJobRequest(new TestJobRequest("not important"))))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("You are combining the JobBuilder with the Job annotation which is not allowed. You can only use one of them.");
    }

    @Test
    void testEnqueue() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestJobRequest("from testEnqueue"));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testEnqueueWithResult() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestJobWithResultRequest("from testEnqueue"));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
        await().atMost(6, SECONDS).until(() -> BackgroundJobRequest.getJobResult(jobId).getResult().equals("The result from testEnqueue"));
    }

    @Test
    void testEnqueueWithId() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(UUID.randomUUID(), new TestJobRequest("from testEnqueue"));
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void testEnqueueReplace() {
        asList("A", "B", "C", "D", "E", "F")
                .forEach(jobName -> BackgroundJobRequest.enqueue(new TestJobRequest("Job " + jobName + "(not important - just filling the queue)")));

        ListAppender<ILoggingEvent> testJobRequestHandlerLogger = LoggerAssert.initFor(TestJobRequestHandler.class);

        UUID id = UUID.randomUUID();
        JobRequestId jobId1 = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequest("wrong input"));
        JobRequestId jobId2 = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequest("correct input"));
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        assertThat(testJobRequestHandlerLogger)
                .hasDebugMessageContaining("correct input");
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void testEnqueueReplaceWithBuilder() {
        asList("A", "B", "C", "D", "E", "F")
                .forEach(jobName -> BackgroundJobRequest.create(aJob().withName("Job " + jobName).withJobRequest(new TestJobRequestWithoutJobAnnotation("Job " + jobName + "(not important - just filling the queue)"))));

        UUID id = UUID.randomUUID();
        JobRequestId jobId1 = BackgroundJobRequest.createOrReplace(aJob().withId(id).withName("Wrong Job").withJobRequest(new TestJobRequestWithoutJobAnnotation("wrong input")));
        JobRequestId jobId2 = BackgroundJobRequest.createOrReplace(aJob().withId(id).withName("Correct Job").withJobRequest(new TestJobRequestWithoutJobAnnotation("correct input")));
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1))
                .hasStates(ENQUEUED, PROCESSING, SUCCEEDED)
                .hasJobName("Correct Job")
        );
    }

    @Test
    void testScheduleReplaceAScheduledJob() {
        UUID id = UUID.randomUUID();
        storageProvider.save(aScheduledJob().withId(id).build());
        JobRequestId jobId = BackgroundJobRequest.scheduleOrReplace(id, now().plusSeconds(2), new TestJobRequest("from testScheduleReplaceAScheduledJob"));
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(TEN_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED));
    }

    @Test
    void testEnqueueReplaceAJobThatIsAlreadyProcessing() {
        UUID id = UUID.randomUUID();
        JobRequestId jobId1 = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequestThatTakesLong("from testEnqueueReplaceAJobThatIsAlreadyProcessing", 15));
        await().until(() -> storageProvider.getJobById(jobId1).getState() == PROCESSING);
        JobRequestId jobId2 = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequest("from testEnqueueReplaceAJobThatIsAlreadyProcessing"));
        // why: no exception should be thrown.

        assertThat(jobId1).isEqualTo(jobId2);
        await().atMost(TEN_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(jobId1)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(jobId1).getLastJobStateOfType(EnqueuedState.class);
        Assertions.assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @Test
    void testEnqueueReplaceAJobThatHasAlreadySucceeded() {
        UUID id = UUID.randomUUID();
        storageProvider.save(aSucceededJob().withId(id).build());
        JobRequestId jobId = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequest("from testEnqueueReplaceAJobThatHasAlreadySucceeded"));
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(id)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(id).getLastJobStateOfType(EnqueuedState.class);
        Assertions.assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @Test
    void testEnqueueReplaceAJobThatHasAlreadyFailed() {
        UUID id = UUID.randomUUID();
        storageProvider.save(aFailedJob().withId(id).build());
        JobRequestId jobId = BackgroundJobRequest.enqueueOrReplace(id, new TestJobRequest("from testEnqueueReplaceAJobThatHasAlreadyFailed"));
        // why: no exception should be thrown.

        assertThat(jobId.asUUID()).isEqualTo(id);
        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.getJobById(id)).hasStates(ENQUEUED, PROCESSING, SUCCEEDED));
        Optional<EnqueuedState> lastEnqueuedJobState = storageProvider.getJobById(id).getLastJobStateOfType(EnqueuedState.class);
        Assertions.assertThat(lastEnqueuedJobState.get().isReplacingExistingJob()).isTrue();
    }

    @Test
    void testEnqueueWithDisplayName() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestJobRequest("from testEnqueue"));
        assertThat(storageProvider.getJobById(jobId))
                .hasJobName("Some neat Job Display Name");
    }

    @Test
    void testEnqueueOfFailingJobAndRetryCount() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestJobRequest("from testEnqueue", true));
        await().atMost(15, TimeUnit.SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == FAILED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING, FAILED, SCHEDULED, ENQUEUED, PROCESSING, FAILED);
    }

    @Test
    void testEnqueueWithJobContextAndMetadata() {
        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestJobRequest("from testEnqueueWithJobContextAndMetadata", 1));
        await().atMost(FIVE_HUNDRED_MILLISECONDS).until(() -> storageProvider.getJobById(jobId).getState() == PROCESSING);
        await().atMost(TWO_SECONDS).until(() -> !storageProvider.getJobById(jobId).getMetadata().isEmpty());
        assertThat(storageProvider.getJobById(jobId))
                .hasMetadata("test", "test");
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId))
                .hasStates(ENQUEUED, PROCESSING, SUCCEEDED)
                .hasMetadataOnlyContainingObservabilityInfoJobProgressAndLogging();
    }

    @Test
    void testEnqueueStreamWithMultipleParameters() {
        Stream<JobRequest> workStream = jobRequestStream();
        BackgroundJobRequest.enqueue(workStream);

        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testCreateStreamWithJobBuilder() {
        BackgroundJobRequest.create(jobRequestWithoutJobAnnotationStream()
                .map(jobRequest -> aJob().withJobRequest(jobRequest))
        );

        await().atMost(FIVE_SECONDS).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isEqualTo(5));
    }

    @Test
    void testScheduleWithZonedDateTime() {
        JobRequestId jobId = BackgroundJobRequest.schedule(ZonedDateTime.now().plus(ofMillis(1500)), new TestJobRequest("from testScheduleWithZonedDateTime"));
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithOffsetDateTime() {
        JobRequestId jobId = BackgroundJobRequest.schedule(OffsetDateTime.now().plus(ofMillis(1500)), new TestJobRequest("from testScheduleWithOffsetDateTime"));
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithLocalDateTime() {
        JobRequestId jobId = BackgroundJobRequest.schedule(LocalDateTime.now().plus(ofMillis(1500)), new TestJobRequest("from testScheduleWithLocalDateTime"));
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleWithInstant() {
        JobRequestId jobId = BackgroundJobRequest.schedule(now().plusMillis(1500), new TestJobRequest("from testScheduleWithInstant"));
        await().during(ONE_SECOND).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        await().atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SUCCEEDED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testScheduleUsingDateTimeInTheFutureIsNotEnqueued() {
        JobRequestId jobId = BackgroundJobRequest.schedule(now().plus(100, ChronoUnit.DAYS), new TestJobRequest("from testScheduleUsingDateTimeInTheFutureIsNotEnqueued"));
        await().during(TWO_SECONDS).atMost(FIVE_SECONDS).until(() -> storageProvider.getJobById(jobId).getState() == SCHEDULED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(SCHEDULED);
    }

    @Test
    void testRecurringCronJob() {
        BackgroundJobRequest.scheduleRecurrently(everySecond, new TestJobRequest("from testRecurringJob"));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobFromBuilder() {
        BackgroundJobRequest.createRecurrently(aRecurringJob()
                .withCron(everySecond)
                .withJobRequest(new TestJobRequest("from TestRecurringJob")));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobWithId() {
        BackgroundJobRequest.scheduleRecurrently("theId", everySecond, new TestJobRequest("from testRecurringJobWithId"));
        BackgroundJobRequest.scheduleRecurrently("theId", everySecond, new TestJobRequest("from testRecurringJobWithId"));
        // why: no exception should be thrown.

        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCronJobWithIdAndTimezone() {
        BackgroundJobRequest.scheduleRecurrently("theId", everySecond, systemDefault(), new TestJobRequest("from testRecurringJobWithIdAndTimezone"));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringIntervalJob() {
        BackgroundJobRequest.scheduleRecurrently(Duration.ofSeconds(1), new TestJobRequest("from testRecurringJob"));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringIntervalJobFromBuilder() {
        BackgroundJobRequest.createRecurrently(aRecurringJob()
                .withInterval(Duration.ofSeconds(1))
                .withJobRequest(new TestJobRequest("from TestRecurringJob")));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringIntervalJobWithId() {
        BackgroundJobRequest.scheduleRecurrently("theId", Duration.ofSeconds(1), new TestJobRequest("from testRecurringJobWithId"));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCustomScheduleJob() {
        final String scheduledAt = now().plusSeconds(5).toString();
        BackgroundJobRequest.scheduleRecurrently(CustomScheduleTestImplementation.myCustomSchedule(scheduledAt),
                new TestJobRequest("from testRecurringJob"));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testRecurringCustomScheduleJobFromBuilder() {
        final String scheduledAt = now().plusSeconds(5).toString();
        BackgroundJobRequest.createRecurrently(aRecurringJob()
                .withCustomSchedule(CustomScheduleTestImplementation.myCustomSchedule(scheduledAt))
                .withJobRequest(new TestJobRequest("from TestRecurringJob")));
        await().atMost(ofSeconds(20)).untilAsserted(() -> assertThat(storageProvider.countJobs(new JobSearchRequest(SUCCEEDED))).isGreaterThanOrEqualTo(1));

        final Job job = storageProvider.getJob(new JobSearchRequest(SUCCEEDED));
        assertThat(job).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testDeleteOfRecurringJob() {
        BackgroundJobRequest.scheduleRecurrently("theId", Cron.minutely(), systemDefault(), new TestJobRequest("from testRecurringJobWithIdAndTimezone"));
        BackgroundJob.delete("theId");
        assertThat(storageProvider.countRecurringJobs(aRecurringJobSearchRequest().build())).isEqualTo(0L);
    }

    @Test
    void recurringJobIdIsKeptEvenIfBackgroundJobServerRestarts() {
        BackgroundJobRequest.scheduleRecurrently("my-job-id", everySecond, new TestJobRequestThatTakesLong("from recurringJobIdIsKeptEvenIfBackgroundJobServerRestarts", 12));
        await().atMost(TWO_SECONDS).until(() -> storageProvider.countJobs(new JobSearchRequest(PROCESSING)) == 1);
        final UUID jobId = storageProvider.getJob(new JobSearchRequest(PROCESSING)).getId();
        backgroundJobServer.stop();

        backgroundJobServer.start();
        await().atMost(ofSeconds(20)).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobId))
                .hasRecurringJobId("my-job-id")
                .hasStates(SCHEDULED, ENQUEUED, PROCESSING, FAILED, SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void jobCanBeDeletedWhenEnqueued() {
        JobRequestId jobRequestId = BackgroundJobRequest.enqueue(new TestJobRequestThatTakesLong("input", 12));
        BackgroundJobRequest.delete(jobRequestId);

        await().atMost(6, SECONDS).untilAsserted(() -> {
            assertThat(backgroundJobServer.getJobZooKeeper().getOccupiedWorkerCount()).isZero();
            assertThat(storageProvider.getJobById(jobRequestId))
                    .hasStates(ENQUEUED, DELETED)
                    .hasDeletedAtNotNull();
        });
    }

    @Test
    void testJobChaining() {
        JobRequestId jobRequestId = BackgroundJobRequest
                .enqueue(new TestJobRequest("Job numero uno"))
                .continueWith(new TestJobRequest("Job numero due"));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobRequestId).hasState(SUCCEEDED));
        assertThat(storageProvider.getJobById(jobRequestId)).hasStates(AWAITING, ENQUEUED, PROCESSING, SUCCEEDED);
    }

    @Test
    void testJobChainingWithDurationToWait() {
        JobRequestId jobRequestId = BackgroundJobRequest
                .enqueue(new TestJobRequest("Job numero uno"))
                .continueWith(Duration.ofDays(3), new TestJobRequest("Job numero due"));
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobRequestId).hasState(SCHEDULED));
        assertThat(storageProvider.getJobById(jobRequestId))
                .hasStates(AWAITING, SCHEDULED)
                .is(scheduledNear(now().plus(Duration.ofDays(3))));
    }

    @Test
    void mdcContextIsAvailableInJob() {
        MDC.put("someKey", "someValue");

        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestMDCJobRequest("someKey"));
        await().atMost(30, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    @Because("https://github.com/jobrunr/jobrunr/issues/581")
    void mdcContextIsAvailableInJobAndAllowsNullValues() {
        MDC.put("keyA", "keyAValue");
        MDC.put("keyB", null);

        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestMDCJobRequest("keyA"));
        await().atMost(30, SECONDS).until(() -> storageProvider.getJobById(jobId).hasState(SUCCEEDED));
    }

    @Test
    void mdcContextIsAvailableForDisplayName() {
        MDC.put("customer.id", "1");

        JobRequestId jobId = BackgroundJobRequest.enqueue(new TestMDCJobRequest("someKey"));
        assertThat(storageProvider.getJobById(jobId)).hasJobName("Doing some hard work for customerId: 1");
    }

    @Test
    void testJobContextIsThreadSafe() {
        JobRequestId jobId1 = BackgroundJobRequest.enqueue(new TestJobContextJobRequest());
        JobRequestId jobId2 = BackgroundJobRequest.enqueue(new TestJobContextJobRequest());

        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId1).getState() == FAILED);
        await().atMost(TEN_SECONDS).until(() -> storageProvider.getJobById(jobId2).getState() == FAILED);

        Job job1ById = storageProvider.getJobById(jobId1);
        assertThat(job1ById)
                .hasMetadata(allValuesAre(jobId1.asUUID()))
                .hasMetadata(noValueMatches(jobId2.asUUID()));

        Job job2ById = storageProvider.getJobById(jobId2);
        assertThat(job2ById)
                .hasMetadata(allValuesAre(jobId2.asUUID()))
                .hasMetadata(noValueMatches(jobId1.asUUID()));
    }

    Condition<Map<String, Object>> noValueMatches(UUID id) {
        return new Condition<>(s -> !s.containsValue(id), "a value matches %s", id);
    }

    Condition<Map<String, Object>> allValuesAre(UUID id) {
        return new Condition<>(s -> new HashSet<>(s.values()).size() == 2 && new HashSet<>(s.values()).contains(id), "a value matches %s", id);
    }

    private Stream<JobRequest> jobRequestStream() {
        return Stream.of(
                new TestJobRequest("Workstream item 1"),
                new TestJobRequest("Workstream item 2"),
                new TestJobRequest("Workstream item 3"),
                new TestJobRequest("Workstream item 4"),
                new TestJobRequest("Workstream item 5")
        );
    }

    private Stream<TestJobRequestWithoutJobAnnotation> jobRequestWithoutJobAnnotationStream() {
        return Stream.of(
                new TestJobRequestWithoutJobAnnotation("Workstream item 1"),
                new TestJobRequestWithoutJobAnnotation("Workstream item 2"),
                new TestJobRequestWithoutJobAnnotation("Workstream item 3"),
                new TestJobRequestWithoutJobAnnotation("Workstream item 4"),
                new TestJobRequestWithoutJobAnnotation("Workstream item 5")
        );
    }
}
