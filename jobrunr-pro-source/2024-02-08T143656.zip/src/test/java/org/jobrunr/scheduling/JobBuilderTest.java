package org.jobrunr.scheduling;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.details.JobDetailsAsmGenerator;
import org.jobrunr.jobs.details.JobDetailsGenerator;
import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.AwaitingRateLimiterState;
import org.jobrunr.jobs.states.AwaitingState;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.stubs.TestJobRequestWithoutJobAnnotation;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.MILLIS;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.scheduling.JobBuilder.aBatchJob;
import static org.jobrunr.scheduling.JobBuilder.aJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_SERVER_TAG;

class JobBuilderTest {

    private enum MyQueues {
        HighPrio,
        Default,
        LowPrio
    }

    private final JobDetailsGenerator jobDetailsGenerator = new JobDetailsAsmGenerator();
    private final JobRequest jobRequest = new TestJobRequestWithoutJobAnnotation("Not important");
    private final Queues queues = new Queues();
    private TestService testService;

    @Test
    void testJobBuilderCannotBeCombinedWithAnnotation() {
        assertThatThrownBy(() -> aJob()
                .withDetails(() -> testService.doWork())
                .build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("You are combining the JobBuilder with the Job annotation which is not allowed. You can only use one of them.");
    }

    @Test
    void testDefaultJobWithJobLambda() {
        UUID uuid = UUID.randomUUID();
        Job job = aJob()
                .withDetails(() -> testService.doWorkWithUUID(uuid))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasId()
                .hasJobDetails(TestService.class, "doWorkWithUUID", uuid)
                .hasState(ENQUEUED)
                .isBatchJob(false);
    }

    @Test
    void testDefaultJobWithIoCJobLambda() {
        UUID uuid = UUID.randomUUID();
        Job job = aJob()
                .<TestService>withDetails(x -> x.doWorkWithUUID(uuid))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasId()
                .hasJobDetails(TestService.class, "doWorkWithUUID", uuid)
                .hasState(ENQUEUED);
    }

    @Test
    void testDefaultJobWithJobRequest() {
        Job job = aJob()
                .withJobRequest(jobRequest)
                .build(queues);

        assertThat(job)
                .hasId()
                .hasJobDetails(TestJobRequestWithoutJobAnnotation.TestWithoutJobAnnotationJobRequestHandler.class, "run", jobRequest)
                .hasState(ENQUEUED)
                .isBatchJob(false);
    }

    @Test
    void testDefaultBatchJobWithJobLambda() {
        UUID uuid = UUID.randomUUID();
        Job job = aBatchJob()
                .withDetails(() -> testService.doWorkWithUUID(uuid))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasId()
                .hasJobDetails(TestService.class, "doWorkWithUUID", uuid)
                .hasState(ENQUEUED)
                .isBatchJob(true);
    }

    @Test
    void testDefaultBatchJobWithJobRequest() {
        Job job = aBatchJob()
                .withJobRequest(jobRequest)
                .build(queues);

        assertThat(job)
                .hasId()
                .hasJobDetails(TestJobRequestWithoutJobAnnotation.TestWithoutJobAnnotationJobRequestHandler.class, "run", jobRequest)
                .hasState(ENQUEUED)
                .isBatchJob(true);
    }

    @Test
    void testWithId() {
        UUID id = UUID.randomUUID();
        Job job = aJob()
                .withId(id)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasId(id)
                .hasState(ENQUEUED);
    }

    @Test
    void testWithJobName() {
        Job job = aJob()
                .withName("My job name")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasJobName("My job name")
                .hasState(ENQUEUED);
    }

    @Test
    void testWithScheduleIn() {
        Job job = aJob()
                .scheduleIn(Duration.ofMinutes(1))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job).hasState(StateName.SCHEDULED);
        ScheduledState scheduledState = job.getJobState();
        assertThat(scheduledState.getScheduledAt()).isCloseTo(now().plusSeconds(60), within(500, MILLIS));
    }

    @Test
    void testWithScheduleAt() {
        Job job = aJob()
                .scheduleAt(Instant.now().plusSeconds(60))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job).hasState(StateName.SCHEDULED);
        ScheduledState scheduledState = job.getJobState();
        assertThat(scheduledState.getScheduledAt()).isCloseTo(now().plusSeconds(60), within(500, MILLIS));
    }

    @Test
    void testWithRunAfter() {
        UUID jobIdToFirstSucceed = UUID.randomUUID();

        Job job = aJob()
                .runAfter(jobIdToFirstSucceed)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job).hasState(AWAITING);
        AwaitingState awaitingState = job.getJobState();
        assertThat(awaitingState.getWaitingOnJob()).isEqualTo(jobIdToFirstSucceed);
    }

    @Test
    void testThatOnlyOneOfScheduleInScheduleAtOrRunAfterIsAllowed() {
        assertThatThrownBy(() -> aJob().scheduleAt(Instant.now()).scheduleIn(Duration.ZERO).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob().scheduleIn(Duration.ZERO).scheduleAt(Instant.now()).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob().runAfter(UUID.randomUUID()).scheduleAt(Instant.now()).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob().runAfter(UUID.randomUUID()).scheduleIn(Duration.ZERO).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob().scheduleIn(Duration.ZERO).runAfter(UUID.randomUUID()).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob().scheduleAt(Instant.now()).runAfter(UUID.randomUUID()).build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testWithAmountOfRetries() {
        int amountOfRetries = 5;

        Job job = aJob()
                .withAmountOfRetries(amountOfRetries)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasAmountOfRetries(amountOfRetries)
                .hasState(ENQUEUED);
    }

    @Test
    void testWithLabels() {
        Job job = aJob()
                .withLabels(Set.of("TestLabel", "Email"))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasLabels(Set.of("TestLabel", "Email"))
                .hasState(ENQUEUED);
    }

    @Test
    void testMaxAmountOfLabels() {
        assertThatThrownBy(() -> aJob()
                .withLabels("TestLabel", "Email", "Automated", "Too many")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testMaxLengthOfLabel() {
        assertThatThrownBy(() -> aJob()
                .withLabels("Label longer than 45 characters should throw an exception")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testJobDetailsCanOnlyBeSet1Way() {
        assertThatThrownBy(() -> aJob()
                .withJobRequest(jobRequest)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID())))
                .isInstanceOf(IllegalArgumentException.class);

        assertThatThrownBy(() -> aJob()
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .withJobRequest(jobRequest))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testBuildWithIncorrectJobDetails() {
        assertThatThrownBy(() -> aJob()
                .withJobRequest(jobRequest)
                .build(jobDetailsGenerator, queues))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> aJob()
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(queues))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testWithServerTag() {
        Job job = aJob()
                .withServerTag("My server tag")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasServerTag("My server tag")
                .hasState(ENQUEUED);
    }

    @Test
    void testWithDefaultServerTag() {
        Job job = aJob()
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasServerTag(DEFAULT_SERVER_TAG)
                .hasState(ENQUEUED);
    }

    @Test
    void testWithMutex() {
        Job job = aJob()
                .withMutex("My mutex")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasMutex("My mutex")
                .hasState(ENQUEUED);
    }

    @Test
    void testWithRateLimiter() {
        Job job = aJob()
                .withRateLimiter("my-concurrent-rate-limiter")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "my-concurrent-rate-limiter".equals(s.getWaitingOnRateLimiter()))
                .hasRateLimiter("my-concurrent-rate-limiter");
    }

    @Test
    void testWithQueue() {
        Queues queues = new Queues("Default", "Default", "LowPrio");
        Job job = aJob()
                .withQueue("LowPrio")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasPriority(1)
                .hasState(ENQUEUED);
    }

    @Test
    void testWithQueueFromEnum() {
        Queues queues = new Queues(MyQueues.values());
        Job job = aJob()
                .withQueue(MyQueues.LowPrio)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);

        assertThat(job)
                .hasPriority(2)
                .hasState(ENQUEUED);
    }

    @Test
    void testWithDeleteOnSuccess() {
        Job job = aJob()
                .withDeleteOnSuccess("PT10S!PT20S")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnSuccess("PT10S!PT20S");

        job = aJob()
                .withDeleteOnSuccess(Duration.ZERO)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnSuccess("PT0S");

        job = aJob()
                .withDeleteOnSuccess(null, Duration.ofSeconds(5))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnSuccess("!PT5S");

        job = aJob()
                .withDeleteOnSuccess(Duration.ofMinutes(2), Duration.ofSeconds(5))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnSuccess("PT2M!PT5S");
    }

    @Test
    void testWithDeleteOnFailure() {
        Job job = aJob()
                .withDeleteOnFailure("PT10S!PT20S")
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnFailure("PT10S!PT20S");

        job = aJob()
                .withDeleteOnFailure(Duration.ZERO)
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnFailure("PT0S");

        job = aJob()
                .withDeleteOnFailure(null, Duration.ofSeconds(5))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnFailure("!PT5S");

        job = aJob()
                .withDeleteOnFailure(Duration.ofMinutes(2), Duration.ofSeconds(5))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasDeleteOnFailure("PT2M!PT5S");
    }

    @Test
    void testWithProcessTimeOut() {
        Job job = aJob()
                .withProcessTimeOut(Duration.ofMinutes(1))
                .withDetails(() -> testService.doWorkWithUUID(UUID.randomUUID()))
                .build(jobDetailsGenerator, queues);
        assertThat(job)
                .hasProcessTimeOut(Duration.ofMinutes(1));
    }
}