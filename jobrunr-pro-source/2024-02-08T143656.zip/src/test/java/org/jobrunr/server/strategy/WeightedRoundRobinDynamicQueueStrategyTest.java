package org.jobrunr.server.strategy;

import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.utils.SleepUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.server.configuration.RoundRobinDynamicQueuePolicy.DEFAULT_REMOVAL_THRESHOLD;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WeightedRoundRobinDynamicQueueStrategyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    StorageProvider storageProvider;

    private WeightedRoundRobinDynamicQueueStrategy roundRobinDynamicQueueStrategy;

    @BeforeEach
    void setUp() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithoutDynamicQueues() {
        // GIVEN
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy();

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getDistinctDynamicQueues(ENQUEUED);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), isNull(), refEq(ascOnPriorityAndUpdatedAt(5)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueues() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy();

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesIfThereAreResults() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy();

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesAndTakesIntoAccountWeightIfThereAreResults() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(Map.of("Tenant-A", 3));

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), any(AmountRequest.class)))
                .thenReturn(asList(
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()),
                        asList(
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()),
                        emptyList());
        List<Job> tenantAJobsToProcess1 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        assertThat(tenantAJobsToProcess1).hasSize(5);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        List<Job> tenantAJobsToProcess2 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        assertThat(tenantAJobsToProcess2).hasSize(3);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(3)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesAndTakesIntoAccountWeightIfThereAreResultsButIsAlsoLimited() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(Map.of("Tenant-A", 2));

        // GIVEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), any(AmountRequest.class)))
                .thenReturn(asList(
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()),
                        asList(
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()),
                        asList(
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                                anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()),
                        emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class)))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build()));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        List<Job> tenantAJobsToProcess1 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        assertThat(tenantAJobsToProcess1).hasSize(5);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        List<Job> tenantAJobsToProcess2 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        assertThat(tenantAJobsToProcess2).hasSize(5);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        List<Job> tenantBJobsToProcess1 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        assertThat(tenantBJobsToProcess1).hasSize(3);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(3)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        List<Job> tenantAJobsToProcess3 = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        assertThat(tenantAJobsToProcess3).hasSize(5);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesAndNullEntryCyclesThroughQueuesIncludingNull() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        //WHEN
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy();


        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue(null).withLabels("just a label").build(),
                        anEnqueuedJob().withDynamicQueue(null).withLabels("and another label").build()));
        List<Job> nullTenantJobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        // THEN
        assertThat(nullTenantJobsToProcess).hasSize(2);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7))))
                .thenReturn(asList(anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        // THEN
        List<Job> tenantAJobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));
        assertThat(tenantAJobsToProcess).hasSize(1);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(2));
        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesCachesQueuesForGivenDuration() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(1), 1);

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED); // only 1 time

        // WHEN
        SleepUtils.sleep(1000);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        verify(storageProvider, times(2)).getDistinctDynamicQueues(ENQUEUED); // after given period, a second time
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesRemovesQueuesOnRefreshIfQueueNotPresentForXTimesWhereXEqualsRemovalThreshold() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(Map.of("Tenant-B", 2), Duration.ofMillis(100), 1);

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.ofNullable(null)), refEq(ascOnPriorityAndUpdatedAt(5)));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // THEN
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED);

        // GIVEN FOR THE NEXT COUPLE OF TIMES
        Mockito.clearInvocations(storageProvider);
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A")));

        // WHEN
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED);

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.ofNullable(null)), refEq(ascOnPriorityAndUpdatedAt(6)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(4));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(4)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(15));

        // THEN (as there we have only jobs for TENANT-A for the last 3 checks)
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(15)));
        assertThat((Map) Whitebox.getInternalState(roundRobinDynamicQueueStrategy, "roundRobinIds")).hasSize(1);
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsUntilThereAreJobs() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(5), 3);

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), any(AmountRequest.class)))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class)))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build()));
        List<Job> jobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        assertThat(jobsToProcess).hasSize(2);

        // THEN
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), any(AmountRequest.class)))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), any(AmountRequest.class)))
                .thenReturn(asList(anEnqueuedJob().withDynamicQueue("Tenant-D").withLabels("tenant:Tenant-D").build()));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobs() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(5), 3);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testWeightedRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobsButStopsIfItIsAgainAtTheBeginning() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(5), 5);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithChangingDynamicQueuesToEnsureNoQueueIsUsedConsecutivelyWhenAnotherIsAvailable() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createWeightedRoundRobinDynamicQueueStrategy(emptyMap(), Duration.ofMillis(100), 3);
        InOrder queueOrder = inOrder(storageProvider);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "JOBRUNR", "Tenant-A")));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("JOBRUNR")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider, times(0)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(7)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));
    }

    private WeightedRoundRobinDynamicQueueStrategy createWeightedRoundRobinDynamicQueueStrategy() {
        return createWeightedRoundRobinDynamicQueueStrategy(emptyMap());
    }

    private WeightedRoundRobinDynamicQueueStrategy createWeightedRoundRobinDynamicQueueStrategy(Map<String, Integer> roundRobinIdWeights) {
        return createWeightedRoundRobinDynamicQueueStrategy(roundRobinIdWeights, Duration.ofSeconds(10), 1);
    }

    private WeightedRoundRobinDynamicQueueStrategy createWeightedRoundRobinDynamicQueueStrategy(Map<String, Integer> roundRobinIdWeights, Duration durationBeforeRefreshOfDynamicQueues, Integer continueCountOnNoJobs) {
        return new WeightedRoundRobinDynamicQueueStrategy(backgroundJobServer, roundRobinIdWeights, durationBeforeRefreshOfDynamicQueues, continueCountOnNoJobs, DEFAULT_REMOVAL_THRESHOLD);
    }
}