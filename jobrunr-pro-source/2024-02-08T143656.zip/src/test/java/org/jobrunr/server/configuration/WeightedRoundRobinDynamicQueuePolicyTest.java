package org.jobrunr.server.configuration;

import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.strategy.LabelPrefixDynamicQueueProvider;
import org.jobrunr.server.strategy.WeightedRoundRobinDynamicQueueStrategy;
import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.Map;

import static java.util.Collections.emptyMap;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class WeightedRoundRobinDynamicQueuePolicyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;

    @Mock
    StorageProvider storageProvider;

    @BeforeEach
    void setUp() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
    }

    @Test
    void testRoundRobinDynamicQueuePolicyWithDefaults() {
        WeightedRoundRobinDynamicQueuePolicy roundRobinDynamicQueuePolicy = new WeightedRoundRobinDynamicQueuePolicy("tenant", emptyMap());

        assertThat(roundRobinDynamicQueuePolicy.getDynamicQueueProvider()).isInstanceOf(LabelPrefixDynamicQueueProvider.class);
        assertThat(roundRobinDynamicQueuePolicy.createDynamicQueueStrategy(backgroundJobServer)).isInstanceOf(WeightedRoundRobinDynamicQueueStrategy.class);
    }

    @Test
    void testRoundRobinDynamicQueuePolicyWithCustomConfiguration() {
        WeightedRoundRobinDynamicQueuePolicy roundRobinDynamicQueuePolicy = new WeightedRoundRobinDynamicQueuePolicy("tenant", Map.of("Tenant-A", 3), Duration.ofMinutes(1), 5, 3);

        assertThat(roundRobinDynamicQueuePolicy.getDynamicQueueProvider()).isInstanceOf(LabelPrefixDynamicQueueProvider.class);
        assertThat(roundRobinDynamicQueuePolicy.createDynamicQueueStrategy(backgroundJobServer)).isInstanceOf(WeightedRoundRobinDynamicQueueStrategy.class);
    }
}