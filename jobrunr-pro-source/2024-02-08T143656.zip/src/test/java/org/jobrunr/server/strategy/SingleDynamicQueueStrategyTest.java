package org.jobrunr.server.strategy;

import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SingleDynamicQueueStrategyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    StorageProvider storageProvider;

    private SingleDynamicQueueStrategy singleDynamicQueueStrategy;

    @BeforeEach
    void setUp() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
    }

    @Test
    void testSingleDynamicQueueStrategy() {
        // GIVEN
        singleDynamicQueueStrategy = new SingleDynamicQueueStrategy(backgroundJobServer);

        // WHEN
        singleDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), isNull(), refEq(ascOnPriorityAndUpdatedAt(5)));
    }
}