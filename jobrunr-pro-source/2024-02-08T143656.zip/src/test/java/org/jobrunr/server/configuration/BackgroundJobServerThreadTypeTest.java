package org.jobrunr.server.configuration;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.server.configuration.BackgroundJobServerThreadType.PlatformThreads;
import static org.jobrunr.server.configuration.BackgroundJobServerThreadType.VirtualThreads;

class BackgroundJobServerThreadTypeTest {

    @Test
    void platformThreadsAreSupportedAsOfJava8() {
        assertThat(PlatformThreads.isSupported("1.8.0-adoptopenjdk")).isTrue();
        assertThat(PlatformThreads.isSupported("1.8.0")).isTrue();
        assertThat(PlatformThreads.isSupported("1.8.0_191")).isTrue();
        assertThat(PlatformThreads.isSupported("1.7.0_232")).isTrue();
    }

    @Test
    void virtualThreadsAreSupportedAsOfJava21() {
        assertThat(VirtualThreads.isSupported("21.0.0-adoptopenjdk")).isTrue();
        assertThat(VirtualThreads.isSupported("21.0.1")).isTrue();
        assertThat(VirtualThreads.isSupported("22.1.0.1.r17")).isTrue();
        assertThat(VirtualThreads.isSupported("23.ea.3")).isTrue();
        assertThat(VirtualThreads.isSupported("17.0.9")).isFalse();
        assertThat(VirtualThreads.isSupported("1.8.9")).isFalse();
    }

}