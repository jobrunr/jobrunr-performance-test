package org.jobrunr.server.concurrent.statechanges;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.jobs.states.InitialState;
import org.jobrunr.server.JobZooKeeper;
import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;

import static java.time.Instant.now;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.jobrunr.jobs.JobTestBuilder.aJobReplacing;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReplacedJobConcurrentStateChangeTest {

    @Mock
    private JobZooKeeper jobZooKeeper;
    @Mock
    private StorageProvider storageProvider;
    @Mock
    private Thread threadProcessingLocalJob;

    private ReplacedJobConcurrentStateChange replacedJobConcurrentStateChange;

    @BeforeEach
    void setUp() {
        replacedJobConcurrentStateChange = new ReplacedJobConcurrentStateChange(jobZooKeeper, storageProvider);
    }

    @Test
    void ifNoJobIsReplacingJobMatchesReturnsFalse() {
        Job localJob = aJobInProgress().build();
        Job storageJob = aJobInProgress().build();

        assertThat(replacedJobConcurrentStateChange.matches(localJob, storageJob)).isFalse();
    }

    @Test
    void ifLocalJobIsReplacingJobMatchesReturnsTrue() {
        Job storageJob = aJobInProgress().build();
        Job localJob = aJobReplacing(storageJob, new EnqueuedState()).build();

        assertThat(replacedJobConcurrentStateChange.matches(localJob, storageJob)).isTrue();
    }

    @Test
    void ifStorageJobIsReplacingJobMatchesReturnsTrue() {
        Job localJob = aJobInProgress().build();
        Job storageJob = aJobReplacing(localJob, new EnqueuedState()).build();

        assertThat(replacedJobConcurrentStateChange.matches(localJob, storageJob)).isTrue();
    }

    @Test
    void ifBothJobsAreReplacingJobMatchesReturnsTrue() {
        Job oldJob = aJobInProgress().build();
        Job localJob = aJobReplacing(oldJob, new EnqueuedState()).build();
        Job storageJob = aJobReplacing(localJob, new EnqueuedState()).build();

        assertThat(replacedJobConcurrentStateChange.matches(localJob, storageJob)).isTrue();
    }

    @Test
    void ifStorageJobIsReplacingJobAndLocalJobNotThenStorageJobIsKeptAndLocalJobIsDeleted() {
        // GIVEN
        Job localJob = aJobInProgress().build();
        Job storageJob = aJobReplacing(localJob, new EnqueuedState()).withProcessingState().build();
        lenient().when(jobZooKeeper.getThreadProcessingJob(storageJob)).thenReturn(null);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(threadProcessingLocalJob);

        // WHEN
        replacedJobConcurrentStateChange.resolve(localJob, storageJob);

        // THEN
        assertThat(localJob).hasState(DELETED);
        assertThat(storageJob).hasState(PROCESSING);
        verify(threadProcessingLocalJob).interrupt();
    }

    @Test
    void ifLocalJobIsReplacingJobAndStorageJobNotThenLocalJobIsKeptAndStorageJobIsDeleted() {
        // GIVEN
        Job storageJob = aJobInProgress().build();
        Job localJob = aJobReplacing(storageJob, new EnqueuedState()).withProcessingState().build();
        lenient().when(jobZooKeeper.getThreadProcessingJob(storageJob)).thenReturn(null);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(threadProcessingLocalJob);

        // WHEN
        replacedJobConcurrentStateChange.resolve(localJob, storageJob);

        // THEN
        assertThat(localJob).hasState(PROCESSING);
        verify(storageProvider).saveReplace(localJob);
        verifyNoInteractions(threadProcessingLocalJob);
    }

    @Test
    void ifStorageJobWasCreatedAsLastStorageJobIsKeptAndLocalJobIsDeleted() {
        // GIVEN
        Job initialJob = aJobInProgress().build();
        Job localJob = aJobReplacing(initialJob, setInitialStateCreatedAt(new EnqueuedState(), now().minusSeconds(5))).withProcessingState().build();
        Job storageJob = aJobReplacing(initialJob, setInitialStateCreatedAt(new EnqueuedState(), now())).withProcessingState().build();
        lenient().when(jobZooKeeper.getThreadProcessingJob(storageJob)).thenReturn(null);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(threadProcessingLocalJob);

        // WHEN
        replacedJobConcurrentStateChange.resolve(localJob, storageJob);

        // THEN
        assertThat(localJob).hasState(DELETED);
        assertThat(storageJob).hasState(PROCESSING);
        verify(threadProcessingLocalJob).interrupt();
    }

    @Test
    void ifLocalJobWasCreatedAsLastLocalJobIsKeptAndStorageJobIsDeleted() {
        // GIVEN
        Job initialJob = aJobInProgress().build();
        Job localJob = aJobReplacing(initialJob, setInitialStateCreatedAt(new EnqueuedState(), now())).withProcessingState().build();
        Job storageJob = aJobReplacing(initialJob, setInitialStateCreatedAt(new EnqueuedState(), now().minusSeconds(5))).withProcessingState().build();
        lenient().when(jobZooKeeper.getThreadProcessingJob(storageJob)).thenReturn(null);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(threadProcessingLocalJob);

        // WHEN
        replacedJobConcurrentStateChange.resolve(localJob, storageJob);

        // THEN
        assertThat(localJob).hasState(PROCESSING);
        verify(storageProvider).saveReplace(localJob);
        verifyNoInteractions(threadProcessingLocalJob);
    }

    private InitialState setInitialStateCreatedAt(InitialState initialState, Instant createdAt) {
        Whitebox.setInternalState(initialState, "createdAt", createdAt);
        return initialState;
    }

}