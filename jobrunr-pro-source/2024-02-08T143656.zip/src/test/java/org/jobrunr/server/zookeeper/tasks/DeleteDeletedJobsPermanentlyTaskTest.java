package org.jobrunr.server.zookeeper.tasks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static java.time.Instant.now;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.mockito.Mockito.verify;

class DeleteDeletedJobsPermanentlyTaskTest extends AbstractZooKeeperTaskTest {

    DeleteDeletedJobsPermanentlyTask task;

    @BeforeEach
    void setUpTask() {
        task = new DeleteDeletedJobsPermanentlyTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void testTask() {
        runTask(task);

        verify(storageProvider).deleteJobsPermanently(jobSearchRequestArgumentCaptor.capture());
        assertThat(jobSearchRequestArgumentCaptor.getValue())
                .hasState(DELETED)
                .hasDeleteAtToNear(now());
    }
}