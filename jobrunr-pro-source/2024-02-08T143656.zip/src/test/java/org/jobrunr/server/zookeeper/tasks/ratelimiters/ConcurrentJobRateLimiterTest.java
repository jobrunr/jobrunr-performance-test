package org.jobrunr.server.zookeeper.tasks.ratelimiters;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.jobs.states.SucceededState;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.AmountRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.List;
import java.util.stream.IntStream;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConcurrentJobRateLimiterTest {

    static final String CONCURRENT_JOB_RATE_LIMITER_NAME = "concurrent-rate-limiter-name";

    @Mock
    StorageProvider storageProvider;

    @Test
    void ifRebalanceDurationIsSmallerThanPollIntervalInSecondsExceptionIsThrown() {
        assertThatCode(() -> setUpConcurrentJobRateLimiter(4, 5, Duration.ofSeconds(2)))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void afterRebalancingItDoesNotRebalanceUntilTheRebalanceDurationHasPassed() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(Duration.ofSeconds(1), 0);

        // WHEN & THEN
        concurrentJobRateLimiter.getAmountOfJobsToEnqueue();
        verify(storageProvider, times(1)).countJobs(any());
        verify(storageProvider, times(1)).getJobList(any(), any());
        reset(storageProvider);

        // WHEN & THEN
        concurrentJobRateLimiter.getAmountOfJobsToEnqueue();
        verify(storageProvider, never()).countJobs(any());
        verify(storageProvider, never()).getJobList(any(), any());
    }

    @Test
    void ifNoHistoricalDataAvailableOnlyAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockNoHistoricalDataAvailable();

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue).isEqualTo(4);
    }

    @Test
    void ifNoHistoricalDataAvailableButThereAreRateLimitedJobsEnqueuedOnlyLimitedAmountOfJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(null, 2);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue).isEqualTo(2);
    }

    @Test
    void ifNoHistoricalDataAvailableButThereAreALofOfRateLimitedJobsEnqueuedNoJobsAreEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(null, 20);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue).isEqualTo(0);
    }

    @Test
    void ifHistoricalDataAvailableAndThereAreNoRateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(ofMillis(100), ofMillis(200), 0);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(67); // (200ms per job + 100ms overhead) * 5 (pollIntervalInSeconds) * 4 (amountOfConcurrentJobs)
    }

    @Test
    void ifHistoricalDataAvailableAndThereAreRateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5, ofSeconds(20));
        mockHistoricalDataAvailable(ofMillis(100), ofMillis(200), 80);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(47); // due to rebalance factor, in the next 20sec instead of 80 each time only 47 jobs will be enqueued
    }

    @Test
    void ifHistoricalDataAvailableButAHighLatencyAndThereAreNoRateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(ofSeconds(10), ofMillis(200), 0);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(50); // (200ms per job + 200ms overhead (capped) ) * 5 (pollIntervalInSeconds) * 4 (amountOfConcurrentJobs)
    }

    @Test
    void ifHistoricalDataAvailableAndThereAreALotOfRateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5, ofSeconds(20));
        mockHistoricalDataAvailable(ofMillis(200), 320);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(0); // due to rebalance factor, in the next 20sec no jobs will be enqueued as there are already too many jobs enqueued
    }

    @Test
    void ifHistoricalDataAvailableJobsAreSlowAndThereAreNoRateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5, ofSeconds(20));
        mockHistoricalDataAvailable(ofMillis(25000), 0);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(1); // why: each pollIntervalInSeconds it will do 1 = 4 during the whole rebalance duration
    }

    @Test
    void ifHistoricalDataAvailableJobsAreSlowAndThereAre2RateLimitedJobsEnqueuedPerfectAmountOfConcurrentJobsIsEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5, ofSeconds(20));
        mockHistoricalDataAvailable(ofMillis(25000), 2);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(1); // why: each pollIntervalInSeconds it will do 1 = 4 during the whole rebalance duration
    }

    @Test
    void ifHistoricalDataAvailableJobsAreSlowAndThereAre4RateLimitedJobsEnqueuedNoJobsAreEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5, ofSeconds(20));
        mockHistoricalDataAvailable(ofMillis(25000), 4);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(0); // why: there are enough jobs enqueued for the whole rebalance duration
    }

    @Test
    void ifHistoricalDataAvailableJobsAreSlowAndThereAreAlreadyAtLeastAmountOfConcurrentJobsEnqueuedNoJobsAreEnqueued() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(4, 5);
        mockHistoricalDataAvailable(ofSeconds(71000), 4);

        // WHEN
        int amountOfJobsToEnqueue = concurrentJobRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(0); // why: there are enough jobs enqueued for the whole rebalance duration
    }


    @Test
    void updateJobToNewStateAddsMutexAndEnqueuesJob() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(2, 5);
        Job awaitingJob = aJob().withAwaitingRateLimiterState(CONCURRENT_JOB_RATE_LIMITER_NAME).build();

        // WHEN
        concurrentJobRateLimiter.updateJobToNewState(awaitingJob);

        // THEN
        assertThat(awaitingJob)
                .hasState(StateName.ENQUEUED)
                .hasMutex(CONCURRENT_JOB_RATE_LIMITER_NAME + "||1");
    }

    @Test
    void updateJobToNewStateSetsCorrectMutexForEachJob() {
        // GIVEN
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(2, 5);
        Job awaitingJob1 = aJob().withAwaitingRateLimiterState(CONCURRENT_JOB_RATE_LIMITER_NAME).build();
        Job awaitingJob2 = aJob().withAwaitingRateLimiterState(CONCURRENT_JOB_RATE_LIMITER_NAME).build();
        Job awaitingJob3 = aJob().withAwaitingRateLimiterState(CONCURRENT_JOB_RATE_LIMITER_NAME).build();

        // WHEN
        concurrentJobRateLimiter.updateJobToNewState(awaitingJob1);
        concurrentJobRateLimiter.updateJobToNewState(awaitingJob2);
        concurrentJobRateLimiter.updateJobToNewState(awaitingJob3);

        // THEN
        assertThat(awaitingJob1)
                .hasState(StateName.ENQUEUED)
                .hasMutex(CONCURRENT_JOB_RATE_LIMITER_NAME + "||1");
        assertThat(awaitingJob2)
                .hasState(StateName.ENQUEUED)
                .hasMutex(CONCURRENT_JOB_RATE_LIMITER_NAME + "||2");
        assertThat(awaitingJob3)
                .hasState(StateName.ENQUEUED)
                .hasMutex(CONCURRENT_JOB_RATE_LIMITER_NAME + "||1");
    }

    @Test
    void averageJobDurationForConcurrentJobRateLimiterUsesMinimumLatency() {
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(2, 5);

        AmountRequest amountRequest = Paging.AmountBasedList.descOnUpdatedAt(10);
        when(storageProvider.getJobList(any(), refEq(amountRequest))).thenReturn(asList(
                createAwaitingJob(Duration.ofMillis(10), Duration.ofMillis(100)),
                createAwaitingJob(Duration.ofMillis(50), Duration.ofMillis(100))));

        Duration averageJobDurationForConcurrentJobRateLimiter = concurrentJobRateLimiter.getAverageJobDurationForConcurrentJobRateLimiter();
        assertThat(averageJobDurationForConcurrentJobRateLimiter).isEqualTo(Duration.ofMillis(110));
    }

    @Test
    void averageJobDurationForConcurrentJobRateLimiterUsesCappedLatency() {
        ConcurrentJobRateLimiter concurrentJobRateLimiter = setUpConcurrentJobRateLimiter(2, 5);

        AmountRequest amountRequest = Paging.AmountBasedList.descOnUpdatedAt(10);
        when(storageProvider.getJobList(any(), refEq(amountRequest))).thenReturn(asList(
                createAwaitingJob(Duration.ofSeconds(1), Duration.ofMillis(100)),
                createAwaitingJob(Duration.ofSeconds(5), Duration.ofMillis(100))));

        Duration averageJobDurationForConcurrentJobRateLimiter = concurrentJobRateLimiter.getAverageJobDurationForConcurrentJobRateLimiter();
        assertThat(averageJobDurationForConcurrentJobRateLimiter).isEqualTo(Duration.ofMillis(300));
    }

    void mockNoHistoricalDataAvailable() {
        mockHistoricalDataAvailable(null, 0);
    }

    void mockHistoricalDataAvailable(Duration averageDuration, int amountOfEnqueuedJobs) {
        mockHistoricalDataAvailable(ofMillis(200), averageDuration, amountOfEnqueuedJobs);
    }

    void mockHistoricalDataAvailable(Duration averageLatencyDuration, Duration averageProcessDuration, long amountOfEnqueuedJobs) {
        AmountRequest amountRequest = Paging.AmountBasedList.descOnUpdatedAt(10);
        when(storageProvider.getJobList(any(), refEq(amountRequest)))
                .thenReturn(getJobsWithAverageJobDuration(averageLatencyDuration, averageProcessDuration));

        when(storageProvider.countJobs(any())).thenReturn(amountOfEnqueuedJobs);
    }

    List<Job> getJobsWithAverageJobDuration(Duration averageLatencyDuration, Duration averageProcessDuration) {
        if (averageProcessDuration == null) return emptyList();

        return IntStream.range(0, 10).boxed().map(i -> createAwaitingJob(averageLatencyDuration, averageProcessDuration)).collect(toList());
    }

    private static Job createAwaitingJob(Duration latencyDuration, Duration processDuration) {
        return aJob()
                .withAwaitingRateLimiterState(CONCURRENT_JOB_RATE_LIMITER_NAME)
                .withEnqueuedState()
                .withProcessingState()
                .withState(new SucceededState(latencyDuration, processDuration))
                .build();
    }

    private ConcurrentJobRateLimiter setUpConcurrentJobRateLimiter(int amountOfConcurrentJobs, int pollIntervalInSeconds) {
        return setUpConcurrentJobRateLimiter(amountOfConcurrentJobs, pollIntervalInSeconds, Duration.ofMinutes(1));
    }

    private ConcurrentJobRateLimiter setUpConcurrentJobRateLimiter(int amountOfConcurrentJobs, int pollIntervalInSeconds, Duration rebalanceInterval) {
        BackgroundJobServer backgroundJobServer = mock(BackgroundJobServer.class);
        lenient().when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration().andPollIntervalInSeconds(pollIntervalInSeconds));
        return new ConcurrentJobRateLimiter(backgroundJobServer, CONCURRENT_JOB_RATE_LIMITER_NAME, amountOfConcurrentJobs, rebalanceInterval);
    }
}