package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import static java.time.Instant.now;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.*;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.*;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

class InterruptJobsThatHaveTimedOutTaskTest extends AbstractZooKeeperTaskTest {

    private InterruptJobsThatHaveTimedOutTask task;

    @BeforeEach
    void setUpTask() {
        task = new InterruptJobsThatHaveTimedOutTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void taskDoesNothingIfNoTimeoutDuration() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        Thread thread = startProcessingJob(job, now().minusSeconds(3600));

        // WHEN
        runTask(task);

        // THEN
        assertThat(job).hasState(PROCESSING);
        verifyNoInteractions(thread);
    }

    @Test
    void taskDoesNothingIfTimeoutHasNotBeenReached() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().withProcessTimeOut(Duration.ofMinutes(60)).build();
        Thread thread = startProcessingJob(job, now().minusSeconds(3550));

        // WHEN
        runTask(task);

        // THEN
        assertThat(job).hasState(PROCESSING);
        verifyNoInteractions(thread);
    }

    @Test
    void taskDoesNothingIfJobHasSucceededInTheMeanTime() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().withProcessTimeOut(Duration.ofMinutes(60)).build();
        Thread thread = startProcessingJob(job, now().minusSeconds(3600));
        job.succeeded();

        // WHEN
        runTask(task);

        // THEN
        assertThat(job).hasState(SUCCEEDED);
        verifyNoInteractions(thread);
    }

    @Test
    void taskInterruptsJobIfJobHasTimedOut() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().withProcessTimeOut(Duration.ofMinutes(60)).build();
        Thread thread = startProcessingJob(job, now().minusSeconds(3610));

        // WHEN
        runTask(task);

        // THEN
        assertThat(job).hasStates(ENQUEUED, PROCESSING, FAILED, SCHEDULED);
        verify(thread).interrupt();
    }

    Thread startProcessingJob(Job job, Instant processingStartedOn) {
        final Thread threadMock = mock(Thread.class);
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration()
                .andId(UUID.randomUUID())
                .andName("my-host-name"));

        job.startProcessingOn(backgroundJobServer);
        setInternalState(job.getJobState(), "createdAt", processingStartedOn);

        lenient().when(jobZooKeeper.getJobsInProgress()).thenReturn(Set.of(job));
        lenient().when(jobZooKeeper.getThreadProcessingJob(job)).thenReturn(threadMock);
        return threadMock;
    }
}