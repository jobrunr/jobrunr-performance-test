package org.jobrunr.server.zookeeper.tasks.ratelimiters;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;

class ConcurrentJobRateLimiterConfigurationTest {

    @Test
    void testValidConfiguration() {
        assertThatCode(() -> concurrentJobRateLimiter("my-rate-limiter", 1))
                .doesNotThrowAnyException();
    }

    @Test
    void testInvalidConfiguration() {
        assertThatCode(() -> concurrentJobRateLimiter("my-rate-limiter", -1))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The number of concurrent jobs for Rate Limiter 'my-rate-limiter' should be positive.");

        String rateLimiterNameThatIsTooLong = "a".repeat(65);
        assertThatCode(() -> concurrentJobRateLimiter(rateLimiterNameThatIsTooLong, 2))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The Rate Limiter name '" + rateLimiterNameThatIsTooLong + "' should not exceed 64 characters");
    }

}