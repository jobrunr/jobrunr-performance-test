package org.jobrunr.server.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.StorageProvider.StorageProviderInfo;
import org.jobrunr.storage.navigation.OffsetBasedPageRequest;
import org.jobrunr.storage.sql.postgres.PostgresStorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.storage.navigation.OffsetBasedPageRequest.emptyPage;
import static org.mockito.InstantMocker.FIXED_INSTANT_ONE_MINUTE_AFTER_THE_HOUR;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MigrateFromV5toV6TaskTest {

    @Mock
    StorageProvider storageProvider;

    @Mock
    BackgroundJobServer backgroundJobServer;

    @Mock
    StorageProviderInfo storageProviderInfo;

    @Captor
    ArgumentCaptor<List<RecurringJob>> recurringJobsCaptor;


    MigrateFromV5toV6Task task;

    @BeforeEach
    void setUpTask() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(storageProvider.getStorageProviderInfo()).thenReturn(storageProviderInfo);
        lenient().when(storageProvider.getRecurringJobs(any(), any(OffsetBasedPageRequest.class))).thenReturn(emptyPage);

        task = new MigrateFromV5toV6Task(backgroundJobServer);
    }

    @Test
    void doesNoMigrationsOfScheduledJobsIfStorageProviderIsNotAnSqlStorageProvider() {
        doReturn(InMemoryStorageProvider.class).when(storageProviderInfo).getImplementationClass();

        task.run();

        verify(storageProvider, never()).getJobs(any(), any());
    }

    @Test
    void doesMigrationsOfScheduledJobsIfStorageProviderIsAnSqlStorageProvider() {
        doReturn(PostgresStorageProvider.class).when(storageProviderInfo).getImplementationClass();
        when(storageProvider.getJobs(any(), any())).thenReturn(emptyPage);

        task.run();

        verify(storageProvider).getJobs(any(), any());
    }

    @Test
    void doesMigrationsOfAllScheduledJobsIfStorageProviderIsAnSqlStorageProvider() {
        doReturn(PostgresStorageProvider.class).when(storageProviderInfo).getImplementationClass();
        when(storageProvider.getJobs(any(JobSearchRequest.class), any()))
                .thenAnswer(i -> aLotOfScheduledJobs(i.getArgument(1, OffsetBasedPageRequest.class), 5500));

        task.run();

        verify(storageProvider, times(2)).getJobs(any(), any());
        verify(storageProvider, times(6)).save(anyList());
    }

    @Test
    void doesMigrationsOfRecurringJobsIfStorageProviderIsAnSqlStorageProvider() {
        doReturn(PostgresStorageProvider.class).when(storageProviderInfo).getImplementationClass();

        task.run();

        verify(storageProvider).getRecurringJobs(any(RecurringJobSearchRequest.class), any());
    }

    @Test
    void doesMigrationsOfRecurringJobsAndSetsLastRunAtIfStorageProviderIsAnSqlStorageProvider() {
        doReturn(PostgresStorageProvider.class).when(storageProviderInfo).getImplementationClass();
        when(storageProvider.getRecurringJobs(any(), any(OffsetBasedPageRequest.class)))
                .thenAnswer(i -> {
                    OffsetBasedPageRequest request = i.getArgument(1, OffsetBasedPageRequest.class);
                    return request.mapToNewPage(5, asList(
                            aDefaultRecurringJob().withCronExpression("*/15 * * * * *").withCreatedAt(Instant.parse("2022-03-21T15:44:48.987Z")).build(),
                            aDefaultRecurringJob().withCronExpression("*/1 * * * *").withCreatedAt(Instant.parse("2022-03-21T15:44:48.987Z")).build(),
                            aDefaultRecurringJob().withCronExpression("*/2 * * * *").withCreatedAt(Instant.parse("2022-02-21T15:44:48.987Z")).build(),
                            aDefaultRecurringJob().withCronExpression("0 0 1 * *").withZoneId(ZoneOffset.UTC).withCreatedAt(Instant.parse("2022-02-21T15:44:48.987Z")).build(),
                            aDefaultRecurringJob().withCronExpression("0 0 1 1 *").withZoneId(ZoneOffset.UTC).withCreatedAt(Instant.parse("2022-02-21T15:44:48.987Z")).build()));
                });

        try (MockedStatic<Instant> instantMock = mockTime(FIXED_INSTANT_ONE_MINUTE_AFTER_THE_HOUR)) {
            task.run();

            verify(storageProvider).getRecurringJobs(any(RecurringJobSearchRequest.class), any());
            verify(storageProvider, times(1)).saveRecurringJobs(recurringJobsCaptor.capture());
            assertThat(recurringJobsCaptor.getValue()).hasSize(5);
            assertThat(recurringJobsCaptor.getValue().get(0))
                    .hasVersion(1)
                    .hasLastRun(Instant.parse("2022-12-13T14:00:45Z"));
            assertThat(recurringJobsCaptor.getValue().get(1))
                    .hasVersion(1)
                    .hasLastRun(Instant.parse("2022-12-13T14:00:00Z"));
            assertThat(recurringJobsCaptor.getValue().get(2))
                    .hasVersion(1)
                    .hasLastRun(Instant.parse("2022-12-13T14:00:00Z"));
            assertThat(recurringJobsCaptor.getValue().get(3))
                    .hasVersion(1)
                    .hasLastRun(Instant.parse("2022-12-01T00:00:00Z"));
            assertThat(recurringJobsCaptor.getValue().get(4))
                    .hasVersion(1)
                    .hasLastRun(Instant.parse("2022-01-01T00:00:00Z"));
        }
    }

    private Page<Job> aLotOfScheduledJobs(OffsetBasedPageRequest pageRequest, int totalAmountOfScheduledJobs) {
        ArrayList<Job> jobs = new ArrayList<>();
        for (int i = (int) pageRequest.getOffset(); i < (pageRequest.getOffset() == 0 ? pageRequest.getLimit() : totalAmountOfScheduledJobs); i++) {
            jobs.add(aScheduledJob().build());
        }
        return pageRequest.mapToNewPage(totalAmountOfScheduledJobs, jobs);
    }

}