package org.jobrunr.server.metrics;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanBuilder;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.ContextPropagators;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.testing.exporter.InMemorySpanExporter;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.queues.Queues;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.mappers.MDCMapper.OTEL_SPAN_ID_KEY;
import static org.jobrunr.jobs.mappers.MDCMapper.OTEL_TRACE_ID_KEY;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;

class OpenTelemetryJobObservabilityTest {

    Tracer tracer;

    OpenTelemetryJobObservability openTelemetryJobObservability;
    private InMemorySpanExporter spanExporter;

    @BeforeEach
    void setupOpenTelemetryJobObservability() {
        MDC.clear();
        GlobalOpenTelemetry.resetForTest();

        spanExporter = InMemorySpanExporter.create();
        SdkTracerProvider sdkTracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();

        OpenTelemetry openTelemetry = OpenTelemetrySdk.builder()
                .setTracerProvider(sdkTracerProvider)
                .setPropagators(ContextPropagators.create(W3CTraceContextPropagator.getInstance()))
                .buildAndRegisterGlobal();
        tracer = GlobalOpenTelemetry.getTracer("jobrunr");

        openTelemetryJobObservability = new OpenTelemetryJobObservability(tracer, new Queues());
    }

    @Test
    void testOpenTelemetryJobObservabilityPublishesEventWhenJobIsCreated() throws InterruptedException {
        // GIVEN
        Job job = anEnqueuedJob().build();

        // WHEN
        MDC.put(OTEL_TRACE_ID_KEY, "abc");
        MDC.put(OTEL_SPAN_ID_KEY, "def");
        SpanBuilder spanBuilder = tracer.spanBuilder("jobrunr.job").setSpanKind(SpanKind.INTERNAL);
        Span span = spanBuilder.startSpan();
        try (Scope scope = span.makeCurrent()) {
            openTelemetryJobObservability.onCreated(job);
        }
        span.end();

        // THEN
        assertThat(spanExporter.getFinishedSpanItems()).hasSize(1);
        SpanData spanData = spanExporter.getFinishedSpanItems().get(0);
        assertThat(spanData)
                .hasEvent("jobrunr.job.created");
    }

    @Test
    void testOpenTelemetryJobObservabilityStoresTraceIdAndSpanId() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();

        // WHEN
        MDC.put(OTEL_TRACE_ID_KEY, "abc");
        MDC.put(OTEL_SPAN_ID_KEY, "def");
        openTelemetryJobObservability.onProcessing(job);
        openTelemetryJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(job)
                .hasMetadata(OTEL_TRACE_ID_KEY, "abc")
                .hasMetadata(OTEL_SPAN_ID_KEY, "def");
    }

    @Test
    void testOpenTelemetryJobObservabilityDoesNotThrowErrorIfMDCDoesNotContainTraceIdOrSpanId() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();

        // WHEN
        openTelemetryJobObservability.onProcessing(job);
        openTelemetryJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(job)
                .hasNoMetadata();
    }

    @Test
    void testSpanAttributes() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();

        // WHEN
        openTelemetryJobObservability.onProcessing(job);
        Thread.sleep(140);
        openTelemetryJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(spanExporter.getFinishedSpanItems()).hasSize(1);
        SpanData spanData = spanExporter.getFinishedSpanItems().get(0);
        assertThat(spanData)
                .hasAttribute("job.id", job.getId().toString())
                .hasAttribute("job.name", "an enqueued job")
                .hasAttribute("job.signature", "java.lang.System.out.println(java.lang.String)")
                .hasAttribute("job.state", SUCCEEDED.name())
                .hasAttribute("job.background-job-server.name", "test-server-name")
                .hasAttribute("job.server-tag", "server A")
                .hasAttribute("job.dynamic-queue", "my dynamic queue")
                .hasAttribute("job.latency");
    }

    @Test
    void testSpanAttributesForScheduledJob() throws InterruptedException {
        // GIVEN
        Job job = aScheduledJob()
                .withRecurringJobId("a recurring job")
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .withEnqueuedState()
                .withProcessingState()
                .build();

        // WHEN
        openTelemetryJobObservability.onProcessing(job);
        Thread.sleep(140);
        openTelemetryJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(spanExporter.getFinishedSpanItems()).hasSize(1);
        SpanData spanData = spanExporter.getFinishedSpanItems().get(0);
        assertThat(spanData)
                .hasAttribute("job.id", job.getId().toString())
                .hasAttribute("job.name", "a scheduled job")
                .hasAttribute("job.signature", "java.lang.System.out.println(java.lang.String)")
                .hasAttribute("job.state", SUCCEEDED.name())
                .hasAttribute("job.background-job-server.name", "test-server-name")
                .hasAttribute("job.server-tag", "server A")
                .hasAttribute("job.dynamic-queue", "my dynamic queue")
                .hasAttribute("job.latency")
                .hasAttribute("job.scheduled-at")
                .hasAttribute("job.scheduled-reason", "scheduled by recurring job");
    }

    @Test
    void testSpanAttributesForFailedJob() throws InterruptedException {
        // GIVEN
        Job job = aFailedJob()
                .withScheduledState()
                .withEnqueuedState()
                .withProcessingState()
                .build();

        // WHEN
        openTelemetryJobObservability.onProcessing(job);
        Thread.sleep(140);
        openTelemetryJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(spanExporter.getFinishedSpanItems()).hasSize(1);
        SpanData spanData = spanExporter.getFinishedSpanItems().get(0);
        assertThat(spanData)
                .hasAttribute("job.id", job.getId().toString())
                .hasAttribute("job.name", "a failed job")
                .hasAttribute("job.signature", "java.lang.System.out.println(java.lang.String)")
                .hasAttribute("job.state", SUCCEEDED.name())
                .hasAttribute("job.background-job-server.name", "test-server-name")
                .hasAttribute("job.server-tag", "DEFAULT")
                .hasAttribute("job.latency")
                .hasAttribute("job.scheduled-at")
                .hasAttribute("job.scheduled-reason", "retrying failed job");
    }
}