package org.jobrunr.server.strategy;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.utils.SleepUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListMap;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.server.configuration.RoundRobinDynamicQueuePolicy.DEFAULT_REMOVAL_THRESHOLD;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.utils.CollectionUtils.asSet;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FixedSizeWorkerPoolDynamicQueueStrategyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    StorageProvider storageProvider;

    private FixedSizeWorkerPoolDynamicQueueStrategy fixedSizeWorkerPoolDynamicQueueStrategy;

    @BeforeEach
    void setUp() {
        lenient().when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        lenient().when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(new BasicWorkDistributionStrategy(backgroundJobServer, 10));
        lenient().when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID()));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithoutDynamicQueues() {
        // GIVEN
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy();

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getDistinctDynamicQueues(ENQUEUED);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), isNull(), refEq(ascOnPriorityAndUpdatedAt(5)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeCanNotBeGreaterThanBackgroundJobServerWorkerCount() {
        when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(new BasicWorkDistributionStrategy(backgroundJobServer, 10));

        assertThatCode(() -> createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 5, "Tenant-B", 10)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The sum of the workers in all worker pools for the FixedSizeWorkerPoolDynamicQueue cannot exceed the workerCount of your BackgroundJobServer (which is 10).");
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeWithFixedWorkerPoolSizesAndContinueCount4OOnlyRequestsJobsEqualToWorkerPoolSizeButNoResults() {
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(asSet("Tenant-A", "Tenant-B", "Tenant-C", null));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 5, "Tenant-B", 3), 4);

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        InOrder inOrder = Mockito.inOrder(storageProvider);
        inOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        inOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        inOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(3)));
        inOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(2)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeWithFixedSizeWorkerPoolAndContinueCount2OOnlyRequestsJobsEqualToWorkerPoolSizeButNoResults() {
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(asSet("Tenant-A", "Tenant-B", "Tenant-C", null));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 5, "Tenant-B", 3), 2);

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(3)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(2)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeWithFixedSizeWorkerPoolAndContinueCount2OOnlyRequestsJobsEqualToWorkerPoolSize() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(asSet("Tenant-A", "Tenant-B", null));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 8), 3);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(asList(anEnqueuedJob().build(), anEnqueuedJob().build()));
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8))))
                .thenReturn(emptyList());

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN JOBS FROM NULL QUEUE ARE RETURNED
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));

        // WHEN
        clearInvocations(storageProvider);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN ONLY JOBS FROM TENANT-A ARE REQUESTED
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class));

        // WHEN
        clearInvocations(storageProvider);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN ONLY JOBS FROM TENANT-A ARE REQUESTED
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeWithFixedSizeWorkerPoolOnlyRequestsJobsEqualToWorkerPoolSize() {
        // GIVEN
        Job tenantBJob1 = anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build();
        Job tenantBJob2 = anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build();
        Job tenantBJob3 = anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build();
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(asSet("Tenant-A", "Tenant-B", null));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 6, "Tenant-B", 2), 3);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6))))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(asList(tenantBJob1, tenantBJob2));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN JOBS FROM TENANT-B ARE REQUESTED DUE TO LOOP BOUND
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));

        // WHEN
        clearInvocations(storageProvider);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class));

        // WHEN
        clearInvocations(storageProvider);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(1))))
                .thenReturn(asList(tenantBJob3));
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingSucceeded(tenantBJob1);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(1)));
        verifyNoMoreInteractions(storageProvider);

        // WHEN
        clearInvocations(storageProvider);
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingSucceeded(tenantBJob2);
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingFailed(tenantBJob3, new Exception());
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueSizeAlsoWorksWithJobsThatDoNotHaveDynamicQueues() {
        // GIVEN
        Job noTenantJob1 = anEnqueuedJob().withDynamicQueue(null).build();
        Job noTenantJob2 = anEnqueuedJob().withDynamicQueue(null).build();
        Job noTenantJob3 = anEnqueuedJob().withDynamicQueue(null).build();
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(asSet("Tenant-A", "Tenant-B", "Tenant-C", null));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 6, "Tenant-B", 2), 4);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(asList(noTenantJob1, noTenantJob2));
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6))))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(emptyList());

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN JOBS WITHOUT ANY TENANT ARE RETURNED
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN JOBS WITHOUT ANY TENANT ARE RETURNED
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), any(AmountRequest.class));

        // WHEN
        clearInvocations(storageProvider);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(1))))
                .thenReturn(asList(noTenantJob3));
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingSucceeded(noTenantJob1);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(1)));

        // WHEN
        clearInvocations(storageProvider);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), any(AmountRequest.class));

        // WHEN
        clearInvocations(storageProvider);
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2))))
                .thenReturn(emptyList());
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingSucceeded(noTenantJob2);
        fixedSizeWorkerPoolDynamicQueueStrategy.onProcessingFailed(noTenantJob3, new Exception());
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(2)));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueues() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy();

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesIfThereAreResults() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy();

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesAndTakesIntoAccountWorkerPoolSizeIfThereAreResults() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-A", 5));

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobs() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(5), 3);

        // WHEN (no mocking thus returns empty lists)
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists)
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobsButStopsIfItIsAgainAtTheBeginning() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(emptyMap(), Duration.ofSeconds(5), 5);

        // WHEN (no mocking thus returns empty lists)
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithChangingDynamicQueuesToEnsureNoQueueIsUsedConsecutivelyWhenAnotherIsAvailable() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(emptyMap(), Duration.ofMillis(100), 5);
        InOrder queueOrder = inOrder(storageProvider);

        // WHEN (no mocking thus returns empty lists)
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue(null).build(),
                        anEnqueuedJob().withDynamicQueue(null).build())
                );

        // WHEN
        SleepUtils.sleep(100);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "JOBRUNR")));

        // WHEN
        SleepUtils.sleep(100);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("JOBRUNR")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));
    }

    @Test
    void testFixedSizeWorkerPoolDynamicQueueStrategyWithDynamicQueuesRemovesQueuesThatAreNotAvailableAnymore() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED))
                .thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")),
                        new HashSet<>(asList("Tenant-A", "Tenant-B")));
        fixedSizeWorkerPoolDynamicQueueStrategy = createFixedSizeWorkerPoolDynamicQueueStrategy(Map.of("Tenant-C", 6), Duration.ofMillis(100), 3, 2);

        // WHEN (no mocking thus returns empty lists)
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists)
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(4)));

        // WHEN (no mocking thus returns empty lists)
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        fixedSizeWorkerPoolDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(6)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(4)));
        verifyNoMoreInteractions(storageProvider);
    }

    private FixedSizeWorkerPoolDynamicQueueStrategy createFixedSizeWorkerPoolDynamicQueueStrategy() {
        return createFixedSizeWorkerPoolDynamicQueueStrategy(emptyMap());
    }

    private FixedSizeWorkerPoolDynamicQueueStrategy createFixedSizeWorkerPoolDynamicQueueStrategy(Map<String, Integer> dynamicQueueWorkerWithPoolSize) {
        return createFixedSizeWorkerPoolDynamicQueueStrategy(dynamicQueueWorkerWithPoolSize, Duration.ofSeconds(10), 1);
    }

    private FixedSizeWorkerPoolDynamicQueueStrategy createFixedSizeWorkerPoolDynamicQueueStrategy(Map<String, Integer> dynamicQueueWorkerWithPoolSize, Integer continueCountOnNoJobs) {
        return createFixedSizeWorkerPoolDynamicQueueStrategy(dynamicQueueWorkerWithPoolSize, Duration.ofSeconds(10), continueCountOnNoJobs);
    }

    private FixedSizeWorkerPoolDynamicQueueStrategy createFixedSizeWorkerPoolDynamicQueueStrategy(Map<String, Integer> dynamicQueueWorkerWithPoolSize, Duration durationBeforeRefreshOfDynamicQueues, int continueCountOnNoJobs) {
        return createFixedSizeWorkerPoolDynamicQueueStrategy(dynamicQueueWorkerWithPoolSize, durationBeforeRefreshOfDynamicQueues, continueCountOnNoJobs, DEFAULT_REMOVAL_THRESHOLD);
    }

    private FixedSizeWorkerPoolDynamicQueueStrategy createFixedSizeWorkerPoolDynamicQueueStrategy(Map<String, Integer> dynamicQueueWorkerWithPoolSize, Duration durationBeforeRefreshOfDynamicQueues, int continueCountOnNoJobs, int removalThreshold) {
        return new FixedSizeWorkerPoolDynamicQueueStrategy(backgroundJobServer, new ConcurrentSkipListMap<>(dynamicQueueWorkerWithPoolSize), durationBeforeRefreshOfDynamicQueues, continueCountOnNoJobs, removalThreshold);
    }
}