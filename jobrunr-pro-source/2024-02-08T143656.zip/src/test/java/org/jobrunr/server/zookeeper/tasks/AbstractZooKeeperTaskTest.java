package org.jobrunr.server.zookeeper.tasks;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.BackgroundJobServerConfiguration;
import org.jobrunr.server.JobZooKeeper;
import org.jobrunr.server.LogAllStateChangesFilter;
import org.jobrunr.server.strategy.BasicWorkDistributionStrategy;
import org.jobrunr.server.zookeeper.ZooKeeperStatistics;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.jobrunr.jobs.migrations.JobNotFoundConfiguration.usingStandardJobNotFoundConfiguration;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
public abstract class AbstractZooKeeperTaskTest {

    public static final int POLL_INTERVAL_IN_SECONDS = 5;
    @Mock
    JobZooKeeper jobZooKeeper;
    @Mock
    StorageProvider storageProvider;
    @Captor
    ArgumentCaptor<List<Job>> jobsToSaveArgumentCaptor;
    @Captor
    ArgumentCaptor<JobSearchRequest> jobSearchRequestArgumentCaptor;
    BackgroundJobServer backgroundJobServer;

    LogAllStateChangesFilter logAllStateChangesFilter;
    ZooKeeperStatistics zooKeeperStatistics;
    ListAppender<ILoggingEvent> logger;

    @BeforeEach
    void setUpTaskDependencies() {
        setUpTaskDependencies(storageProvider);
    }

    void setUpTaskDependencies(StorageProvider storageProvider) {
        logAllStateChangesFilter = new LogAllStateChangesFilter();
        backgroundJobServer = Mockito.spy(new BackgroundJobServer(storageProvider, null, new JacksonJsonMapper(), null, usingStandardBackgroundJobServerConfiguration().andPollIntervalInSeconds(POLL_INTERVAL_IN_SECONDS), usingStandardJobNotFoundConfiguration()));
        backgroundJobServer.setJobFilters(List.of(logAllStateChangesFilter));
        lenient().when(backgroundJobServer.getJobZooKeeper()).thenReturn(jobZooKeeper);
        lenient().when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(new BasicWorkDistributionStrategy(backgroundJobServer, 2));
        backgroundJobServer.start();

        zooKeeperStatistics = new ZooKeeperStatistics(null);
    }

    void runTask(ZooKeeperTask task) {
        runTask(task, usingStandardBackgroundJobServerConfiguration().andPollIntervalInSeconds(POLL_INTERVAL_IN_SECONDS));
    }

    void runTask(ZooKeeperTask task, BackgroundJobServerConfiguration configuration) {
        logger = LoggerAssert.initFor(jobZooKeeper);
        task.run(zooKeeperStatistics.startRun(configuration));
    }

}
