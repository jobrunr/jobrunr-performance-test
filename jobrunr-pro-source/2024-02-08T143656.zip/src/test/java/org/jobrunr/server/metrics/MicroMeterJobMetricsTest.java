package org.jobrunr.server.metrics;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.internal.DefaultGauge;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.queues.Queues;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.*;

class MicroMeterJobMetricsTest {

    SimpleMeterRegistry simpleMeterRegistry = new SimpleMeterRegistry();
    MicroMeterJobMetrics microMeterJobMetrics = new MicroMeterJobMetrics(simpleMeterRegistry, new Queues());

    @Test
    void testMeterTags() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name");
        });
    }

    @Test
    void testMeterTagsWithLabels() throws InterruptedException {
        // GIVEN
        MicroMeterJobMetrics microMeterJobMetrics = new MicroMeterJobMetrics(simpleMeterRegistry, new Queues(), Set.of("tenant"));
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .withLabels("tenant:customerA", "type:communication", "email")
                .build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name")
                    .hasIdWithTag("job.labels.tenant", "customerA");
        });
    }

    @Test
    void testMeterTagsWithMultipleLabels() throws InterruptedException {
        // GIVEN
        MicroMeterJobMetrics microMeterJobMetrics = new MicroMeterJobMetrics(simpleMeterRegistry, new Queues(), Set.of("tenant", "app"));
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .withLabels("tenant:customerA", "app:invoicing", "type:communication")
                .build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name")
                    .hasIdWithTag("job.labels.tenant", "customerA")
                    .hasIdWithTag("job.labels.app", "invoicing");
        });
    }

    @Test
    void testCustomPercentiles() throws InterruptedException {
        // GIVEN
        MicroMeterJobMetrics microMeterJobMetrics = new MicroMeterJobMetrics(simpleMeterRegistry, new Queues(), null, true, 0.25, 0.50, 0.75, 0.95);
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(10);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name");
        });
    }

    @Test
    void testJobSucceeds() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        assertThat(MicroMeterJobMetricsThreadLocal.getLongTaskTimerSample()).isNull();
    }

    @Test
    void testJobFails() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingFailed(job, new Exception());

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(3);
        assertThat(MicroMeterJobMetricsThreadLocal.getLongTaskTimerSample()).isNull();
    }

    @Test
    void testJobInProgressFailsFirstTimeDoesIncreaseCounter() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(140);
        microMeterJobMetrics.onProcessingFailed(job, new Exception());

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        DefaultGauge gauge = getMeter(meters, "jobrunr.jobs.failures");
        assertThat(gauge.value()).isEqualTo(1.0);
    }

    @Test
    void testJobInProgressAlreadyFailedDoesNotIncreaseCounter() throws InterruptedException {
        // GIVEN
        Job job = aFailedJob().withProcessingState().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(60);
        microMeterJobMetrics.onProcessingFailed(job, new Exception());

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        doesNotContainMeter(meters, "jobrunr.jobs.failures");
    }

    @Test
    void testJobFailedAndThenSucceedsResetsCounter() throws InterruptedException {
        // GIVEN first run
        Job job = aJobInProgress().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(60);
        microMeterJobMetrics.onProcessingFailed(job, new Exception());

        // GIVEN second run
        Job retryingJob = aCopyOf(job).withFailedState().withEnqueuedState().withProcessingState().build();
        microMeterJobMetrics.onProcessing(retryingJob);
        Thread.sleep(70);
        microMeterJobMetrics.onProcessingSucceeded(retryingJob);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        DefaultGauge gauge = getMeter(meters, "jobrunr.jobs.failures");
        assertThat(gauge.value()).isEqualTo(0.0);
    }

    @Test
    void testJobFailsMultipleTimesAndThenSucceedsResetsCounter() throws InterruptedException {
        // GIVEN first run
        Job job = aJobInProgress().build();
        microMeterJobMetrics.onProcessing(job);
        Thread.sleep(60);
        microMeterJobMetrics.onProcessingFailed(job, new Exception());

        // GIVEN second run
        Job retry1Job = aCopyOf(job).withFailedState().withEnqueuedState().withProcessingState().build();
        microMeterJobMetrics.onProcessing(retry1Job);
        Thread.sleep(60);
        microMeterJobMetrics.onProcessingFailed(retry1Job, new Exception());

        // GIVEN third run
        Job retry2Job = aCopyOf(retry1Job).withFailedState().withEnqueuedState().withProcessingState().build();
        microMeterJobMetrics.onProcessing(retry2Job);
        Thread.sleep(60);
        microMeterJobMetrics.onProcessingSucceeded(retry2Job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        DefaultGauge gauge = getMeter(meters, "jobrunr.jobs.failures");
        assertThat(gauge.value()).isEqualTo(0.0);
    }

    private static <T extends Meter> T getMeter(List<Meter> meters, String name) {
        return (T) meters.stream().filter(m -> name.equals(m.getId().getName())).findFirst().orElseThrow();
    }

    private static void doesNotContainMeter(List<Meter> meters, String name) {
        assertThat(meters.stream().filter(m -> name.equals(m.getId().getName())).findFirst()).isEmpty();
    }

}