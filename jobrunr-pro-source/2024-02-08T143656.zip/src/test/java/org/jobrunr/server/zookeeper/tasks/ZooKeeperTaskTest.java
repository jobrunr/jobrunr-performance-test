package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.server.zookeeper.ZooKeeperRunTaskInfo;
import org.jobrunr.utils.annotations.Because;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.internal.util.reflection.Whitebox;

import static java.time.Instant.now;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verifyNoInteractions;

public class ZooKeeperTaskTest extends AbstractZooKeeperTaskTest {

    ProcessRecurringJobsTask task;

    @BeforeEach
    void setUpTask() {
        task = new ProcessRecurringJobsTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    @Because("https://github.com/jobrunr/jobrunr/issues/122")
    void tasksArePostponedToNextRunIfPollIntervalInSecondsTimeBoxIsAboutToPass() {
        reset(storageProvider);

        ZooKeeperRunTaskInfo zooKeeperRunTaskInfo = zooKeeperStatistics.startRun(usingStandardBackgroundJobServerConfiguration());
        setRunStartTimeInPast(zooKeeperRunTaskInfo, 15);

        task.run(zooKeeperRunTaskInfo);

        verifyNoInteractions(storageProvider);
    }

    private static void setRunStartTimeInPast(ZooKeeperRunTaskInfo zooKeeperRunTaskInfo, int secondsInPast) {
        Whitebox.setInternalState(zooKeeperRunTaskInfo, "runStartTime", now().minusSeconds(secondsInPast));
    }
}
