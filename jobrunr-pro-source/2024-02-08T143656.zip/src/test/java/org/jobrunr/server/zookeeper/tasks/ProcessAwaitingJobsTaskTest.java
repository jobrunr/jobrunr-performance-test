package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.utils.multicast.JobEnqueuedMessagePublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import java.time.Duration;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aProcessedBatchJob;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ProcessAwaitingJobsTaskTest extends AbstractZooKeeperTaskTest {

    ProcessAwaitingJobsTask task;

    @Mock
    JobEnqueuedMessagePublisher jobEnqueuedMessagePublisher;

    @BeforeEach
    void setUpTask() {
        task = new ProcessAwaitingJobsTask(jobZooKeeper, backgroundJobServer, jobEnqueuedMessagePublisher);
    }

    @Test
    void taskEnqueuesJobsWaitingForSucceededJobs() {
        final Job succeededJob = aSucceededJob().build();
        final Job jobWaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(asList(jobWaitingOnSucceededJob), emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(AWAITING, ENQUEUED);
        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void taskSchedulesJobsWaitingForSucceededJobs() {
        final Job succeededJob = aSucceededJob().build();
        final Job jobWaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId(), Duration.ofDays(3)).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(asList(jobWaitingOnSucceededJob), emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(AWAITING, SCHEDULED);
        verify(jobEnqueuedMessagePublisher, never()).publishJobEnqueued();
    }

    @Test
    void taskEnqueuesJobsWaitingForSucceededJobsUsingPagination() {
        final Job succeededJob = aSucceededJob().build();
        final Job job1WaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        final Job job2WaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        final Job job3WaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        final Job job4WaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        final Job job5WaitingOnSucceededJob = aJob().withAwaitingState(succeededJob.getId()).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(
                asList(job1WaitingOnSucceededJob, job2WaitingOnSucceededJob, job3WaitingOnSucceededJob),
                asList(job4WaitingOnSucceededJob, job5WaitingOnSucceededJob),
                emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(emptyList());

        runTask(task);

        verify(storageProvider, times(2)).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(0)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(1)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(2)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(1).get(0)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(1).get(1)).hasStates(AWAITING, ENQUEUED);
        verify(jobEnqueuedMessagePublisher, times(2)).publishJobEnqueued();
    }

    @Test
    void taskEnqueuesJobsWaitingForProcessedBatchJobs() {
        final Job batchJob = aProcessedBatchJob().build();
        final Job jobWaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(asList(jobWaitingOnBatchJob), emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(AWAITING, ENQUEUED);
        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void taskSchedulesJobsWaitingForProcessedBatchJobs() {
        final Job batchJob = aProcessedBatchJob().build();
        final Job jobWaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId(), Duration.ofDays(2)).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(asList(jobWaitingOnBatchJob), emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(AWAITING, SCHEDULED);
        verify(jobEnqueuedMessagePublisher, never()).publishJobEnqueued();
    }

    @Test
    void taskEnqueuesJobsWaitingForProcessedBatchJobsUsingPagination() {
        final Job batchJob = aProcessedBatchJob().build();
        final Job job1WaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        final Job job2WaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        final Job job3WaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        final Job job4WaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        final Job job5WaitingOnBatchJob = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(SUCCEEDED), any(AmountRequest.class))).thenReturn(emptyList());
        when(storageProvider.getAwaitingJobsOnOtherJobWithState(eq(PROCESSED), any(AmountRequest.class))).thenReturn(
                asList(job1WaitingOnBatchJob, job2WaitingOnBatchJob, job3WaitingOnBatchJob),
                asList(job4WaitingOnBatchJob, job5WaitingOnBatchJob),
                emptyList());

        runTask(task);

        verify(storageProvider, times(2)).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(0)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(1)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(2)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(1).get(0)).hasStates(AWAITING, ENQUEUED);
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(1).get(1)).hasStates(AWAITING, ENQUEUED);
        verify(jobEnqueuedMessagePublisher, times(2)).publishJobEnqueued();
    }
}