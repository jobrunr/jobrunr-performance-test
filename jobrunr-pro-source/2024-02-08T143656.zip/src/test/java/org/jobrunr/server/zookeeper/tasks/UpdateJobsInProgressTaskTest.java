package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.ProcessingState;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.storage.JobNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;
import java.util.UUID;

import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.*;

class UpdateJobsInProgressTaskTest extends AbstractZooKeeperTaskTest {

    UpdateJobsInProgressTask task;

    @BeforeEach
    void setUpTask() {
        task = new UpdateJobsInProgressTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void jobsThatAreProcessedAreBeingUpdatedWithAHeartbeat() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        startProcessingJob(job);

        // WHEN
        runTask(task);

        // THEN
        verify(storageProvider).save(singletonList(job));
        ProcessingState processingState = job.getJobState();
        assertThat(processingState.getUpdatedAt()).isAfter(processingState.getCreatedAt());
    }

    @Test
    void noExceptionIsThrownIfAJobHasSucceededWhileUpdateProcessingIsCalled() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        startProcessingJob(job);

        // WHEN
        job.succeeded();
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        verify(storageProvider).save(singletonList(job));
    }

    @Test
    void noExceptionIsThrownIfAJobHasBeenReplacedWhileUpdateProcessingIsCalled() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        final Job replacingJob = anEnqueuedJobReplacing(job).build();
        startProcessingJob(job);
        when(storageProvider.save(anyList())).thenThrow(new ConcurrentJobModificationException(asList(job)));
        when(storageProvider.getJobById(job.getId())).thenReturn(replacingJob);

        // WHEN
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        verify(storageProvider).save(singletonList(job));
    }

    @Test
    void jobsThatAreBeingProcessedButHaveBeenDeletedViaDashboardWillBeInterrupted() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        doThrow(new ConcurrentJobModificationException(job)).when(storageProvider).save(singletonList(job));
        when(storageProvider.getJobById(job.getId())).thenReturn(aCopyOf(job).withDeletedState().build());
        final Thread threadMock = startProcessingJobAndReturnThread(job);

        // WHEN
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        assertThat(job).hasState(DELETED);
        verify(storageProvider).save(singletonList(job));
        verify(threadMock).interrupt();
    }

    @Test
    void jobsThatAreBeingProcessedButArePermanentlyDeletedViaAPIWillBeInterrupted() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();
        doThrow(new ConcurrentJobModificationException(job)).when(storageProvider).save(singletonList(job));
        when(storageProvider.getJobById(job.getId())).thenThrow(new JobNotFoundException(job.getId()));
        final Thread threadMock = startProcessingJobAndReturnThread(job);

        // WHEN
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        assertThat(job).hasState(DELETED);
        verify(storageProvider).save(singletonList(job));
        verify(threadMock).interrupt();
    }

    void startProcessingJob(Job job) {
        startProcessingJobAndReturnThread(job);
    }

    Thread startProcessingJobAndReturnThread(Job job) {
        final Thread threadMock = mock(Thread.class);
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration()
                .andId(UUID.randomUUID())
                .andName("my-host-name"));

        job.startProcessingOn(backgroundJobServer);

        lenient().when(jobZooKeeper.getJobsInProgress()).thenReturn(Set.of(job));
        lenient().when(jobZooKeeper.getThreadProcessingJob(job)).thenReturn(threadMock);
        return threadMock;
    }
}