package org.jobrunr.server.tasks;

import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.contentOfResource;

@ExtendWith(MockitoExtension.class)
class MigrateFromV6toV7TaskTest {

    @Test
    void testV6JobMapperForProcessedBatchJob() {
        String processedV6BatchJob = contentOfResource("/org/jobrunr/utils/mapper/batch-job-v6.0-processed.json");

        MigrateFromV6toV7Task.V6BatchJobMapper jobMapper = new MigrateFromV6toV7Task.V6BatchJobMapper(new JacksonJsonMapper());
        Job job = jobMapper.deserializeJob(processedV6BatchJob);

        assertThat(job)
                .isInstanceOf(BatchJob.class)
                .hasState(StateName.PROCESSED);
    }

    @Test
    void testV6JobMapperForSucceededBatchJob() {
        String processedV6BatchJob = contentOfResource("/org/jobrunr/utils/mapper/batch-job-v6.0-succeeded.json");

        MigrateFromV6toV7Task.V6BatchJobMapper jobMapper = new MigrateFromV6toV7Task.V6BatchJobMapper(new JacksonJsonMapper());
        Job job = jobMapper.deserializeJob(processedV6BatchJob);

        assertThat(job)
                .isInstanceOf(BatchJob.class)
                .hasState(StateName.SUCCEEDED);
    }

}