package org.jobrunr.server.tasks;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.migrations.JobNotFoundConfigurationReader;
import org.jobrunr.jobs.migrations.ScheduledJobThatDoNotExistAnymoreMigrations;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static java.util.Arrays.asList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.classThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.methodThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CheckIfAllJobsExistTaskTest {

    private CheckIfAllJobsExistTask checkIfAllJobsExistTask;

    @Mock
    private BackgroundJobServer backgroundJobServer;

    @Mock
    private JobNotFoundConfigurationReader jobNotFoundConfiguration;

    private StorageProvider storageProvider;

    private ListAppender<ILoggingEvent> logger;

    @BeforeEach
    void setUp() {
        storageProvider = spy(new InMemoryStorageProvider());
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(jobNotFoundConfiguration.getScheduledJobsThatDoNotExistAnymoreMigrations()).thenReturn(new ScheduledJobThatDoNotExistAnymoreMigrations());

        checkIfAllJobsExistTask = new CheckIfAllJobsExistTask(backgroundJobServer, jobNotFoundConfiguration);

        logger = LoggerAssert.initFor(checkIfAllJobsExistTask);
    }

    @Test
    void onRunItLogsAllRecurringJobsThatDoNotExist() {
        save(
                aDefaultRecurringJob().build(),
                aDefaultRecurringJob().withJobDetails(classThatDoesNotExistJobDetails()).build());

        checkIfAllJobsExistTask.run();

        assertThat(logger)
                .hasWarningMessageContaining("JobRunr found RECURRING jobs that do not exist anymore")
                .hasWarningMessageContaining("i.dont.exist.Class.notImportant(java.lang.Integer)")
                .hasNoErrorLogMessages();
    }

    @Test
    void onRunItLogsAllScheduledJobsThatDoNotExist() {
        save(
                aScheduledJob().build(),
                aScheduledJob().withJobDetails(classThatDoesNotExistJobDetails()).build());

        checkIfAllJobsExistTask.run();

        assertThat(logger)
                .hasWarningMessageContaining("JobRunr found SCHEDULED jobs that do not exist anymore")
                .hasWarningMessageContaining("i.dont.exist.Class.notImportant(java.lang.Integer)")
                .hasNoErrorLogMessages();
    }

    @Test
    void onRunItLogsAllScheduledAndRecurringJobsThatDoNotExist() {
        save(
                aDefaultRecurringJob().build(),
                aDefaultRecurringJob().withJobDetails(classThatDoesNotExistJobDetails()).build());

        save(
                aScheduledJob().build(),
                aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build());

        checkIfAllJobsExistTask.run();

        assertThat(logger)
                .hasWarningMessageContaining("JobRunr found RECURRING AND SCHEDULED jobs that do not exist anymore in your code.")
                .hasWarningMessageContaining("i.dont.exist.Class.notImportant(java.lang.Integer)")
                .hasWarningMessageContaining("org.jobrunr.stubs.TestService.doWorkThatDoesNotExist(java.lang.Integer)")
                .hasNoErrorLogMessages();
    }

    @Test
    void onRunItDeletesAllRecurringJobsThatDoNotExistIfConfigured() {
        when(jobNotFoundConfiguration.mustDeleteAllRecurringJobsThatAreNotFound()).thenReturn(true);

        save(
                aDefaultRecurringJob().withId("recurringJob1").build(),
                aDefaultRecurringJob().withId("recurringJob2").withJobDetails(classThatDoesNotExistJobDetails()).build());

        checkIfAllJobsExistTask.run();

        assertThat(storageProvider.countRecurringJobs(new RecurringJobSearchRequest())).isEqualTo(1);
        assertThat(logger)
                .hasInfoMessageContaining("Deleted RecurringJob recurringJob2 with name 'a recurring job' and job signature i.dont.exist.Class.notImportant(java.lang.Integer) as the code for it can no longer be found.")
                .hasNoWarnLogMessages()
                .hasNoErrorLogMessages();
    }

    @Test
    void onRunItDeletesAllScheduledJobsThatDoNotExistIfConfigured() {
        when(jobNotFoundConfiguration.mustDeleteAllScheduledJobsThatAreNotFound()).thenReturn(true);
        save(
                aScheduledJob().withJobDetails(defaultJobDetails()).build(),
                aScheduledJob().withJobDetails(classThatDoesNotExistJobDetails()).build(),
                aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build(),
                aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build()
        );

        checkIfAllJobsExistTask.run();
        assertThat(storageProvider.countJobs(new JobSearchRequest(SCHEDULED))).isEqualTo(1L);
        assertThat(logger)
                .hasInfoMessageContaining("Deleted 2 SCHEDULED Job(s) with job signature org.jobrunr.stubs.TestService.doWorkThatDoesNotExist(java.lang.Integer) as the code for it can no longer be found.")
                .hasInfoMessageContaining("Deleted 1 SCHEDULED Job(s) with job signature i.dont.exist.Class.notImportant(java.lang.Integer) as the code for it can no longer be found.")
                .hasNoWarnLogMessages()
                .hasNoErrorLogMessages();
    }

    @Test
    void onRunItMigratesClassesViaMigrations() {
        when(jobNotFoundConfiguration.mustDeleteAllScheduledJobsThatAreNotFound()).thenReturn(false);
        when(jobNotFoundConfiguration.getScheduledJobsThatDoNotExistAnymoreMigrations()).thenReturn(new ScheduledJobThatDoNotExistAnymoreMigrations(
                ((scheduledJobMatcher, scheduledJobUpdater) -> {
                    if (scheduledJobMatcher.matches("i.dont.exist.Class")) {
                        scheduledJobUpdater.deleteJob();
                    } else if (scheduledJobMatcher.matches(TestService.class, "doWorkThatDoesNotExist")) {
                        scheduledJobUpdater.setMethodName("doWork");
                    }
                })
        ));

        save(
                aScheduledJob().withJobDetails(defaultJobDetails()).build(),
                aScheduledJob().withJobDetails(classThatDoesNotExistJobDetails()).build(),
                aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build(),
                aScheduledJob().withJobDetails(methodThatDoesNotExistJobDetails()).build()
        );

        checkIfAllJobsExistTask.run();

        assertThat(storageProvider.getJobList(new JobSearchRequest(SCHEDULED), Paging.AmountBasedList.ascOnPriorityAndUpdatedAt(10))).hasSize(3);
        assertThat(logger)
                .hasInfoMessageContaining("JobRunr successfully migrated 2 jobs with jobSignature org.jobrunr.stubs.TestService.doWorkThatDoesNotExist(java.lang.Integer)")
                .hasInfoMessageContaining("JobRunr successfully migrated 1 jobs with jobSignature i.dont.exist.Class.notImportant(java.lang.Integer)")
                .hasNoWarnLogMessages();
    }


    private void save(Job... jobs) {
        storageProvider.save(asList(jobs));
    }

    private void save(RecurringJob... recurringJobs) {
        storageProvider.saveRecurringJobs(asList(recurringJobs));
    }
}