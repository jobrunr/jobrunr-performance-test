package org.jobrunr.server.zookeeper.tasks.ratelimiters;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobTestBuilder;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.function.Consumer;
import java.util.stream.IntStream;

import static java.time.Duration.ofHours;
import static java.time.temporal.ChronoUnit.HOURS;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SlidingTimeWindowRateLimiterTest {

    static final String SLIDING_TIME_WINDOW_RATE_LIMITER_NAME = "sliding-time-window-rate-limiter";

    @Test
    void updateJobToNewStateAddsEnqueuesJob() {
        // GIVEN
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(null, "2/PT2S", 5);
        Job awaitingJob = aJob().withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME).build();

        // WHEN
        slidingTimeWindowRateLimiter.updateJobToNewState(awaitingJob);

        // THEN
        assertThat(awaitingJob)
                .hasState(StateName.ENQUEUED);
    }

    @Test
    void rateLimiterDoesCorrectJobSearchRequest() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "100/PT1h", 5);
        saveAlreadyEnqueuedJobsForRateLimiter(storageProvider, 0);
        try (MockedStatic<Instant> instantMock = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // WHEN
            slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

            // THEN
            verify(storageProvider).countJobs(refEq(
                    aJobSearchRequest()
                            .withStateNames(ENQUEUED, PROCESSING)
                            .withRateLimiter(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME)
                            .withUpdatedAtFrom(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR.minus(ofHours(1)))
                            .build()));
        }
    }

    @Test
    void ifSmallTimeWindowAndNoJobsEnqueuedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "2/PT1S", 5);
        saveAlreadyEnqueuedJobsForRateLimiter(storageProvider, 0);

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(10); // why: 2 * 5 (pollIntervalInSeconds)
    }

    @Test
    void ifSmallTimeWindowAndSomeJobsEnqueuedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "2/PT1S", 5);
        saveAlreadyEnqueuedJobsForRateLimiter(storageProvider, 3);

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(7); // why: 2 * 5 (pollIntervalInSeconds) - 3
    }

    @Test
    void ifLargeTimeWindowAndNoJobsEnqueuedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "100/PT1H", 5);
        saveAlreadyEnqueuedJobsForRateLimiter(storageProvider, 0);

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(100);
    }

    @Test
    void ifLargeTimeWindowAndSomeJobsEnqueuedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "100/PT1H", 5);
        saveAlreadyEnqueuedJobsForRateLimiter(storageProvider, 35);

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(65); // why: 100 - 35
    }

    @Test
    void ifJobsAreCreatedALongTimeAgoAndSomeJobsEnqueuedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "5/PT2M", 15);

        saveJobs(storageProvider, 5, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, Instant.now().minus(1, HOURS))
                .withEnqueuedState());

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(0); // why: already 5 enqueued
    }

    @Test
    void ifJobsAreCreatedALongTimeAgoAndSomeJobsSucceededRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "5/PT2M", 15);

        saveJobs(storageProvider, 1, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, Instant.now().minus(1, HOURS))
                .withEnqueuedState());

        saveJobs(storageProvider, 50, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, Instant.now().minus(1, HOURS))
                .withEnqueuedState()
                .withProcessingState()
                .withSucceededState());

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(4); // why: already 1 enqueued
    }

    @Test
    void ifJobsAreCreatedALongTimeAgoAndSomeJobsFailedRateLimiterReturnsAmountOfJobsThatCanBeDoneDuringPollIntervalInSeconds() {
        // GIVEN
        StorageProvider storageProvider = storageProvider();
        SlidingTimeWindowRateLimiter slidingTimeWindowRateLimiter = setUpSlidingTimeWindowsRateLimiter(storageProvider, "5/PT2M", 15);

        saveJobs(storageProvider, 2, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, Instant.now().minus(1, HOURS))
                .withEnqueuedState()
                .withProcessingState());

        saveJobs(storageProvider, 50, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, Instant.now().minus(1, HOURS))
                .withEnqueuedState()
                .withProcessingState()
                .withFailedState());

        // WHEN
        int amountOfJobsToEnqueue = slidingTimeWindowRateLimiter.getAmountOfJobsToEnqueue();

        // THEN
        assertThat(amountOfJobsToEnqueue)
                .isEqualTo(3); // why: already 2 processing
    }

    void saveAlreadyEnqueuedJobsForRateLimiter(StorageProvider storageProvider, int alreadyEnqueuedJobs) {
        saveJobs(storageProvider, alreadyEnqueuedJobs, job -> job
                .withAwaitingRateLimiterState(SLIDING_TIME_WINDOW_RATE_LIMITER_NAME)
                .withEnqueuedState());
    }

    void saveJobs(StorageProvider storageProvider, int alreadyCreatedJobs, Consumer<JobTestBuilder> jobTestBuilderConsumer) {
        IntStream.range(0, alreadyCreatedJobs).boxed()
                .forEach(i -> {
                    JobTestBuilder jobTestBuilder = aJob();
                    jobTestBuilderConsumer.accept(jobTestBuilder);
                    storageProvider.save(jobTestBuilder.build());
                });
    }

    private SlidingTimeWindowRateLimiter setUpSlidingTimeWindowsRateLimiter(StorageProvider storageProvider, String rateLimit, int pollIntervalInSeconds) {
        BackgroundJobServer backgroundJobServer = mock(BackgroundJobServer.class);
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration().andPollIntervalInSeconds(pollIntervalInSeconds));
        return new SlidingTimeWindowRateLimiter(backgroundJobServer, SLIDING_TIME_WINDOW_RATE_LIMITER_NAME, rateLimit);
    }

    private StorageProvider storageProvider() {
        StorageProvider storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return spy(storageProvider);
    }
}