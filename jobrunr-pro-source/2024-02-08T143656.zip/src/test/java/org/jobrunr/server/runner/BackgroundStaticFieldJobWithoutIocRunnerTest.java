package org.jobrunr.server.runner;

import org.jobrunr.jobs.Job;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;

class BackgroundStaticFieldJobWithoutIocRunnerTest {

    private BackgroundStaticFieldJobWithoutIocRunner backgroundStaticFieldJobWithoutIocRunner;

    @BeforeEach
    void setup() {
        backgroundStaticFieldJobWithoutIocRunner = new BackgroundStaticFieldJobWithoutIocRunner(new JobResultSaver(new JacksonJsonMapper()));
    }

    @Test
    void supportsJobIfJobIsStaticMethodCall() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(systemOutPrintLnJobDetails("This is a test"))
                .build();

        assertThat(backgroundStaticFieldJobWithoutIocRunner.supports(job)).isTrue();
    }

    @Test
    void doesNotSupportJobIfJobIsNotAStaticMethodCall() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails())
                .build();

        assertThat(backgroundStaticFieldJobWithoutIocRunner.supports(job)).isFalse();
    }

    @Test
    void runSimpleMethod() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(systemOutPrintLnJobDetails("This is a test"))
                .build();

        assertThatCode(() -> backgroundStaticFieldJobWithoutIocRunner.run(job)).doesNotThrowAnyException();
    }

}