package org.jobrunr.server.runner;

import org.jobrunr.jobs.Job;
import org.jobrunr.stubs.TestServiceForIoC;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobParameter.JobContext;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;

class BackgroundJobWithoutIocRunnerTest {

    private BackgroundJobWithoutIocRunner backgroundJobWithoutIocRunner;

    @BeforeEach
    void setup() {
        backgroundJobWithoutIocRunner = new BackgroundJobWithoutIocRunner(new JobResultSaver(new JacksonJsonMapper()));
    }

    @Test
    void supportsJobIfJobClassHasDefaultConstructor() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails())
                .build();

        assertThat(backgroundJobWithoutIocRunner.supports(job)).isTrue();
    }

    @Test
    void doesNotSupportJobIfClassHasNoDefaultConstructor() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails().withClassName(TestServiceForIoC.class))
                .build();

        assertThat(backgroundJobWithoutIocRunner.supports(job)).isFalse();
    }

    @Test
    void runSimpleMethod() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails())
                .build();

        assertThatCode(() -> backgroundJobWithoutIocRunner.run(job)).doesNotThrowAnyException();
    }

    @Test
    void runMethodWithJobContext() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails()
                        .withJobParameter(JobContext))
                .build();

        assertThatCode(() -> backgroundJobWithoutIocRunner.run(job)).doesNotThrowAnyException();
    }

}