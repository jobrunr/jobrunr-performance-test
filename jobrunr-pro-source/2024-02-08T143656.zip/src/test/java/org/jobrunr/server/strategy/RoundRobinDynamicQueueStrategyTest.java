package org.jobrunr.server.strategy;

import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.utils.SleepUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.server.configuration.RoundRobinDynamicQueuePolicy.DEFAULT_REMOVAL_THRESHOLD;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RoundRobinDynamicQueueStrategyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    StorageProvider storageProvider;

    private RoundRobinDynamicQueueStrategy roundRobinDynamicQueueStrategy;

    @BeforeEach
    void setUp() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithoutDynamicQueues() {
        // GIVEN
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy();

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getDistinctDynamicQueues(ENQUEUED);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(null), refEq(ascOnPriorityAndUpdatedAt(5)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueues() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy();

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesCyclesThroughQueuesIfThereAreResults() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(Set.of("Tenant-A", "Tenant-B"));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy();

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesAndNullEntryCyclesThroughQueuesIncludingNull() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy();

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue(null).withLabels("just a label").build(),
                        anEnqueuedJob().withDynamicQueue(null).withLabels("and another label").build()));
        List<Job> nullTenantJobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        // THEN
        assertThat(nullTenantJobsToProcess).hasSize(2);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-A").withLabels("tenant: Tenant-A").build()));
        // THEN
        List<Job> tenantAJobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(7));
        assertThat(tenantAJobsToProcess).hasSize(1);
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(7)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(2));
        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(2)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(2));
        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(2)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesCachesQueuesForGivenDuration() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofSeconds(1), 1);

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED); // only 1 time

        // WHEN
        SleepUtils.sleep(1000);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        verify(storageProvider, times(2)).getDistinctDynamicQueues(ENQUEUED); // after given period, a second time
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesRemovesQueuesOnRefreshIfQueueNotPresentForXTimesWhereXEqualsRemovalThreshold() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofMillis(100), 1);

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.ofNullable(null)), refEq(ascOnPriorityAndUpdatedAt(5)));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(3)));

        // THEN
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED);

        // GIVEN FOR THE NEXT COUPLE OF TIMES
        Mockito.clearInvocations(storageProvider);
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A")));

        // WHEN
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));
        verify(storageProvider, times(1)).getDistinctDynamicQueues(ENQUEUED);

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(6)));

        // WHEN
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(3));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(3)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(6)));

        // WHEN
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(15));

        // THEN (as there we have only jobs for TENANT-A for the last 3 checks)
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(15)));
        assertThat((Map) Whitebox.getInternalState(roundRobinDynamicQueueStrategy, "roundRobinIds")).hasSize(1);
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsUntilThereAreJobs() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofSeconds(5), 3);

        // WHEN
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), any(AmountRequest.class)))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), any(AmountRequest.class)))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build(),
                        anEnqueuedJob().withDynamicQueue("Tenant-B").withLabels("tenant: Tenant-B").build()));
        List<Job> jobsToProcess = roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));
        assertThat(jobsToProcess).hasSize(2);

        // THEN
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), any(AmountRequest.class)))
                .thenReturn(emptyList());
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), any(AmountRequest.class)))
                .thenReturn(asList(anEnqueuedJob().withDynamicQueue("Tenant-D").withLabels("tenant:Tenant-D").build()));
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider, times(1)).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider, never()).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobs() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofSeconds(5), 3);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesKeepsCyclingForContinueCountOnNoJobsIfNoJobsButStopsIfItIsAgainAtTheBeginning() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofSeconds(5), 5);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verifyNoMoreInteractions(storageProvider);
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithChangingDynamicQueuesToEnsureNoQueueIsUsedConsecutivelyWhenAnotherIsAvailable() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofMillis(100), 5);
        InOrder queueOrder = inOrder(storageProvider);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "Tenant-A", "Tenant-B")));
        when(storageProvider.getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5))))
                .thenReturn(asList(
                        anEnqueuedJob().withDynamicQueue(null).withLabels("just a label").build(),
                        anEnqueuedJob().withDynamicQueue(null).withLabels("and another label").build())
                );

        // WHEN
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));

        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED)).thenReturn(new HashSet<>(asList(null, "JOBRUNR")));

        // WHEN
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("JOBRUNR")), refEq(ascOnPriorityAndUpdatedAt(5)));
        queueOrder.verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.empty()), refEq(ascOnPriorityAndUpdatedAt(5)));
    }

    @Test
    void testRoundRobinDynamicQueueStrategyWithDynamicQueuesRemovesQueuesThatAreNotAvailableAnymore() {
        // GIVEN
        when(storageProvider.getDistinctDynamicQueues(ENQUEUED))
                .thenReturn(new HashSet<>(asList("Tenant-A", "Tenant-B", "Tenant-C", "Tenant-D", "Tenant-E")),
                        new HashSet<>(asList("Tenant-A", "Tenant-B")));
        roundRobinDynamicQueueStrategy = createRoundRobinDynamicQueueStrategy(Duration.ofMillis(100), 3, 2);

        // WHEN (no mocking thus returns empty lists)
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(5)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-C")), refEq(ascOnPriorityAndUpdatedAt(5)));

        // WHEN (no mocking thus returns empty lists)
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-D")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-E")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));

        // WHEN (no mocking thus returns empty lists)
        Mockito.clearInvocations(storageProvider);
        SleepUtils.sleep(100);
        roundRobinDynamicQueueStrategy.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-B")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verify(storageProvider).getJobsToProcess(eq(backgroundJobServer), eq(Optional.of("Tenant-A")), refEq(ascOnPriorityAndUpdatedAt(8)));
        verifyNoMoreInteractions(storageProvider);
    }

    private RoundRobinDynamicQueueStrategy createRoundRobinDynamicQueueStrategy() {
        return createRoundRobinDynamicQueueStrategy(Duration.ofSeconds(10), 1);
    }

    private RoundRobinDynamicQueueStrategy createRoundRobinDynamicQueueStrategy(Duration durationBeforeRefreshOfDynamicQueues, int continueCountOnNoJobs) {
        return new RoundRobinDynamicQueueStrategy(backgroundJobServer, durationBeforeRefreshOfDynamicQueues, continueCountOnNoJobs, DEFAULT_REMOVAL_THRESHOLD);
    }

    private RoundRobinDynamicQueueStrategy createRoundRobinDynamicQueueStrategy(Duration durationBeforeRefreshOfDynamicQueues, int continueCountOnNoJobs, int removalThreshold) {
        return new RoundRobinDynamicQueueStrategy(backgroundJobServer, durationBeforeRefreshOfDynamicQueues, continueCountOnNoJobs, removalThreshold);
    }
}