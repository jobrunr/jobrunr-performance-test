package org.jobrunr.server.concurrent;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.JobZooKeeper;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.SleepUtils;
import org.jobrunr.utils.annotations.Because;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.UUID;
import java.util.stream.Stream;

import static java.time.Instant.now;
import static java.time.Instant.parse;
import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.*;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.failedJob;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.states.StateName.*;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DefaultConcurrentJobModificationResolverTest {

    private DefaultConcurrentJobModificationResolver concurrentJobModificationResolver;

    @Mock
    private StorageProvider storageProvider;
    @Mock
    private JobZooKeeper jobZooKeeper;

    @BeforeEach
    void setUp() {
        concurrentJobModificationResolver = new DefaultConcurrentJobModificationResolver(storageProvider, jobZooKeeper);
    }

    @ParameterizedTest
    @MethodSource("getJobsThatWereDeletedInDifferentStates")
    void concurrentStateChangeFromSucceededFailedOrScheduledToDeletedIsAllowed(Job localJob, Job storageProviderJob) {
        final Thread jobThread = mock(Thread.class);
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob));

        verifyNoInteractions(jobThread);
    }

    @ParameterizedTest
    @MethodSource("getJobsThatAreInProgressInDifferentStates")
    void concurrentStateChangeWhileProcessingIsAllowedIfJobIsNotProcessingAnymore(Job localJob, Job storageProviderJob) {
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(null);

        assertThatCode(() -> concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob)))
                .doesNotThrowAnyException();
    }

    @ParameterizedTest
    @MethodSource("getJobsThatAreInProgressInDifferentStates")
    void concurrentStateChangeWhileProcessingIsNotAllowedIfJobIsProcessing(Job localJob, Job storageProviderJob) {
        final Thread jobThread = mock(Thread.class);
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        assertThatCode(() -> concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob)))
                .isInstanceOf(UnresolvableConcurrentJobModificationException.class);
    }

    @ParameterizedTest
    @MethodSource("getJobsThatWereSucceededInDifferentStates")
    void concurrentStateChangeWhileSucceededInStorageProviderIsAllowed(Job localJob, Job storageProviderJob) {
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);

        assertThatCode(() -> concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob)))
                .doesNotThrowAnyException();
    }

    @ParameterizedTest
    @MethodSource("getJobsInDifferentStatesThatAreReplaced")
    void concurrentStateChangeFromAnyStateToEnqueuedOrScheduledIsAllowedIfJobHasBeenReplaced(Job localJob, Job storageProviderJob) {
        final Thread jobThread = mock(Thread.class);
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob));

        verify(jobThread).interrupt();
    }

    @Test
    void concurrentStateChangeFromEnqueuedToEnqueuedIsAllowedWhenItWasScheduledBefore() {
        UUID id = UUID.randomUUID();
        final Job localJob = aScheduledJob().withId(id).withEnqueuedState().build();
        final Job storageProviderJob = aScheduledJob().withId(id).withEnqueuedState().build();

        when(storageProvider.getJobById(localJob.getId())).thenReturn(aCopyOf(localJob).build());
        when(storageProvider.getJobById(storageProviderJob.getId())).thenReturn(aCopyOf(storageProviderJob).build());

        assertThatCode(() -> concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob)))
                .doesNotThrowAnyException();
    }

    @Test
    void concurrentStateChangeFromProcessingToDeletedIsAllowedAndInterruptsThread() {
        final Job job1 = aJobInProgress().build();
        final Job job2 = aJobInProgress().build();

        final Thread job1Thread = mock(Thread.class);
        final Thread job2Thread = mock(Thread.class);

        when(storageProvider.getJobById(job1.getId())).thenReturn(aCopyOf(job1).withDeletedState().build());
        when(storageProvider.getJobById(job2.getId())).thenReturn(aCopyOf(job2).withDeletedState().build());

        when(jobZooKeeper.getThreadProcessingJob(job1)).thenReturn(job1Thread);
        when(jobZooKeeper.getThreadProcessingJob(job2)).thenReturn(job2Thread);

        concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(asList(job1, job2)));

        verify(job1Thread).interrupt();
        verify(job2Thread).interrupt();
        assertThat(job1).hasState(DELETED);
        assertThat(job2).hasState(DELETED);
    }

    @Test
    void concurrentStateChangeForJobThatIsPerformedOnOtherBackgroundJobServerIsAllowed() {
        final Job jobInProgress = aJobInProgress().build();
        Job localJob = aCopyOf(jobInProgress).withVersion(3).build();
        Job storageProviderJob = aCopyOf(jobInProgress).withVersion(6).withFailedState().withScheduledState().withEnqueuedState(now()).withProcessingState().build();

        final Thread jobThread = mock(Thread.class);
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob));

        verify(jobThread).interrupt();
    }

    @Test
    void concurrentStateChangeFromConcurrentReplacingJobsIsHandled() {
        final Job storageProviderJob = aJob()
                .withScheduledState(parse("2022-08-11T23:47:09.653Z"))
                .withEnqueuedState(parse("2022-08-11T23:47:17.038Z"))
                .withProcessingState(parse("2022-08-11T23:47:17.053Z"))
                .build();
        EnqueuedState enqueuedState = new EnqueuedState();
        enqueuedState.isReplacingJobInState(PROCESSING, parse("2022-08-11T23:47:17.053Z"));
        final Job localJob = aJob()
                .withState(enqueuedState, parse("2022-08-11T23:47:19.039Z"))
                .withProcessingState(parse("2022-08-11T23:47:19.058Z"))
                .build();

        final Thread jobThread = mock(Thread.class);
        when(storageProvider.getJobById(localJob.getId())).thenReturn(storageProviderJob);
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(localJob));

        verify(storageProvider).saveReplace(localJob);
        verifyNoInteractions(jobThread);
    }

    @Test
    @Because("https://github.com/jobrunr/jobrunr-pro/issues/44")
    void concurrentStateChangeFromConcurrentReplacingJobsIsHandledWithRealStorageProvider() {
        final BackgroundJobServer backgroundJobServer = mock(BackgroundJobServer.class);
        final Thread jobThread = mock(Thread.class);
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());

        storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));

        concurrentJobModificationResolver = new DefaultConcurrentJobModificationResolver(storageProvider, jobZooKeeper);


        UUID jobId = UUID.randomUUID();
        // GIVEN other job is processed
        Job scheduledJob = storageProvider.save(aScheduledJob().withId(jobId).build());
        Job enqueuedJob = storageProvider.save(scheduledJob.enqueue());
        Job processingJob = storageProvider.save(enqueuedJob.startProcessingOn(backgroundJobServer));
        SleepUtils.sleep(100);
        processingJob.updateProcessing();
        Job storageJob = storageProvider.save(processingJob);

        // GIVEN local job that is replacing other job is processed
        final Job localJob = aJobReplacing(storageJob, new EnqueuedState())
                .withId(jobId)
                .withVersion(3)
                .withProcessingState()
                .build();
        lenient().when(jobZooKeeper.getThreadProcessingJob(localJob)).thenReturn(jobThread);

        // WHEN local job is saved
        try {
            storageProvider.save(Arrays.asList(localJob));
            fail("ConcurrentJobModificationException should be thrown");
        } catch (ConcurrentJobModificationException e) {
            concurrentJobModificationResolver.resolve(e);
        }

        // THEN local job will continue
        verifyNoInteractions(jobThread);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING);


        // WHEN storage job is updated
        Job updatedStorageJob = aCopyOf(storageJob).build();
        updatedStorageJob.updateProcessing();
        try {
            storageProvider.save(Arrays.asList(updatedStorageJob));
            fail("ConcurrentJobModificationException should be thrown");
        } catch (ConcurrentJobModificationException e) {
            concurrentJobModificationResolver.resolve(e);
        }
        assertThat(updatedStorageJob).hasStates(SCHEDULED, ENQUEUED, PROCESSING, DELETED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING);

        // OR WHEN storage job has succeeded
        Job succeededStorageJob = aCopyOf(storageJob).build();
        succeededStorageJob.succeeded();
        try {
            storageProvider.save(Arrays.asList(succeededStorageJob));
            fail("ConcurrentJobModificationException should be thrown");
        } catch (ConcurrentJobModificationException e) {
            concurrentJobModificationResolver.resolve(e);
        }
        assertThat(succeededStorageJob).hasStates(SCHEDULED, ENQUEUED, PROCESSING, SUCCEEDED, DELETED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING);

        // OR WHEN storage job has failed
        Job failedStorageJob = aCopyOf(storageJob).build();
        failedStorageJob.failed("An exception occurred", new Exception());
        try {
            storageProvider.save(Arrays.asList(failedStorageJob));
            fail("ConcurrentJobModificationException should be thrown");
        } catch (ConcurrentJobModificationException e) {
            concurrentJobModificationResolver.resolve(e);
        }
        assertThat(failedStorageJob).hasStates(SCHEDULED, ENQUEUED, PROCESSING, FAILED, DELETED);
        assertThat(storageProvider.getJobById(jobId)).hasStates(ENQUEUED, PROCESSING);
    }

    @Test
    void concurrentStateChangeFromUnsupportedStateChangeIsNotAllowedAndThrowsException() {
        final Job job1 = aJobInProgress().build();
        final Job job2 = aJobInProgress().build();

        when(storageProvider.getJobById(job1.getId())).thenReturn(aCopyOf(job1).build());
        when(storageProvider.getJobById(job2.getId())).thenReturn(aCopyOf(job2).build());

        assertThatThrownBy(() -> concurrentJobModificationResolver.resolve(new ConcurrentJobModificationException(asList(job1, job2))))
                .isInstanceOf(ConcurrentJobModificationException.class)
                .has(failedJob(job1))
                .has(failedJob(job2));
    }

    static Stream<Arguments> getJobsThatWereDeletedInDifferentStates() {
        final Job scheduledJob = aScheduledJob().build();
        final Job jobInProgress = aJobInProgress().build();
        return Stream.of(
                arguments(aCopyOf(scheduledJob).withEnqueuedState(now()).build(), aCopyOf(scheduledJob).withDeletedState().build()),
                arguments(aCopyOf(jobInProgress).withSucceededState().build(), aCopyOf(jobInProgress).withDeletedState().build()),
                arguments(aCopyOf(jobInProgress).withFailedState().build(), aCopyOf(jobInProgress).withDeletedState().build()),
                arguments(aCopyOf(jobInProgress).withScheduledState().build(), aCopyOf(jobInProgress).withDeletedState().build())
        );
    }

    static Stream<Arguments> getJobsInDifferentStatesThatAreReplaced() {
        final Job scheduledJob = aScheduledJob().build();
        final Job jobInProgress = aJobInProgress().build();
        return Stream.of(
                arguments(aCopyOf(scheduledJob).build(), anEnqueuedJobReplacing(scheduledJob).build()),
                arguments(aCopyOf(scheduledJob).withEnqueuedState(now()).build(), anEnqueuedJobReplacing(scheduledJob).build()),
                arguments(aCopyOf(jobInProgress).build(), anEnqueuedJobReplacing(scheduledJob).withProcessingState().build()),
                arguments(aCopyOf(jobInProgress).withSucceededState().build(), anEnqueuedJobReplacing(jobInProgress).build()),
                arguments(aCopyOf(jobInProgress).withFailedState().build(), anEnqueuedJobReplacing(jobInProgress).build()),
                arguments(aCopyOf(jobInProgress).withScheduledState().build(), anEnqueuedJobReplacing(jobInProgress).build()),
                arguments(aCopyOf(jobInProgress).withDeletedState().build(), anEnqueuedJobReplacing(jobInProgress).build()),
                arguments(aCopyOf(jobInProgress).withDeletedState().build(), anEnqueuedJobReplacing(jobInProgress).withProcessingState().withFailedState().withScheduledState(now()).build()),
                arguments(aCopyOf(jobInProgress).build(), aScheduledJobReplacing(jobInProgress).withEnqueuedState().withProcessingState().build())
        );
    }

    static Stream<Arguments> getJobsThatAreInProgressInDifferentStates() {
        final Job jobInProgress = aJobInProgress().withVersion(2).build();
        return Stream.of(
                arguments(jobInProgress, aCopyOf(jobInProgress).withVersion(3).withEnqueuedState(Instant.now()).build()),
                arguments(jobInProgress, aCopyOf(jobInProgress).withVersion(3).withFailedState().build()),
                arguments(jobInProgress, aCopyOf(jobInProgress).withVersion(3).withScheduledState().build())
        );
    }

    static Stream<Arguments> getJobsThatWereSucceededInDifferentStates() {
        final Job succeededJob = aJobInProgress().withSucceededState().build();
        return Stream.of(
                arguments(aScheduledJob().build(), succeededJob),
                arguments(anEnqueuedJob().build(), succeededJob),
                arguments(aJobInProgress().build(), succeededJob),
                arguments(aFailedJob().build(), succeededJob)
        );
    }

}