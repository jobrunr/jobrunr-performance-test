package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.storage.JobRunrMetadata;
import org.jobrunr.utils.multicast.JobEnqueuedMessagePublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

import static java.time.Instant.now;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.concurrent.TimeUnit.SECONDS;
import static java.util.stream.Collectors.toList;
import static java.util.stream.IntStream.range;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.states.StateName.*;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.StorageProviderUtils.Metadata.RATE_LIMITER_NAME;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.*;

class ProcessScheduledJobsTaskTest extends AbstractZooKeeperTaskTest {

    private static final int PAGE_REQUEST_SIZE = 1000;

    ProcessScheduledJobsTask task;

    @Mock
    JobEnqueuedMessagePublisher jobEnqueuedMessagePublisher;

    @BeforeEach
    void setUpTask() {
        when(backgroundJobServer.getConfiguration()).thenReturn(
                usingStandardBackgroundJobServerConfiguration()
                        .andScheduledJobsRequestSize(PAGE_REQUEST_SIZE));
        task = new ProcessScheduledJobsTask(jobZooKeeper, backgroundJobServer, jobEnqueuedMessagePublisher);
    }

    @Test
    void testTaskEnqueuedImmediatelyWhenScheduleAtIsInPast() {
        final Job scheduledJob = aJob().withScheduledState(now()).build();
        whenGetScheduledJobsThenReturn(asList(scheduledJob), emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(SCHEDULED, ENQUEUED);
        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void testTaskEnqueuesJobIfJobHasNoRateLimiter() {
        final Job scheduledJob = aJob().withScheduledState(now().plusMillis(200)).build();
        whenGetScheduledJobsThenReturn(asList(scheduledJob), emptyList());

        runTask(task);

        await()
                .atMost(10, SECONDS)
                .untilAsserted(() -> verify(storageProvider).save(jobsToSaveArgumentCaptor.capture()));

        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(SCHEDULED, ENQUEUED);
        verify(jobEnqueuedMessagePublisher).publishJobEnqueued();
    }

    @Test
    void testTaskAwaitsRateLimiterIfHasRateLimiter() {
        final Job scheduledJob = aJob()
                .withRateLimiter("my-rate-limiter")
                .withScheduledState(now().plusMillis(200))
                .build();
        when(storageProvider.getMetadata(RATE_LIMITER_NAME)).thenReturn(asList(new JobRunrMetadata(RATE_LIMITER_NAME, "my-rate-limiter", "ignored")));
        whenGetScheduledJobsThenReturn(asList(scheduledJob), emptyList());

        runTask(task);

        await()
                .atMost(10, SECONDS)
                .untilAsserted(() -> verify(storageProvider).save(jobsToSaveArgumentCaptor.capture()));

        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasStates(SCHEDULED, AWAITING);
    }

    @Test
    void testTaskSchedulesRealtimeAndGroupsThemPer100msIfScheduleAtIsInTheFuture() {
        try (MockedStatic<Instant> instantMock = mockTime(Instant.parse("2023-05-25T08:04:07.000Z"))) {
            final Job scheduledJob1 = aJob().withScheduledState(now().plusMillis(2100)).build(); // first group of enqueued jobs
            final Job scheduledJob2 = aJob().withScheduledState(now().plusMillis(2101)).build(); // second group of enqueued jobs
            final Job scheduledJob3 = aJob().withScheduledState(now().plusMillis(2150)).build();
            final Job scheduledJob4 = aJob().withScheduledState(now().plusMillis(2190)).build();
            final Job scheduledJob5 = aJob().withScheduledState(now().plusMillis(2199)).build();
            final Job scheduledJob6 = aJob().withScheduledState(now().plusMillis(2200)).build();
            final Job scheduledJob7 = aJob().withScheduledState(now().plusMillis(2280)).build(); // third group of enqueued jobs
            final Job scheduledJob8 = aJob().withScheduledState(now().plusMillis(2300)).build();
            final Job scheduledJob9 = aJob().withScheduledState(now().plusMillis(2467)).build(); // fourth group of enqueued jobs
            final Job scheduledJob10 = aJob().withScheduledState(now().plusMillis(5400)).build(); // fifth group of enqueued jobs
            whenGetScheduledJobsThenReturn(
                    asList(scheduledJob1, scheduledJob2, scheduledJob3, scheduledJob4, scheduledJob5,
                            scheduledJob6, scheduledJob7, scheduledJob8, scheduledJob9, scheduledJob10),
                    emptyList());

            runTask(task);

            verify(storageProvider, times(1)).getJobList(any(), any());

            await()
                    .atMost(5, SECONDS)
                    .untilAsserted(() -> verify(backgroundJobServer, times(5)).scheduleAt(any(), any()));
            await()
                    .atMost(10, SECONDS)
                    .untilAsserted(() -> verify(storageProvider, times(5)).save(jobsToSaveArgumentCaptor.capture()));

            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0))
                    .hasSize(1)
                    .contains(scheduledJob1)
                    .allMatch(job -> job.hasState(ENQUEUED));

            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(1))
                    .hasSize(5)
                    .contains(scheduledJob2, scheduledJob3, scheduledJob4, scheduledJob5, scheduledJob6)
                    .allMatch(job -> job.hasState(ENQUEUED));

            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(2))
                    .hasSize(2)
                    .contains(scheduledJob7, scheduledJob8)
                    .allMatch(job -> job.hasState(ENQUEUED));

            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(3))
                    .hasSize(1)
                    .contains(scheduledJob9)
                    .allMatch(job -> job.hasState(ENQUEUED));

            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(4))
                    .hasSize(1)
                    .contains(scheduledJob10)
                    .allMatch(job -> job.hasState(ENQUEUED));

            await().untilAsserted(() -> verify(jobEnqueuedMessagePublisher, times(5)).publishJobEnqueued());
        }
    }

    @Test
    void testTaskEnqueuesJobsPer500msIfThereIsMultiplePagesOfScheduledJobsToEnqueue() {
        Instant runStartTime = Instant.parse("2023-05-25T08:04:07.00Z");
        try (MockedStatic<Instant> instantMock = mockTime(runStartTime)) {
            final List<Job> aLotOfScheduled1 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(2).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled2 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(3).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled3 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(4).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled4 = range(0, 50).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(5).plusMillis(i)).build()).collect(toList());
            whenGetScheduledJobsThenReturn(aLotOfScheduled1, aLotOfScheduled2, aLotOfScheduled3, aLotOfScheduled4, emptyList());

            runTask(task);
            
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(0))
                    .hasScheduledAtFrom(null);
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(1))
                    .hasScheduledAtFrom(runStartTime.plusMillis(3000));
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(2))
                    .hasScheduledAtFrom(runStartTime.plusMillis(4000));
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(3))
                    .hasScheduledAtFrom(runStartTime.plusMillis(5000));

            verify(backgroundJobServer, times(7)).scheduleAt(any(), any());
            await()
                    .atMost(10, SECONDS)
                    .untilAsserted(() -> verify(storageProvider, times(7)).save(jobsToSaveArgumentCaptor.capture()));
            assertThat(jobsToSaveArgumentCaptor.getValue()).hasSize(50);
            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0))
                    .allMatch(job -> job.hasState(ENQUEUED));
            verify(jobEnqueuedMessagePublisher, times(7)).publishJobEnqueued();
        }
    }

    @Test
    void testTaskEnqueuesJobsPer100msIfThereIsMaxOnePageOfScheduledJobsToEnqueue() {
        Instant runStartTime = Instant.parse("2023-05-25T08:04:07.00Z");
        try (MockedStatic<Instant> instantMock = mockTime(runStartTime)) {
            final List<Job> aLotOfScheduled1 = range(0, PAGE_REQUEST_SIZE - 1).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(2).plusMillis(i * 10)).build()).collect(toList());
            whenGetScheduledJobsThenReturn(aLotOfScheduled1);

            runTask(task);

            verify(storageProvider, times(1)).getJobList(any(), any());
            assertThat(jobSearchRequestArgumentCaptor.getValue()).hasScheduledAtFrom(null);

            verify(backgroundJobServer, times(101)).scheduleAt(any(), any());
            await()
                    .atMost(15, SECONDS)
                    .untilAsserted(() -> verify(storageProvider, times(101)).save(jobsToSaveArgumentCaptor.capture()));
            assertThat(jobsToSaveArgumentCaptor.getValue()).hasSize(8);
            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0))
                    .allMatch(job -> job.hasState(ENQUEUED));
            verify(jobEnqueuedMessagePublisher, times(101)).publishJobEnqueued();
        }
    }

    @Test
    void testTaskDoesNotScheduleJobsTwiceIfThereAreMultiplePagesOfScheduledJobsToEnqueue() {
        Instant runStartTime = Instant.parse("2023-05-25T08:04:07.00Z");
        try (MockedStatic<Instant> instantMock = mockTime(runStartTime)) {
            final List<Job> aLotOfScheduled1 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(2).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled2 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(3).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled3 = range(0, PAGE_REQUEST_SIZE).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(4).plusMillis(i)).build()).collect(toList());
            final List<Job> aLotOfScheduled4 = range(0, 50).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(5).plusMillis(i)).build()).collect(toList());
            whenGetScheduledJobsThenReturn(aLotOfScheduled1, aLotOfScheduled2, aLotOfScheduled3, aLotOfScheduled4, asList(aLotOfScheduled4.get(49)));

            runTask(task);

            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(0))
                    .hasScheduledAtFrom(null);
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(1))
                    .hasScheduledAtFrom(runStartTime.plusMillis(3000));
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(2))
                    .hasScheduledAtFrom(runStartTime.plusMillis(4000));
            assertThat(jobSearchRequestArgumentCaptor.getAllValues().get(3))
                    .hasScheduledAtFrom(runStartTime.plusMillis(5000));

            verify(backgroundJobServer, times(7)).scheduleAt(any(), any());
            await()
                    .atMost(10, SECONDS)
                    .untilAsserted(() -> verify(storageProvider, times(7)).save(jobsToSaveArgumentCaptor.capture()));
            assertThat(jobsToSaveArgumentCaptor.getValue()).hasSize(50);
            assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0))
                    .allMatch(job -> job.hasState(ENQUEUED));
            verify(jobEnqueuedMessagePublisher, times(7)).publishJobEnqueued();
        }
    }

    @Test
    void testTaskCleansStateAtTheEnd() {
        Instant runStartTime = Instant.parse("2023-05-25T08:04:07.00Z");
        try (MockedStatic<Instant> instantMock = mockTime(runStartTime)) {
            final List<Job> aLotOfScheduled1 = range(0, PAGE_REQUEST_SIZE - 1).mapToObj(i -> aJob().withScheduledState(now().plusSeconds(2).plusMillis(i * 10)).build()).collect(toList());
            whenGetScheduledJobsThenReturn(aLotOfScheduled1, emptyList());

            runTask(task);

            assertThat(task)
                    .hasFieldOrPropertyWithValue("hasMultiplePages", null)
                    .hasFieldOrPropertyWithValue("lastProcessedScheduledAtDuringTaskRun", null)
                    .hasFieldOrPropertyWithValue("maxScheduledAtDuringTaskRun", null);
        }
    }

    private void whenGetScheduledJobsThenReturn(List<Job>... jobs) {
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), any()))
                .thenReturn(jobs[0], Arrays.copyOfRange(jobs, 1, jobs.length));
    }
}