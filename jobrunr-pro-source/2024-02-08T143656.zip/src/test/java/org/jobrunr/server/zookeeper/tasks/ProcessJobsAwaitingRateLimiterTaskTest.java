package org.jobrunr.server.zookeeper.tasks;


import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.zookeeper.tasks.ratelimiters.RateLimiter;
import org.jobrunr.server.zookeeper.tasks.ratelimiters.RateLimiterConfiguration;
import org.jobrunr.storage.JobRunrMetadata;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.navigation.AmountRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.invocation.InvocationOnMock;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.ConcurrentJobRateLimiterConfiguration.concurrentJobRateLimiter;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.SlidingTimeWindowRateLimiterConfiguration.slidingTimeWindowRateLimiter;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.storage.StorageProviderUtils.Metadata.RATE_LIMITER_NAME;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;

class ProcessJobsAwaitingRateLimiterTaskTest extends AbstractZooKeeperTaskTest {

    @Captor
    ArgumentCaptor<AmountRequest> amountRequestArgumentCaptor;

    @BeforeEach
    void setUpRateLimiterInStorageProvider() {
        when(storageProvider.getMetadata(RATE_LIMITER_NAME)).thenReturn(asList(
                new JobRunrMetadata(RATE_LIMITER_NAME, "test-rate-limiter", ""),
                new JobRunrMetadata(RATE_LIMITER_NAME, "rate-limiter-1", ""),
                new JobRunrMetadata(RATE_LIMITER_NAME, "rate-limiter-2", "")
        ));
    }

    @Test
    void taskCanCreateRateLimitersUsingConfiguration() {
        // GIVEN
        when(storageProvider.getMetadata(RATE_LIMITER_NAME))
                .thenReturn(asList(
                        slidingTimeWindowRateLimiter("my-sliding-time-window-rate-limiter", "3/PT5S").toMetadata(),
                        concurrentJobRateLimiter("my-concurrent-job-rate-limiter", 2).toMetadata(),
                        myTestRateLimiterConfiguration("some-name").toMetadata()));

        // WHEN
        ProcessJobsAwaitingRateLimiterTask task = new ProcessJobsAwaitingRateLimiterTask(jobZooKeeper, backgroundJobServer);
        List<RateLimiter> rateLimiters = getInternalState(task, "rateLimiters");

        // THEN
        assertThat(rateLimiters)
                .hasSize(3)
                .allMatch(rl -> Set.of("my-sliding-time-window-rate-limiter", "my-concurrent-job-rate-limiter", "some-name").contains(rl.getName()));
    }

    @Test
    void taskEnqueues1AwaitingJobIfRateLimiterReturns1JobToEnqueue() {
        // GIVEN
        RateLimiter rateLimiter = new TestRateLimiter(1);
        ProcessJobsAwaitingRateLimiterTask task = createProcessJobsAwaitingRateLimiterTask(rateLimiter);
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), amountRequestArgumentCaptor.capture())).thenAnswer(i ->
                getAwaitingJobs(1, i));

        // WHEN
        runTask(task);

        // THEN
        verifyJobSearchRequestAndPageRequest(rateLimiter.getName(), 1);
        verify(backgroundJobServer, times(1)).scheduleAt(any(), any());
        await()
                .atMost(6, TimeUnit.SECONDS)
                .untilAsserted(() -> verify(storageProvider, times(1)).save(jobsToSaveArgumentCaptor.capture()));
        assertThat(jobsToSaveArgumentCaptor.getValue())
                .hasSize(1)
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED));
    }

    @Test
    void taskEnqueues10AwaitingJobIfRateLimiterReturns10JobToEnqueueAndGroupsThemPerSecond() {
        // GIVEN
        RateLimiter rateLimiter = new TestRateLimiter(10);
        ProcessJobsAwaitingRateLimiterTask task = createProcessJobsAwaitingRateLimiterTask(rateLimiter);
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), amountRequestArgumentCaptor.capture())).thenAnswer(i ->
                getAwaitingJobs(10, i));

        // WHEN
        runTask(task);

        // THEN
        verifyJobSearchRequestAndPageRequest(rateLimiter.getName(), 10);
        verify(backgroundJobServer, times(5)).scheduleAt(any(), any());
        await()
                .atMost(6, TimeUnit.SECONDS)
                .untilAsserted(() -> verify(storageProvider, times(5)).save(jobsToSaveArgumentCaptor.capture()));
        assertThat(jobsToSaveArgumentCaptor.getValue())
                .hasSize(2)
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED));
    }


    @Test
    void taskChecksForJobsForEachRateLimiter() {
        // GIVEN
        RateLimiter rateLimiter1 = new TestRateLimiter("rate-limiter-1", 0);
        RateLimiter rateLimiter2 = new TestRateLimiter("rate-limiter-2", 5);
        ProcessJobsAwaitingRateLimiterTask task = createProcessJobsAwaitingRateLimiterTask(rateLimiter1, rateLimiter2);
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), amountRequestArgumentCaptor.capture())).thenAnswer(i ->
                getAwaitingJobs(5, i));

        // WHEN
        runTask(task);

        // THEN
        verifyJobSearchRequestAndPageRequest(rateLimiter2.getName(), 5);
        verify(backgroundJobServer, times(5)).scheduleAt(any(), any());
        await()
                .atMost(6, TimeUnit.SECONDS)
                .untilAsserted(() -> verify(storageProvider, times(5)).save(jobsToSaveArgumentCaptor.capture()));
        assertThat(jobsToSaveArgumentCaptor.getValue())
                .hasSize(1)
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED));
    }

    @Test
    void taskDoesNotThrowIndexOutOfBoundsExceptionWhenJobsAreDividedPerSecond() {
        // GIVEN
        RateLimiter rateLimiter = new TestRateLimiter(13);
        ProcessJobsAwaitingRateLimiterTask task = createProcessJobsAwaitingRateLimiterTask(rateLimiter);
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), amountRequestArgumentCaptor.capture())).thenAnswer(i ->
                getAwaitingJobs(13, i));

        // WHEN
        runTask(task);

        // THEN
        verifyJobSearchRequestAndPageRequest(rateLimiter.getName(), 13);
        verify(backgroundJobServer, times(5)).scheduleAt(any(), any());
        await()
                .atMost(6, TimeUnit.SECONDS)
                .untilAsserted(() -> verify(storageProvider, times(5)).save(jobsToSaveArgumentCaptor.capture()));
        assertThat(jobsToSaveArgumentCaptor.getValue())
                .hasSize(1)
                .allSatisfy(job -> assertThat(job).hasStates(AWAITING, ENQUEUED));
    }

    private void verifyJobSearchRequestAndPageRequest(String rateLimiterName, int amount) {
        assertThat(jobSearchRequestArgumentCaptor.getValue())
                .hasState(AWAITING)
                .hasRateLimiter(rateLimiterName);
        assertThat(amountRequestArgumentCaptor.getValue()).usingRecursiveComparison().isEqualTo(ascOnPriorityAndUpdatedAt(amount)); // equal to POLL_INTERVAL_IN_SECONDS
    }

    List<Job> getAwaitingJobs(int amount, InvocationOnMock invocation) {
        return IntStream.range(0, amount).mapToObj(i -> toAwaitingJob(invocation)).collect(toList());
    }

    Job toAwaitingJob(InvocationOnMock invocationOnMock) {
        JobSearchRequest jobSearchRequest = invocationOnMock.getArgument(0);
        return aJob().withAwaitingRateLimiterState(jobSearchRequest.getRateLimiter()).build();
    }

    static MyTestRateLimiterConfiguration myTestRateLimiterConfiguration(String name) {
        return new MyTestRateLimiterConfiguration(name);
    }

    private ProcessJobsAwaitingRateLimiterTask createProcessJobsAwaitingRateLimiterTask(RateLimiter... rateLimiters) {
        return new ProcessJobsAwaitingRateLimiterTask(jobZooKeeper, backgroundJobServer) {
            @Override
            protected List<RateLimiter> getRateLimiters() {
                return asList(rateLimiters);
            }
        };
    }

    private static class TestRateLimiter implements RateLimiter {

        private final String rateLimiterName;
        private final int amountOfJobsToReturn;

        public TestRateLimiter(int amountOfJobsToReturn) {
            this("test-rate-limiter", amountOfJobsToReturn);
        }

        public TestRateLimiter(String rateLimiterName, int amountOfJobsToReturn) {
            this.rateLimiterName = rateLimiterName;
            this.amountOfJobsToReturn = amountOfJobsToReturn;
        }

        @Override
        public String getName() {
            return rateLimiterName;
        }

        @Override
        public int getAmountOfJobsToEnqueue() {
            return amountOfJobsToReturn;
        }

        @Override
        public void updateJobToNewState(Job job) {
            job.enqueue("Enqueued by test rate limiter");
        }
    }

    private static class MyTestRateLimiterConfiguration implements RateLimiterConfiguration {

        private final String name;

        private MyTestRateLimiterConfiguration(String name) {
            this.name = name;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getRateLimiterArgs() {
            return null;
        }

        @Override
        public Class<? extends RateLimiter> getRateLimiter() {
            return MyTestRateLimiter.class;
        }
    }

    private static class MyTestRateLimiter implements RateLimiter {

        private final String name;

        public MyTestRateLimiter(BackgroundJobServer ignored, String name) {
            this.name = name;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public int getAmountOfJobsToEnqueue() {
            return 0;
        }

        @Override
        public void updateJobToNewState(Job job) {

        }
    }
}