package org.jobrunr.server.zookeeper.tasks;

import io.github.artsok.RepeatedIfExceptionsTest;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.storage.ConcurrentRecurringJobModificationException;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.OffsetBasedPageRequest;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static java.time.Instant.now;
import static java.time.Instant.parse;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.InstantMocker.FIXED_INSTANT_ONE_MINUTE_AFTER_THE_HOUR;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_AFTER_THE_HOUR;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_ON_THE_MINUTE;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ProcessRecurringJobsTaskTest extends AbstractZooKeeperTaskTest {

    StorageProvider storageProvider;
    ProcessRecurringJobsTask task;
    @Captor
    ArgumentCaptor<RecurringJobSearchRequest> recurringJobSearchRequestArgumentCaptor;
    @Captor
    ArgumentCaptor<OffsetBasedPageRequest> pageRequestArgumentCaptor;

    @BeforeEach
    void setUpTaskDependencies() {
        InMemoryStorageProvider inMemoryStorageProvider = new InMemoryStorageProvider();
        inMemoryStorageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        storageProvider = Mockito.spy(inMemoryStorageProvider);
        setUpTaskDependencies(storageProvider);
        task = new ProcessRecurringJobsTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void testTask() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            RecurringJob aRecurringJobRunningEvery5Seconds = aDefaultRecurringJob()
                    .withId("recurring-job-every-5-seconds")
                    .withCronExpression("*/5 * * * * *")
                    .build();
            RecurringJob aRecurringJobRunningEveryHour = aDefaultRecurringJob()
                    .withId("recurring-job-every-hour")
                    .withCronExpression(Cron.hourly())
                    .build();

            storageProvider.saveRecurringJobs(List.of(aRecurringJobRunningEveryHour, aRecurringJobRunningEvery5Seconds));

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(2);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryHour.getId());
        }
    }

    @Test
    void testTaskUsesJobFilters() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            RecurringJob aRecurringJobRunningEvery5Seconds = aDefaultRecurringJob()
                    .withId("recurring-job-every-5-seconds")
                    .withCronExpression("*/5 * * * * *")
                    .build();

            storageProvider.saveRecurringJob(aRecurringJobRunningEvery5Seconds);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            assertThat(logAllStateChangesFilter.getStateChanges()).containsExactly("CREATED->SCHEDULED");
        }
    }

    @Test
    void testTaskNoRecurringJobsToRun() {
        // GIVEN NO RECURRING JOBS
        // WHEN
        runTask(task);

        // THEN
        verify(storageProvider, never()).save(any(List.class));
        verify(storageProvider, never()).getRecurringJobIdsOfJobsWithState(any());
    }

    @Test
    void testTaskTakesIntoAccountPausedRecurringJobsThatRunMoreThanOncePerMinute() {
        // GIVEN
        RecurringJob recurringJob = aDefaultRecurringJob().withId("my-recurring-job").withCronExpression("*/5 * * * * *").build();
        storageProvider.saveRecurringJob(recurringJob);
        runTask(task);
        reset(storageProvider);

        // WHEN
        recurringJob.setPaused(true);
        storageProvider.saveRecurringJob(recurringJob);
        runTask(task);

        // THEN
        verify(storageProvider, never()).save(any(List.class));
    }

    @Test
    void testTaskTakesIntoAccountPausedRecurringJobsThatRunLessThanOncePerMinute() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            RecurringJob recurringJobV1 = aDefaultRecurringJob().withId("my-recurring-job").withCronExpression(Cron.hourly()).build();
            storageProvider.saveRecurringJob(recurringJobV1);
            runTask(task);
            reset(storageProvider);

            // WHEN
            RecurringJob recurringJobV2 = storageProvider.getRecurringJobById(recurringJobV1.getId());
            recurringJobV2.setPaused(true);
            storageProvider.saveRecurringJob(recurringJobV2);
            runTask(task);

            // THEN
            verify(storageProvider, never()).save(any(List.class));
        }
    }

    @Test
    void testTaskTakesIntoAccountRecurringJobsThatRunLessThanOncePerMinute() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            RecurringJob aRecurringJobRunningEveryHour = aDefaultRecurringJob()
                    .withId("recurring-job-every-hour")
                    .withCronExpression(Cron.hourly())
                    .build();

            storageProvider.saveRecurringJob(aRecurringJobRunningEveryHour);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(1);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryHour.getId());
        }
    }

    @Test
    void testTaskTakesIntoAccountRecurringJobsThatRunLessThanOncePerMinuteAndAreCreatedRightBeforeTheirRunTime() {
        RecurringJob aRecurringJobRunningEveryHour = aDefaultRecurringJob()
                .withId("recurring-job-every-hour")
                .withCronExpression(Cron.hourly())
                .withCreatedAt(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)
                .build();

        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_ONE_MINUTE_AFTER_THE_HOUR)) {
            storageProvider.saveRecurringJob(aRecurringJobRunningEveryHour);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(1);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryHour.getId());
        }
    }

    @Test
    void testTaskTakesIntoAccountRecurringJobsThatRunExactlyOncePerMinute() {
        RecurringJob aRecurringJobRunningEveryMinute = aDefaultRecurringJob()
                .withId("recurring-job-every-minute")
                .withCronExpression(Cron.minutely())
                .withCreatedAt(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE)
                .build();

        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE.plusSeconds(3))) {
            storageProvider.saveRecurringJob(aRecurringJobRunningEveryMinute);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(1);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryMinute.getId());
        }
    }

    @Test
    void testTaskTakesIntoAccountRecurringJobsThatRunExactlyOncePerMinuteWithLastRunInThePastAndWithoutScheduleSkippedJobsDuringDowntime() {
        RecurringJob aRecurringJobRunningEveryMinute = aDefaultRecurringJob()
                .withId("recurring-job-every-minute")
                .withCronExpression(Cron.minutely())
                .withLastRun(FIXED_INSTANT_RIGHT_ON_THE_MINUTE)
                .build();

        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE.plusSeconds(120))) {
            storageProvider.saveRecurringJob(aRecurringJobRunningEveryMinute);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(1);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryMinute.getId());
        }
    }

    @Test
    void testTaskSchedulesJobsThatRunExactlyOncePerMinuteImmediateOnStartupSoTheyKeepRunningCorrectly() {
        RecurringJob aRecurringJobRunningEveryMinute = aDefaultRecurringJob()
                .withId("recurring-job-every-minute")
                .withCronExpression("30 * * * * *")
                .withLastRun(FIXED_INSTANT_RIGHT_ON_THE_MINUTE)
                .build();

        // GIVEN FIRST RUN
        try (MockedStatic<Instant> ignored = mockTime(parse("2023-04-26T21:04:27.509Z"))) {
            storageProvider.saveRecurringJob(aRecurringJobRunningEveryMinute);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> scheduledJobs = jobsToSaveArgumentCaptor.getValue();
            assertThat(scheduledJobs).hasSize(2);
            Job savedJob = scheduledJobs.get(0);
            assertThat(savedJob)
                    .hasState(SCHEDULED)
                    .hasRecurringJobId(aRecurringJobRunningEveryMinute.getId());
        }
    }

    @Test
    void testTaskTakesIntoAccountRecurringJobsThatRunExactlyOncePerMinuteButJobAlreadyRan() {
        RecurringJob aRecurringJobRunningEveryHour = aDefaultRecurringJob()
                .withId("recurring-job-every-minute")
                .withCronExpression(Cron.minutely())
                .withLastRun(FIXED_INSTANT_RIGHT_ON_THE_MINUTE)
                .build();

        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE)) {
            storageProvider.saveRecurringJob(aRecurringJobRunningEveryHour);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider, never()).save(jobsToSaveArgumentCaptor.capture());
        }
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void taskSchedulesRecurringJobsSkippedDuringDowntime() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // GIVEN
            RecurringJob recurringJobScheduleJobsDuringDowntime = aDefaultRecurringJob()
                    .withId("id-schedule-jobs-during-downtime")
                    .withName("recurring job to schedule during downtime")
                    .withCronExpression("* * * * *")
                    .withLastRun(now().minusSeconds(185))
                    .withScheduleJobsSkippedDuringDowntime()
                    .build();
            RecurringJob recurringJobDoNotScheduleJobsDuringDowntime = aDefaultRecurringJob()
                    .withId("id-do-not-schedule-jobs-during-downtime")
                    .withName("recurring job not to schedule during downtime")
                    .withCronExpression("* * * * *")
                    .withLastRun(now().minusSeconds(185))
                    .build();

            storageProvider.saveRecurringJobs(List.of(recurringJobScheduleJobsDuringDowntime, recurringJobDoNotScheduleJobsDuringDowntime));

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> jobsToSchedule = jobsToSaveArgumentCaptor.getValue();
            assertThat(jobsToSchedule).hasSize(5);

            assertThat(jobsToSchedule.stream().filter(j -> "id-do-not-schedule-jobs-during-downtime".equals(j.getRecurringJobId().orElse(null))).collect(toList()))
                    .hasSize(1);
            assertThat(jobsToSchedule.stream().filter(j -> "id-schedule-jobs-during-downtime".equals(j.getRecurringJobId().orElse(null))).collect(toList()))
                    .hasSize(4);
        }
    }

    @Test
    void taskSchedulesRecurringJobsSkippedDuringDowntimeDoesNotScheduleALotOfJobsIfItHasNotRunYet() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // GIVEN
            RecurringJob recurringJobScheduleJobsDuringDowntime = aDefaultRecurringJob()
                    .withId("id-schedule-jobs-during-downtime")
                    .withName("recurring job to schedule during downtime")
                    .withCronExpression("* * * * *")
                    .withLastRun(null)
                    .withScheduleJobsSkippedDuringDowntime()
                    .build();
            RecurringJob recurringJobDoNotScheduleJobsDuringDowntime = aDefaultRecurringJob()
                    .withId("id-do-not-schedule-jobs-during-downtime")
                    .withName("recurring job not to schedule during downtime")
                    .withCronExpression("* * * * *")
                    .withLastRun(null)
                    .build();

            storageProvider.saveRecurringJobs(List.of(recurringJobScheduleJobsDuringDowntime, recurringJobDoNotScheduleJobsDuringDowntime));

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
            List<Job> jobsToSchedule = jobsToSaveArgumentCaptor.getValue();
            assertThat(jobsToSchedule).hasSize(2);

            assertThat(jobsToSchedule.stream().filter(j -> "id-do-not-schedule-jobs-during-downtime".equals(j.getRecurringJobId().orElse(null))).collect(toList()))
                    .hasSize(1);
            assertThat(jobsToSchedule.stream().filter(j -> "id-schedule-jobs-during-downtime".equals(j.getRecurringJobId().orElse(null))).collect(toList()))
                    .hasSize(1);
        }
    }

    @Test
    void onlyRecurringJobsThatRunLessThanOncePerMinuteAndNeedToBeTriggeredAreFetched() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // GIVEN
            RecurringJob recurringJob = aDefaultRecurringJob().withCronExpression("0 * * * * *").build();
            storageProvider.saveRecurringJob(recurringJob);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider, times(2)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            assertThat(recurringJobSearchRequestArgumentCaptor.getAllValues()).hasSize(2);
            RecurringJobSearchRequest searchRequest = recurringJobSearchRequestArgumentCaptor.getAllValues().get(0);
            assertThat(searchRequest)
                    .hasNextRunTo(parse("2022-12-13T14:01:00Z"))
                    .hasPaused(false);
        }
    }

    @Test
    void ifRecurringJobsThatRunLessThanOncePerMinuteAlreadyFetchedAndEnqueuedTheyAreNotFetchedOnNextRun() {
        // GIVEN
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_AFTER_THE_HOUR)) {
            // GIVEN IT HAS ALREADY RUN 15 SECONDS AGO
            Whitebox.setInternalState(task, "recurringJobsThatRunLessThanOncePerMinuteLastUpdate", FIXED_INSTANT_RIGHT_AFTER_THE_HOUR.minusSeconds(15));

            // GIVEN
            RecurringJob recurringJobEvery30Seconds = aDefaultRecurringJob().withId("every-30-sec").withCronExpression(Cron.every30seconds()).build();
            RecurringJob recurringJobEveryMinute = aDefaultRecurringJob().withId("every-1-min").withCronExpression(Cron.minutely()).build();
            storageProvider.saveRecurringJobs(List.of(recurringJobEvery30Seconds, recurringJobEveryMinute));

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider, times(1)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            assertThat(recurringJobSearchRequestArgumentCaptor.getValue())
                    .hasRunsMoreThanOncePerMinute(true);
        }
    }

    @Test
    void onlyRecurringJobsThatRunMoreThanOncePerMinuteAndHaveBeenUpdatedAreFetched() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_AFTER_THE_HOUR)) {
            // GIVEN
            RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("*/5 * * * * *")
                    .build();
            storageProvider.saveRecurringJob(recurringJob);

            // WHEN ON FIRST RUN
            runTask(task);

            // THEN ON FIRST RUN updatedAt = Instant.EPOCH;
            verify(storageProvider, times(2)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest firstRunSearchRequest = recurringJobSearchRequestArgumentCaptor.getAllValues().get(1);
            assertThat(firstRunSearchRequest).hasUpdatedAtFrom(Instant.EPOCH);

            // WHEN ON SECOND RUN
            reset(storageProvider);
            runTask(task);

            // THEN ON SECOND RUN updatedAt = max instant of recurring jobs;
            verify(storageProvider, times(1)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest searchRequest = recurringJobSearchRequestArgumentCaptor.getAllValues().get(2);
            assertThat(searchRequest).hasUpdatedAtFrom(FIXED_INSTANT_RIGHT_AFTER_THE_HOUR.plusMillis(1));
        }
    }

    @Test
    void onlyRecurringJobsThatRunMoreThanOncePerMinuteAndHaveBeenUpdatedAreFetchedUsingLastUpdatedTimestampOfRecurringJob() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_AFTER_THE_HOUR)) {
            // GIVEN NO RECURRING JOBS

            // WHEN ON FIRST RUN
            runTask(task);

            // THEN ON FIRST RUN updatedAt = Instant.EPOCH;
            verify(storageProvider, times(2)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest searchRequest1 = recurringJobSearchRequestArgumentCaptor.getAllValues().get(1);
            assertThat(searchRequest1).hasUpdatedAtFrom(Instant.EPOCH);

            // WHEN ON SECOND RUN
            reset(storageProvider);
            runTask(task);

            // THEN ON SECOND RUN updatedAt = Instant.EPOCH;
            verify(storageProvider, times(1)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest searchRequest2 = recurringJobSearchRequestArgumentCaptor.getAllValues().get(2);
            assertThat(searchRequest2).hasUpdatedAtFrom(Instant.EPOCH);

            // GIVEN RECURRING JOB THAT RUNS MORE THAN ONCE PER MINUTE IS SAVED
            Instant recurringJobUpdatedAt = FIXED_INSTANT_RIGHT_AFTER_THE_HOUR.minusMillis(2);
            RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("*/5 * * * * *")
                    .withUpdatedAt(recurringJobUpdatedAt)
                    .build();
            storageProvider.saveRecurringJob(recurringJob);

            // WHEN ON THIRD RUN
            reset(storageProvider);
            runTask(task);

            // THEN ON THIRD RUN updatedAt = Instant.EPOCH;
            verify(storageProvider, times(1)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest searchRequest3 = recurringJobSearchRequestArgumentCaptor.getAllValues().get(3);
            assertThat(searchRequest3).hasUpdatedAtFrom(Instant.EPOCH);

            // WHEN ON FOURTH RUN
            reset(storageProvider);
            runTask(task);

            // THEN ON FOURTH RUN updatedAt = max instant of recurring jobs;
            verify(storageProvider, times(1)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            RecurringJobSearchRequest searchRequest4 = recurringJobSearchRequestArgumentCaptor.getAllValues().get(4);
            assertThat(searchRequest4).hasUpdatedAtFrom(recurringJobUpdatedAt.plusMillis(1));
        }
    }

    @Test
    void ifALotOfRecurringJobsNeedToBeTriggeredTheyAreAllFetched() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // GIVEN
            List<RecurringJob> aLotOfRecurringJobs = createALotOfRecurringJobs(Cron.hourly(), 5500);
            storageProvider.saveRecurringJobs(aLotOfRecurringJobs);

            // WHEN
            runTask(task);

            // THEN
            verify(storageProvider, times(3)).getRecurringJobs(recurringJobSearchRequestArgumentCaptor.capture(), pageRequestArgumentCaptor.capture());
            assertThat(recurringJobSearchRequestArgumentCaptor.getAllValues()).hasSize(3);
            assertThat(pageRequestArgumentCaptor.getAllValues()).hasSize(3);
            assertThat(pageRequestArgumentCaptor.getAllValues().get(0).getOffset()).isEqualTo(0);
            assertThat(pageRequestArgumentCaptor.getAllValues().get(1).getOffset()).isEqualTo(5000);

            ArgumentCaptor<List<Job>> createdJobsArgumentCaptor = ArgumentCaptor.forClass(List.class);
            verify(storageProvider, times(1)).save(createdJobsArgumentCaptor.capture());
            assertThat(createdJobsArgumentCaptor.getValue()).hasSize(5500);
        }
    }

    @Test
    void taskDoesNotScheduleSameJobIfItIsAlreadyScheduledEnqueuedOrProcessed() {
        // GIVEN
        RecurringJob recurringJob = aDefaultRecurringJob().withId("id1").withCronExpression("*/5 * * * * *").build();
        storageProvider.saveRecurringJob(recurringJob);
        mockRunningRecurringJob(List.of("id1"));

        // WHEN
        runTask(task);

        // THEN
        verify(storageProvider, never()).save(anyList());
        verify(storageProvider, never()).saveRecurringJobs(anyList());
    }

    @Test
    void taskDoesScheduleSameJobIfConcurrentJobsIsAllowedAndItIsAlreadyScheduledEnqueuedOrProcessed() {
        // GIVEN
        RecurringJob recurringJob = aDefaultRecurringJob()
                .withId("id1")
                .withCronExpression("*/5 * * * * *")
                .withMaxConcurrentJobs(2)
                .build();
        storageProvider.saveRecurringJob(recurringJob);
        mockRunningRecurringJob(List.of("id1"));

        // WHEN
        runTask(task);

        // THEN
        verify(storageProvider, times(1)).save(anyList());
        verify(storageProvider, never()).saveRecurringJobs(anyList());
    }

    @Test
    void taskDoesNotScheduleSameJobIfConcurrentJobsIsLimitingAlreadyScheduledEnqueuedOrProcessedJobs() {
        // GIVEN
        RecurringJob recurringJob = aDefaultRecurringJob()
                .withId("id1")
                .withCronExpression("*/5 * * * * *")
                .withMaxConcurrentJobs(2)
                .build();
        storageProvider.saveRecurringJob(recurringJob);
        mockRunningRecurringJob(List.of("id1", "id1"));

        // WHEN
        runTask(task);

        // THEN
        verify(storageProvider, never()).save(anyList());
        verify(storageProvider, never()).saveRecurringJobs(anyList());
    }

    @Test
    void taskCanHandleConcurrentRecurringJobModificationExceptions() {
        try (MockedStatic<Instant> ignored = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            // GIVEN
            RecurringJob recurringJob1 = aDefaultRecurringJob().withId("recurring-job-A").withCronExpression(Cron.minutely()).build();
            RecurringJob recurringJob2 = aDefaultRecurringJob().withId("recurring-job-B").withCronExpression(Cron.minutely()).build();
            storageProvider.saveRecurringJob(recurringJob1);
            storageProvider.saveRecurringJob(recurringJob2);
            when(storageProvider.saveRecurringJobs(anyList()))
                    .thenThrow(new ConcurrentRecurringJobModificationException(recurringJob2))
                    .thenAnswer(i -> i.getArgument(0, List.class));

            // WHEN ON FIRST RUN
            runTask(task);

            // THEN
            verify(storageProvider, times(2)).saveRecurringJobs(anyList());
        }
    }

    @RepeatedIfExceptionsTest(repeats = 3)
    void taskSchedulesJobsThatWereMissedDuringStopTheWorldGC() {
        RecurringJob recurringJob = aDefaultRecurringJob().withCronExpression("*/5 * * * * *").build();

        mockStorageProvider(List.of(recurringJob), emptyList());

        runTask(task);
        sleep(10500);
        runTask(task);

        verify(storageProvider, times(2)).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue())
                .hasSizeBetween(2, 3)
                .extracting(Job::getState)
                .containsOnly(SCHEDULED);
    }

    private void mockStorageProvider(List<RecurringJob> recurringJobs, List<String> runningRecurringJobs) {
        storageProvider.saveRecurringJobs(recurringJobs);
        lenient().when(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED, ENQUEUED, PROCESSING)).thenReturn(runningRecurringJobs);
    }

    private void mockRunningRecurringJob(List<String> runningRecurringJobs) {
        lenient().when(storageProvider.getRecurringJobIdsOfJobsWithState(SCHEDULED, ENQUEUED, PROCESSING)).thenReturn(runningRecurringJobs);
    }

    private List<RecurringJob> createALotOfRecurringJobs(String cronExpression, int amount) {
        List<RecurringJob> aLotOfRecurringJobs = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            RecurringJob recurringJob = aDefaultRecurringJob()
                    .withId("recurring-job-every-hour-" + i)
                    .withName("recurring job " + i)
                    .withCronExpression(cronExpression)
                    .build();
            aLotOfRecurringJobs.add(recurringJob);
        }
        return aLotOfRecurringJobs;
    }
}