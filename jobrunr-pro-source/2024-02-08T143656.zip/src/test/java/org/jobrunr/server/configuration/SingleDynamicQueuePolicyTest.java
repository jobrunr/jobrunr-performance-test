package org.jobrunr.server.configuration;

import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.strategy.SingleDynamicQueueStrategy;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class SingleDynamicQueuePolicyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;

    @Test
    void testSingleDynamicQueuePolicy() {
        SingleDynamicQueuePolicy singleDynamicQueuePolicy = new SingleDynamicQueuePolicy();

        assertThat(singleDynamicQueuePolicy.getDynamicQueueProvider()).isNull();
        assertThat(singleDynamicQueuePolicy.createDynamicQueueStrategy(backgroundJobServer)).isInstanceOf(SingleDynamicQueueStrategy.class);
    }
}