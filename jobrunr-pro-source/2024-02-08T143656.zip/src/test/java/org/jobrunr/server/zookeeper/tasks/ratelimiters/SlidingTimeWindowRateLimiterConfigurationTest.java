package org.jobrunr.server.zookeeper.tasks.ratelimiters;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.server.zookeeper.tasks.ratelimiters.SlidingTimeWindowRateLimiterConfiguration.slidingTimeWindowRateLimiter;

class SlidingTimeWindowRateLimiterConfigurationTest {

    @Test
    void testValidConfiguration() {
        assertThatCode(() -> slidingTimeWindowRateLimiter("my-rate-limiter", "5/PT5S"))
                .doesNotThrowAnyException();
    }

    @Test
    void testInvalidConfiguration() {
        assertThatCode(() -> slidingTimeWindowRateLimiter("my-rate-limiter", "5"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The amount per duration value for Rate Limiter 'my-rate-limiter' has a wrong format (it should be amount/ISO duration, e.g. 2/PT5S).");

        assertThatCode(() -> slidingTimeWindowRateLimiter("my-rate-limiter", "PT5S"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The amount per duration value for Rate Limiter 'my-rate-limiter' has a wrong format (it should be amount/ISO duration, e.g. 2/PT5S).");

        assertThatCode(() -> slidingTimeWindowRateLimiter("my-rate-limiter", "haha/PT5S"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The amount per duration value for Rate Limiter 'my-rate-limiter' has a wrong format (it should be amount/ISO duration, e.g. 2/PT5S).");

        assertThatCode(() -> slidingTimeWindowRateLimiter("my-rate-limiter", "5/HAHA"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The amount per duration value for Rate Limiter 'my-rate-limiter' has a wrong format (it should be amount/ISO duration, e.g. 2/PT5S).");

        String rateLimiterNameThatIsTooLong = "a".repeat(65);
        assertThatCode(() -> slidingTimeWindowRateLimiter(rateLimiterNameThatIsTooLong, "5/PT5S"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The Rate Limiter name '" + rateLimiterNameThatIsTooLong + "' should not exceed 64 characters");
    }

}