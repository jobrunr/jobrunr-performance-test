package org.jobrunr.server.metrics;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.cumulative.CumulativeTimer;
import io.micrometer.core.instrument.observation.DefaultMeterObservationHandler;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.queues.Queues;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.mappers.MDCMapper.OTEL_SPAN_ID_KEY;
import static org.jobrunr.jobs.mappers.MDCMapper.OTEL_TRACE_ID_KEY;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;

class MicroMeterJobObservabilityTest {

    ObservationRegistry observationRegistry;

    SimpleMeterRegistry simpleMeterRegistry = new SimpleMeterRegistry();

    MicroMeterJobObservability microMeterJobObservability;

    @BeforeEach
    void setupMicroMeterJobObservability() {
        MDC.clear();

        observationRegistry = ObservationRegistry.create();
        observationRegistry.observationConfig().observationHandler(new DefaultMeterObservationHandler(simpleMeterRegistry));
        microMeterJobObservability = new MicroMeterJobObservability(observationRegistry, new Queues());
    }

    @Test
    void testMicroMeterJobObservabilityPublishesEventWhenJobIsCreated() throws InterruptedException {
        // GIVEN
        Job job = anEnqueuedJob().build();

        // WHEN
        MDC.put(OTEL_TRACE_ID_KEY, "abc");
        MDC.put(OTEL_SPAN_ID_KEY, "def");
        Observation observation = Observation.createNotStarted("jobrunr.jobs", observationRegistry);
        observation.start();
        try (Observation.Scope scope = observation.openScope()) {
            microMeterJobObservability.onCreated(job);
        }
        observation.stop();

        // THEN
        Meter meter = getMeter(simpleMeterRegistry.getMeters(), "jobrunr.jobs.jobrunr.job.created");
        assertThat(meter)
                .hasValue(1.0);
    }

    @Test
    void testMicroMeterJobObservabilityStoresTraceIdAndSpanId() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();

        // WHEN
        MDC.put(OTEL_TRACE_ID_KEY, "abc");
        MDC.put(OTEL_SPAN_ID_KEY, "def");
        microMeterJobObservability.onProcessing(job);
        microMeterJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(job)
                .hasMetadata(OTEL_TRACE_ID_KEY, "abc")
                .hasMetadata(OTEL_SPAN_ID_KEY, "def");
    }

    @Test
    void testMicroMeterJobObservabilityDoesNotThrowErrorIfMDCDoesNotContainTraceIdOrSpanId() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress().build();

        // WHEN
        microMeterJobObservability.onProcessing(job);
        microMeterJobObservability.onProcessingSucceeded(job);

        // THEN
        assertThat(job)
                .hasNoMetadata();
    }

    @Test
    void testDefaultMeterTags() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();
        microMeterJobObservability.onProcessing(job);
        Thread.sleep(140);
        microMeterJobObservability.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue");
        });
    }

    @Test
    void testDefaultMeterTagsAndHighCardinalityEvents() throws InterruptedException {
        // GIVEN
        Job job = aScheduledJob()
                .withRecurringJobId("a recurring job")
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .withEnqueuedState()
                .withProcessingState()
                .build();
        microMeterJobObservability.onProcessing(job);
        Thread.sleep(140);
        microMeterJobObservability.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name")
                    .hasIdWithTag("job.server-tag", "server A")
                    .hasIdWithTag("job.dynamic-queue", "my dynamic queue");
        });
    }

    @Test
    void testScheduledJobThatWasFailedBefore() throws InterruptedException {
        Job job = aFailedJob()
                .withScheduledState()
                .withEnqueuedState()
                .withProcessingState()
                .build();

        microMeterJobObservability.onProcessing(job);
        Thread.sleep(140);
        microMeterJobObservability.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        assertThat(meters).hasSize(2);
        meters.forEach(meter -> {
            assertThat(meter)
                    .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                    .hasIdWithTag("job.background-job-server.name", "test-server-name")
                    .hasIdWithTag("job.server-tag", "DEFAULT");
        });
    }

    @Test
    void testSucceededJobMeterTags() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();
        microMeterJobObservability.onProcessing(job);
        Thread.sleep(140);
        microMeterJobObservability.onProcessingSucceeded(job);

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        CumulativeTimer meter = getMeter(meters, "jobrunr.jobs");
        assertThat(meter)
                .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                .hasIdWithTag("job.background-job-server.name", "test-server-name")
                .hasIdWithTag("job.server-tag", "server A")
                .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                .hasIdWithTag("job.state", SUCCEEDED.name());
    }

    @Test
    void testFailedJobMeterTags() throws InterruptedException {
        // GIVEN
        Job job = aJobInProgress()
                .withServerTag("server A")
                .withDynamicQueue("my dynamic queue")
                .build();
        microMeterJobObservability.onProcessing(job);
        Thread.sleep(140);
        microMeterJobObservability.onProcessingFailed(job, new IllegalStateException());

        // WHEN
        List<Meter> meters = simpleMeterRegistry.getMeters();

        // THEN
        CumulativeTimer meter = getMeter(meters, "jobrunr.jobs");
        assertThat(meter)
                .hasIdWithTag("job.signature", "java.lang.System.out.println(java.lang.String)")
                .hasIdWithTag("job.background-job-server.name", "test-server-name")
                .hasIdWithTag("job.server-tag", "server A")
                .hasIdWithTag("job.dynamic-queue", "my dynamic queue")
                .hasIdWithTag("job.state", FAILED.name());
    }

    private static <T extends Meter> T getMeter(List<Meter> meters, String name) {
        return (T) meters.stream().filter(m -> name.equals(m.getId().getName())).findFirst().orElseThrow();
    }
}