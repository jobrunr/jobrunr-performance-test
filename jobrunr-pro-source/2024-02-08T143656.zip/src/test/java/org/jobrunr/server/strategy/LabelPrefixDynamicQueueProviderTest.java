package org.jobrunr.server.strategy;

import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.Test;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;

class LabelPrefixDynamicQueueProviderTest {

    @Test
    void testLabelPrefix() {
        LabelPrefixDynamicQueueProvider dynamicQueueProvider = new LabelPrefixDynamicQueueProvider("tenant");

        Job jobTenantA = anEnqueuedJob().withLabels("tenant:Tenant-A").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantA);
        assertThat(jobTenantA).hasDynamicQueue("Tenant-A");

        Job jobTenantB = anEnqueuedJob().withLabels("tenant:Tenant-B").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantB);
        assertThat(jobTenantB).hasDynamicQueue("Tenant-B");

        Job jobTenantC = anEnqueuedJob().withLabels("tenant: Tenant-C").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantC);
        assertThat(jobTenantC).hasDynamicQueue("Tenant-C");

        Job unrelatedJob = anEnqueuedJob().withLabels("unrelated label").build();
        dynamicQueueProvider.setDynamicQueueOnJob(unrelatedJob);
        assertThat(unrelatedJob).hasNoDynamicQueue();

        Job withoutLabelJob = anEnqueuedJob().build();
        dynamicQueueProvider.setDynamicQueueOnJob(withoutLabelJob);
        assertThat(withoutLabelJob).hasNoDynamicQueue();
    }

    @Test
    void testLabelPrefixWithColon() {
        LabelPrefixDynamicQueueProvider dynamicQueueProvider = new LabelPrefixDynamicQueueProvider("tenant:");

        Job jobTenantA = anEnqueuedJob().withLabels("tenant:Tenant-A").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantA);
        assertThat(jobTenantA).hasDynamicQueue("Tenant-A");

        Job jobTenantB = anEnqueuedJob().withLabels("tenant:Tenant-B").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantB);
        assertThat(jobTenantB).hasDynamicQueue("Tenant-B");

        Job jobTenantC = anEnqueuedJob().withLabels("tenant: Tenant-C").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantC);
        assertThat(jobTenantC).hasDynamicQueue("Tenant-C");
    }

    @Test
    void testLabelPrefixWithCustomSeparator() {
        LabelPrefixDynamicQueueProvider dynamicQueueProvider = new LabelPrefixDynamicQueueProvider("cus", "-");

        Job jobTenantA = anEnqueuedJob().withLabels("cus-134").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantA);
        assertThat(jobTenantA).hasDynamicQueue("134");
    }

    @Test
    void testLabelPrefixWithCustomSeparatorMultipleTimesInLabel() {
        LabelPrefixDynamicQueueProvider dynamicQueueProvider = new LabelPrefixDynamicQueueProvider("cus", "/");

        Job jobTenantA = anEnqueuedJob().withLabels("cus/123/789").build();
        dynamicQueueProvider.setDynamicQueueOnJob(jobTenantA);
        assertThat(jobTenantA).hasDynamicQueue("123/789");
    }
}