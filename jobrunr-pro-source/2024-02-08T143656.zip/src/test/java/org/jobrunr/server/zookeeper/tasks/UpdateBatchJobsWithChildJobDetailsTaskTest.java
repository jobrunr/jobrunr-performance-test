package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.storage.StorageProvider.BatchJobChildStats;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import java.util.List;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aProcessedBatchJob;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UpdateBatchJobsWithChildJobDetailsTaskTest extends AbstractZooKeeperTaskTest {

    UpdateBatchJobsWithChildJobDetailsTask task;

    @BeforeEach
    void setUpTask() {
        task = new UpdateBatchJobsWithChildJobDetailsTask(jobZooKeeper, backgroundJobServer) {
            @Override
            protected void clearJobs() {
                // needed for Mockito as otherwise capture fails?
            }
        };
    }

    @Test
    void updateBatchJobsWithChildJobWhileChildJobsNotYetProcessedThenStateChangeFilterNotApplied() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 0L, 0L);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        Job job = jobsToSaveArgumentCaptor.getValue().get(0);
        assertThat(job).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isFalse();
    }

    @Test
    void updateBatchJobsWithChildJobWhileChildJobsStillProcessingThenStateChangeFilterNotApplied() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 2L, 0L);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
    }

    @Test
    void updateBatchJobsWithChildJobWhileChildJobsStillProcessingAndSomeFailedThenStateChangeFilterNotApplied() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 2L, 2L);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
    }

    @Test
    void updateBatchJobsWithChildJobDetailsNoFailedChildJobs() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 5L, 0L);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0))
                .hasState(SUCCEEDED)
                .hasDeletedAtNotNull();
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->SUCCEEDED");
    }

    @Test
    void updateBatchJobsWithChildJobDetailsWithFailedChildJobs() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 4L, 1L);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->FAILED");
    }

    @Test
    void updateBatchJobsWithChildJobDetailsWithFailedChildJobsMultipleRuns() {
        final BatchJob batchJob = aProcessedBatchJob().build();

        mockStorageProvider(batchJob, 5L, 0L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 2L, 1L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 2L, 2L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 2L, 3L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->FAILED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isTrue();
        clearInvocations(storageProvider);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);


        mockStorageProvider(batchJob, 5L, 2L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("FAILED->PROCESSED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 5L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(SUCCEEDED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);
    }

    @Test
    void updateBatchJobsWithChildJobDetailsWithFailedChildJobsThatFailsImmediately() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 0L, 1L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 0L, 2L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 0L, 3L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 0L, 5L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->FAILED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isTrue();
        clearInvocations(storageProvider);


        mockStorageProvider(batchJob, 5L, 2L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("FAILED->PROCESSED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 5L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(SUCCEEDED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);
    }

    @Test
    void updateBatchJobsWithChildJobDetailsWithSucceededAndFailedChildJobsMultipleRuns() {
        final BatchJob batchJob = aProcessedBatchJob().build();
        mockStorageProvider(batchJob, 5L, 2L, 1L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 2L, 2L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 2L, 3L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->FAILED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isTrue();
        clearInvocations(storageProvider);

        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(FAILED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);


        mockStorageProvider(batchJob, 5L, 2L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(PROCESSED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("FAILED->PROCESSED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);

        mockStorageProvider(batchJob, 5L, 5L, 0L);
        runTask(task);
        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getValue().get(0)).hasState(SUCCEEDED);
        assertThat(logAllStateChangesFilter.getStateChanges(batchJob)).containsExactly("PROCESSED->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(batchJob)).isFalse();
        assertThat(logAllStateChangesFilter.onBatchJobSucceededIsCalled(batchJob)).isTrue();
        assertThat(logAllStateChangesFilter.onBatchJobFailedIsCalled(batchJob)).isFalse();
        clearInvocations(storageProvider);
    }

    public <T> void clearInvocations(T... mocks) {
        Mockito.clearInvocations(mocks);
        ((List) Whitebox.getInternalState(task, "jobsWithStateChanges")).clear();
        ((List) Whitebox.getInternalState(task, "jobsWithoutStateChanges")).clear();
        logAllStateChangesFilter.clear();
    }

    public void mockStorageProvider(BatchJob batchJob, Long totalCount, Long succeededChildCount, Long failedChildCount) {
        when(storageProvider.getBatchJobs(PROCESSED, FAILED)).thenReturn(List.of(batchJob));
        when(storageProvider.getBatchJobsChildStats(List.of(batchJob.getId()))).thenReturn(List.of(new BatchJobChildStats(batchJob.getId(), totalCount, succeededChildCount, failedChildCount)));
    }

}