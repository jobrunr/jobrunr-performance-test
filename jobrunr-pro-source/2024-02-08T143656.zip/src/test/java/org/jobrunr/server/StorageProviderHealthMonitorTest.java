package org.jobrunr.server;

import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StorageProviderHealthMonitorTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    StorageProvider storageProvider;

    @Mock
    Runnable runnable;

    StorageProviderHealthMonitor healthMonitor;


    @BeforeEach
    void setUp() {
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);

        healthMonitor = new StorageProviderHealthMonitor(backgroundJobServer, runnable);
        reset(backgroundJobServer);
    }

    @Test
    void onlyIfStorageProviderHealthIsHealthy3TimesInARowItStartsTheBackgroundJobServerAgain() {
        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verify(backgroundJobServer).start();
    }

    @Test
    void ifStorageProviderHealthIsFlakyThenBackgroundJobServerIsNotStarted() {
        when(storageProvider.isUnHealthy()).thenReturn(false, true, false, true);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);

        healthMonitor.run();
        verifyNoInteractions(backgroundJobServer);
    }
}