package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.server.LogAllStateChangesFilter;
import org.jobrunr.storage.JobSearchRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ProcessOrphanedJobsTaskTest extends AbstractZooKeeperTaskTest {

    LogAllStateChangesFilter logAllStateChangesFilter;
    ProcessOrphanedJobsTask task;

    @BeforeEach
    void setUpTask() {
        logAllStateChangesFilter = new LogAllStateChangesFilter();
        when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID(), logAllStateChangesFilter));
        task = new ProcessOrphanedJobsTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void testTask() {
        final Job orphanedJob = aJobInProgress().build();
        when(storageProvider.getJobList(refEq(new JobSearchRequest(PROCESSING), "updatedAtTo"), any()))
                .thenReturn(singletonList(orphanedJob), emptyList());

        runTask(task);

        verify(storageProvider).save(jobsToSaveArgumentCaptor.capture());
        assertThat(jobsToSaveArgumentCaptor.getAllValues().get(0).get(0)).hasStates(ENQUEUED, PROCESSING, FAILED, SCHEDULED);
        assertThat(logAllStateChangesFilter.getStateChanges(orphanedJob)).containsExactly("PROCESSING->FAILED", "FAILED->SCHEDULED");
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(orphanedJob)).isTrue();
    }

}