package org.jobrunr.server.concurrent.statechanges;

import org.jobrunr.jobs.Job;
import org.jobrunr.server.concurrent.ConcurrentJobModificationResolveResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;

class EnqueuedFromScheduledConcurrentStateChangeTest {

    EnqueuedFromScheduledConcurrentStateChange allowedStateChange;

    @BeforeEach
    public void setUp() {
        allowedStateChange = new EnqueuedFromScheduledConcurrentStateChange();
    }

    @Test
    void ifJobIsEnqueuedAndWasScheduledBeforeItMayBeTakenTwiceFromStorageAndThusItWillBeEnqueuedTwice() {
        final Job anEnqueuedJob1 = aScheduledJob().withEnqueuedState().build();
        final Job anEnqueuedJob2 = aScheduledJob().withEnqueuedState().build();

        assertThat(allowedStateChange.matches(anEnqueuedJob1, anEnqueuedJob2)).isTrue();

        final ConcurrentJobModificationResolveResult resolveResult = allowedStateChange.resolve(anEnqueuedJob1, anEnqueuedJob2);
        assertThat(resolveResult.failed()).isFalse();
    }

    @Test
    void ifJobIsEnqueuedAndWasScheduledBeforeItMayBeTakenTwiceFromStorageAndThusItWillBeEnqueuedAgainAlthoughAlreadyProcessing() {
        final Job anEnqueuedJob = aScheduledJob().withEnqueuedState().build();
        final Job aJobInProgress = aScheduledJob().withEnqueuedState().withProcessingState().build();

        assertThat(allowedStateChange.matches(anEnqueuedJob, aJobInProgress)).isTrue();

        final ConcurrentJobModificationResolveResult resolveResult = allowedStateChange.resolve(anEnqueuedJob, aJobInProgress);
        assertThat(resolveResult.failed()).isFalse();
    }

    @Test
    void ifLocalJobIsEnqueuedAndWasNotScheduledBeforeItDoesNotMatch() {
        final Job anEnqueuedJob1 = anEnqueuedJob().build();
        final Job anEnqueuedJob2 = aScheduledJob().withEnqueuedState().build();

        assertThat(allowedStateChange.matches(anEnqueuedJob1, anEnqueuedJob2)).isFalse();
    }

    @Test
    void ifStorageProviderJobIsEnqueuedAndWasNotScheduledBeforeItDoesNotMatch() {
        final Job anEnqueuedJob1 = aScheduledJob().withEnqueuedState().build();
        final Job anEnqueuedJob2 = anEnqueuedJob().build();

        assertThat(allowedStateChange.matches(anEnqueuedJob1, anEnqueuedJob2)).isFalse();
    }

}