package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.stubs.TestServiceInterface;
import org.jobrunr.utils.annotations.Because;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

import static java.time.Instant.now;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.methodThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR;
import static org.mockito.InstantMocker.mockTime;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DeleteSucceededJobsTaskTest extends AbstractZooKeeperTaskTest {

    DeleteSucceededJobsTask task;

    @BeforeEach
    void setUpTask() {
        task = new DeleteSucceededJobsTask(jobZooKeeper, backgroundJobServer);
    }

    @Test
    void testTask() {
        try (MockedStatic<Instant> instantMock = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR)) {
            Job job1 = aSucceededJob().withDeleteAt(now().minusSeconds(60)).build();
            Job job2 = aSucceededJob().withDeleteAt(now().minusSeconds(60)).build();
            Job job3 = aFailedJob().withDeleteAt(now().minusSeconds(60)).build();
            whenGetJobsToDeleteThenReturn(asList(job1, job2, job3), emptyList());

            runTask(task);

            verify(storageProvider).save(anyList());
            assertThat(jobSearchRequestArgumentCaptor.getValue())
                    .hasStates(SUCCEEDED, FAILED)
                    .hasDeleteAtTo(FIXED_INSTANT_RIGHT_BEFORE_THE_HOUR);

            assertThat(logAllStateChangesFilter.getStateChanges(job1)).containsExactly("SUCCEEDED->DELETED");
            assertThat(logAllStateChangesFilter.getStateChanges(job2)).containsExactly("SUCCEEDED->DELETED");
            assertThat(logAllStateChangesFilter.getStateChanges(job3)).containsExactly("FAILED->DELETED");

            assertThat(logAllStateChangesFilter.onProcessingIsCalled(job1)).isFalse();
            assertThat(logAllStateChangesFilter.onProcessingIsCalled(job2)).isFalse();
            assertThat(logAllStateChangesFilter.onProcessingIsCalled(job3)).isFalse();
            assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job1)).isFalse();
            assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job2)).isFalse();
            assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job3)).isFalse();
        }
    }

    @Test
    @Because("https://github.com/jobrunr/jobrunr/issues/27")
    void taskMovesSucceededJobsToDeletedStateAlsoForMethodsThatDontExistAnymore() {
        Job job = aSucceededJob().withJobDetails(methodThatDoesNotExistJobDetails()).build();

        whenGetJobsToDeleteThenReturn(singletonList(job), emptyList());

        // WHEN
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        verify(storageProvider).save(anyList());
    }

    @Test
    void taskMovesSucceededJobsToDeletedStateAlsoForInterfacesWithMethodsThatDontExistAnymore() {
        // GIVEN
        Job job = aSucceededJob().withJobDetails(jobDetails()
                        .withClassName(TestServiceInterface.class)
                        .withMethodName("methodThatDoesNotExist")
                        .build())
                .build();

        whenGetJobsToDeleteThenReturn(singletonList(job), emptyList());

        // WHEN
        runTask(task);

        // THEN
        assertThat(logger).hasNoWarnLogMessages();
        verify(storageProvider).save(anyList());
    }

    private void whenGetJobsToDeleteThenReturn(List<Job>... jobs) {
        when(storageProvider.getJobList(jobSearchRequestArgumentCaptor.capture(), any()))
                .thenReturn(jobs[0], Arrays.copyOfRange(jobs, 1, jobs.length));
    }
}