package org.jobrunr.server.runner;

import org.jobrunr.JobRunrException;
import org.jobrunr.jobs.Job;
import org.jobrunr.server.runner.AbstractBackgroundJobRunner.BackgroundJobWorker;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class AbstractBackgroundJobRunnerTest {

    private TestService testService = new TestService();

    @Mock
    private BackgroundJobWorker worker;

    @Test
    void ifCodeThrowsInterruptedException_AnInterruptExceptionIsThrown() throws Exception {
        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(worker);
        final Job job = aJobInProgress().build();
        doThrow(new InterruptedException()).when(worker).run();

        assertThatThrownBy(() -> backgroundJobRunner.run(job)).isInstanceOf(InterruptedException.class);
    }

    @Test
    void ifCurrentThreadIsInterrupted_AnInterruptExceptionIsThrown() throws Exception {
        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(worker);
        final Job job = aJobInProgress().build();
        doAnswer(invocation -> {
            Thread.currentThread().interrupt();
            return null;
        }).when(worker).run();

        assertThatThrownBy(() -> backgroundJobRunner.run(job)).isInstanceOf(InterruptedException.class);
    }

    @Test
    void invokeJobMethodUpdatesJobContextThreadLocal() throws Exception {
        final Job job = aJobInProgress().withJobDetails(this::testJobContext).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        backgroundJobRunner.run(job);
        assertThat(ThreadLocalJobContext.getJobContext()).isNull();
    }

    @Test
    void invokeJobMethodAlwaysResetsJobContextThreadLocal() {
        final Job job = aJobInProgress().withJobDetails(this::throwingJobContext).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        assertThatCode(() -> backgroundJobRunner.run(job)).isInstanceOf(Exception.class);
        assertThat(ThreadLocalJobContext.getJobContext()).isNull();
    }

    @Test
    void invokeJobMethodSavesResultIfThereIsOne() throws Exception {
        final Job job = aJobInProgress().withJobDetails(() -> testService.doWorkWithUUID(UUID.randomUUID())).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        backgroundJobRunner.run(job);

        assertThat(job.hasResult()).isTrue();
        assertThat(job.<String>getResult()).startsWith("The result");
    }

    @Test
    void invokeJobMethodDoesNotSaveResultIfThereIsNone() throws Exception {
        final Job job = aJobInProgress().withJobDetails(() -> testService.doWork(UUID.randomUUID())).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        backgroundJobRunner.run(job);

        assertThat(job.hasResult()).isFalse();
        assertThat(job.getJobResult()).isNull();
        assertThat((Object) job.getResult()).isNull();
    }

    @Test
    void ifResultCanBeSerializedAndDeserializedThenResultIsSaved() throws Exception {
        final Job job = aJobInProgress().withJobDetails(() -> testService.doWorkWithSerializableCustomObjectResult()).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        backgroundJobRunner.run(job);

        assertThat(job.hasResult()).isTrue();
        assertThat(job.<TestService.CustomObjectThatIsSerializable>getResult()).isNotNull();
    }

    @Test
    void ifResultCanNotBeSerializedAndDeserializedByJacksonThenResultIsNotSavedAndWarningIsLogged() throws Exception {
        final Job job = aJobInProgress().withJobDetails(() -> testService.doWorkWithUnSerializableCustomObjectResult()).build();

        final AbstractBackgroundJobRunner backgroundJobRunner = getJobRunner(job);

        assertThatThrownBy(() -> backgroundJobRunner.run(job))
                        .isInstanceOf(JobRunrException.class)
                .hasMessageContaining("Job result could not be saved.");
    }

    private AbstractBackgroundJobRunner getJobRunner(Job job) {
        return getJobRunner(new BackgroundJobWorker(new JobResultSaver(new JacksonJsonMapper()), job));
    }

    private AbstractBackgroundJobRunner getJobRunner(BackgroundJobWorker worker) {
        return new AbstractBackgroundJobRunner(new JobResultSaver(new JacksonJsonMapper())) {

            @Override
            public boolean supports(Job job) {
                return true;
            }

            @Override
            protected BackgroundJobWorker getBackgroundJobWorker(JobResultSaver jobResultSaver, Job job) {
                return worker;
            }
        };
    }

    public void testJobContext() {
        assertThat(ThreadLocalJobContext.getJobContext()).isNotNull();
    }

    public void throwingJobContext() {
        assertThat(ThreadLocalJobContext.getJobContext()).isNotNull();
        throw new RuntimeException("Boem");
    }

}