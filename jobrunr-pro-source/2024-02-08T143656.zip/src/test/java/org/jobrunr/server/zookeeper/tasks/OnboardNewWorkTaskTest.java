package org.jobrunr.server.zookeeper.tasks;

import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.StorageException;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.utils.SleepUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.JobTestBuilder.emptyJobList;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class OnboardNewWorkTaskTest extends AbstractZooKeeperTaskTest {

    OnboardNewWorkTask task;

    @BeforeEach
    void setUpTask() {
        task = new OnboardNewWorkTask(jobZooKeeper, backgroundJobServer);
        when(backgroundJobServer.isRunning()).thenReturn(true);
    }

    @Test
    void testTask() {
        Job enqueuedJob1 = anEnqueuedJobWithName().build();
        Job enqueuedJob2 = anEnqueuedJobWithName().build();

        when(storageProvider.getJobsToProcess(any(BackgroundJobServer.class), isNull(), any(AmountRequest.class))).thenReturn(asList(enqueuedJob1, enqueuedJob2), emptyJobList());

        runTask(task);

        verify(backgroundJobServer).processJob(enqueuedJob1);
        verify(backgroundJobServer).processJob(enqueuedJob2);
    }

    @Test
    void testTaskCanHappenAgainAfterException() {
        Job enqueuedJob1 = anEnqueuedJobWithName().build();
        Job enqueuedJob2 = anEnqueuedJobWithName().build();
        when(storageProvider.getJobsToProcess(any(BackgroundJobServer.class), isNull(), any(AmountRequest.class)))
                .thenThrow(new StorageException("Some error occurred"))
                .thenReturn(asList(enqueuedJob1, enqueuedJob2), emptyJobList());

        new Thread(() -> runTask(task)).start();
        SleepUtils.sleep(500);

        runTask(task);

        verify(backgroundJobServer).processJob(enqueuedJob1);
        verify(backgroundJobServer).processJob(enqueuedJob2);
    }

    @Test
    void testTaskIsNotPerformedWhenBackgroundJobServerIsPaused() {
        when(backgroundJobServer.isRunning()).thenReturn(false);

        runTask(task);

        verify(storageProvider, never()).getJobsToProcess(any(BackgroundJobServer.class), isNull(), any(AmountRequest.class));
        verify(backgroundJobServer, never()).processJob(any(Job.class));
    }

    @Test
    void taskIsNotDoneConcurrently() throws InterruptedException {
        when(storageProvider.getJobsToProcess(any(BackgroundJobServer.class), eq(null), any(AmountRequest.class))).thenAnswer((invocationOnMock) -> {
            sleep(100);
            return emptyList();
        });

        CountDownLatch countDownLatch = new CountDownLatch(2);
        final Thread thread1 = new Thread(() -> {
            runTask(task);
            countDownLatch.countDown();
        });
        final Thread thread2 = new Thread(() -> {
            runTask(task);
            countDownLatch.countDown();
        });
        thread1.start();
        thread2.start();

        countDownLatch.await(30, TimeUnit.SECONDS);
        verify(storageProvider, times(1)).getJobsToProcess(any(BackgroundJobServer.class), isNull(), any(AmountRequest.class));
    }
}