package org.jobrunr.server;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.jobs.mappers.MDCMapper;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.IllegalJobStateChangeException;
import org.jobrunr.server.runner.BackgroundJobRunner;
import org.jobrunr.server.runner.BackgroundStaticFieldJobWithoutIocRunner;
import org.jobrunr.server.runner.JobResultSaver;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.storage.MutexInUseException;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

import static java.lang.String.format;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJobWithRetries;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BackgroundJobPerformerTest {

    @Mock
    private BackgroundJobServer backgroundJobServer;
    @Mock
    private StorageProvider storageProvider;
    @Mock
    private JobZooKeeper jobZooKeeper;

    private LogAllStateChangesFilter logAllStateChangesFilter;

    @BeforeEach
    void setUpMocks() {
        logAllStateChangesFilter = new LogAllStateChangesFilter();

        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(backgroundJobServer.getJobZooKeeper()).thenReturn(jobZooKeeper);
        when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID(), logAllStateChangesFilter));
    }

    @Test
    void onStartIfJobIsProcessingByStorageProviderItStaysInProcessingAndThenSucceeded() throws Exception {
        Job job = anEnqueuedJobWithName()
                .withProcessingState(backgroundJobServer.getConfiguration().getId())
                .build();

        mockBackgroundJobRunner(job, jobFromStorage -> {});

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("PROCESSING->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isTrue();
        assertThat(logger)
                .hasNoErrorLogMessages();
    }

    @Test
    void onStartIfJobIsNotProcessingByStorageProviderItGoesToProcessingAndThenSucceeded() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        mockBackgroundJobRunner(job, jobFromStorage -> {});

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isTrue();
        assertThat(logger)
                .hasNoErrorLogMessages();
    }

    @Test
    void onSuccessAfterDeleteTheIllegalJobStateChangeIsCatchedAndLogged() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        mockBackgroundJobRunner(job, jobFromStorage -> jobFromStorage.delete("for testing"));

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isTrue();
        assertThat(logger)
                .hasNoErrorLogMessages()
                .hasInfoMessage(format("Job(id=%s, jobName='an enqueued job') finished successfully but it was already deleted - ignoring illegal state change from DELETED to SUCCEEDED", job.getId()));
    }

    @Test
    void onSuccessIllegalJobStateChangeIsThrown() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        mockBackgroundJobRunner(job, jobFromStorage -> jobFromStorage.failed("boe", new Exception()));

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        assertThatThrownBy(backgroundJobPerformer::run)
                .isInstanceOf(IllegalJobStateChangeException.class);
    }

    @Test
    void onFailureAfterDeleteTheIllegalJobStateChangeIsCatchedAndLogged() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        mockBackgroundJobRunner(job, jobFromStorage -> {
            jobFromStorage.delete("for testing");
            jobFromStorage.failed("to throw exception that will bring it to failed state", new Exception());
        });

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isFalse();
        assertThat(logger)
                .hasNoErrorLogMessages()
                .hasInfoMessage("Job processing failed but it was already deleted - ignoring illegal state change from DELETED to FAILED");
    }

    @Test
    void onFailureIllegalJobStateChangeIsThrown() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        mockBackgroundJobRunner(job, jobFromStorage -> {
            jobFromStorage.succeeded();
            jobFromStorage.succeeded(); //to throw exception that will bring it to failed state
        });

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        assertThatThrownBy(backgroundJobPerformer::run)
                .isInstanceOf(IllegalJobStateChangeException.class);
    }

    @Test
    void jobNotRunOnConcurrentJobModificationException() {
        Job job = anEnqueuedJobWithName().withId().build();

        doThrow(new ConcurrentJobModificationException(job)).when(storageProvider).save(job);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        verify(backgroundJobServer, never()).getBackgroundJobRunner(job);
        assertThat(logAllStateChangesFilter.getStateChanges(job)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isFalse();
    }

    @Test
    void jobNotRunOnMutexInUseException() {
        Job job = anEnqueuedJobWithName().withId().build();

        doThrow(new MutexInUseException(job)).when(storageProvider).save(job);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        verify(backgroundJobServer, never()).getBackgroundJobRunner(job);
        assertThat(logAllStateChangesFilter.getStateChanges(job)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isFalse();
    }

    @Test
    void allStateChangesArePassingViaTheApplyStateFilterOnSuccess() {
        Job job = anEnqueuedJobWithName().build();

        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(new BackgroundStaticFieldJobWithoutIocRunner(new JobResultSaver(new JacksonJsonMapper())));

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->SUCCEEDED");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(job)).isFalse();
    }

    @Test
    void allStateChangesArePassingViaTheApplyStateFilterOnFailure() {
        Job job = anEnqueuedJobWithName().build();

        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(null);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->FAILED", "FAILED->SCHEDULED");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingFailedIsCalled(job)).isTrue();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isFalse();

        assertThat(logger)
                .hasNoErrorLogMessages()
                .hasWarningMessageContaining("processing failed: An exception occurred during the performance of the job");
    }

    @Test
    void onFailureAndRetriesAreNotExhaustedServerFilterOnFailedAfterRetriesIsNotCalled() {
        Job job = anEnqueuedJobWithName().build();
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(null);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.onFailedAfterRetriesIsCalled(job)).isFalse();
    }

    @Test
    void onFailureAfterAllRetriesServerFilterOnFailedAfterRetriesNotCalled() {
        Job job = aFailedJobWithRetries().withEnqueuedState(Instant.now()).build();
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(null);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.onFailedAfterRetriesIsCalled(job)).isTrue();
    }

    @Test
    void onFailureAfterAllRetriesExceptionIsLoggedToError() {
        Job job = aFailedJobWithRetries().withEnqueuedState(Instant.now()).build();
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(null);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("ENQUEUED->PROCESSING", "PROCESSING->FAILED");
        assertThat(logger)
                .hasNoWarnLogMessages()
                .hasErrorMessage(format("Job(id=%s, jobName='failed job') processing failed: An exception occurred during the performance of the job", job.getId()));
    }

    @Test
    void onConcurrentJobModificationExceptionAllIsStillOk() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        when(storageProvider.save(job))
                .thenReturn(job)
                .thenThrow(new ConcurrentJobModificationException(job));
        mockBackgroundJobRunner(job, job1 -> System.out.println("Nothing to do"));

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        assertThatCode(backgroundJobPerformer::run).doesNotThrowAnyException();
    }

    @Test
    void onConcurrentJobModificationExceptionOnJobSucceededDueToReplaceJobNoErrorIsLogged() throws Exception {
        Job job = anEnqueuedJobWithName().build();

        when(storageProvider.save(job))
                .thenReturn(job)
                .thenThrow(new ConcurrentJobModificationException(job));
        mockBackgroundJobRunner(job, job1 -> System.out.println("Nothing to do"));

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logger).hasInfoMessage(format("Job(id=%s, jobName='%s') finished successfully but was either replaced or deleted", job.getId(), job.getJobName()));
    }

    @Test
    void onConcurrentJobModificationExceptionOnJobFailedDueToReplaceJobNoErrorIsLogged() {
        Job job = anEnqueuedJobWithName().build();

        when(storageProvider.save(job))
                .thenReturn(job)
                .thenThrow(new ConcurrentJobModificationException(job));
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(null);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(backgroundJobPerformer);
        backgroundJobPerformer.run();

        assertThat(logger).hasInfoMessage(format("Job(id=%s, jobName='%s') processing failed but was either replaced or deleted", job.getId(), job.getJobName()));
    }

    @Test
    @DisplayName("InvocationTargetException is unwrapped and the actual error is stored instead")
    void invocationTargetExceptionUnwrapped() throws Exception {
        var job = anEnqueuedJobWithName().build();
        var runner = mock(BackgroundJobRunner.class);
        doThrow(new InvocationTargetException(new RuntimeException("test error"))).when(runner).run(job);
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(runner);

        var backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        var lastFailure = job.getLastJobStateOfType(FailedState.class);
        assertThat(lastFailure.isPresent()).isTrue();
        assertThat(lastFailure.get().getExceptionMessage()).isEqualTo("test error");
        assertThat(lastFailure.get().getException()).isInstanceOf(RuntimeException.class);
        assertThat(lastFailure.get().getException().getMessage()).isEqualTo("test error");
    }

    @Test
    @DisplayName("any exception other than InvocationTargetException stays unwrapped")
    void anyExceptionOtherThanInvocationTargetExceptionIsNotUnwrapped() throws Exception {
        var job = anEnqueuedJobWithName().build();
        var runner = mock(BackgroundJobRunner.class);
        doThrow(new RuntimeException("test error")).when(runner).run(job);
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(runner);

        var backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        backgroundJobPerformer.run();

        var lastFailure = job.getLastJobStateOfType(FailedState.class);
        assertThat(lastFailure.isPresent()).isTrue();
        assertThat(lastFailure.get().getExceptionMessage()).isEqualTo("test error");
        assertThat(lastFailure.get().getException()).isInstanceOf(RuntimeException.class);
        assertThat(lastFailure.get().getException().getMessage()).isEqualTo("test error");
    }

    @Test
    void mdcIsAlsoAvailableDuringLoggingOfJobSuccess() {
        // GIVEN
        Job job = anEnqueuedJobWithName().build();
        MDC.put("testKey", "testValue");
        MDCMapper.saveMDCContextToJob(job);

        BackgroundJobRunner runner = mock(BackgroundJobRunner.class);
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(runner);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        ListAppender logger = LoggerAssert.initFor(backgroundJobPerformer);

        // WHEN
        backgroundJobPerformer.run();

        // THEN
        assertThat(logger)
                .hasDebugMessageContaining(
                        "Job(id=" + job.getId() + ", jobName='" + job.getJobName() + "') processing succeeded",
                        Map.of(
                                "jobrunr.jobId", job.getId().toString(),
                                "jobrunr.jobName", job.getJobName(),
                                "testKey", "testValue"
                        ));

        assertThat(MDC.getCopyOfContextMap()).isNullOrEmpty(); // backgroundJobPerformer clears MDC Context
    }

    @Test
    void mdcIsAlsoAvailableDuringLoggingOfJobFailure() throws Exception {
        // GIVEN
        Job job = anEnqueuedJobWithName().build();
        MDC.put("testKey", "testValue");
        MDCMapper.saveMDCContextToJob(job);

        BackgroundJobRunner runner = mock(BackgroundJobRunner.class);
        doThrow(new InvocationTargetException(new RuntimeException("test error"))).when(runner).run(job);
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(runner);

        BackgroundJobPerformer backgroundJobPerformer = new BackgroundJobPerformer(backgroundJobServer, job);
        ListAppender logger = LoggerAssert.initFor(backgroundJobPerformer);

        // WHEN
        backgroundJobPerformer.run();

        // THEN
        assertThat(logger)
                .hasWarningMessageContaining(
                        "Job(id=" + job.getId() + ", jobName='" + job.getJobName() + "') processing failed",
                        Map.of(
                                "jobrunr.jobId", job.getId().toString(),
                                "jobrunr.jobName", job.getJobName(),
                                "testKey", "testValue"
                        ));
        assertThat(MDC.getCopyOfContextMap()).isNullOrEmpty(); // backgroundJobPerformer clears MDC Context
    }

    private void mockBackgroundJobRunner(Job job, Consumer<Job> jobConsumer) throws Exception {
        BackgroundJobRunner backgroundJobRunnerMock = mock(BackgroundJobRunner.class);
        doAnswer(invocation -> {
            final Job jobArgument = invocation.getArgument(0, Job.class);
            jobConsumer.accept(jobArgument);
            return null;
        }).when(backgroundJobRunnerMock).run(Mockito.any());
        when(backgroundJobServer.getBackgroundJobRunner(job)).thenReturn(backgroundJobRunnerMock);
    }
}