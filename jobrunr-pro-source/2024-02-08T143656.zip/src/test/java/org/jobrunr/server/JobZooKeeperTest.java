package org.jobrunr.server;

import org.jobrunr.SevereJobRunrException;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.jobs.states.ProcessingState;
import org.jobrunr.server.dashboard.DashboardNotificationManager;
import org.jobrunr.server.strategy.DynamicQueueStrategy;
import org.jobrunr.server.strategy.WorkDistributionStrategy;
import org.jobrunr.storage.BackgroundJobServerStatus;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.storage.JobRunrMetadata;
import org.jobrunr.storage.JobSearchRequestArgumentMatcher;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.storage.navigation.OffsetBasedPageRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.aDefaultBackgroundJobServerStatus;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JobZooKeeperTest {

    @Mock
    private StorageProvider storageProvider;
    @Mock
    private BackgroundJobServer backgroundJobServer;
    @Mock
    private WorkDistributionStrategy workDistributionStrategy;
    @Mock
    private DynamicQueueStrategy dynamicQueueStrategy;
    @Captor
    private ArgumentCaptor<JobRunrMetadata> jobRunrMetadataArgumentCaptor;

    private BackgroundJobServerStatus backgroundJobServerStatus;
    private JobZooKeeper jobZooKeeper;
    private LogAllStateChangesFilter logAllStateChangesFilter;

    @BeforeEach
    void setUpBackgroundJobZooKeeper() {
        when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration().andPollIntervalInSeconds(5));
        when(backgroundJobServer.getDynamicQueueStrategy()).thenReturn(dynamicQueueStrategy);
        logAllStateChangesFilter = new LogAllStateChangesFilter();
        backgroundJobServerStatus = aDefaultBackgroundJobServerStatus().withIsStarted().withPollIntervalInSeconds(5).build();
        jobZooKeeper = initializeJobZooKeeper();
    }

    @Test
    void jobZooKeeperDoesNothingIfItIsNotInitialized() {
        reset(storageProvider);
        when(backgroundJobServer.isUnAnnounced()).thenReturn(true);

        jobZooKeeper.run();

        verifyNoInteractions(storageProvider);
    }

    @Test
    void evenWhenNoWorkCanBeOnboardedJobsThatAreProcessedAreBeingUpdatedWithAHeartbeat() {
        backgroundJobServerStatus = aDefaultBackgroundJobServerStatus().withWorkerSize(0).build();
        jobZooKeeper = initializeJobZooKeeper();

        final Job job = anEnqueuedJobWithName().withId().build();
        lenient().when(storageProvider.getJobsToProcess(eq(backgroundJobServer), isNull(), any())).thenReturn(singletonList(job));

        job.startProcessingOn(backgroundJobServer);
        jobZooKeeper.startProcessing(job, mock(Thread.class));
        jobZooKeeper.run();
        jobZooKeeper.startProcessing(aJobInProgress().build(), mock(Thread.class));

        verify(storageProvider).save(singletonList(job));
        ProcessingState processingState = job.getJobState();
        assertThat(processingState.getUpdatedAt()).isAfter(processingState.getCreatedAt());
    }

    @Test
    void checkForEnqueuedJobsIfJobsPresentSubmitsThemToTheBackgroundJobServer() {
        final Job enqueuedJob = anEnqueuedJobWithName().build();
        final List<Job> jobs = List.of(enqueuedJob);

        lenient().when(dynamicQueueStrategy.getJobsToProcess(any(AmountRequest.class))).thenReturn(jobs);

        jobZooKeeper.run();

        verify(backgroundJobServer).processJob(enqueuedJob);
    }

    @Test
    void checkForEnqueuedJobsIfJobPresentDeletesSameJobsAndSubmitsUpdatedJobsToTheBackgroundJobServer() {
        // GIVEN
        UUID jobId = UUID.randomUUID();
        final Job enqueuedJobv1 = anEnqueuedJobWithName().withId(jobId).build();
        final Job enqueuedJobv2 = anEnqueuedJobWithName().withId(jobId).build(); // job replacing original job
        Thread thread1 = mock(Thread.class);
        Thread thread2 = mock(Thread.class);

        jobZooKeeper.startProcessing(enqueuedJobv1, thread1);

        // WHEN
        jobZooKeeper.startProcessing(enqueuedJobv2, thread2);

        // THEN
        assertThat(enqueuedJobv1).hasState(DELETED);
        verify(thread1).interrupt();
    }

    @Test
    void checkForEnqueuedJobsIfJobPresentAndAlreadyDeletedDeletesSameJobsAndSubmitsUpdatedJobsToTheBackgroundJobServer() {
        // GIVEN
        UUID jobId = UUID.randomUUID();
        final Job enqueuedJobv1 = anEnqueuedJobWithName().withId(jobId).withDeletedState().build();
        final Job enqueuedJobv2 = anEnqueuedJobWithName().withId(jobId).build(); // job replacing original job
        Thread thread1 = mock(Thread.class);
        Thread thread2 = mock(Thread.class);

        jobZooKeeper.startProcessing(enqueuedJobv1, thread1);

        // WHEN
        jobZooKeeper.startProcessing(enqueuedJobv2, thread2);

        // THEN
        assertThat(enqueuedJobv1).hasState(DELETED);
        verify(thread1).interrupt();
    }

    @Test
    void allStateChangesArePassingViaTheApplyStateFilterOnSuccess() {
        Job job = aScheduledJob().build();

        JobSearchRequestArgumentMatcher argumentMatcher = new JobSearchRequestArgumentMatcher(aJobSearchRequest().withStateName(SCHEDULED).build());
        when(storageProvider.getJobList(argThat(argumentMatcher), any()))
                .thenReturn(singletonList(job), emptyList());

        jobZooKeeper.run();

        assertThat(logAllStateChangesFilter.getStateChanges(job)).containsExactly("SCHEDULED->ENQUEUED");
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(job)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(job)).isFalse();
    }

    @Test
    void ifNoStateChangeHappensStateChangeFiltersAreNotInvoked() {
        Job aJobInProgress = aJobInProgress().build();

        jobZooKeeper.startProcessing(aJobInProgress, mock(Thread.class));

        for (int i = 0; i <= 5; i++) {
            jobZooKeeper.run();
        }

        assertThat(logAllStateChangesFilter.getStateChanges(aJobInProgress)).isEmpty();
        assertThat(logAllStateChangesFilter.onProcessingIsCalled(aJobInProgress)).isFalse();
        assertThat(logAllStateChangesFilter.onProcessingSucceededIsCalled(aJobInProgress)).isFalse();
    }

    // FIX ME (because now searchrequest instead of some scheduled method on storageprovider)
    @Test
    void severeJobRunrExceptionsAreLoggedToStorageProvider() {
        Job succeededJob1 = aSucceededJob().build();
        Job succeededJob2 = aSucceededJob().build();

        // scheduled jobs to enqueue
        when(storageProvider.getJobList(any(), any())).thenReturn(emptyList());
        when(storageProvider.getJobById(succeededJob1.getId())).thenReturn(succeededJob1);
        when(storageProvider.getJobById(succeededJob2.getId())).thenReturn(succeededJob2);
        // succeeded jobs to delete
        when(storageProvider.getJobList(argThat(x -> x.getDeleteAtTo() != null), any())).thenReturn(
                asList(succeededJob1, succeededJob2, aSucceededJob().build(), aSucceededJob().build(), aSucceededJob().build()));

        when(storageProvider.save(anyList())).thenThrow(new ConcurrentJobModificationException(asList(succeededJob1, succeededJob2)));

        jobZooKeeper.run();

        verify(storageProvider).saveMetadata(jobRunrMetadataArgumentCaptor.capture());

        assertThat(jobRunrMetadataArgumentCaptor.getValue())
                .hasName(SevereJobRunrException.class.getSimpleName())
                .hasOwner("BackgroundJobServer " + backgroundJobServer.getId())
                .valueContains("## Runtime information");
    }

    // FIX ME (because now searchrequest instead of some scheduled method on storageprovider)
    @Test
    void jobZooKeeperStopsIfTooManyExceptions() {
        Job succeededJob1 = aSucceededJob().build();
        Job succeededJob2 = aSucceededJob().build();

        // scheduled jobs to enqueue
        when(storageProvider.getJobList(any(), any())).thenReturn(emptyList());
        when(storageProvider.getJobById(succeededJob1.getId())).thenReturn(succeededJob1);
        when(storageProvider.getJobById(succeededJob2.getId())).thenReturn(succeededJob2);
        // succeeded jobs to delete
        when(storageProvider.getJobList(argThat(x -> x.getDeleteAtTo() != null), any())).thenReturn(
                asList(succeededJob1, succeededJob2, aSucceededJob().build(), aSucceededJob().build(), aSucceededJob().build()));

        when(storageProvider.save(anyList())).thenThrow(new ConcurrentJobModificationException(asList(succeededJob1, succeededJob2)));

        for (int i = 0; i <= 5; i++) {
            jobZooKeeper.run();
        }

        verify(backgroundJobServer).stopBecauseOfException(eq("FATAL - JobRunr encountered too many processing exceptions. Shutting down."), any(Exception.class));
    }

    private JobZooKeeper initializeJobZooKeeper() {
        UUID backgroundJobServerId = UUID.randomUUID();
        lenient().when(backgroundJobServer.getId()).thenReturn(backgroundJobServerId);
        lenient().when(backgroundJobServer.getServerStatus()).thenReturn(backgroundJobServerStatus);
        lenient().when(backgroundJobServer.isRunning()).thenReturn(true);
        when(backgroundJobServer.getStorageProvider()).thenReturn(storageProvider);
        when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(workDistributionStrategy);
        when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(backgroundJobServerId, logAllStateChangesFilter));
        when(backgroundJobServer.getDashboardNotificationManager()).thenReturn(new DashboardNotificationManager(backgroundJobServerId, storageProvider));
        lenient().when(workDistributionStrategy.canOnboardNewWork()).thenReturn(true);
        lenient().when(workDistributionStrategy.getWorkAmountRequest()).thenReturn(ascOnPriorityAndUpdatedAt(10));
        lenient().when(backgroundJobServer.isAnnounced()).thenReturn(true);
        lenient().when(backgroundJobServer.isMaster()).thenReturn(true);
        lenient().when(storageProvider.getRecurringJobs(any(), any(OffsetBasedPageRequest.class))).thenReturn(OffsetBasedPageRequest.emptyPage);
        return new JobZooKeeper(backgroundJobServer);
    }
}