package org.jobrunr.server.configuration;

import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.strategy.LabelPrefixDynamicQueueProvider;
import org.jobrunr.server.strategy.RoundRobinDynamicQueueStrategy;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class RoundRobinDynamicQueuePolicyTest {

    @Mock
    BackgroundJobServer backgroundJobServer;

    @Test
    void testRoundRobinDynamicQueuePolicyWithDefaults() {
        RoundRobinDynamicQueuePolicy roundRobinDynamicQueuePolicy = new RoundRobinDynamicQueuePolicy("tenant");

        assertThat(roundRobinDynamicQueuePolicy.getDynamicQueueProvider()).isInstanceOf(LabelPrefixDynamicQueueProvider.class);
        assertThat(roundRobinDynamicQueuePolicy.createDynamicQueueStrategy(backgroundJobServer)).isInstanceOf(RoundRobinDynamicQueueStrategy.class);
    }

    @Test
    void testRoundRobinDynamicQueuePolicyWithCustomConfiguration() {
        RoundRobinDynamicQueuePolicy roundRobinDynamicQueuePolicy = new RoundRobinDynamicQueuePolicy("tenant", Duration.ofMinutes(1), 5, 3);

        assertThat(roundRobinDynamicQueuePolicy.getDynamicQueueProvider()).isInstanceOf(LabelPrefixDynamicQueueProvider.class);
        assertThat(roundRobinDynamicQueuePolicy.createDynamicQueueStrategy(backgroundJobServer)).isInstanceOf(RoundRobinDynamicQueueStrategy.class);
    }
}