package org.jobrunr.dashboard.server.security.basic;

import com.sun.net.httpserver.Filter;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BasicAuthenticationProviderTest {

    @Mock
    HttpContext httpContext;
    @Mock
    HttpExchange httpExchange;
    @Mock
    Filter.Chain chain;

    Headers httpRequestHeaders;

    Filter filter;

    @BeforeEach
    void setUpHttpContext() {
        List<Filter> filters = new ArrayList<>();
        when(httpContext.getFilters()).thenReturn(filters);

        BasicAuthenticationProvider basicAuthenticationProvider = new BasicAuthenticationProvider("user", "test");
        basicAuthenticationProvider.secureHttpContext(httpContext);
        Object basicAuthenticator = Whitebox.getInternalState(basicAuthenticationProvider, "basicAuthenticator");
        filter = filters.get(0);

        httpRequestHeaders = new Headers();
        when(httpExchange.getRequestHeaders()).thenReturn(httpRequestHeaders);
    }

    @Test
    void ifNoAuthorizationHeaderIsPresentChainIsContinuedSoBasicAuthenticatorIsInvoked() throws Exception {
        filter.doFilter(httpExchange, chain);

        verify(chain).doFilter(httpExchange);
    }

    @Test
    void ifWrongAuthorizationHeaderIsPresentChainIsContinuedSoBasicAuthenticatorIsReInvoked() throws Exception {
        httpRequestHeaders.put("Authorization", List.of("Basic cm9uYWxkOnRlc3Rlbg=="));
        filter.doFilter(httpExchange, chain);

        verify(chain).doFilter(httpExchange);
    }

    @Test
    void ifCorrectAuthorizationHeaderIsPresentChainIsContinuedSoBasicAuthenticatorCanValidateUserAndPassword() throws Exception {
        httpRequestHeaders.put("Authorization", List.of("Basic dXNlcjp0ZXN0"));
        filter.doFilter(httpExchange, chain);

        verify(chain).doFilter(httpExchange);
    }
}