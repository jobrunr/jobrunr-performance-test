package org.jobrunr.dashboard;

import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.gson.GsonJsonMapper;

public class GsonJobRunrDashboardWebserverBasicAuthenticationTest extends JobRunrDashboardWebServerAuthTest {
    @Override
    public JsonMapper getJsonMapper() {
        return new GsonJsonMapper();
    }
}
