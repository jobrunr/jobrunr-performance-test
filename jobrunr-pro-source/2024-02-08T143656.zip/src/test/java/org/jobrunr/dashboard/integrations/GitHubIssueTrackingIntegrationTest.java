package org.jobrunr.dashboard.integrations;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;

class GitHubIssueTrackingIntegrationTest {
    
    GitHubIssueTrackingIntegration integration = new GitHubIssueTrackingIntegration("jobrunr", "jobrunr-pro", "bug", "rdehuyss");

    @Test
    void testIssueUrl() {
        String linkToCreateIssue = integration.getLinkToCreateIssue(aFailedJob().withId(UUID.fromString("98dd6af1-2d7f-4c85-a574-12382bb3f1e4")).build());
        assertThat(linkToCreateIssue)
                .startsWith("https://github.com/jobrunr/jobrunr-pro/issues/new")
                .contains("title=Exception+in+JobRunr+Job%3A+java.lang.System.out.println%28java.lang.String")
                .contains("body=%23%23+Exception+happened+in+Job+with+id+%2798dd6af1-2d7f-4c85-a574-12382bb3f1e4%27")
                .contains("labels=bug&assignee=rdehuyss");
    }
}