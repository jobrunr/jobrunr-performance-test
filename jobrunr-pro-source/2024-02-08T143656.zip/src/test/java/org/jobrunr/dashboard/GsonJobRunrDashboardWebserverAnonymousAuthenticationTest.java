package org.jobrunr.dashboard;

import org.jobrunr.dashboard.server.http.client.TeenyHttpClient;
import org.jobrunr.dashboard.server.security.AnonymousAuthenticationProvider;
import org.jobrunr.dashboard.server.security.AuthenticationProvider;
import org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRules;

public class GsonJobRunrDashboardWebserverAnonymousAuthenticationTest extends GsonJobRunrDashboardWebserverBasicAuthenticationTest {
    @Override
    protected TeenyHttpClient setHttpClientHeaders(TeenyHttpClient teenyHttpClient) {
        return teenyHttpClient;
    }

    @Override
    protected AuthenticationProvider authenticationProvider(JobRunrUserAuthorizationRules authorizationRules) {
        return new AnonymousAuthenticationProvider(authorizationRules);
    }
}
