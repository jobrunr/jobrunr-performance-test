package org.jobrunr.dashboard;

import org.jobrunr.dashboard.server.security.AnonymousAuthenticationProvider;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.dashboard.JobRunrDashboardWebServerConfiguration.usingStandardDashboardConfiguration;

class JobRunrDashboardWebServerConfigurationTest {

    JobRunrDashboardWebServerConfiguration configuration = usingStandardDashboardConfiguration();

    @Test
    void dashboardWebServerConfigurationHasAnonymousAuthenticationByDefault() {
        assertThat(configuration.authenticationProvider)
                .isNotNull()
                .isInstanceOf(AnonymousAuthenticationProvider.class);
    }

    @Test
    void dashboardWebServerConfigurationThrowsExceptionIfNullAuthenticationProviderIsPassed() {
        assertThatCode(() -> configuration.andAuthentication(null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasCauseInstanceOf(NullPointerException.class);
    }

}