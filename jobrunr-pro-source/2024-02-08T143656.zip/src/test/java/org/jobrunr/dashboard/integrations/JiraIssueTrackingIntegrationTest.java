package org.jobrunr.dashboard.integrations;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;

class JiraIssueTrackingIntegrationTest {
    
    JiraIssueTrackingIntegration integration = new JiraIssueTrackingIntegration("https://jobrunr.atlassian.net/", "10001", "10007", "ronald.dehuysser@gmail.com");

    @Test
    void testIssueUrl() {
        String linkToCreateIssue = integration.getLinkToCreateIssue(aFailedJob().withId(UUID.fromString("98dd6af1-2d7f-4c85-a574-12382bb3f1e4")).build());
        assertThat(linkToCreateIssue)
                .startsWith("https://jobrunr.atlassian.net/secure/CreateIssueDetails!init.jspa?pid=10001&issuetype=10007")
                .contains("summary=Exception+in+JobRunr+Job%3A+java.lang.System.out.println%28java.lang.String%29")
                .contains("description=h1.+Exception+happened+in+Job+with+id+%2798dd6af1-2d7f-4c85-a574-12382bb3f1e4%27%0Ah2.+Job+Signature%3A%0A%7B%7Bjava.lang.System.out.println%28java.lang.String%29%7D%7D%0A%0Ah2.+Stacktrace%3A")
                .contains("assignee=ronald.dehuysser%40gmail.com");
    }
}