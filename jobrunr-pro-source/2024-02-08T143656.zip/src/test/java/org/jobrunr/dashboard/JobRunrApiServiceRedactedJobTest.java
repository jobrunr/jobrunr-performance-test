package org.jobrunr.dashboard;

import org.jobrunr.dashboard.server.security.JobRunrUser;
import org.jobrunr.dashboard.server.security.JobRunrUserContext;
import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.mapper.gson.GsonJsonMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static java.util.Arrays.asList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRules.redactedReadOnly;
import static org.jobrunr.jobs.BatchJobTestBuilder.aFailedBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.storage.JobSearchRequest.forBatchJobsOnly;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;

class JobRunrApiServiceRedactedJobTest {

    private JobRunrApiService jobRunrApiService;
    private StorageProvider storageProvider;

    @BeforeEach
    void setUp() {
        storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(new GsonJsonMapper()));
        jobRunrApiService = new JobRunrApiService(storageProvider, null, null, null);
        JobRunrUserContext.setCurrentUser(new JobRunrUser(null, null, redactedReadOnly()));
    }

    @AfterEach
    void tearDown() {
        storageProvider.close();
        JobRunrUserContext.clear();
    }

    @Test
    void testRedactedJobReadOnly() {
        Job failedJob = aFailedJob().build();

        storageProvider.save(failedJob);

        Job job = jobRunrApiService.getJobById(failedJob.getId());

        assertThat(job).isNotNull().isRedactedIfComparedToUnredactedJob(failedJob);
    }

    @Test
    void testRedactedJobsReadOnly() {
        Job enqueuedJob = anEnqueuedJob().build();
        Job failedJob = aFailedJob().build();

        storageProvider.save(asList(enqueuedJob, failedJob));

        Page<Job> jobs = jobRunrApiService.getJobs(aJobSearchRequest().build(), Paging.OffsetBasedPage.ascOnUpdatedAt(2));

        assertThat(jobs)
                .hasItems(2)
                .allMatch(job -> assertThat(job).isRedactedIfComparedToUnredactedJob(job));
    }

    @Test
    void testRedactedBatchJobsReadOnly() {
        BatchJob batchJob1 = anEnqueuedBatchJob().build();
        BatchJob batchJob2 = aFailedBatchJob().build();

        storageProvider.save(asList(batchJob1, batchJob2));

        Page<Job> batchJobs = jobRunrApiService.getJobs(forBatchJobsOnly(aJobSearchRequest().build()), Paging.OffsetBasedPage.ascOnUpdatedAt(2));

        assertThat(batchJobs)
                .hasItems(2)
                .allMatch(job -> assertThat(job).isRedactedIfComparedToUnredactedJob(job));
    }

    @Test
    void testRedactedRecurringJobsReadOnly() {
        RecurringJob recurringJob1 = aDefaultRecurringJob().withId("recurring-job-1").withName("Generate sales reports").withCronExpression("*/5 * * * * *").build();
        RecurringJob recurringJob2 = aDefaultRecurringJob().withId("recurring-job-2").withName("Import sales data").withCronExpression(Cron.every5minutes()).build();
        storageProvider.saveRecurringJobs(asList(recurringJob1, recurringJob2));

        Page<RecurringJob> recurringJobPage = jobRunrApiService.getRecurringJobs(aRecurringJobSearchRequest().build(), Paging.OffsetBasedPage.ascOnUpdatedAt(2));

        assertThat(recurringJobPage).hasItems(2);
        recurringJobPage.getItems().forEach(recurringJob -> assertThat(recurringJob).isRedacted());
    }
}