package org.jobrunr.storage.sql.common.mapper;

import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.sql.common.RecurringJobTable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_CREATED_AT;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_ID;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_JOB_SIGNATURE;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_SERVER_TAG;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_UPDATED_AT;
import static org.jobrunr.storage.StorageProviderUtils.RecurringJobs.FIELD_LABELS;
import static org.jobrunr.storage.StorageProviderUtils.RecurringJobs.FIELD_NAME;
import static org.jobrunr.storage.StorageProviderUtils.RecurringJobs.FIELD_PRIORITY;
import static org.jobrunr.storage.StorageProviderUtils.RecurringJobs.FIELD_RUNS_MORE_THAN_ONCE_PER_MINUTE;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

@ExtendWith(MockitoExtension.class)
class SqlRecurringJobSearchRequestMapperTest {

    @Mock
    private RecurringJobTable recurringJobTable;

    private SqlRecurringJobSearchRequestMapper searchRequestMapper;

    @BeforeEach
    void setUp() {
        searchRequestMapper = new SqlRecurringJobSearchRequestMapper(recurringJobTable, null);
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsEmptySearchRequest() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().build();

        String filter = searchRequestMapper.map(searchRequest);

        verifyNoInteractions(recurringJobTable);
        assertThat(filter).isEqualTo("");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperDoesNotMapPriorityIfNull() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withPriority(null).build();

        String filter = searchRequestMapper.map(searchRequest);

        assertThat(filter).isEqualTo("");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsPriority() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withPriority(1).build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_PRIORITY, 1);
        assertThat(filter).isEqualTo(" WHERE priority = :priority");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsLabels() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withLabel("my-recurring-job-label").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_LABELS, "%my-recurring-job-label%");
        assertThat(filter).isEqualTo(" WHERE labels like :labels");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobName() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withJobName("some NAME").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_NAME, "%some name%");
        assertThat(filter).isEqualTo(" WHERE jobName like :jobName");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobId() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withId("some-id").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).withId("some-id");
        assertThat(filter).isEqualTo(" WHERE id = :id");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobIds() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withIds("some-id-1", "some-id-2").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_ID, asList("some-id-1", "some-id-2"));
        assertThat(filter).isEqualTo(" WHERE id in (:id-0, :id-1)");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobSignature() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withJobSignature("System.out.print").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_JOB_SIGNATURE, "System.out.print");
        assertThat(filter).isEqualTo(" WHERE jobSignature = :jobSignature");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsServerTag() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withServerTag("SOME_TAG").build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_SERVER_TAG, "%SOME_TAG%");
        assertThat(filter).isEqualTo(" WHERE serverTag like :serverTag");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsCreatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withCreatedAt(from, to).build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_CREATED_AT + "From", from);
        verify(recurringJobTable).with(FIELD_CREATED_AT + "To", to);
        assertThat(filter).isEqualTo(" WHERE createdAt >= :createdAtFrom and createdAt < :createdAtTo");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsUpdatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withUpdatedAt(from, to).build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_UPDATED_AT + "From", from);
        verify(recurringJobTable).with(FIELD_UPDATED_AT + "To", to);
        assertThat(filter).isEqualTo(" WHERE updatedAt >= :updatedAtFrom and updatedAt < :updatedAtTo");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsRunsMoreThanOncePerMinute() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withRunsMoreThanOncePerMinute(true).build();

        String filter = searchRequestMapper.map(searchRequest);

        verify(recurringJobTable).with(FIELD_RUNS_MORE_THAN_ONCE_PER_MINUTE, 1);
        assertThat(filter).isEqualTo(" WHERE runsMoreThanOncePerMinute = :runsMoreThanOncePerMinute");
    }

}