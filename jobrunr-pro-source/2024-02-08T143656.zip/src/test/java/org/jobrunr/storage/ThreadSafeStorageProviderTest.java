package org.jobrunr.storage;

import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.server.BackgroundJobServer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static java.time.Duration.between;
import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aJobInProgress;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.StorageProviderUtils.Metadata.RATE_LIMITER_NAME;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ThreadSafeStorageProviderTest {

    @Mock
    private StorageProvider storageProviderMock;
    @Mock
    private BackgroundJobServer backgroundJobServerMock;

    @Captor
    private ArgumentCaptor<JobSearchRequest> jobSearchRequestArgumentCaptor;

    private ThreadSafeStorageProvider threadSafeStorageProvider;

    @BeforeEach
    void setUp() {
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);
        reset(storageProviderMock);

        lenient().when(storageProviderMock.save(any(Job.class))).thenAnswer(invocation -> {
            sleep(100);
            return invocation.getArgument(0);
        });
        lenient().when(storageProviderMock.save(any(List.class))).thenAnswer(invocation -> {
            sleep(100);
            return invocation.getArgument(0);
        });
        lenient().when(backgroundJobServerMock.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());
    }

    @Test
    void multipleJobsCanBeSavedConcurrently() throws InterruptedException {
        final Job succeededJob1 = aSucceededJob().build();
        final Job succeededJob2 = aSucceededJob().build();
        final Job succeededJob3 = aSucceededJob().build();
        final Job failedJob = aFailedJob().build();

        CountDownLatch countDownLatch = new CountDownLatch(4);

        final ExecutorService executorService = Executors.newFixedThreadPool(4);
        final Callable<Void> runnable1 = () -> saveAndCountDown(succeededJob1, countDownLatch);
        final Callable<Void> runnable2 = () -> saveAndCountDown(succeededJob2, countDownLatch);
        final Callable<Void> runnable3 = () -> saveAndCountDown(succeededJob3, countDownLatch);
        final Callable<Void> runnable4 = () -> saveAndCountDown(failedJob, countDownLatch);

        final Instant before = Instant.now();
        executorService.invokeAll(asList(
                runnable1,
                runnable2,
                runnable3,
                runnable4
        ));
        countDownLatch.await();
        final Instant after = Instant.now();

        assertThat(between(before, after).toMillis()).isLessThan(500L);
    }

    @Test
    void sameJobCanNotBeSavedConcurrently() throws InterruptedException {
        final Job jobInProgress1 = aJobInProgress().build();
        final Job jobInProgress2 = aJobInProgress().build();
        final Job finishedJob = aCopyOf(jobInProgress1).withSucceededState().build();

        CountDownLatch countDownLatch = new CountDownLatch(2);

        final ExecutorService executorService = Executors.newFixedThreadPool(2);
        final Callable<Void> runnable1 = () -> saveAllAndCountDown(asList(jobInProgress1, jobInProgress2), countDownLatch);
        final Callable<Void> runnable2 = () -> saveAndCountDown(finishedJob, countDownLatch);

        final Instant before = Instant.now();
        executorService.invokeAll(asList(
                runnable1,
                runnable2
        ));
        countDownLatch.await();
        final Instant after = Instant.now();

        assertThat(between(before, after).toMillis()).isGreaterThan(200L);
    }

    @Test
    public void batchChildJobsAreDeletedWhenBatchJobIsEnqueuedAfterFailureToNotHaveDoublesWhenRetriesHappen() {
        InOrder inOrder = Mockito.inOrder(storageProviderMock);

        //GIVEN
        final BatchJob batchJob = anEnqueuedBatchJob().withId().build();

        //WHEN
        threadSafeStorageProvider.save(batchJob);

        //THEN
        inOrder.verify(storageProviderMock).deleteJobsPermanently(jobSearchRequestArgumentCaptor.capture());
        inOrder.verify(storageProviderMock).save(batchJob);
        assertThat(jobSearchRequestArgumentCaptor.getValue())
                .hasState(AWAITING)
                .hasParentId(batchJob.getId());

        //WHEN
        batchJob.startProcessingOn(backgroundJobServerMock);
        threadSafeStorageProvider.save(batchJob);

        //THEN
        inOrder.verify(storageProviderMock).save(batchJob);
        inOrder.verifyNoMoreInteractions();
    }

    @Test
    public void batchChildJobsAreDeletedWhenListOfBatchJobsIsEnqueuedAfterFailureToNotHaveDoublesWhenRetriesHappen() {
        InOrder inOrder = Mockito.inOrder(storageProviderMock);

        //GIVEN
        final BatchJob batchJob = anEnqueuedBatchJob().withId().build();

        //WHEN
        threadSafeStorageProvider.save(asList(batchJob));

        //THEN
        inOrder.verify(storageProviderMock).deleteJobsPermanently(jobSearchRequestArgumentCaptor.capture());
        inOrder.verify(storageProviderMock).save(asList(batchJob));
        assertThat(jobSearchRequestArgumentCaptor.getValue())
                .hasState(AWAITING)
                .hasParentId(batchJob.getId());

        //WHEN
        batchJob.startProcessingOn(backgroundJobServerMock);
        threadSafeStorageProvider.save(asList(batchJob));

        //THEN
        inOrder.verify(storageProviderMock).save(asList(batchJob));
        inOrder.verifyNoMoreInteractions();
    }

    @Test
    public void batchChildJobsAreNotDeletedWhenBatchUpdateProcessingHappens() {
        // GIVEN
        final BatchJob batchJob = anEnqueuedBatchJob().withId().build();

        // WHEN
        batchJob.startProcessingOn(backgroundJobServerMock);
        threadSafeStorageProvider.save(batchJob);

        // THEN
        verify(storageProviderMock).save(batchJob);
        verifyNoMoreInteractions(storageProviderMock);
        clearInvocations(storageProviderMock);

        // WHEN
        batchJob.updateProcessing();
        threadSafeStorageProvider.save(batchJob);

        // THEN
        verify(storageProviderMock).save(batchJob);
        verifyNoMoreInteractions(storageProviderMock);
        verify(storageProviderMock, never()).deleteJobsPermanently(any(JobSearchRequest.class));
        verifyNoMoreInteractions(storageProviderMock);
    }

    @Test
    public void batchChildJobsAreNotDeletedWhenBatchJobIsScheduledAfterFailure() {
        // GIVEN
        final BatchJob batchJob = aBatchJob().withId().withScheduledState().build();

        // WHEN
        threadSafeStorageProvider.save(batchJob);

        // THEN
        verify(storageProviderMock).save(batchJob);
        verifyNoMoreInteractions(storageProviderMock);
        clearInvocations(storageProviderMock);
    }

    @Test
    public void batchChildJobsAreNotDeletedWhenJobIsNotABatchJob() {
        // GIVEN
        final Job job = anEnqueuedJobWithName().withId().build();

        // WHEN
        job.startProcessingOn(backgroundJobServerMock);
        threadSafeStorageProvider.save(job);

        // THEN
        verify(storageProviderMock).save(job);
        verifyNoMoreInteractions(storageProviderMock);
        clearInvocations(storageProviderMock);

        // WHEN
        job.updateProcessing();
        threadSafeStorageProvider.save(job);

        // THEN
        verify(storageProviderMock).save(job);
        verifyNoMoreInteractions(storageProviderMock);
        verify(storageProviderMock, never()).deleteJobsPermanently(any(JobSearchRequest.class));
        verifyNoMoreInteractions(storageProviderMock);
    }

    @Test
    void onSaveOfJobWithUnknownRateLimiterExceptionIsThrown() {
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job job = anEnqueuedJobWithName()
                .withRateLimiter("unknown-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.save(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter 'unknown-rate-limiter' is not configured.");
    }

    @Test
    void onSaveOfJobWithKnownRateLimiterItIsSavedInActualStorageProvider() {
        when(storageProviderMock.getMetadata(RATE_LIMITER_NAME))
                .thenReturn(asList(new JobRunrMetadata(RATE_LIMITER_NAME, "known-rate-limiter", "5/PT1S")));
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job job = anEnqueuedJobWithName()
                .withRateLimiter("known-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.save(job)).doesNotThrowAnyException();
        verify(storageProviderMock).save(job);
    }

    @Test
    void onSaveReplaceOfJobWithUnknownRateLimiterExceptionIsThrown() {
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job job = anEnqueuedJobWithName()
                .withRateLimiter("unknown-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.saveReplace(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter 'unknown-rate-limiter' is not configured.");
    }

    @Test
    void onSaveReplaceOfJobWithKnownRateLimiterItIsSavedInActualStorageProvider() {
        when(storageProviderMock.getMetadata(RATE_LIMITER_NAME))
                .thenReturn(asList(new JobRunrMetadata(RATE_LIMITER_NAME, "known-rate-limiter", "5/PT1S")));
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job job = anEnqueuedJobWithName()
                .withRateLimiter("known-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.saveReplace(job)).doesNotThrowAnyException();
        verify(storageProviderMock).saveReplace(job);
    }

    @Test
    void onSaveOfJobListWithUnknownRateLimiterExceptionIsThrown() {
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job jobWithUnknownRateLimiter = anEnqueuedJobWithName()
                .withRateLimiter("unknown-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.save(asList(jobWithUnknownRateLimiter)))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter 'unknown-rate-limiter' is not configured.");
    }

    @Test
    void onSaveOfJobWithKnownRateLimiterThenRateLimitersAreNotReloaded() {
        when(storageProviderMock.getMetadata(RATE_LIMITER_NAME))
                .thenReturn(asList(new JobRunrMetadata(RATE_LIMITER_NAME, "known-rate-limiter", "5/PT1S")));
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        threadSafeStorageProvider.save(anEnqueuedJobWithName().withRateLimiter("known-rate-limiter").build());
        threadSafeStorageProvider.save(anEnqueuedJobWithName().withRateLimiter("known-rate-limiter").build());

        verify(storageProviderMock, times(1)).getMetadata(RATE_LIMITER_NAME);
    }

    @Test
    void ifJobListWithKnownRateLimiterIsSavedItIsSavedInActualStorageProvider() {
        when(storageProviderMock.getMetadata(RATE_LIMITER_NAME))
                .thenReturn(asList(new JobRunrMetadata(RATE_LIMITER_NAME, "known-rate-limiter", "5/PT1S")));
        threadSafeStorageProvider = new ThreadSafeStorageProvider(storageProviderMock);

        Job job = anEnqueuedJobWithName()
                .withRateLimiter("known-rate-limiter")
                .build();

        assertThatCode(() -> threadSafeStorageProvider.save(asList(job))).doesNotThrowAnyException();
        verify(storageProviderMock).save(asList(job));
    }

    private Void saveAndCountDown(Job job, CountDownLatch countDownLatch) {
        threadSafeStorageProvider.save(job);
        countDownLatch.countDown();
        return null;
    }

    private Void saveAllAndCountDown(List<Job> jobs, CountDownLatch countDownLatch) {
        threadSafeStorageProvider.save(jobs);
        countDownLatch.countDown();
        return null;
    }
}