package org.jobrunr.storage.sql.h2;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.SqlStorageProviderTest;
import org.jobrunr.storage.sql.common.LiquibaseMigrationTest;
import org.junit.jupiter.api.AfterAll;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SetupH2UsingLiquibaseStorageProviderTest extends SqlStorageProviderTest implements LiquibaseMigrationTest {

    private static HikariDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        if (testMethodIndex < 5) {
            try {
                migrateDatabaseUsingLiquibase("h2");
            } catch (Exception e) {
                migrateDatabaseUsingLiquibase("h2");
            }
        }
    }

    @Override
    public HikariDataSource getDataSource() {
        if (dataSource == null) {
            HikariConfig config = new HikariConfig();

            config.setJdbcUrl("jdbc:h2:/tmp/test-hikari-liquibase;CASE_INSENSITIVE_IDENTIFIERS=TRUE;AUTO_SERVER=TRUE");
            config.setUsername("sa");
            config.setPassword("sa");
            config.setAutoCommit(true);
            dataSource = new HikariDataSource(config);
        }
        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() throws IOException {
        dataSource.close();
        Files.delete(Path.of("/tmp/test-hikari-liquibase.mv.db"));
        Files.delete(Path.of("/tmp/test-hikari-liquibase.trace.db"));
    }
}
