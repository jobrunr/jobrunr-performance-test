package org.jobrunr.storage.nosql.mongo.mapper;

import org.bson.conversions.Bson;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Paging.CursorBasedPage;
import org.jobrunr.storage.navigation.CursorBasedPageRequest;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.states.StateName.ALL_STATES;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.nosql.mongo.MongoUtils.toMicroSeconds;

class MongoDBJobSearchRequestMapperTest {

    MongoDBJobSearchRequestMapper searchRequestMapper = new MongoDBJobSearchRequestMapper();

    @Test
    void mongoDBJobSearchRequestMapperMapsSearchRequestAndPageRequest() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateName(ENQUEUED).build();
        CursorBasedPageRequest pageRequest = CursorBasedPage.ascOnName(20);

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest, pageRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='state', value=ENQUEUED}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsState() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateName(ENQUEUED).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='state', value=ENQUEUED}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsSingleStatesToState() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ENQUEUED).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='state', value=ENQUEUED}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsStates() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ENQUEUED, PROCESSING, SUCCEEDED).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='state', operator='$in', value=[ENQUEUED, PROCESSING, SUCCEEDED]}");
    }

    @Test
    void mongoDBJobSearchRequestMapperDoesNotMapStatesIfItAreAllStates() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ALL_STATES()).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("{}");
    }

    @Test
    void mongoDBJobSearchRequestMapperDoesNotMapPriorityIfNull() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withPriority(null).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("{}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsPriority() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withPriority(1).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='priority', value=1}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobName() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobName("some NAME").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='jobName', operator='$eq', value=BsonRegularExpression{pattern='.*some name.*', options=''}}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobId() {
        UUID jobId = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobId(jobId).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='_id', value=" + jobId + "}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobIds() {
        UUID jobId0 = UUID.randomUUID();
        UUID jobId1 = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobIds(jobId0, jobId1).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='_id', operator='$in', value=[" + jobId0 + ", " + jobId1 + "]}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsLabels() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withLabel("my-job-label").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='labels', operator='$eq', value=BsonRegularExpression{pattern='.*my-job-label.*', options=''}}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobSignature() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobSignature("System.out.print").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='jobSignature', value=System.out.print}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobFingerprint() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobFingerprint("System.out.print").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='jobFingerprint', operator='$eq', value=BsonRegularExpression{pattern='.*\\QSystem.out.print\\E.*', options='i'}}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsJobExceptionType() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobExceptionType("java.lang.IllegalStateException").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='jobExceptionType', value=java.lang.IllegalStateException}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsServerTag() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withServerTag("SOME_TAG").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='serverTag', operator='$eq', value=BsonRegularExpression{pattern='.*SOME_TAG.*', options='i'}}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsMutex() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withMutex("Windows").build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='mutex', operator='$eq', value=BsonRegularExpression{pattern='.*\\QWindows\\E.*', options='i'}}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsAwaitingOn() {
        UUID awaitingOn = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withAwaitingOn(awaitingOn).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='awaitingOn', value=" + awaitingOn + "}");
    }

    @Test
    void sqlJobSearchRequestMapperMapsParentId() {
        UUID parentId = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withParentId(parentId).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='parentJobId', value=" + parentId + "}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsRateLimiter() {
        String rateLimiter = "my-rate-limiter";
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withRateLimiter(rateLimiter).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='rateLimiter', value=my-rate-limiter}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsOnlyBatchJobs() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withOnlyBatchJobs(true).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='isBatch', value=true}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsCreatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withCreatedAt(from, to).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("And Filter{filters=[Operator Filter{fieldName='createdAt', operator='$gte', value=" + toMicroSeconds(from) + "}, Operator Filter{fieldName='createdAt', operator='$lt', value=" + toMicroSeconds(to) + "}]}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsUpdatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withUpdatedAt(from, to).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("And Filter{filters=[Operator Filter{fieldName='updatedAt', operator='$gte', value=" + toMicroSeconds(from) + "}, Operator Filter{fieldName='updatedAt', operator='$lt', value=" + toMicroSeconds(to) + "}]}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsScheduledAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withScheduledAt(from, to).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("And Filter{filters=[Operator Filter{fieldName='scheduledAt', operator='$gte', value=" + toMicroSeconds(from) + "}, Operator Filter{fieldName='scheduledAt', operator='$lt', value=" + toMicroSeconds(to) + "}]}");
    }

    @Test
    void mongoDBJobSearchRequestMapperMapsDeleteAt() {
        Instant deleteAt = Instant.now();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withDeleteAtTo(deleteAt).build();

        Bson filter = searchRequestMapper.mapToFilter(jobSearchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='deleteAt', operator='$lt', value=" + toMicroSeconds(deleteAt) + "}");
    }
}