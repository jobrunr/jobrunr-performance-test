package org.jobrunr.storage;

import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;

import static org.jobrunr.utils.resilience.RateLimiter.Builder.rateLimit;

public class InMemoryStorageProviderUsingJacksonTest extends StorageProviderTest {

    private StorageProvider storageProvider;

    @Override
    protected void cleanup(int testMethodIndex) {
        storageProvider = new InMemoryStorageProvider(rateLimit().withoutLimits());
        storageProvider.setJobMapper(new JobMapper(getJsonMapper()));
    }

    @Override
    protected StorageProvider getStorageProvider() {
        return storageProvider;
    }

    @Override
    protected ThrowingStorageProvider makeThrowingStorageProvider(StorageProvider storageProvider) {
        return new InMemoryStorageProviderTest.ThrowingInMemoryStorageProvider(storageProvider);
    }

    @Override
    protected JsonMapper getJsonMapper() {
        return new JacksonJsonMapper();
    }
}
