package org.jobrunr.storage.sql.common;

import org.flywaydb.core.Flyway;
import org.jobrunr.utils.FileUtils;

import javax.sql.DataSource;

import static org.flywaydb.core.api.Location.FILESYSTEM_PREFIX;

public interface FlywayMigrationTest {

    DataSource getDataSource();

    default void migrateDatabaseUsingFlyway(String databaseType) {
        String outputDirectory = System.getProperty("java.io.tmpdir") + "flyway/" + databaseType + "/migrations";
        FileUtils.deleteAllFiles(outputDirectory);
        System.setProperty("databaseManager", "flyway");
        System.setProperty("output", outputDirectory);
        DatabaseSqlMigrationFileProvider.main(new String[]{databaseType});
        runMigrations(outputDirectory);
    }

    private void runMigrations(String outputDirectory) {
        Flyway flyway = Flyway.configure()
                .dataSource(getDataSource())
                .locations(FILESYSTEM_PREFIX + outputDirectory)
                .load();
        flyway.migrate();
    }
}
