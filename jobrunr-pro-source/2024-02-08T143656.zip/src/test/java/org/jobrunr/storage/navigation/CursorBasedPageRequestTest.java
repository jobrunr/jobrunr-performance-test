package org.jobrunr.storage.navigation;

import org.jobrunr.jobs.Job;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.StorageProviderUtils.Jobs;
import org.junit.jupiter.api.Test;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;

class CursorBasedPageRequestTest {

    @Test
    void testCursorBasedPageRequestWithEmptyString() {
        CursorBasedPageRequest cursorBasedPageRequest = CursorBasedPageRequest.fromString("");

        assertThat(cursorBasedPageRequest).isNull();
    }

    @Test
    void testCursorBasedPageRequestWithoutCursorFromAndToString() {
        CursorBasedPageRequest cursorBasedPageRequest = CursorBasedPageRequest.fromString("order=jobName:ASC&limit=10");

        assertThat(cursorBasedPageRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 10)
                .hasFieldOrPropertyWithValue("cursor", null);

        assertThat(cursorBasedPageRequest.asString()).isEqualTo("order=jobName:ASC&limit=10&cursor=");
    }

    @Test
    void testCursorBasedPageRequestWithEmptyCursorFromAndToString() {
        CursorBasedPageRequest cursorBasedPageRequest = CursorBasedPageRequest.fromString("order=jobName:ASC&limit=10&cursor=");

        assertThat(cursorBasedPageRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 10)
                .hasFieldOrPropertyWithValue("cursor", "");

        assertThat(cursorBasedPageRequest.asString()).isEqualTo("order=jobName:ASC&limit=10&cursor=");
    }

    @Test
    void testCursorBasedPageRequestWithCursorFromAndToString() {
        CursorBasedPageRequest cursorBasedPageRequest = CursorBasedPageRequest.fromString("order=jobName:ASC&limit=10&cursor=am9iTmFtZT1Kb2IgMnx8fGNyZWF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFp8fHxkZWxldGVBdD18fHxpZD00OTk5OGM2Mi04MWRmLTQyNjMtYjMwMS0xNTFjYjZjMDMxZjJ8fHxwcmlvcml0eT0tMXx8fHNjaGVkdWxlZEF0PXx8fHVwZGF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFo=");

        assertThat(cursorBasedPageRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 10)
                .hasFieldOrPropertyWithValue("cursor", "am9iTmFtZT1Kb2IgMnx8fGNyZWF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFp8fHxkZWxldGVBdD18fHxpZD00OTk5OGM2Mi04MWRmLTQyNjMtYjMwMS0xNTFjYjZjMDMxZjJ8fHxwcmlvcml0eT0tMXx8fHNjaGVkdWxlZEF0PXx8fHVwZGF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFo=");

        assertThat(cursorBasedPageRequest.asString()).isEqualTo("order=jobName:ASC&limit=10&cursor=am9iTmFtZT1Kb2IgMnx8fGNyZWF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFp8fHxkZWxldGVBdD18fHxpZD00OTk5OGM2Mi04MWRmLTQyNjMtYjMwMS0xNTFjYjZjMDMxZjJ8fHxwcmlvcml0eT0tMXx8fHNjaGVkdWxlZEF0PXx8fHVwZGF0ZWRBdD0yMDIzLTEyLTA3VDEwOjE3OjIwLjgwNzk0MFo=");
    }

    @Test
    void testCursorBasedPageRequestWithEmptyCursorReturnsNoCursorValues() {
        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest(Jobs.FIELD_NAME + ":ASC", "", 10);

        assertThat(cursorBasedPageRequest.getCursorValues()).isNull();
    }

    @Test
    void testCursorBasedPageRequestWithCursorReturnsCorrectCursorValues() {
        CursorBasedPageRequest cursorBasedPageRequest1 = Paging.CursorBasedPage.ascOnName(2);

        Page<Job> jobPage = cursorBasedPageRequest1.mapToNewPage(50, asList(
                anEnqueuedJob().withName("Job 1").build(),
                anEnqueuedJob().withName("Job 2").build()));
        CursorBasedPageRequest cursorBasedPageRequest2 = Paging.CursorBasedPage.next(jobPage);

        assertThat(cursorBasedPageRequest2.getCursorValues())
                .isNotEmpty()
                .containsEntry(Jobs.FIELD_NAME, "Job 2");
    }

    @Test
    void testCursorBasedPageRequestNextPageWorks() {
        CursorBasedPageRequest cursorBasedPageRequest = Paging.CursorBasedPage.ascOnName(2);

        Page<Job> jobPage1 = cursorBasedPageRequest.mapToNewPage(50, asList(
                anEnqueuedJob().withName("Job 1").build(),
                anEnqueuedJob().withName("Job 2").build()));
        CursorBasedPageRequest page2CursorBasedPageRequest = Paging.CursorBasedPage.next(jobPage1);

        Page<Job> jobPage2 = page2CursorBasedPageRequest.mapToNewPage(50, asList(
                anEnqueuedJob().withName("Job 3").build(),
                anEnqueuedJob().withName("Job 4").build()));

        CursorBasedPageRequest page1CursorBasedPageRequest = Paging.CursorBasedPage.previous(jobPage2);
        CursorBasedPageRequest page3CursorBasedPageRequest = Paging.CursorBasedPage.next(jobPage2);

        assertThat(page1CursorBasedPageRequest.getCursorValues())
                .isNotEmpty()
                .containsEntry(Jobs.FIELD_NAME, "Job 3");
        assertThat(page3CursorBasedPageRequest.getCursorValues())
                .isNotEmpty()
                .containsEntry(Jobs.FIELD_NAME, "Job 4");
    }

    @Test
    void testCursorBasedPageRequestWithCursorFromString() {
        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest(Jobs.FIELD_NAME + ":ASC", Jobs.FIELD_NAME + "=job name", 10);

        String pageRequestAsString = cursorBasedPageRequest.asString();
        CursorBasedPageRequest cursorBasedPageRequestFromString = CursorBasedPageRequest.fromString(pageRequestAsString);

        assertThat(cursorBasedPageRequestFromString)
                .usingRecursiveComparison()
                .isEqualTo(cursorBasedPageRequest);
    }
}