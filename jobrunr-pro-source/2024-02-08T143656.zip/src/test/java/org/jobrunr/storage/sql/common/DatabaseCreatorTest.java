package org.jobrunr.storage.sql.common;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.h2.jdbcx.JdbcDataSource;
import org.h2.tools.Upgrade;
import org.jobrunr.JobRunrException;
import org.jobrunr.configuration.JobRunrPro;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.tasks.MigrateFromV5toV6Task;
import org.jobrunr.server.tasks.MigrateFromV6toV7Task;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.sql.SqlStorageProvider;
import org.jobrunr.storage.sql.common.migrations.DefaultSqlMigrationProvider;
import org.jobrunr.storage.sql.common.migrations.SqlMigration;
import org.jobrunr.storage.sql.h2.H2StorageProvider;
import org.jobrunr.storage.sql.mariadb.MariaDbStorageProvider;
import org.jobrunr.storage.sql.mysql.MySqlStorageProvider;
import org.jobrunr.storage.sql.postgres.PostgresStorageProvider;
import org.jobrunr.storage.sql.sqlite.SqLiteStorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.sqlite.SQLiteDataSource;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Stream;

import static java.util.Comparator.comparing;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.fail;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DatabaseCreatorTest {

    static final String SQLITE_DB1 = "/tmp/oss-to-pro.db";
    static final String SQLITE_DB2 = "/tmp/jobrunr-failing-test.db";
    static final String H2_DB1 = "/tmp/test-correct-schema";
    static final String H2_DB2 = "/tmp/test-wrong-schema";

    static final String SQLITE_OSS_TO_PRO_ORIGINAL_20220501 = "src/test/resources/database/sqlite-oss-to-pro-20220501.db";
    static final String H2_OSS_TO_PRO_ORIGINAL_20230920 = "src/test/resources/database/h2-oss-to-pro-20230920.mv.db";
    static final String H2_PRO_V5 = "src/test/resources/database/h2-pro-v5.0.0.mv.db";

    @BeforeEach
    void setupJobStorageProvider() throws IOException {
        JobRunrPro.configure();
        deleteSqliteDataSource(SQLITE_DB1);
        deleteSqliteDataSource(SQLITE_DB2);
        deleteH2DataSource(H2_DB1);
        deleteH2DataSource(H2_DB2);
    }

    @Test
    void noSmallSQLKeywordsInSqlFilesSoTablePrefixStatementUpdaterWorksCorrectly() {
        migrationsFor(H2StorageProvider.class).forEach(this::assertNoLowerCaseSQLKeywords);
        migrationsFor(MariaDbStorageProvider.class).forEach(this::assertNoLowerCaseSQLKeywords);
        migrationsFor(MySqlStorageProvider.class).forEach(this::assertNoLowerCaseSQLKeywords);
        migrationsFor(PostgresStorageProvider.class).forEach(this::assertNoLowerCaseSQLKeywords);
        migrationsFor(SqLiteStorageProvider.class).forEach(this::assertNoLowerCaseSQLKeywords);
    }

    @Test
    void testSqlLiteMigrationsUsingMainMethod() {
        assertThatCode(() -> DatabaseCreator.main(new String[]{"jdbc:sqlite:" + SQLITE_DB1, "", ""})).doesNotThrowAnyException();
    }

    @Test
    void testSqlLiteMigrations() {
        final DatabaseCreator databaseCreator = new DatabaseCreator(createSqliteDataSource("jdbc:sqlite:" + SQLITE_DB1), SqLiteStorageProvider.class);
        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();
        assertThatCode(databaseCreator::validateTables).doesNotThrowAnyException();
    }

    @Test
    void testSqlLiteMigrationsAllMigrationsApplied() {
        DefaultSqlMigrationProvider sqlMigrationProvider = new DefaultSqlMigrationProvider();
        List<SqlMigration> migrations = sqlMigrationProvider.getMigrations(DatabaseCreator.class);

        SQLiteDataSource dataSource = createSqliteDataSource("jdbc:sqlite:" + SQLITE_DB1);
        final DatabaseCreator databaseCreator = new DatabaseCreator(dataSource, SqLiteStorageProvider.class);
        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();

        try (Connection connection = dataSource.getConnection()) {
            migrations.forEach(migration -> assertThat(databaseCreator.isMigrationApplied(connection, migration))
                    .describedAs("Expecting %s to be applied", migration)
                    .isTrue());
        } catch (SQLException e) {
            fail("Error evaluating SQL", e);
        }
    }

    @Test
    void testValidateWithoutTables() {
        final DatabaseCreator databaseCreator = new DatabaseCreator(createSqliteDataSource("jdbc:sqlite:" + SQLITE_DB2));
        assertThatThrownBy(databaseCreator::validateTables).isInstanceOf(JobRunrException.class);
    }

    @Test
    void testH2MigrationsWithSchema() {
        final JdbcDataSource dataSource = createH2DataSource("jdbc:h2:/tmp/test-correct-schema;INIT=CREATE SCHEMA IF NOT EXISTS the_schema");
        final DatabaseCreator databaseCreator = new DatabaseCreator(dataSource, "the_schema.prefix_", H2StorageProvider.class);
        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();
        assertThatCode(databaseCreator::validateTables).doesNotThrowAnyException();
    }

    @Test
    void testH2ValidateWithTablesInWrongSchema() {
        final JdbcDataSource dataSource = createH2DataSource("jdbc:h2:/tmp/test-wrong-schema;INIT=CREATE SCHEMA IF NOT EXISTS schema1\\;CREATE SCHEMA IF NOT EXISTS schema2");
        final DatabaseCreator databaseCreatorForSchema1 = new DatabaseCreator(dataSource, "schema1.prefix_", H2StorageProvider.class);
        databaseCreatorForSchema1.runMigrations();
        final DatabaseCreator databaseCreatorForSchema2 = new DatabaseCreator(dataSource, "schema2.prefix_", H2StorageProvider.class);
        assertThatThrownBy(databaseCreatorForSchema2::validateTables).isInstanceOf(JobRunrException.class);
    }

    @Test
    void testMigrationIsNotDoneMoreThanOnce() {
        final JdbcDataSource dataSource = createH2DataSource("jdbc:h2:mem:/test;DB_CLOSE_DELAY=-1");
        final DatabaseCreator databaseCreator = Mockito.spy(new DatabaseCreator(dataSource, H2StorageProvider.class));

        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();

        insertExtraMigrationInDB(dataSource, databaseCreator);
        Mockito.reset(databaseCreator);

        assertThatCode(databaseCreator::runMigrations)
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("A migration was applied multiple times (probably because it took too long and the process was killed). " +
                        "Please cleanup the migrations_table and remove duplicate entries.");

        verify(databaseCreator, never()).runMigration(any(), any());
    }

    @Test
    void testOssToProAt20220501() throws IOException {
        Path tempDirectory = Files.createTempDirectory("test-oss-to-pro-20220501");
        Files.copy(Paths.get(SQLITE_OSS_TO_PRO_ORIGINAL_20220501), tempDirectory.resolve("oss-to-pro.db"), StandardCopyOption.REPLACE_EXISTING);

        final DatabaseCreator databaseCreator = new DatabaseCreator(createSqliteDataSource("jdbc:sqlite:" + tempDirectory.toFile().getAbsolutePath() + "/oss-to-pro.db"), SqLiteStorageProvider.class);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(databaseCreator);

        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();
        assertThatCode(databaseCreator::validateTables).doesNotThrowAnyException();
    }

    @Test
    void testOssToProAt20230920() throws IOException {
        Path tempDirectory = Files.createTempDirectory("test-oss-to-pro-20230920");
        Files.copy(Paths.get(H2_OSS_TO_PRO_ORIGINAL_20230920), tempDirectory.resolve("oss-to-pro.mv.db"), StandardCopyOption.REPLACE_EXISTING);

        final DatabaseCreator databaseCreator = new DatabaseCreator(createH2DataSource("jdbc:h2:file:" + tempDirectory.toFile().getAbsolutePath() + "/oss-to-pro"), H2StorageProvider.class);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(databaseCreator);

        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();
        assertThatCode(databaseCreator::validateTables).doesNotThrowAnyException();

        assertThat(logger).hasNoWarnLogMessages();
    }

    @Test
    void testProV5ToLatestPro() throws Exception {
        Path tempDirectory = Files.createTempDirectory("test-pro-v5");
        Files.copy(Paths.get(H2_PRO_V5), tempDirectory.resolve("pro-v5.0.0.mv.db"), StandardCopyOption.REPLACE_EXISTING);

        Upgrade.upgrade("jdbc:h2:file:" + tempDirectory.toFile().getAbsolutePath() + "/pro-v5.0.0", new Properties(), 214);

        JdbcDataSource h2DataSource = createH2DataSource("jdbc:h2:file:" + tempDirectory.toFile().getAbsolutePath() + "/pro-v5.0.0");
        final DatabaseCreator databaseCreator = new DatabaseCreator(h2DataSource, H2StorageProvider.class);
        final ListAppender<ILoggingEvent> logger = LoggerAssert.initFor(databaseCreator);

        assertThatCode(databaseCreator::runMigrations).doesNotThrowAnyException();
        assertThatCode(databaseCreator::validateTables).doesNotThrowAnyException();

        assertThat(logger).hasNoWarnLogMessages();

        BackgroundJobServer backgroundJobServer = mock(BackgroundJobServer.class);
        JacksonJsonMapper jsonMapper = new JacksonJsonMapper();

        H2StorageProvider h2StorageProvider = new H2StorageProvider(h2DataSource, "myschema_");
        h2StorageProvider.setJobMapper(new JobMapper(jsonMapper));
        when(backgroundJobServer.getStorageProvider()).thenReturn(h2StorageProvider);
        when(backgroundJobServer.getJsonMapper()).thenReturn(jsonMapper);

        new MigrateFromV5toV6Task(backgroundJobServer).run();
        new MigrateFromV6toV7Task(backgroundJobServer).run();

        assertThat(h2StorageProvider.countJobs(new JobSearchRequest(SCHEDULED))).isEqualTo(23);
        assertThat(h2StorageProvider.countJobs(aJobSearchRequest().withParentId(UUID.fromString("0d9f7c47-da87-4d92-aa2a-274a407734ec")).build())).isEqualTo(100);
        assertThat(h2StorageProvider.countRecurringJobs(new RecurringJobSearchRequest())).isEqualTo(1235);
        assertThat(h2StorageProvider.countRecurringJobs(aRecurringJobSearchRequest().withPaused(false).build())).isEqualTo(1235);
        assertThat(h2StorageProvider.countRecurringJobs(aRecurringJobSearchRequest().withPaused(true).build())).isEqualTo(0);
    }

    private JdbcDataSource createH2DataSource(String url) {
        JdbcDataSource dataSource = new JdbcDataSource();
        dataSource.setURL(url);
        return dataSource;
    }

    private static SQLiteDataSource createSqliteDataSource(String url) {
        SQLiteDataSource sqLiteDataSource = new SQLiteDataSource();
        sqLiteDataSource.setUrl(url);
        return sqLiteDataSource;
    }

    private void insertExtraMigrationInDB(DataSource dataSource, DatabaseCreator databaseCreator) {
        try (Connection connection = dataSource.getConnection()) {
            SqlMigration migration = mock(SqlMigration.class);
            when(migration.getFileName()).thenReturn("v021__improve_awaitingon.sql");
            databaseCreator.updateMigrationsTable(connection, migration);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void deleteSqliteDataSource(String path) throws IOException {
        Files.deleteIfExists(Paths.get(path));
    }

    private static void deleteH2DataSource(String path) throws IOException {
        Files.deleteIfExists(Path.of(path + ".mv.db"));
        Files.deleteIfExists(Path.of(path + ".trace.db"));
    }

    private Stream<SqlMigration> migrationsFor(Class<? extends SqlStorageProvider> sqlStorageProviderClass) {
        return new DatabaseMigrationsProvider(sqlStorageProviderClass).getMigrations().sorted(comparing(SqlMigration::getFileName));
    }

    private void assertNoLowerCaseSQLKeywords(SqlMigration sqlMigration) {
        try {
            String migrationSql = sqlMigration.getMigrationSql();
            assertThat(migrationSql)
                    .describedAs("Migration " + sqlMigration.getFileName() + " contains lowercase SQL Keyword")
                    .doesNotContain("create ", "unique", "index", "drop", " on ", " view", " replace");
        } catch (IOException e) {
            throw new RuntimeException("Could not load SQL file", e);
        }
    }
}