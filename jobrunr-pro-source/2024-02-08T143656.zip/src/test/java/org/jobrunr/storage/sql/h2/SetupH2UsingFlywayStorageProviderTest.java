package org.jobrunr.storage.sql.h2;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.SqlStorageProviderTest;
import org.jobrunr.storage.sql.common.FlywayMigrationTest;
import org.junit.jupiter.api.AfterAll;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SetupH2UsingFlywayStorageProviderTest extends SqlStorageProviderTest implements FlywayMigrationTest {

    private static HikariDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        if (testMethodIndex < 5) {
            migrateDatabaseUsingFlyway("h2");
        }
    }

    @Override
    public HikariDataSource getDataSource() {
        if (dataSource == null) {
            HikariConfig config = new HikariConfig();

            config.setJdbcUrl("jdbc:h2:/tmp/test-hikari-flyway;database_to_upper=false");
            config.setUsername("sa");
            config.setPassword("sa");
            config.setAutoCommit(true);
            dataSource = new HikariDataSource(config);
        }
        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() throws IOException {
        dataSource.close();
        Files.delete(Path.of("/tmp/test-hikari-flyway.mv.db"));
        Files.delete(Path.of("/tmp/test-hikari-flyway.trace.db"));
    }
}
