package org.jobrunr.storage.nosql.mongo.mapper;

import org.bson.conversions.Bson;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.jobrunr.storage.nosql.mongo.MongoUtils.toMicroSeconds;

class MongoDBRecurringJobSearchRequestMapperTest {

    private MongoDBRecurringJobSearchRequestMapper searchRequestMapper;

    @BeforeEach
    void setUp() {
        searchRequestMapper = new MongoDBRecurringJobSearchRequestMapper();
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsEmptySearchRequest() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("{}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperDoesNotMapPriorityIfNull() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withPriority(null).build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("{}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsPriority() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withPriority(1).build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='priority', value=1}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsLabels() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withLabel("my-recurring-job-label").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='labels', operator='$eq', value=BsonRegularExpression{pattern='.*my-recurring-job-label.*', options='i'}}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobName() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withJobName("some NAME").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='jobName', operator='$eq', value=BsonRegularExpression{pattern='.*some NAME.*', options='i'}}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobId() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withId("some-id").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='_id', value=some-id}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobIds() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withIds("some-id-1", "some-id-2").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='_id', operator='$in', value=[some-id-1, some-id-2]}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsJobSignature() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withJobSignature("System.out.print").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='jobSignature', value=System.out.print}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsServerTag() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withServerTag("SOME_TAG").build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Operator Filter{fieldName='serverTag', operator='$eq', value=BsonRegularExpression{pattern='.*SOME_TAG.*', options='i'}}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsCreatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withCreatedAt(from, to).build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("And Filter{filters=[Operator Filter{fieldName='createdAt', operator='$gte', value=" + toMicroSeconds(from) + "}, Operator Filter{fieldName='createdAt', operator='$lt', value=" + toMicroSeconds(to) + "}]}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsUpdatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withUpdatedAt(from, to).build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("And Filter{filters=[Operator Filter{fieldName='updatedAt', operator='$gte', value=" + toMicroSeconds(from) + "}, Operator Filter{fieldName='updatedAt', operator='$lt', value=" + toMicroSeconds(to) + "}]}");
    }

    @Test
    void sqlRecurringJobSearchRequestMapperMapsRunsMoreThanOncePerMinute() {
        RecurringJobSearchRequest searchRequest = aRecurringJobSearchRequest().withRunsMoreThanOncePerMinute(true).build();

        Bson filter = searchRequestMapper.mapToFilter(searchRequest);

        assertThat(filter.toString()).isEqualTo("Filter{fieldName='runsMoreThanOncePerMinute', value=true}");
    }
}