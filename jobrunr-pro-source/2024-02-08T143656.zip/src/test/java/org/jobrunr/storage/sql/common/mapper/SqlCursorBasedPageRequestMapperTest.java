package org.jobrunr.storage.sql.common.mapper;

import org.jobrunr.jobs.Job;
import org.jobrunr.storage.navigation.CursorBasedPageRequest;
import org.jobrunr.storage.sql.common.db.AnsiDialect;
import org.jobrunr.storage.sql.common.db.Sql;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Base64;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_ID;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_NAME;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_PRIORITY;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_UPDATED_AT;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SqlCursorBasedPageRequestMapperTest {


    private SqlCursorBasedPageRequestMapper cursorBasedPageRequestMapper;

    @Mock
    Sql sql;

    @BeforeEach
    void setUp() {
        cursorBasedPageRequestMapper = new SqlCursorBasedPageRequestMapper(new AnsiDialect(), Job.ALLOWED_SORT_COLUMNS.keySet());
    }

    @Test
    void testCursorBasedPageRequestJustOrdersByUpdatedAtAscWithoutCursor() {
        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:ASC", null, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo(" ORDER BY updatedAt ASC, id ASC LIMIT :limit");
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:ASC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(updatedAt > :updatedAtOrder) OR (updatedAt = :updatedAtOrder AND id > :idOrder) ORDER BY updatedAt ASC, id ASC LIMIT :limit");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with(FIELD_ID, "idOrder", "9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb");
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:DESC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(updatedAt < :updatedAtOrder) OR (updatedAt = :updatedAtOrder AND id < :idOrder) ORDER BY updatedAt DESC, id DESC LIMIT :limit");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with(FIELD_ID, "idOrder", "9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb");
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesPriorityAndUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||priority=2|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("priority:ASC,updatedAt:ASC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(priority > :priorityOrder) OR (priority = :priorityOrder AND updatedAt > :updatedAtOrder) OR (priority = :priorityOrder AND updatedAt = :updatedAtOrder AND id > :idOrder) ORDER BY priority ASC, updatedAt ASC, id ASC LIMIT :limit");
        verify(sql).with(FIELD_PRIORITY, "priorityOrder", "2");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesPriorityAndUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||priority=2|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("priority:DESC,updatedAt:DESC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(priority < :priorityOrder) OR (priority = :priorityOrder AND updatedAt < :updatedAtOrder) OR (priority = :priorityOrder AND updatedAt = :updatedAtOrder AND id < :idOrder) ORDER BY priority DESC, updatedAt DESC, id DESC LIMIT :limit");
        verify(sql).with(FIELD_PRIORITY, "priorityOrder", "2");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesJobNameAndUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||jobName=my job jobName|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("jobName:ASC,updatedAt:ASC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(jobName > :jobNameOrder) OR (jobName = :jobNameOrder AND updatedAt > :updatedAtOrder) OR (jobName = :jobNameOrder AND updatedAt = :updatedAtOrder AND id > :idOrder) ORDER BY jobName ASC, updatedAt ASC, id ASC LIMIT :limit");
        verify(sql).with(FIELD_NAME, "jobNameOrder", "my job jobName");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with(FIELD_ID, "idOrder", "9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb");
        verify(sql).with("limit", 10);
    }

    @Test
    void testCursorBasedPageRequestUsesJobNameAndUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||jobName=my job jobName|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("jobName:DESC,updatedAt:DESC", cursor, 10);
        String cursorClause = cursorBasedPageRequestMapper.mapToSqlQuery(cursorBasedPageRequest, sql);

        assertThat(cursorClause).isEqualTo("(jobName < :jobNameOrder) OR (jobName = :jobNameOrder AND updatedAt < :updatedAtOrder) OR (jobName = :jobNameOrder AND updatedAt = :updatedAtOrder AND id < :idOrder) ORDER BY jobName DESC, updatedAt DESC, id DESC LIMIT :limit");
        verify(sql).with(FIELD_NAME, "jobNameOrder", "my job jobName");
        verify(sql).with(FIELD_UPDATED_AT, "updatedAtOrder", updatedAt.toString());
        verify(sql).with(FIELD_ID, "idOrder", "9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb");
        verify(sql).with("limit", 10);
    }

    private String toCursor(String input) {
        return Base64.getEncoder().encodeToString(input.getBytes(UTF_8));
    }
}