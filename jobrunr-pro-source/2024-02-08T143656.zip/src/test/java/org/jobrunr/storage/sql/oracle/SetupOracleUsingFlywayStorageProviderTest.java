package org.jobrunr.storage.sql.oracle;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.common.FlywayMigrationTest;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.executioncondition.RunTestBetween;
import org.junit.jupiter.executioncondition.RunTestIfDockerImageExists;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@RunTestBetween(from = "02:00", to = "04:00")
@RunTestIfDockerImageExists("container-registry.oracle.com/database/standard:12.1.0.2")
public class SetupOracleUsingFlywayStorageProviderTest extends AbstractOracleStorageProviderTest implements FlywayMigrationTest {

    private static HikariDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        if (testMethodIndex < 5) {
            migrateDatabaseUsingFlyway("oracle");
        }
    }

    @Override
    protected void cleanupDatabase(DataSource dataSource, int testMethodIndex) {
        super.cleanupDatabase(dataSource, testMethodIndex);
        try (Connection connection = dataSource.getConnection(); Statement statement = connection.createStatement()) {
            statement.execute("PURGE RECYCLEBIN");
        } catch (SQLException e) {
            // could not purge
            throw new RuntimeException(e);
        }
    }

    @Override
    public DataSource getDataSource() {
        if (dataSource == null) {
            HikariConfig config = new HikariConfig();

            config.setJdbcUrl(sqlContainer.getJdbcUrl().replace(":xe", ":ORCL"));
            config.setUsername(sqlContainer.getUsername());
            config.setPassword(sqlContainer.getPassword());
            dataSource = new HikariDataSource(config);
        }

        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() {
        dataSource.close();
    }
}
