package org.jobrunr.storage.navigation;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AmountRequestTest {

    @Test
    void testAmountRequestWithEmptyString() {
        AmountRequest amountRequest = AmountRequest.fromString("");

        assertThat(amountRequest).isNull();
    }

    @Test
    void testAmountRequestWithNullString() {
        AmountRequest amountRequest = AmountRequest.fromString(null);

        assertThat(amountRequest).isNull();
    }

    @Test
    void testAmountRequestWithOrderStringAndNoLimit() {
        AmountRequest amountRequest = AmountRequest.fromString("order=jobName:ASC&");

        assertThat(amountRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 20);
    }

    @Test
    void testAmountRequestWithOrderStringAndEmptyLimit() {
        AmountRequest amountRequest = AmountRequest.fromString("order=jobName:ASC&limit=");

        assertThat(amountRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 20);
    }

    @Test
    void testAmountRequestWithOrderStringAndLimit() {
        AmountRequest amountRequest = AmountRequest.fromString("order=jobName:ASC&limit=40");

        assertThat(amountRequest)
                .hasFieldOrPropertyWithValue("order", "jobName:ASC")
                .hasFieldOrPropertyWithValue("limit", 40);
    }

    @Test
    void testAmountRequestWithoutOrderStringAndLimit() {
        AmountRequest amountRequest = AmountRequest.fromString("limit=30");

        assertThat(amountRequest)
                .hasFieldOrPropertyWithValue("order", "updatedAt:ASC")
                .hasFieldOrPropertyWithValue("limit", 30);
    }

}