package org.jobrunr.storage.sql.common;

import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.DirectoryResourceAccessor;
import org.jobrunr.utils.FileUtils;

import javax.sql.DataSource;
import java.nio.file.Paths;
import java.sql.Connection;

public interface LiquibaseMigrationTest {
    
    DataSource getDataSource();

    default void migrateDatabaseUsingLiquibase(String databaseType) {
        String outputDirectory = System.getProperty("java.io.tmpdir") + "liquibase/" + databaseType + "/migrations";
        FileUtils.deleteAllFiles(outputDirectory);
        System.setProperty("databaseManager", "liquibase");
        System.setProperty("output", outputDirectory);
        DatabaseSqlMigrationFileProvider.main(new String[]{databaseType});
        runMigrations(outputDirectory, databaseType);
    }

    private void runMigrations(String outputDirectory, String databaseType) {
        try (Connection connection = getDataSource().getConnection()) {
            Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(new JdbcConnection(connection));

            Liquibase liquibase = new Liquibase("database-changelog.xml", new DirectoryResourceAccessor(Paths.get(outputDirectory)), database);
            liquibase.update(new Contexts(), new LabelExpression());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}
