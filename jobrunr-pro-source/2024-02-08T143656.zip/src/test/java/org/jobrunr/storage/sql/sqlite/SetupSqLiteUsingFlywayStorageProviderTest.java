package org.jobrunr.storage.sql.sqlite;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.SqlStorageProviderTest;
import org.jobrunr.storage.sql.common.FlywayMigrationTest;
import org.junit.jupiter.api.AfterAll;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SetupSqLiteUsingFlywayStorageProviderTest extends SqlStorageProviderTest implements FlywayMigrationTest {

    private static HikariDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        if (testMethodIndex < 5) {
            migrateDatabaseUsingFlyway("sqlite");
        }
    }


    @Override
    public DataSource getDataSource() {
        if (dataSource == null) {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl("jdbc:sqlite:/tmp/jobrunr-test.db");
            dataSource = new HikariDataSource(config);
        }
        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() throws IOException {
        dataSource.close();
        Files.delete(Path.of("/tmp/jobrunr-test.db"));
    }
}
