package org.jobrunr.storage.nosql.mongo.mapper;

import org.jobrunr.jobs.Job;
import org.jobrunr.storage.navigation.AmountRequest;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnUpdatedAt;

class MongoDBAmountRequestMapperTest {

    MongoDBAmountRequestMapper mapper = new MongoDBAmountRequestMapper(Job.ALLOWED_SORT_COLUMNS.keySet());

    @Test
    void mapsAscOnUpdatedAtOrderCorrectly() {
        AmountRequest amountRequest = ascOnUpdatedAt(20);

        assertThat(mapper.mapToFilter(amountRequest)).isNull();
        assertThat(mapper.mapToSort(amountRequest).toString()).isEqualTo("{\"updatedAt\": 1}");
    }

    @Test
    void mapsAscOnPriorityAndUpdatedAtOrderCorrectly() {
        AmountRequest amountRequest = ascOnPriorityAndUpdatedAt(20);

        assertThat(mapper.mapToFilter(amountRequest)).isNull();
        assertThat(mapper.mapToSort(amountRequest).toString()).isEqualTo("Compound Sort{sorts=[{\"priority\": 1}, {\"updatedAt\": 1}]}");
    }
}