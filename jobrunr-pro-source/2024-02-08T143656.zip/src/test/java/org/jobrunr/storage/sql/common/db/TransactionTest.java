package org.jobrunr.storage.sql.common.db;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;
import java.sql.SQLException;

import static org.jobrunr.storage.sql.common.db.Transaction.AutoCommitMode.INHERIT_FROM_CONNECTION;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionTest {

    @Mock
    private Connection connection;

    @Test
    void testDefaultTransactionModeTransactionSucceedsWithAutocommitTrue() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(true, false);
        final Transaction transaction = new Transaction(connection);

        //WHEN
        transaction.commit();
        transaction.close();

        //THEN
        verify(connection).commit();
        verify(connection, never()).rollback();
        verify(connection).setAutoCommit(true);
    }

    @Test
    void testDefaultTransactionModeTransactionSucceedsWithAutocommitFalse() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(false);
        final Transaction transaction = new Transaction(connection);

        //WHEN
        transaction.commit();
        transaction.close();

        //THEN
        verify(connection).commit();
        verify(connection, never()).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }

    @Test
    void testDefaultTransactionModeTransactionFailsWithAutocommitTrue() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(true, false);
        final Transaction transaction = new Transaction(connection);

        //WHEN
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection).rollback();
        verify(connection).setAutoCommit(true);
    }

    @Test
    void testDefaultTransactionModeTransactionFailsWithAutocommitFalse() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(false);
        final Transaction transaction = new Transaction(connection);

        //WHEN
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }

    @Test
    void testInheritFromTransactionTransactionModeTransactionFailsWithAutocommitTrueButOverriddenInTransaction() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(true);
        final Transaction transaction = new Transaction(connection, INHERIT_FROM_CONNECTION);
        verify(connection, never()).setAutoCommit(anyBoolean());

        //WHEN
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection, never()).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }

    @Test
    void testInheritFromTransactionTransactionModeTransactionSucceedsWithAutocommitTrueButOverriddenInTransaction() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(true);
        final Transaction transaction = new Transaction(connection, INHERIT_FROM_CONNECTION);
        verify(connection, never()).setAutoCommit(anyBoolean());

        //WHEN
        transaction.commit();
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection, never()).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }

    @Test
    void testInheritFromTransactionTransactionModeTransactionFailsWithAutocommitFalseButOverriddenInTransaction() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(false);
        final Transaction transaction = new Transaction(connection, INHERIT_FROM_CONNECTION);
        verify(connection, never()).setAutoCommit(anyBoolean());

        //WHEN
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection, never()).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }

    @Test
    void testInheritFromTransactionTransactionModeTransactionSucceedsWithAutocommitFalseButOverriddenInTransaction() throws SQLException {
        //GIVEN
        when(connection.getAutoCommit()).thenReturn(false);
        final Transaction transaction = new Transaction(connection, INHERIT_FROM_CONNECTION);
        verify(connection, never()).setAutoCommit(anyBoolean());

        //WHEN
        transaction.commit();
        transaction.close();

        //THEN
        verify(connection, never()).commit();
        verify(connection, never()).rollback();
        verify(connection, never()).setAutoCommit(anyBoolean());
    }
}