package org.jobrunr.storage.nosql.mongo.mapper;

import org.bson.conversions.Bson;
import org.jobrunr.jobs.Job;
import org.jobrunr.storage.navigation.CursorBasedPageRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Base64;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.storage.nosql.mongo.MongoUtils.toMicroSeconds;

class MongoDBCursorBasedPageRequestMapperTest {


    private MongoDBCursorBasedPageRequestMapper cursorBasedPageRequestMapper;

    @BeforeEach
    void setUp() {
        cursorBasedPageRequestMapper = new MongoDBCursorBasedPageRequestMapper(Job.ALLOWED_SORT_COLUMNS.keySet());
    }

    @Test
    void testCursorBasedPageRequestJustOrdersByUpdatedAtAscWithoutCursor() {
        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:ASC", null, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);
        Bson sort = cursorBasedPageRequestMapper.mapToSort(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("{}");
        assertThat(sort.toString()).isEqualTo("Compound Sort{sorts=[{\"updatedAt\": 1}, {\"id\": 1}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:ASC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='updatedAt', operator='$gt', value=" + toMicroSeconds(updatedAt) + "}, " +
                "And Filter{filters=[Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$gt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("updatedAt:DESC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='updatedAt', operator='$lt', value=" + toMicroSeconds(updatedAt) + "}, " +
                "And Filter{filters=[Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$lt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesPriorityAndUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||priority=2|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("priority:ASC,updatedAt:ASC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='priority', operator='$gt', value=2}, " +
                "And Filter{filters=[Filter{fieldName='priority', value=2}, Operator Filter{fieldName='updatedAt', operator='$gt', value=" + toMicroSeconds(updatedAt) + "}]}, " +
                "And Filter{filters=[Filter{fieldName='priority', value=2}, Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$gt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesPriorityAndUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||priority=2|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("priority:DESC,updatedAt:DESC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='priority', operator='$lt', value=2}, " +
                "And Filter{filters=[Filter{fieldName='priority', value=2}, Operator Filter{fieldName='updatedAt', operator='$lt', value=" + toMicroSeconds(updatedAt) + "}]}, " +
                "And Filter{filters=[Filter{fieldName='priority', value=2}, Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$lt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesJobNameAndUpdatedAtAsc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||jobName=my job jobName|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("jobName:ASC,updatedAt:ASC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='jobName', operator='$gt', value=my job jobName}, " +
                "And Filter{filters=[Filter{fieldName='jobName', value=my job jobName}, Operator Filter{fieldName='updatedAt', operator='$gt', value=" + toMicroSeconds(updatedAt) + "}]}, " +
                "And Filter{filters=[Filter{fieldName='jobName', value=my job jobName}, Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$gt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    @Test
    void testCursorBasedPageRequestUsesJobNameAndUpdatedAtDesc() {
        Instant updatedAt = Instant.parse("2023-11-26T18:40:00.000Z");
        String cursor = toCursor("id=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb|||jobName=my job jobName|||updatedAt=" + updatedAt);

        CursorBasedPageRequest cursorBasedPageRequest = new CursorBasedPageRequest("jobName:DESC,updatedAt:DESC", cursor, 10);
        Bson filter = cursorBasedPageRequestMapper.mapToFilter(cursorBasedPageRequest);

        assertThat(filter.toString()).isEqualTo("Or Filter{filters=[" +
                "Operator Filter{fieldName='jobName', operator='$lt', value=my job jobName}, " +
                "And Filter{filters=[Filter{fieldName='jobName', value=my job jobName}, Operator Filter{fieldName='updatedAt', operator='$lt', value=" + toMicroSeconds(updatedAt) + "}]}, " +
                "And Filter{filters=[Filter{fieldName='jobName', value=my job jobName}, Filter{fieldName='updatedAt', value=" + toMicroSeconds(updatedAt) + "}, Operator Filter{fieldName='id', operator='$lt', value=9b3c8c83-1ff7-4b2e-9c27-358f9507c4eb}]}]}");
    }

    private String toCursor(String input) {
        return Base64.getEncoder().encodeToString(input.getBytes(UTF_8));
    }
}