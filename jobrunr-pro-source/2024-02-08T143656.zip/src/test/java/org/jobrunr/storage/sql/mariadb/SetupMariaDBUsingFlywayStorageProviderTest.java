package org.jobrunr.storage.sql.mariadb;

import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.common.FlywayMigrationTest;
import org.junit.jupiter.api.AfterAll;
import org.mariadb.jdbc.MariaDbPoolDataSource;

import javax.sql.DataSource;
import java.sql.SQLException;

public class SetupMariaDBUsingFlywayStorageProviderTest extends AbstractMariaDbStorageProviderTest implements FlywayMigrationTest {

    private static MariaDbPoolDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        if (testMethodIndex < 5) {
            migrateDatabaseUsingFlyway("mariadb");
        }
    }

    @Override
    public DataSource getDataSource() {
        if (dataSource == null) {
            try {
                dataSource = new MariaDbPoolDataSource();
                dataSource.setUrl(sqlContainer.getJdbcUrl() + "?rewriteBatchedStatements=true&pool=true&useBulkStmts=false");
                dataSource.setUser(sqlContainer.getUsername());
                dataSource.setPassword(sqlContainer.getPassword());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() {
        dataSource.close();
    }
}
