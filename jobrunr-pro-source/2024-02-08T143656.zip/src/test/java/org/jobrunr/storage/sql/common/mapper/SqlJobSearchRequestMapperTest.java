package org.jobrunr.storage.sql.common.mapper;

import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.Paging.AmountBasedList;
import org.jobrunr.storage.Paging.CursorBasedPage;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.storage.navigation.CursorBasedPageRequest;
import org.jobrunr.storage.navigation.OffsetBasedPageRequest;
import org.jobrunr.storage.sql.common.JobTable;
import org.jobrunr.storage.sql.common.db.AnsiDialect;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.UUID;

import static java.util.Arrays.asList;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.states.StateName.ALL_STATES;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.Paging.OffsetBasedPage.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_CREATED_AT;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_DELETE_AT;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_ID;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_IS_BATCH;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_JOB_EXCEPTION_TYPE;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_JOB_FINGERPRINT;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_JOB_SIGNATURE;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_LABELS;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_MUTEX;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_NAME;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_SCHEDULED_AT;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_SERVER_TAG;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_STATE;
import static org.jobrunr.storage.StorageProviderUtils.Jobs.FIELD_UPDATED_AT;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SqlJobSearchRequestMapperTest {

    @Mock
    private JobTable jobTable;

    private SqlJobSearchRequestMapper searchRequestMapper;

    @BeforeEach
    void setUp() {
        searchRequestMapper = new SqlJobSearchRequestMapper(jobTable, new AnsiDialect());
    }

    @Test
    void sqlJobSearchRequestMapperMapsState() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateName(ENQUEUED).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).withState(ENQUEUED);
        assertThat(filter).isEqualTo(" WHERE state = :state");
    }

    @Test
    void sqlJobSearchRequestMapperMapsSingleStatesToState() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ENQUEUED).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).withState(ENQUEUED);
        assertThat(filter).isEqualTo(" WHERE state = :state");
    }

    @Test
    void sqlJobSearchRequestMapperMapsStates() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ENQUEUED, PROCESSING, SUCCEEDED).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_STATE, asList(ENQUEUED, PROCESSING, SUCCEEDED));
        assertThat(filter).isEqualTo(" WHERE state in (:state-0, :state-1, :state-2)");
    }

    @Test
    void sqlJobSearchRequestMapperDoesNotMapStatesIfItAreAllStates() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withStateNames(ALL_STATES()).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable, never()).with(eq(FIELD_STATE), anyList());
        assertThat(filter).isEmpty();
    }

    @Test
    void sqlJobSearchRequestMapperDoesNotMapPriorityIfNull() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withPriority(null).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        assertThat(filter).isEqualTo("");
    }

    @Test
    void sqlJobSearchRequestMapperMapsPriority() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withPriority(1).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).withPriority(1);
        assertThat(filter).isEqualTo(" WHERE priority = :priority");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobName() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobName("some NAME").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_NAME, "%some name%");
        assertThat(filter).isEqualTo(" WHERE jobName like :jobName");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobId() {
        UUID jobId = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobId(jobId).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_ID, jobId);
        assertThat(filter).isEqualTo(" WHERE id = :id");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobIds() {
        UUID jobId0 = UUID.randomUUID();
        UUID jobId1 = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobIds(jobId0, jobId1).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_ID, asList(jobId0, jobId1));
        assertThat(filter).isEqualTo(" WHERE id in (:id-0, :id-1)");
    }

    @Test
    void sqlJobSearchRequestMapperMapsLabel() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withLabel("my-job-label").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_LABELS, "%my-job-label%");
        assertThat(filter).isEqualTo(" WHERE labels like :labels");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobSignature() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobSignature("System.out.print").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_JOB_SIGNATURE, "System.out.print");
        assertThat(filter).isEqualTo(" WHERE jobSignature = :jobSignature");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobFingerprint() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobFingerprint("System.out.print").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_JOB_FINGERPRINT, "%system.out.print%");
        assertThat(filter).isEqualTo(" WHERE jobFingerprint like :jobFingerprint");
    }

    @Test
    void sqlJobSearchRequestMapperMapsJobExceptionType() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withJobExceptionType("java.lang.IllegalStateException").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_JOB_EXCEPTION_TYPE, "java.lang.IllegalStateException");
        assertThat(filter).isEqualTo(" WHERE jobExceptionType = :jobExceptionType");
    }

    @Test
    void sqlJobSearchRequestMapperMapsServerTag() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withServerTag("SOME_TAG").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_SERVER_TAG, "%SOME_TAG%");
        assertThat(filter).isEqualTo(" WHERE serverTag like :serverTag");
    }

    @Test
    void sqlJobSearchRequestMapperMapsMutex() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withMutex("Windows").build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_MUTEX, "%Windows%");
        assertThat(filter).isEqualTo(" WHERE mutex like :mutex");
    }

    @Test
    void sqlJobSearchRequestMapperMapsAwaitingOn() {
        UUID awaitingOn = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withAwaitingOn(awaitingOn).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).withAwaitingOn(awaitingOn);
        assertThat(filter).isEqualTo(" WHERE awaitingOn = :awaitingOn");
    }

    @Test
    void sqlJobSearchRequestMapperMapsParentId() {
        UUID parentId = UUID.randomUUID();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withParentId(parentId).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with("parentJobId", parentId);
        assertThat(filter).isEqualTo(" WHERE parentJobId = :parentJobId");
    }

    @Test
    void sqlJobSearchRequestMapperMapsRateLimiter() {
        String rateLimiter = "my-rate-limiter";
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withRateLimiter(rateLimiter).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).withRateLimiter(rateLimiter);
        assertThat(filter).isEqualTo(" WHERE rateLimiter = :rateLimiter");
    }

    @Test
    void sqlJobSearchRequestMapperMapsOnlyBatchJobs() {
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withOnlyBatchJobs(true).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_IS_BATCH, 1);
        assertThat(filter).isEqualTo(" WHERE isBatch = :isBatch");
    }

    @Test
    void sqlJobSearchRequestMapperMapsCreatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withCreatedAt(from, to).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_CREATED_AT + "From", from);
        verify(jobTable).with(FIELD_CREATED_AT + "To", to);
        assertThat(filter).isEqualTo(" WHERE createdAt >= :createdAtFrom and createdAt < :createdAtTo");
    }

    @Test
    void sqlJobSearchRequestMapperMapsUpdatedAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withUpdatedAt(from, to).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_UPDATED_AT + "From", from);
        verify(jobTable).with(FIELD_UPDATED_AT + "To", to);
        assertThat(filter).isEqualTo(" WHERE updatedAt >= :updatedAtFrom and updatedAt < :updatedAtTo");
    }

    @Test
    void sqlJobSearchRequestMapperMapsScheduledAt() {
        Instant from = Instant.now();
        Instant to = from.plusSeconds(5);
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withScheduledAt(from, to).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_SCHEDULED_AT + "From", from);
        verify(jobTable).with(FIELD_SCHEDULED_AT + "To", to);
        assertThat(filter).isEqualTo(" WHERE scheduledAt >= :scheduledAtFrom and scheduledAt < :scheduledAtTo");
    }

    @Test
    void sqlJobSearchRequestMapperMapsDeleteAt() {
        Instant deleteAt = Instant.now();
        JobSearchRequest jobSearchRequest = aJobSearchRequest().withDeleteAtTo(deleteAt).build();

        String filter = searchRequestMapper.map(jobSearchRequest);

        verify(jobTable).with(FIELD_DELETE_AT + "To", deleteAt);
        assertThat(filter).isEqualTo(" WHERE deleteAt < :deleteAtTo");
    }

    @Test
    void sqlJobSearchRequestMapperMapsOffsetBasedPageRequest() {
        OffsetBasedPageRequest offsetBasedPageRequest = ascOnPriorityAndUpdatedAt(20, 10);

        String filter = searchRequestMapper.map(offsetBasedPageRequest);
        assertThat(filter).isEqualTo(" ORDER BY priority ASC, updatedAt ASC LIMIT :limit OFFSET :offset");
    }

    @Test
    void sqlJobSearchRequestMapperMapsOffsetBasedPageRequestSwitchesToAmountIfOffsetIs0() {
        OffsetBasedPageRequest offsetBasedPageRequest = ascOnPriorityAndUpdatedAt(0, 10);

        String filter = searchRequestMapper.map(offsetBasedPageRequest);
        assertThat(filter).isEqualTo(" ORDER BY priority ASC, updatedAt ASC LIMIT :limit");
    }

    @Test
    void sqlJobSearchRequestMapperMapsCursorBasedPageRequest() {
        CursorBasedPageRequest cursorBasedPageRequest = CursorBasedPage.ascOnName(10);

        String filter = searchRequestMapper.map(cursorBasedPageRequest);
        assertThat(filter).isEqualTo(" ORDER BY jobName ASC, id ASC LIMIT :limit");
    }

    @Test
    void sqlJobSearchRequestMapperMapsAmountBasedPageRequest() {
        AmountRequest amountRequest = AmountBasedList.ascOnPriorityAndUpdatedAt(10);

        String filter = searchRequestMapper.map(amountRequest);
        assertThat(filter).isEqualTo(" ORDER BY priority ASC, updatedAt ASC LIMIT :limit");
    }
}