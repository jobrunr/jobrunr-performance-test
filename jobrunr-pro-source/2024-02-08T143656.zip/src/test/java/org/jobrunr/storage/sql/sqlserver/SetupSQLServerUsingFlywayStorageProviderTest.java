package org.jobrunr.storage.sql.sqlserver;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.sql.common.FlywayMigrationTest;
import org.junit.jupiter.api.AfterAll;

import javax.sql.DataSource;

public class SetupSQLServerUsingFlywayStorageProviderTest extends AbstractSQLServerStorageProviderTest implements FlywayMigrationTest {

    private static HikariDataSource dataSource;

    @Override
    protected StorageProvider getStorageProvider() {
        return getStorageProvider(true);
    }

    @Override
    protected void setUpDatabaseUsingDatabaseManager(int testMethodIndex) {
        migrateDatabaseUsingFlyway("sqlserver");
    }


    @Override
    public DataSource getDataSource() {
        if (dataSource == null) {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(sqlContainer.getJdbcUrl());
            config.setUsername(sqlContainer.getUsername());
            config.setPassword(sqlContainer.getPassword());
            dataSource = new HikariDataSource(config);
        }
        return dataSource;
    }

    @AfterAll
    public static void destroyDatasource() {
        dataSource.close();
    }
}
