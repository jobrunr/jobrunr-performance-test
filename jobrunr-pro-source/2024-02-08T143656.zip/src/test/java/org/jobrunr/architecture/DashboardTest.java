package org.jobrunr.architecture;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.JobRunrAssertions.contentOfResource;

public class DashboardTest {

    @Test
    void testDashboardSanity() {
        assertThat(contentOfResource("src/main/resources/org/jobrunr/dashboard/frontend/public/index.html"))
                .describedAs("Please make sure to comment the window.contextPath line in index.html is correct")
                .contains("window.contextPath = \"%REACT_APP_CONTEXT_PATH%\"")
                .doesNotContain("window.contextPath = \"/");

        assertThat(contentOfResource("src/main/resources/org/jobrunr/dashboard/frontend/.env"))
                .describedAs("Please make sure to comment the REACT_APP_CONTEXT_PATH line in .env is correct")
                .contains("REACT_APP_CONTEXT_PATH=%CONTEXT_PATH%");

        assertThat(contentOfResource("src/main/resources/org/jobrunr/dashboard/frontend/.env"))
                .describedAs("Please make sure the PUBLIC_URL variable in .env is correct")
                .contains("PUBLIC_URL=%PUBLIC_URL%");

        assertThat(contentOfResource("src/main/resources/org/jobrunr/dashboard/frontend/.env"))
                .describedAs("Please make sure the PUBLIC_URL variable in .env is correct")
                .contains("https://api.jobrunr.io");

        assertThat(contentOfResource("src/main/resources/org/jobrunr/dashboard/frontend/src/components/panic/panic-view.js"))
                .describedAs("Please make sure that panic-view.js has the correct JobRunr API backend url")
                .contains("process.env.REACT_APP_JOBRUNR_API_BASE_URL");
    }

}
