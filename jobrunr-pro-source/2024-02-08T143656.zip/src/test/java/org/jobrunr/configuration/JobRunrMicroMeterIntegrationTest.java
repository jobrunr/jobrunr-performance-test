package org.jobrunr.configuration;

import io.micrometer.core.instrument.MeterRegistry;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.metrics.BackgroundJobServerMetricsBinder;
import org.jobrunr.storage.JobStats;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.metrics.StorageProviderMetricsBinder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

import static java.util.Collections.emptyList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JobRunrMicroMeterIntegrationTest {

    @Mock
    private MeterRegistry meterRegistry;
    @Mock
    private StorageProvider storageProvider;
    @Mock
    private BackgroundJobServer backgroundJobServer;

    @Test
    void testWithStorageProviderOnly() {
        // GIVEN
        JobRunrMicroMeterIntegration jobRunrMicroMeterIntegration = new JobRunrMicroMeterIntegration(meterRegistry);
        when(storageProvider.getJobStats()).thenReturn(JobStats.empty());

        // WHEN
        jobRunrMicroMeterIntegration.initialize(storageProvider, null, null);

        // THEN
        verify(storageProvider).getJobStats();
        verify(storageProvider).addJobStorageOnChangeListener(any(StorageProviderMetricsBinder.class));
        verify(meterRegistry, times(9)).gauge(any(String.class), any(Iterable.class), any(AtomicLong.class));

        assertThat(
                (BackgroundJobServerMetricsBinder) Whitebox.getInternalState(jobRunrMicroMeterIntegration,
                        "backgroundJobServerMetricsBinder")
        ).isNull();

        // WHEN
        assertThatCode(jobRunrMicroMeterIntegration::close).doesNotThrowAnyException();
    }

    @Test
    void testWithStorageProviderAndBackgroundJobServerOnly() {
        // GIVEN
        JobRunrMicroMeterIntegration jobRunrMicroMeterIntegration = new JobRunrMicroMeterIntegration(meterRegistry);
        when(meterRegistry.more()).thenReturn(mock(MeterRegistry.More.class));
        when(storageProvider.getJobStats()).thenReturn(JobStats.empty());
        when(backgroundJobServer.getId()).thenReturn(UUID.randomUUID());

        // WHEN
        jobRunrMicroMeterIntegration.initialize(storageProvider, backgroundJobServer, null);

        // THEN
        verify(storageProvider).getJobStats();
        verify(storageProvider).addJobStorageOnChangeListener(any(StorageProviderMetricsBinder.class));
        verify(meterRegistry, times(9)).gauge(any(String.class), any(Iterable.class), any(AtomicLong.class));

        assertThat(
                (BackgroundJobServerMetricsBinder) Whitebox.getInternalState(jobRunrMicroMeterIntegration,
                        "backgroundJobServerMetricsBinder")
        ).isNotNull();

        // WHEN
        assertThatCode(jobRunrMicroMeterIntegration::close).doesNotThrowAnyException();
    }

    @Test
    void testWithStorageProviderAndBackgroundJobServerAndPublishJobMetrics() {
        // GIVEN
        JobRunrMicroMeterIntegration jobRunrMicroMeterIntegration = new JobRunrMicroMeterIntegration(meterRegistry, true);
        when(meterRegistry.more()).thenReturn(mock(MeterRegistry.More.class));
        when(storageProvider.getJobStats()).thenReturn(JobStats.empty());
        when(backgroundJobServer.getId()).thenReturn(UUID.randomUUID());
        when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID(), emptyList(), null));

        // WHEN
        jobRunrMicroMeterIntegration.initialize(storageProvider, backgroundJobServer, null);

        // THEN
        verify(storageProvider).getJobStats();
        verify(storageProvider).addJobStorageOnChangeListener(any(StorageProviderMetricsBinder.class));
        verify(meterRegistry, times(9)).gauge(any(String.class), any(Iterable.class), any(AtomicLong.class));

        assertThat(
                (BackgroundJobServerMetricsBinder) Whitebox.getInternalState(jobRunrMicroMeterIntegration,
                        "backgroundJobServerMetricsBinder")
        ).isNotNull();

        verify(backgroundJobServer, times(1)).getJobFilters();

        // WHEN
        assertThatCode(jobRunrMicroMeterIntegration::close).doesNotThrowAnyException();
    }


    @Test
    void testWithStorageProviderAndBackgroundJobServerAndJobMetricsLabelsToPublish() {
        // GIVEN
        JobRunrMicroMeterIntegration jobRunrMicroMeterIntegration = new JobRunrMicroMeterIntegration(meterRegistry, "l1", "l2");
        when(meterRegistry.more()).thenReturn(mock(MeterRegistry.More.class));
        when(storageProvider.getJobStats()).thenReturn(JobStats.empty());
        when(backgroundJobServer.getId()).thenReturn(UUID.randomUUID());
        when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID(), emptyList(), null));

        // WHEN
        jobRunrMicroMeterIntegration.initialize(storageProvider, backgroundJobServer, null);

        // THEN
        verify(storageProvider).getJobStats();
        verify(storageProvider).addJobStorageOnChangeListener(any(StorageProviderMetricsBinder.class));
        verify(meterRegistry, times(9)).gauge(any(String.class), any(Iterable.class), any(AtomicLong.class));

        assertThat(
                (BackgroundJobServerMetricsBinder) Whitebox.getInternalState(jobRunrMicroMeterIntegration,
                        "backgroundJobServerMetricsBinder")
        ).isNotNull();

        verify(backgroundJobServer, times(1)).getJobFilters();

        // WHEN
        assertThatCode(jobRunrMicroMeterIntegration::close).doesNotThrowAnyException();
    }

}