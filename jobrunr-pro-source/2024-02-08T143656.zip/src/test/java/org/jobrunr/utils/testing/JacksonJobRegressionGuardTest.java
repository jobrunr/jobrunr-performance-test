package org.jobrunr.utils.testing;

import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;

public class JacksonJobRegressionGuardTest extends AbstractJobRegressionGuardTest {
    @Override
    JsonMapper getJsonMapper() {
        return new JacksonJsonMapper();
    }
}
