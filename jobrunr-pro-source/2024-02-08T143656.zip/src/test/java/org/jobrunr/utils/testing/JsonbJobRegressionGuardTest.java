package org.jobrunr.utils.testing;

import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.jsonb.JsonbJsonMapper;
import org.junit.jupiter.api.Disabled;

@Disabled("Jsonb is acting up and no JobRunrPro customers for the moment")
public class JsonbJobRegressionGuardTest extends AbstractJobRegressionGuardTest {
    @Override
    JsonMapper getJsonMapper() {
        return new JsonbJsonMapper();
    }
}
