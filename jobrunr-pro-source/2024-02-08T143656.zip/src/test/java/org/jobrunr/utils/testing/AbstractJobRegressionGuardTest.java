package org.jobrunr.utils.testing;

import org.jobrunr.dashboard.JobRunrDashboardWebServer;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.FreePortFinder;
import org.jobrunr.utils.mapper.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.stubs.TestService.*;

abstract class AbstractJobRegressionGuardTest {

    private StorageProvider storageProvider;
    private JobRunrDashboardWebServer dashboardWebServer;
    private int port;
    private JobRegressionGuard jobRegressionGuard;

    abstract JsonMapper getJsonMapper();

    @BeforeEach
    void setUpWebServer() {
        final JsonMapper jsonMapper = getJsonMapper();

        storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(jsonMapper));

        port = FreePortFinder.nextFreePort(8000);
        dashboardWebServer = new JobRunrDashboardWebServer(storageProvider, jsonMapper, new Queues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue), port);
        dashboardWebServer.start();

        this.jobRegressionGuard = new JobRegressionGuard(jsonMapper);
    }

    @Test
    void testJobRegressionsAllOK() {
        storageProvider.save(aScheduledJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkThatTakesLong")
                        .withJobParameter(JobContext.Null))
                .build());
        jobRegressionGuard.validateJobs("http://localhost:" + port + "/dashboard");
    }

    @Test
    void testJobRegressionsMissingJobs() {
        storageProvider.save(aScheduledJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkThatDoesNotExist")
                        .withJobParameter(JobContext.Null))
                .build());

        storageProvider.saveRecurringJob(aDefaultRecurringJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doRecurringWorkThatDoesNotExist")
                        .withJobParameter(JobContext.Null))
                .build());

        assertThatCode(() -> jobRegressionGuard.validateJobs("http://localhost:" + port + "/dashboard"))
                .isInstanceOf(IllegalStateException.class)
                .message()
                .contains("a scheduled job: org.jobrunr.stubs.TestService.doWorkThatDoesNotExist(org.jobrunr.jobs.context.JobContext) (non-recurring)")
                .contains("a recurring job: org.jobrunr.stubs.TestService.doRecurringWorkThatDoesNotExist(org.jobrunr.jobs.context.JobContext) (recurring)");
    }
}