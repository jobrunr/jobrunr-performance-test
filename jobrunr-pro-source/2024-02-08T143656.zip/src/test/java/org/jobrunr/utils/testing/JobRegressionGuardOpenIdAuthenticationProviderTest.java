package org.jobrunr.utils.testing;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

class JobRegressionGuardOpenIdAuthenticationProviderTest {

    @Test
    void returnsCorrectAuthorizationHeader() {
        JobRegressionGuardOpenIdAuthenticationProvider openIdAuthenticationProvider = spy(new JobRegressionGuardOpenIdAuthenticationProvider(
                "token-endpoint",
                "my-client-id",
                "my-client-secret"));

        doReturn("{\"access_token\":\"the-access-token\",\"expires_in\":60,\"refresh_expires_in\":0,\"token_type\":\"Bearer\",\"scope\":\"profile email\"}").when(openIdAuthenticationProvider).getAccessTokenAsJsonString();

        assertThat(openIdAuthenticationProvider.getAuthorizationHeader()).isEqualTo("Bearer the-access-token");
    }
}