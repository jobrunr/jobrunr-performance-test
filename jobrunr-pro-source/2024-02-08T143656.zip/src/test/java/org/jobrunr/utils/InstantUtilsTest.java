package org.jobrunr.utils;

import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class InstantUtilsTest {

    @Test
    void testRangeContains() {
        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:33:52Z")).isTrue();
        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:33:50Z")).isTrue();

        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:33:45Z")).isFalse();
        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:33:55Z")).isFalse();
        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:32:52Z")).isFalse();
        assertThat(rangeContains("2023-04-28T09:33:50Z", "2023-04-28T09:33:55Z", "2023-04-28T09:34:52Z")).isFalse();
    }

    @Test
    void testRangeContainsThrowsExceptionIfInvalid() {
        assertThatThrownBy(() -> rangeContains("2023-04-28T09:33:55Z", "2023-04-28T09:33:50Z", "2023-04-28T09:33:52Z"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Start (2023-04-28T09:33:55Z) should be before end (2023-04-28T09:33:50Z)");
    }

    public boolean rangeContains(String start, String end, String toCheck) {
        return InstantUtils.rangeContains(Instant.parse(start), Instant.parse(end), Instant.parse(toCheck));
    }

}