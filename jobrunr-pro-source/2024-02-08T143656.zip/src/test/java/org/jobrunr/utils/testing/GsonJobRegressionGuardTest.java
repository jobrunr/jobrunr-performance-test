package org.jobrunr.utils.testing;

import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.gson.GsonJsonMapper;

public class GsonJobRegressionGuardTest extends AbstractJobRegressionGuardTest {
    @Override
    JsonMapper getJsonMapper() {
        return new GsonJsonMapper();
    }
}
