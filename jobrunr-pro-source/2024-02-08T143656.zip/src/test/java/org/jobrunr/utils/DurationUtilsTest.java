package org.jobrunr.utils;

import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

class DurationUtilsTest {


    @Test
    void testMax() {
        Duration duration1 = Duration.ofMinutes(1);
        Duration duration2 = Duration.ofMinutes(2);

        assertThat(DurationUtils.max(duration1, duration2))
                .isEqualTo(duration2);

        assertThat(DurationUtils.max(duration2, duration1))
                .isEqualTo(duration2);

        assertThat(DurationUtils.max(null, duration2))
                .isEqualTo(duration2);

        assertThat(DurationUtils.max(duration1, null))
                .isEqualTo(duration1);
    }

    @Test
    void testMin() {
        Duration duration1 = Duration.ofMinutes(1);
        Duration duration2 = Duration.ofMinutes(2);

        assertThat(DurationUtils.min(duration1, duration2))
                .isEqualTo(duration1);

        assertThat(DurationUtils.min(duration2, duration1))
                .isEqualTo(duration1);

        assertThat(DurationUtils.min(null, duration2))
                .isEqualTo(duration2);

        assertThat(DurationUtils.min(duration1, null))
                .isEqualTo(duration1);
    }
}