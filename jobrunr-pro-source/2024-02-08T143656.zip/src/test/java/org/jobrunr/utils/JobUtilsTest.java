package org.jobrunr.utils;

import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.BatchJobTestBuilder;
import org.jobrunr.jobs.states.FailedBatchJobState;
import org.junit.jupiter.api.Test;

import static java.util.Collections.emptySet;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.utils.CollectionUtils.asSet;
import static org.jobrunr.utils.JobUtils.*;

class JobUtilsTest {

    @Test
    void testJobExists() {
        assertThat(jobExists("org.jobrunr.stubs.TestService.doWork(java.util.UUID)")).isTrue();
        assertThat(jobExists("org.jobrunr.stubs.TestService.getProcessedJobs()")).isTrue();
        assertThat(jobExists("org.jobrunr.stubs.TestService.doWorkThatTakesLong(java.lang.Integer)")).isTrue();
        assertThat(jobExists("org.jobrunr.stubs.TestService.doWork(java.lang.Integer,java.lang.Integer)")).isTrue();
        assertThat(jobExists("java.lang.System.out.println(java.lang.String)")).isTrue();
        assertThat(jobExists("javax.sql.DataSource.getConnection()")).isTrue();

        assertThat(jobExists("org.jobrunr.stubs.TestServiceThatDoesNotExist.doWork(java.lang.Integer,java.lang.Integer)")).isFalse();
        assertThat(jobExists("org.jobrunr.stubs.TestService.methodThatDoesNotExist(java.lang.Integer,java.lang.Integer)")).isFalse();
        assertThat(jobExists("org.jobrunr.stubs.TestService.doWork(java.util.UUID,org.jobrunr.stubs.JobParameterThatDoesNotExist)")).isFalse();
        assertThat(jobExists("org.jobrunr.stubs.TestService.doWork(java.lang.Integer,java.lang.Integer,java.lang.Integer,java.lang.Integer)")).isFalse(); // too many parameters
    }

    @Test
    void testGetRootPackageName() {
        assertThat(getRootPackageName(emptySet()))
                .isEqualTo("");
        assertThat(getRootPackageName(asSet("org.jobrunr.examples.services.SampleJobService.recurringJob()")))
                .isEqualTo("org.jobrunr.examples.services");
        assertThat(getRootPackageName(asSet("org.jobrunr.examples.services.SampleJobService.recurringJob()", "org.jobrunr.examples.utils.CleanUpService.recurringJob()")))
                .isEqualTo("org.jobrunr.examples");
    }

    @Test
    void testGetExceptionTypeForBatchJobWithFailedBatchJobState() {
        BatchJob batchJob = BatchJobTestBuilder.aBatchJob().withState(new FailedBatchJobState()).build();
        assertThat(getExceptionType(batchJob)).isEqualTo("org.jobrunr.jobs.BatchChildJobFailedException");
    }

}