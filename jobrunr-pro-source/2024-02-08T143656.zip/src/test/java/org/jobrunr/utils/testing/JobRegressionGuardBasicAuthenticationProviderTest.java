package org.jobrunr.utils.testing;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class JobRegressionGuardBasicAuthenticationProviderTest {

    @Test
    void testAuthenticationHeader() {
        JobRegressionGuardBasicAuthenticationProvider basicAuthenticationProvider = new JobRegressionGuardBasicAuthenticationProvider("test", "password");

        assertThat(basicAuthenticationProvider.getAuthorizationHeader()).isEqualTo("Basic dGVzdDpwYXNzd29yZA==");
    }
}