package org.jobrunr.utils.multicast;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.utils.StringUtils.toURI;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class MulticastTest {

    @Mock
    Runnable runnable;

    MulticastMessagePublisher multicastMessagePublisher;
    MulticastMessageReceiver multicastMessageReceiver;

    @BeforeEach
    void setUp() {
        multicastMessagePublisher = new MulticastMessagePublisher(toURI("udp://239.076.159.181:8379"));
        multicastMessageReceiver = new MulticastMessageReceiver(toURI("udp://239.076.159.181:8379"), runnable::run);
        multicastMessageReceiver.start();
    }

    @AfterEach
    void tearDown() {
        multicastMessagePublisher.close();
        multicastMessageReceiver.close();
    }

    @Test
    void testMulticastSendsAndReceives() {
        multicastMessagePublisher.publishJobEnqueued();

        await().atMost(5, SECONDS).untilAsserted(() -> verify(runnable).run());
    }
}
