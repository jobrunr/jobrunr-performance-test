package org.jobrunr.utils.resilience;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;

class LRUCacheTest {

    private final LRUCache<String, String> cache = new LRUCache<>(3);
    private final List<String> computedCounters = new ArrayList<>();

    @BeforeEach
    void clearFunctionCounter() {
        computedCounters.clear();
    }

    @Test
    void canComputeIfAbsent() {
        String result1 = cache.computeIfAbsent("key1", this::compute);
        assertThat(result1).isEqualTo("computedkey1");
        assertThat(computedCounters).hasSize(1);

        String result2 = cache.computeIfAbsent("key1", this::compute);
        assertThat(result2).isEqualTo("computedkey1");
        assertThat(computedCounters).hasSize(1);
    }

    @Test
    void canComputeAndCacheNull() {
        String result1 = cache.computeIfAbsent("key1", this::computeNull);
        assertThat(result1).isNull();
        assertThat(computedCounters).hasSize(1);

        String result2 = cache.computeIfAbsent("key1", this::computeNull);
        assertThat(result2).isNull();
        assertThat(computedCounters).hasSize(1);
    }

    @Test
    void maxSizeOfLruCacheIsRespected() {
        cache.computeIfAbsent("key1", this::compute);
        cache.computeIfAbsent("key2", this::compute);
        cache.computeIfAbsent("key3", this::compute);
        cache.computeIfAbsent("key4", this::compute);
        clearFunctionCounter();

        cache.computeIfAbsent("key2", this::compute);
        cache.computeIfAbsent("key3", this::compute);
        cache.computeIfAbsent("key4", this::compute);
        assertThat(computedCounters).hasSize(0);

        cache.computeIfAbsent("key1", this::compute);
        assertThat(computedCounters).hasSize(1);
        assertThat(computedCounters).contains("key1");

        LinkedHashMap<String, String> internalState = getInternalState(cache, "hashMap");
        assertThat(internalState)
                .hasSize(3)
                .containsOnlyKeys("key1", "key3", "key4");
    }

    @Test
    void testSize() {
        LRUCache<UUID, String> cache = new LRUCache<>(1_000_001);

        Runtime.getRuntime().gc();
        long memoryBefore = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.out.println("Memory before: " + (memoryBefore));

        for(int i = 0; i < 100_000; i++) {
            cache.computeIfAbsent(UUID.randomUUID(), id -> this.compute(id.toString()));
        }

        Runtime.getRuntime().gc();
        long memoryAfter = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

        System.out.println("Memory after: " + (memoryAfter));
        System.out.println("Memory used: " + (memoryAfter - memoryBefore));
        clearFunctionCounter();

        UUID anotherId = UUID.randomUUID();
        cache.computeIfAbsent(anotherId, uuid -> this.compute(anotherId.toString()));
        assertThat(computedCounters).hasSize(1);

        cache.computeIfAbsent(anotherId, uuid -> this.compute(anotherId.toString()));
        assertThat(computedCounters).hasSize(1);
    }


    private String compute(String key) {
        this.computedCounters.add(key);
        return "computed" + key;
    }

    private String computeNull(String key) {
        this.computedCounters.add(key);
        return null;
    }

}