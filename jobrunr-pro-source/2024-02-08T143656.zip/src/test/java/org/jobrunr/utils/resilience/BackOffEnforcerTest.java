package org.jobrunr.utils.resilience;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import java.util.function.Function;

import static org.jobrunr.JobRunrAssertions.assertThat;

class BackOffEnforcerTest {

    private int counter;

    @Test
    void ifResultNotAvailableBackOffEnforcerReturnsUnAvailableResult() {
        TestBackOffEnforcer backOffEnforcer = new TestBackOffEnforcer(id -> null);
        UUID id = UUID.randomUUID();
        TestBackOffResult backOffResult = backOffEnforcer.get(id);

        assertThat(backOffResult)
                .isNotNull()
                .isUnavailable()
                .hasBackOffPeriod(Duration.of(5, ChronoUnit.SECONDS));
    }

    @Test
    void ifResultIsRequestedManyTimesBackOffEnforcerReturnsSameResult() {
        TestBackOffEnforcer backOffEnforcer = new TestBackOffEnforcer(id -> null);
        UUID id = UUID.randomUUID();
        backOffEnforcer.get(id);

        TestBackOffResult backOffResult = backOffEnforcer.get(id);
        assertThat(backOffResult)
                .isNotNull()
                .isUnavailable()
                .hasBackOffPeriod(Duration.of(5, ChronoUnit.SECONDS));
    }

    @Test
    void ifResultIsNotRequestedTooManyTimesBackOffEnforcerReturnsNewBackOffResult() throws InterruptedException {
        TestBackOffEnforcer backOffEnforcer = new TestBackOffEnforcer(id -> null);
        UUID id = UUID.randomUUID();
        backOffEnforcer.get(id);
        Thread.sleep(5001);

        TestBackOffResult backOffResult2 = backOffEnforcer.get(id);
        assertThat(backOffResult2)
                .isNotNull()
                .isUnavailable()
                .hasBackOffPeriod(Duration.of(10, ChronoUnit.SECONDS));
    }

    @Test
    void ifResultIsRequestedAfterBackOffPeriodAndIsAvailableItIsReturned() throws InterruptedException {
        TestBackOffEnforcer backOffEnforcer = new TestBackOffEnforcer(this::getResultOnSecondTime);
        UUID id = UUID.randomUUID();
        backOffEnforcer.get(id);
        Thread.sleep(5001);

        TestBackOffResult backOffResult2 = backOffEnforcer.get(id);
        assertThat(backOffResult2)
                .isNotNull()
                .isAvailable()
                .hasBackOffPeriod(Duration.ZERO);
    }

    @Test
    void ifResultIsAvailableImmediatelyItCanBeRequestedManyTimes() throws InterruptedException {
        TestBackOffEnforcer backOffEnforcer = new TestBackOffEnforcer(id -> id);
        UUID id = UUID.randomUUID();
        TestBackOffResult backOffResult1 = backOffEnforcer.get(id);
        assertThat(backOffResult1)
                .isNotNull()
                .isAvailable()
                .hasBackOffPeriod(Duration.ZERO);

        TestBackOffResult backOffResult2 = backOffEnforcer.get(id);
        assertThat(backOffResult2)
                .isNotNull()
                .isAvailable()
                .hasBackOffPeriod(Duration.ZERO);
    }


    @NotNull
    private UUID getResultOnSecondTime(UUID id) {
        if (this.counter == 0) {
            this.counter++;
            return null;
        }
        return id;
    }

    static class TestBackOffEnforcer extends BackOffEnforcer<TestBackOffResult> {

        private final Function<UUID, UUID> providerFunction;

        public TestBackOffEnforcer(Function<UUID, UUID> providerFunction) {
            this.providerFunction = providerFunction;
        }


        @Override
        protected TestBackOffResult getBackOffResult(UUID id) {
            UUID result = providerFunction.apply(id);
            if(result != null) {
                return new TestBackOffResult(Instant.now(), result);
            }
            return new TestBackOffResult(Instant.now(), Duration.of(5, ChronoUnit.SECONDS));
        }

        @Override
        protected TestBackOffResult getBackOffResult(UUID id, TestBackOffResult previousBackOffResult) {
            UUID result = providerFunction.apply(id);
            if(result != null) {
                return new TestBackOffResult(Instant.now(), result);
            }
            return new TestBackOffResult(Instant.now(), previousBackOffResult.initialBackOffPeriod().multipliedBy(2));
        }

        @Override
        protected TestBackOffResult refreshBackOffResult(TestBackOffResult other) {
            return new TestBackOffResult(other);
        }
    }

    static class TestBackOffResult extends BackOffResult {

        protected TestBackOffResult(Instant firstCheckedAt, Duration backOffPeriod) {
            super(firstCheckedAt, backOffPeriod);
        }

        protected TestBackOffResult(Instant firstCheckedAt, UUID result) {
            super(firstCheckedAt, result);
        }

        protected TestBackOffResult(TestBackOffResult other) {
            super(other.getFirstCheckedAt(), (Object) other.getResult());
        }
    }
}