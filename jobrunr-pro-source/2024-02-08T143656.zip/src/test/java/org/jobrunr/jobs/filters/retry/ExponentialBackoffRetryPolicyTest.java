package org.jobrunr.jobs.filters.retry;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ExponentialBackoffRetryPolicyTest {

    @Test
    void testDefaultExponentialBackoffPolicy() {
        RetryPolicy retryPolicy = new ExponentialBackoffRetryPolicy();

        assertThat(retryPolicy.getMaxAmountOfRetries()).isEqualTo(10);
        assertThat(retryPolicy.getSecondsToAdd(1)).isEqualTo(3);
        assertThat(retryPolicy.getSecondsToAdd(2)).isEqualTo(9);
        assertThat(retryPolicy.getSecondsToAdd(3)).isEqualTo(27);
    }

    @Test
    void testCustomExponentialBackoffPolicy() {
        RetryPolicy retryPolicy = new ExponentialBackoffRetryPolicy(3, 4);

        assertThat(retryPolicy.getMaxAmountOfRetries()).isEqualTo(3);
        assertThat(retryPolicy.getSecondsToAdd(1)).isEqualTo(4);
        assertThat(retryPolicy.getSecondsToAdd(2)).isEqualTo(16);
        assertThat(retryPolicy.getSecondsToAdd(3)).isEqualTo(64);
    }

}