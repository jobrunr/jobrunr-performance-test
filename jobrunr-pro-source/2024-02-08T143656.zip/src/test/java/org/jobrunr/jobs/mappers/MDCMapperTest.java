package org.jobrunr.jobs.mappers;

import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;

class MDCMapperTest {

    @Test
    void testTraceIdAndSpanId() {
        // GIVEN
        MDC.put("traceId", "abcdefghuijklmn");
        MDC.put("spanId", "nmlkjiuhgfedcba");

        Job job = anEnqueuedJobWithName().build();

        MDCMapper.saveMDCContextToJob(job);

        assertThat(job)
                .hasMetadata("constructing.traceId", "abcdefghuijklmn")
                .hasMetadata("constructing.spanId", "nmlkjiuhgfedcba");
    }

}