package org.jobrunr.jobs.states;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;

class StateNameTest {

    @Test
    void testAllBut() {
        StateName[] stateNames = StateName.allBut(AWAITING, DELETED);
        assertThat(stateNames).containsExactly(SCHEDULED, ENQUEUED, PROCESSING, PROCESSED, FAILED, SUCCEEDED);
    }
}