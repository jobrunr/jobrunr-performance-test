package org.jobrunr.jobs.filters;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.StateName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.Duration;
import java.time.Instant;
import java.util.stream.Stream;

import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.HOURS;
import static java.time.temporal.ChronoUnit.MINUTES;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aSucceededBatchJob;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.states.StateName.*;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_DELETE_SUCCEEDED_JOBS_DURATION;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_PERMANENTLY_DELETE_JOBS_DURATION;
import static org.junit.jupiter.params.provider.Arguments.arguments;


class DeleteFilterTest {

    private static final StateName STATE_NOT_RELEVANT = DELETED;
    private static final Instant DURATION_NOT_RELEVANT = Instant.EPOCH;

    @ParameterizedTest
    @MethodSource("deleteFilterInputAndExpectedResults")
    void testDeleteFilter(Job job, String deleteOnSuccess, String deleteOnFailure, StateName firstState, Instant firstStateDeleteAt, StateName secondState, Instant secondStateDeleteAt) {
        final DeleteFilter deleteFilter = new DeleteFilter(DEFAULT_DELETE_SUCCEEDED_JOBS_DURATION, DEFAULT_PERMANENTLY_DELETE_JOBS_DURATION) {
            @Override
            DeletionPolicy getDeletionPolicy(Job job) {
                return new DeletionPolicy(deleteOnSuccess, deleteOnFailure, DEFAULT_DELETE_SUCCEEDED_JOBS_DURATION, DEFAULT_PERMANENTLY_DELETE_JOBS_DURATION);
            }
        };

        deleteFilter.onStateElection(job, job.getJobState());
        assertThat(job)
                .hasState(firstState)
                .hasDeletedAt(firstStateDeleteAt);

        if (!job.hasState(DELETED)) {
            final Job deletedJob = job.delete("For testing purposes");
            deleteFilter.onStateElection(deletedJob, deletedJob.getJobState());
            assertThat(deletedJob)
                    .hasState(secondState)
                    .hasDeletedAt(secondStateDeleteAt);
        }
    }

    @ParameterizedTest
    @MethodSource("toParseableStringAndExpectedResults")
    void testToParseableString(Duration deleteAfter, Duration permanentlyDeleteAfter, String result) {
        assertThat(DeleteFilter.toParseableString(deleteAfter, permanentlyDeleteAfter)).isEqualTo(result);

    }

    static Stream<Arguments> deleteFilterInputAndExpectedResults() {
        return Stream.of(
                arguments(aSucceededJob().build(), "", "", SUCCEEDED, now().plus(Duration.ofHours(36)), DELETED, now().plus(Duration.ofHours(72))),
                arguments(aSucceededJob().build(), "!", "", DELETED, now(), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT),
                arguments(aSucceededJob().build(), "PT0S!", "", DELETED, now(), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT),
                arguments(aSucceededJob().build(), "PT5S", "", SUCCEEDED, now().plusSeconds(5), DELETED, now().plus(Duration.ofHours(72))),
                arguments(aSucceededJob().build(), "PT5S!", "", SUCCEEDED, now().plusSeconds(5), DELETED, now()),
                arguments(aSucceededJob().build(), "PT5S!PT10S", "", SUCCEEDED, now().plusSeconds(5), DELETED, now().plusSeconds(10)),
                arguments(aSucceededJob().build(), "PT5H!PT10M", "", SUCCEEDED, now().plus(5, HOURS), DELETED, now().plus(10, MINUTES)),
                arguments(aSucceededJob().build(), "!PT10S", "", DELETED, now().plusSeconds(10), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT),
                arguments(aSucceededJob().build(), "P2DT2H!PT10S", "", SUCCEEDED, now().plus(50, HOURS), DELETED, now().plusSeconds(10)),
                arguments(aSucceededJob().build(), "PT11D!PT5M", "", SUCCEEDED, now().plus(Duration.ofHours(36)), DELETED, now().plus(Duration.ofHours(72))),
                arguments(aSucceededJob().build(), "DOES NOT MATCH", "", SUCCEEDED, now().plus(Duration.ofHours(36)), DELETED, now().plus(Duration.ofHours(72))),
                arguments(aSucceededBatchJob().build(), "PT2M!PT5M", "", SUCCEEDED, now().plus(Duration.ofMinutes(2)), DELETED, now().plus(Duration.ofMinutes(5))),
                arguments(aFailedJob().build(), "", "", FAILED, null, DELETED, now().plus(Duration.ofHours(72))),
                arguments(aFailedJob().build(), "!", "!", DELETED, now(), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT),
                arguments(aFailedJob().build(), "", "PT5S", FAILED, now().plusSeconds(5), DELETED, now().plus(Duration.ofHours(72))),
                arguments(aFailedJob().build(), "", "PT5S!", FAILED, now().plusSeconds(5), DELETED, now()),
                arguments(aFailedJob().build(), "", "PT5S!PT10S", FAILED, now().plusSeconds(5), DELETED, now().plusSeconds(10)),
                arguments(aFailedJob().build(), "", "!PT10S", DELETED, now().plusSeconds(10), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT),
                arguments(aSucceededJob().build(), "PT5S!PT10S", "PT5S!PT20S", SUCCEEDED, now().plusSeconds(5), DELETED, now().plusSeconds(10)),
                arguments(aFailedJob().build(), "PT5S!PT10S", "PT10S!PT20S", FAILED, now().plusSeconds(10), DELETED, now().plusSeconds(20)),
                arguments(anEnqueuedJobWithName().withDeletedState().build(), "PT5H!PT10M", "PT5H!PT10M", DELETED, now().plus(72, HOURS), STATE_NOT_RELEVANT, DURATION_NOT_RELEVANT)
        );
    }

    static Stream<Arguments> toParseableStringAndExpectedResults() {
        return Stream.of(
                arguments(null, null, null),
                arguments(Duration.ofSeconds(5), null, "PT5S"),
                arguments(null, Duration.ofSeconds(5), "!PT5S"),
                arguments(Duration.ofSeconds(5), Duration.ofSeconds(5), "PT5S!PT5S"),
                arguments(Duration.ZERO, Duration.ofSeconds(5), "PT0S!PT5S"),
                arguments(Duration.ofDays(2), Duration.ofSeconds(5), "PT48H!PT5S")
        );
    }
}