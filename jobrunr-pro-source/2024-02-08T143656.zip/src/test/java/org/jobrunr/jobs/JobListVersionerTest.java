package org.jobrunr.jobs;

import org.junit.jupiter.api.Test;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;

class JobListVersionerTest {

    @Test
    void testJobListVersionerChecksWhetherAllJobsAreNewThrowsIllegalArgumentExceptionIfFirstJobIsNewAndOthersNot() {
        Job job1 = aScheduledJob().withVersion(0).build();
        Job job2 = aScheduledJob().withVersion(5).build();
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));

        assertThatCode(jobListVersioner::areNewJobs).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testJobListVersionerChecksWhetherAllJobsAreNewThrowsIllegalArgumentExceptionIfFirstJobIsNotNewAndOthersAreNew() {
        Job job1 = aScheduledJob().withVersion(5).build();
        Job job2 = aScheduledJob().withVersion(0).build();
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));

        assertThatCode(jobListVersioner::areNewJobs).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testJobListVersionerChecksWhetherAllJobsAreNewDoesNotThrowExceptionIfAllAreNew() {
        Job job1 = aScheduledJob().withVersion(0).build();
        Job job2 = aScheduledJob().withVersion(0).build();
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));

        assertThatCode(jobListVersioner::areNewJobs).doesNotThrowAnyException();
    }

    @Test
    void testJobListVersionerChecksWhetherAllJobsAreNewDoesNotThrowExceptionIfAllAreUpdates() {
        Job job1 = aScheduledJob().withVersion(4).build();
        Job job2 = aScheduledJob().withVersion(8).build();
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));

        assertThatCode(jobListVersioner::areNewJobs).doesNotThrowAnyException();
    }

    @Test
    void testJobListVersionerOnCommitVersionIsIncreased() {
        // GIVEN
        Job job1 = aScheduledJob().withVersion(5).build();
        Job job2 = aScheduledJob().withVersion(5).build();

        // WHEN
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));
        jobListVersioner.commitVersions();

        // THEN
        assertThat(job1).hasVersion(6);
        assertThat(job2).hasVersion(6);
    }

    @Test
    void testJobListVersionerOnRollbackOfSomeJobsVersionIsDecreasedForThoseJobs() {
        // GIVEN
        Job job1 = aScheduledJob().withVersion(5).build();
        Job job2 = aScheduledJob().withVersion(5).build();

        // WHEN
        JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2));
        jobListVersioner.rollbackVersions(asList(job2));
        jobListVersioner.close();

        // THEN
        assertThat(job1).hasVersion(6);
        assertThat(job2).hasVersion(5);
    }

    @Test
    void testJobListVersionerInTryWithResourcesOnRollbackOfSomeJobsVersionIsDecreasedForThoseJobs() {
        // GIVEN
        Job job1 = aScheduledJob().withVersion(5).build();
        Job job2 = aScheduledJob().withVersion(5).build();

        // WHEN
        try (JobListVersioner jobListVersioner = new JobListVersioner(asList(job1, job2))) {
            jobListVersioner.rollbackVersions(asList(job2));
        }

        // THEN
        assertThat(job1).hasVersion(6);
        assertThat(job2).hasVersion(5);
    }
}