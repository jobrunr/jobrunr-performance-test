package org.jobrunr.jobs.migrations;

import org.jobrunr.jobs.Job;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;

class ScheduledJobsThatDoNotExistAnymoreMigratorTest {

    @Test
    void scheduledJobThatDoNotExistAnymoreWithEmptyMigrations() {
        final Job scheduledJob1 = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("dontDoWork"))
                .build();

        final List<Job> scheduledJobsThatDoNotExistAnymore = Arrays.asList(scheduledJob1);

        final ScheduledJobThatDoNotExistAnymoreMigrations scheduledJobThatDoNotExistAnymoreMigrations = new ScheduledJobThatDoNotExistAnymoreMigrations();

        final ScheduledJobsThatDoNotExistAnymoreMigrator scheduledJobsThatDoNotExistAnymoreMigrator = new ScheduledJobsThatDoNotExistAnymoreMigrator(scheduledJobThatDoNotExistAnymoreMigrations);
        final List<Job> jobs = scheduledJobsThatDoNotExistAnymoreMigrator.updateScheduledJobsThatDoNotExistAnymore(scheduledJobsThatDoNotExistAnymore);

        assertThat(jobs).hasSize(1);
    }

    @Test
    void scheduledJobThatDoNotExistAnymoreWithMigrationForOtherClass() {
        final Job scheduledJob1 = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("dontDoWork"))
                .build();

        final List<Job> scheduledJobsThatDoNotExistAnymore = Arrays.asList(scheduledJob1);

        final ScheduledJobThatDoNotExistAnymoreMigrations scheduledJobThatDoNotExistAnymoreMigrations = new ScheduledJobThatDoNotExistAnymoreMigrations(
                this::updateSomeClassThatDoesNotExistToTestService
        );

        final ScheduledJobsThatDoNotExistAnymoreMigrator scheduledJobsThatDoNotExistAnymoreMigrator = new ScheduledJobsThatDoNotExistAnymoreMigrator(scheduledJobThatDoNotExistAnymoreMigrations);
        final List<Job> jobs = scheduledJobsThatDoNotExistAnymoreMigrator.updateScheduledJobsThatDoNotExistAnymore(scheduledJobsThatDoNotExistAnymore);

        assertThat(jobs).hasSize(1);
    }

    @Test
    void scheduledJobThatDoNotExistAnymoreMigrations() {
        final Job scheduledJob1 = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("dontDoWork"))
                .build();

        final Job scheduledJob2 = aScheduledJob()
                .withJobDetails(jobDetails().withClassName("some.class.that.does.not.exist").withMethodName("doWork"))
                .build();

        final Job scheduledJob3 = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("jobCanBeDeleted"))
                .build();

        final List<Job> scheduledJobsThatDoNotExistAnymore = Arrays.asList(scheduledJob1, scheduledJob2, scheduledJob3);

        final ScheduledJobThatDoNotExistAnymoreMigrations scheduledJobThatDoNotExistAnymoreMigrations = new ScheduledJobThatDoNotExistAnymoreMigrations(
                this::updateDontDoWorkMethods,
                this::updateSomeClassThatDoesNotExistToTestService,
                this::deleteJobsWithJobCanBeDeletedMethod
        );

        final ScheduledJobsThatDoNotExistAnymoreMigrator scheduledJobsThatDoNotExistAnymoreMigrator = new ScheduledJobsThatDoNotExistAnymoreMigrator(scheduledJobThatDoNotExistAnymoreMigrations);
        final List<Job> jobs = scheduledJobsThatDoNotExistAnymoreMigrator.updateScheduledJobsThatDoNotExistAnymore(scheduledJobsThatDoNotExistAnymore);

        assertThat(jobs).hasSize(3);
    }

    private void updateDontDoWorkMethods(ScheduledJobMatcher scheduledJobMatcher, ScheduledJobUpdater scheduledJobUpdater) {
        if (scheduledJobMatcher.matches(TestService.class, "dontDoWork")) {
            scheduledJobUpdater.updateMethodName(methodName -> methodName.replace("dontD", "d"));
        }
    }

    private void updateSomeClassThatDoesNotExistToTestService(ScheduledJobMatcher scheduledJobMatcher, ScheduledJobUpdater scheduledJobUpdater) {
        if (scheduledJobMatcher.matches("some.class.that.does.not.exist")) {
            scheduledJobUpdater.setClass(TestService.class);
        }
    }

    private void deleteJobsWithJobCanBeDeletedMethod(ScheduledJobMatcher scheduledJobMatcher, ScheduledJobUpdater scheduledJobUpdater) {
        if (scheduledJobMatcher.matches(TestService.class, "jobCanBeDeleted")) {
            scheduledJobUpdater.deleteJob();
        }
    }
}