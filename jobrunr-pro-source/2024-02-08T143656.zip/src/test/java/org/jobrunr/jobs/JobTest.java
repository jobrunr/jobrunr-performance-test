package org.jobrunr.jobs;

import org.assertj.core.data.Offset;
import org.jobrunr.jobs.context.JobDashboardLogger;
import org.jobrunr.jobs.states.*;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.utils.annotations.Because;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.context.JobDashboardLogger.JOBRUNR_LOG_KEY;
import static org.jobrunr.jobs.context.JobDashboardProgressBar.JOBRUNR_PROGRESSBAR_KEY;
import static org.jobrunr.jobs.mappers.MDCMapper.*;
import static org.jobrunr.jobs.states.StateName.*;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class JobTest {

    @Mock
    private BackgroundJobServer backgroundJobServer;

    @BeforeEach
    void setUpBackgroundJobServer() {
        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());
    }

    @Test
    void ifIdIsNullAnIdIsCreated() {
        Job jobWithoutIdProvided = new Job(jobDetails().build());
        assertThat(jobWithoutIdProvided.getId()).isNotNull();

        Job jobWithNullIdProvided = new Job(null, jobDetails().build());
        assertThat(jobWithNullIdProvided.getId()).isNotNull();
    }

    @Test
    void ifIdIsNullThenTimeBasedIdsAreCreated() {
        Job job1 = new Job(jobDetails().build());
        Job job2 = new Job(jobDetails().build());
        String job1IdSubstring = job1.getId().toString().substring(0, 6);
        String job2IdSubstring = job2.getId().toString().substring(0, 6);
        assertThat(job1IdSubstring).isEqualTo(job2IdSubstring);
    }

    @Test
    void getJobSignature() {
        Job job = anEnqueuedJobWithName().withJobDetails(systemOutPrintLnJobDetails("some message")).build();

        assertThat(job.getJobSignature()).isEqualTo("java.lang.System.out.println(java.lang.String)");
    }

    @Test
    void whenJobIsAwaitingOrScheduledAndRateLimiterIsSetStateIsKept() {
        Job job = aJob().withAwaitingBatchJobState(UUID.randomUUID()).build();

        job.setRateLimiter("rateLimiterName");

        assertThat(job)
                .hasState(AWAITING, s -> s instanceof AwaitingBatchJobState)
                .hasRateLimiter("rateLimiterName");
    }

    @Test
    void whenJobIsScheduledAndRateLimiterIsSetStateIsKept() {
        Job job = aScheduledJob().build();

        job.setRateLimiter("rateLimiterName");

        assertThat(job)
                .hasState(SCHEDULED)
                .hasRateLimiter("rateLimiterName");
    }

    @Test
    void whenJobIsEnqueuedAndRateLimiterIsSetStateIsChangedToAwaiting() {
        Job job = anEnqueuedJobWithName().build();

        job.setRateLimiter("rateLimiterName");

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "rateLimiterName".equals(s.getWaitingOnRateLimiter()))
                .hasRateLimiter("rateLimiterName");
    }

    @Test
    void whenJobIsHasOtherStateThanAwaitingScheduledOrEnqueuedAndRateLimiterIsSetStateThenExceptionIsThrown() {
        Job jobInProgress = aJobInProgress().build();
        assertThatCode(() -> jobInProgress.setRateLimiter("rateLimiterName"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter can only be set for jobs with state AWAITING, SCHEDULED and ENQUEUED");

        Job failedJob = aFailedJob().build();
        assertThatCode(() -> failedJob.setRateLimiter("rateLimiterName"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter can only be set for jobs with state AWAITING, SCHEDULED and ENQUEUED");

        Job succeededJob = aSucceededJob().build();
        assertThatCode(() -> succeededJob.setRateLimiter("rateLimiterName"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter can only be set for jobs with state AWAITING, SCHEDULED and ENQUEUED");

        Job deletedJob = aDeletedJob().build();
        assertThatCode(() -> deletedJob.setRateLimiter("rateLimiterName"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("RateLimiter can only be set for jobs with state AWAITING, SCHEDULED and ENQUEUED");
    }

    @Test
    void jobCannotGoToProcessingTwice() {
        Job job = anEnqueuedJobWithName().build();

        job.startProcessingOn(backgroundJobServer);
        assertThatThrownBy(() -> job.startProcessingOn(backgroundJobServer)).isInstanceOf(ConcurrentJobModificationException.class);
    }

    @Test
    void updateProcessingOnlyHasEffectIfJobIsInProcessingState() {
        Job job = anEnqueuedJobWithName().build();
        job.startProcessingOn(backgroundJobServer);

        job.updateProcessing();

        ProcessingState processingState = job.getJobState();
        assertThat(processingState.getUpdatedAt()).isAfter(processingState.getCreatedAt());
    }

    @Test
    void updateProcessingThrowsExceptionIfJobHasScheduledState() {
        Job job = aScheduledJob().build();

        assertThatThrownBy(job::updateProcessing).isInstanceOf(ClassCastException.class);
    }

    @Test
    void updateProcessingThrowsExceptionIfJobHasSucceededState() {
        Job job = aSucceededJob().build();

        assertThatThrownBy(job::updateProcessing).isInstanceOf(ClassCastException.class);
    }

    @Test
    void succeededLatencyDurationAndProcessDurationOnlyTakesIntoAccountStateFromEnqueuedToProcessing() {
        Job job = aJob()
                .withState(new ScheduledState(now()), now().minusSeconds(600))
                .withState(new EnqueuedState(), now().minusSeconds(60))
                .withState(new ProcessingState(backgroundJobServer), now().minusSeconds(10))
                .build();
        job.updateProcessing();
        job.succeeded();

        SucceededState succeededState = job.getJobState();
        assertThat(succeededState.getLatencyDuration().toSeconds()).isCloseTo(50, Offset.offset(1L));
        assertThat(succeededState.getProcessDuration().toSeconds()).isCloseTo(10, Offset.offset(1L));
    }

    @Test
    void succeededLatencyDurationAndProcessDurationNotTakenIntoAccountIfJobSucceedsByJobFilter() {
        Job job = aJob()
                .withState(new ScheduledState(now()), now().minusSeconds(600))
                .withState(new EnqueuedState(), now().minusSeconds(60))
                .withState(new ProcessingState(backgroundJobServer), now().minusSeconds(10))
                .withFailedState()
                .withScheduledState()
                .build();

        job.succeeded();

        SucceededState succeededState = job.getJobState();
        assertThat(succeededState.getLatencyDuration()).isNull();
        assertThat(succeededState.getProcessDuration()).isNull();
    }

    @Test
    void failedLatencyDurationAndProcessDurationOnlyTakesIntoAccountStateFromEnqueuedToProcessing() {
        Job job = aJob()
                .withState(new ScheduledState(now()), now().minusSeconds(600))
                .withState(new EnqueuedState(), now().minusSeconds(60))
                .withState(new ProcessingState(backgroundJobServer), now().minusSeconds(10))
                .build();
        job.updateProcessing();
        job.failed("An exception occurred", new RuntimeException("boem"));

        FailedState failedState = job.getJobState();
        assertThat(failedState.getLatencyDuration().toSeconds()).isCloseTo(50, Offset.offset(1L));
        assertThat(failedState.getProcessDuration().toSeconds()).isCloseTo(10, Offset.offset(1L));
    }

    @Test
    void failedLatencyDurationAndProcessDurationNotTakenIntoAccountIfJobSucceedsByJobFilter() {
        Job job = aJob()
                .withState(new ScheduledState(now()), now().minusSeconds(600))
                .withState(new EnqueuedState(), now().minusSeconds(60))
                .withState(new ProcessingState(backgroundJobServer), now().minusSeconds(10))
                .withFailedState()
                .withScheduledState()
                .build();

        job.failed("Boem", new RuntimeException());

        FailedState failedState = job.getJobState();
        assertThat(failedState.getLatencyDuration()).isNull();
        assertThat(failedState.getProcessDuration()).isNull();
    }

    @Test
    void testStateChangesOnlyOneStateChange() {
        Job job = anEnqueuedJobWithName().build();
        assertThat(job.getStateChangesForJobFilters()).hasSize(1);

        job.startProcessingOn(backgroundJobServer);
        job.updateProcessing();
        assertThat(job.getStateChangesForJobFilters()).hasSize(1);
    }

    @Test
    void testStateChangesMultipleStateChanges() {
        Job job = anEnqueuedJobWithName().build();
        assertThat(job.getStateChangesForJobFilters()).hasSize(1);

        job.delete("Via jobfilter");
        job.scheduleAt(now().plusSeconds(10), "Via jobfilter");
        assertThat(job.getStateChangesForJobFilters()).hasSize(2);
    }

    @Test
    void testStateChangesResetsStateChanges() {
        Job job = anEnqueuedJobWithName().build();
        assertThat(job.getStateChangesForJobFilters()).hasSize(1);
        job.startProcessingOn(backgroundJobServer);

        assertThat(job.getStateChangesForJobFilters()).hasSize(1);
        assertThat(job.getStateChangesForJobFilters()).isEmpty();
    }

    @Test
    void metadataIsClearedWhenAJobSucceeds() {
        Job job = aJobInProgress()
                .withMetadata("key", "value")
                .withMetadata(JOBRUNR_CONSTRUCTING_TRACE_ID_KEY, "constructing-some-trace-id")
                .withMetadata(JOBRUNR_CONSTRUCTING_SPAN_ID_KEY, "constructing-some-span-id")
                .withMetadata(OTEL_TRACE_ID_KEY, "some-trace-id")
                .withMetadata(OTEL_SPAN_ID_KEY, "some-span-id")
                .build();
        assertThat(job).hasMetadata("key", "value");

        job.failed("En exception occurred", new RuntimeException("boem"));
        assertThat(job).hasMetadata("key", "value");

        job.scheduleAt(now(), "failure before");
        assertThat(job).hasMetadata("key", "value");

        job.succeeded();
        assertThat(job)
                .hasMetadataOnlyContainingObservabilityInfoJobProgressAndLogging()
                .hasMetadata(JOBRUNR_CONSTRUCTING_TRACE_ID_KEY, "constructing-some-trace-id")
                .hasMetadata(JOBRUNR_CONSTRUCTING_SPAN_ID_KEY, "constructing-some-span-id")
                .hasMetadata(OTEL_TRACE_ID_KEY, "some-trace-id")
                .hasMetadata(OTEL_SPAN_ID_KEY, "some-span-id");
    }

    @Test
    void metadataIsClearedWhenAJobIsDeleted() {
        Job job = aJobInProgress()
                .withMetadata("key", "value")
                .withMetadata(JOBRUNR_CONSTRUCTING_TRACE_ID_KEY, "constructing-some-trace-id")
                .withMetadata(JOBRUNR_CONSTRUCTING_SPAN_ID_KEY, "constructing-some-span-id")
                .withMetadata(OTEL_TRACE_ID_KEY, "some-trace-id")
                .withMetadata(OTEL_SPAN_ID_KEY, "some-span-id")
                .build();
        assertThat(job).hasMetadata("key", "value");

        job.failed("En exception occurred", new RuntimeException("boem"));
        assertThat(job).hasMetadata("key", "value");

        job.scheduleAt(now(), "failure before");
        assertThat(job).hasMetadata("key", "value");

        job.delete("not important");
        assertThat(job)
                .hasMetadataOnlyContainingObservabilityInfoJobProgressAndLogging()
                .hasMetadata(JOBRUNR_CONSTRUCTING_TRACE_ID_KEY, "constructing-some-trace-id")
                .hasMetadata(JOBRUNR_CONSTRUCTING_SPAN_ID_KEY, "constructing-some-span-id")
                .hasMetadata(OTEL_TRACE_ID_KEY, "some-trace-id")
                .hasMetadata(OTEL_SPAN_ID_KEY, "some-span-id");
    }

    @Test
    void jobHasDefaultDeleteAtIfDeleted() {
        Job job = anEnqueuedJobWithName().build();

        job.delete("not important");

        assertThat(job).hasDeletedAtNotNull();
    }

    //why: multiple threads can simultaneously change a job to the DELETED state:
    // - the thread that is running the actual job will save to the DB every pollIntervalInSeconds and on a ConcurrentJobModificationException (the job is deleted) put the job in DELETED state
    // - the JobZooKeeper when it starts processing (org.jobrunr.server.JobZooKeeper#startProcessing(Job, Thread)) (so a newer / updated Job with the same id was fetched with ENQUEUED state) will first try to find the old job and change the state to DELETED
    // => possible duplicate statechange from DELETED to DELETED
    @Test
    @Because(value = "https://github.com/jobrunr/jobrunr-pro/issues/140")
    void jobCanBeDeletedTwiceButSecondDeleteStateChangeIsNotAdded() {
        Job job = anEnqueuedJobWithName().build();

        job.delete("not important");
        job.delete("not important");

        assertThat(job)
                .hasDeletedAtNotNull()
                .hasStates(ENQUEUED, DELETED);
    }

    @Test
    void jobLoggingAndProgressIsNotClearedIfMoreThan10Retries() {
        Job job = anEnqueuedJobWithName().build();
        for (int i = 0; i < 10; i++) {
            job.startProcessingOn(backgroundJobServer);

            JobDashboardLogger jobDashboardLogger = new JobDashboardLogger(job);
            jobDashboardLogger.info("Message " + i);

            job.failed("Job failed", new IllegalStateException("Not important"));
            job.scheduleAt(now(), "Retry");
            job.enqueue();
        }

        job.startProcessingOn(backgroundJobServer);
        job.succeeded();
        assertThat(job)
                .hasMetadata("jobRunrDashboardLog-2")
                .hasMetadata("jobRunrDashboardLog-6")
                .hasMetadata("jobRunrDashboardLog-10")
                .hasMetadata("jobRunrDashboardLog-14")
                .hasMetadata("jobRunrDashboardLog-18")
                .hasMetadata("jobRunrDashboardLog-22")
                .hasMetadata("jobRunrDashboardLog-26")
                .hasMetadata("jobRunrDashboardLog-30")
                .hasMetadata("jobRunrDashboardLog-34")
                .hasMetadata("jobRunrDashboardLog-38");
    }

    @Test
    void testRedactJob() {
        Map<String, Object> metadata = new HashMap<>() {{
            put(JOBRUNR_LOG_KEY + "-2", "");
            put(JOBRUNR_PROGRESSBAR_KEY + "-2", "");
        }};
        Job job = aFailedJob().withFailedState().withMetadata(metadata).build();
        job.redact();
        assertThat(job).isRedactedIfComparedToUnredactedJob(job);
    }
}