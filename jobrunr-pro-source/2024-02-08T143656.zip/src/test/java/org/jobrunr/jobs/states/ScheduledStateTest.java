package org.jobrunr.jobs.states;


import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;

class ScheduledStateTest {

    @Test
    void testIfJobIsNotInScheduledStateItThrowsAnException() {
        ScheduledState scheduledState = new ScheduledState(Instant.now().plusSeconds(10));

        Job job = anEnqueuedJobWithName().build();
        assertThatCode(() -> scheduledState.moveToNextState(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("Only jobs in SCHEDULED state can move to a next state");
    }

    @Test
    void testIfJobDoesNotHaveSameExactScheduledStateItThrowsAnException() {
        ScheduledState scheduledState = new ScheduledState(Instant.now().plusSeconds(10));

        Job job = aJob().withScheduledState(Instant.now().plusSeconds(20)).build();

        assertThatCode(() -> scheduledState.moveToNextState(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("Only jobs in SCHEDULED state can move to a next state");
    }

    @Test
    void testToNextStateForScheduledJobWithoutRateLimiterWillGoToEnqueued() {
        ScheduledState scheduledState = new ScheduledState(Instant.now().plusSeconds(10));
        Job job = aJob()
                .withoutRateLimiter()
                .withState(scheduledState)
                .build();

        scheduledState.moveToNextState(job);

        assertThat(job).hasState(ENQUEUED);
    }

    @Test
    void testToNextStateForScheduledJobWithRateLimiterWillGoToAwaitingRateLimiter() {
        ScheduledState scheduledState = new ScheduledState(Instant.now().plusSeconds(10));
        Job job = aJob()
                .withRateLimiter("my-rate-limiter")
                .withState(scheduledState)
                .build();

        scheduledState.moveToNextState(job);

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "my-rate-limiter".equals(s.getWaitingOnRateLimiter()));
    }

}