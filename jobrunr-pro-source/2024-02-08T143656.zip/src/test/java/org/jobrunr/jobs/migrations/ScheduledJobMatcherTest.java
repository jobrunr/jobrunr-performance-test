package org.jobrunr.jobs.migrations;

import org.jobrunr.jobs.Job;
import org.jobrunr.stubs.TestService;
import org.jobrunr.stubs.TestServiceForIoC;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;

class ScheduledJobMatcherTest {

    private TestService testService;

    @Test
    void scheduledJobMatcherMatchesByClass() {
        Job job = aScheduledJob()
                .withJobDetails(() -> testService.doWork())
                .build();
        final ScheduledJobMatcher scheduledJobMatcher = new ScheduledJobMatcher(job.getJobSignature());

        assertThat(scheduledJobMatcher.matches(TestService.class)).isTrue();
        assertThat(scheduledJobMatcher.matches(TestServiceForIoC.class)).isFalse();
    }

    @Test
    void scheduledJobMatcherMatchesByClassName() {
        Job job = aScheduledJob()
                .withJobDetails(() -> testService.doWork())
                .build();
        final ScheduledJobMatcher scheduledJobMatcher = new ScheduledJobMatcher(job.getJobSignature());

        assertThat(scheduledJobMatcher.matches(TestService.class.getName())).isTrue();
        assertThat(scheduledJobMatcher.matches(TestServiceForIoC.class.getName())).isFalse();
    }

    @Test
    void scheduledJobMatcherMatchesByClassAndMethodName() {
        Job job = aScheduledJob()
                .withJobDetails(() -> testService.doWork())
                .build();
        final ScheduledJobMatcher scheduledJobMatcher = new ScheduledJobMatcher(job.getJobSignature());

        assertThat(scheduledJobMatcher.matches(TestService.class, "doWork")).isTrue();
        assertThat(scheduledJobMatcher.matches(TestServiceForIoC.class, "doWork")).isFalse();
        assertThat(scheduledJobMatcher.matches(TestService.class, "wrongMethodName")).isFalse();
    }

    @Test
    void scheduledJobMatcherMatchesByClassNameAndMethodName() {
        Job job = aScheduledJob()
                .withJobDetails(() -> testService.doWork())
                .build();
        final ScheduledJobMatcher scheduledJobMatcher = new ScheduledJobMatcher(job.getJobSignature());

        assertThat(scheduledJobMatcher.matches(TestService.class.getName(), "doWork")).isTrue();
        assertThat(scheduledJobMatcher.matches(TestServiceForIoC.class.getName(), "doWork")).isFalse();
        assertThat(scheduledJobMatcher.matches(TestService.class.getName(), "wrongMethodName")).isFalse();
    }

    @Test
    void scheduledJobMatcherMatchesByClassMethodNameAndParameterTypes() {
        Job job = aScheduledJob()
                .withJobDetails(() -> testService.doWork(UUID.randomUUID(), 5, Instant.now()))
                .build();
        final ScheduledJobMatcher scheduledJobMatcher = new ScheduledJobMatcher(job.getJobSignature());

        assertThat(scheduledJobMatcher.matches(TestService.class, "doWork", UUID.class, int.class, Instant.class)).isTrue();
        assertThat(scheduledJobMatcher.matches(TestService.class, "doWork", UUID.class, Integer.class, Instant.class)).isTrue();
        assertThat(scheduledJobMatcher.matches(TestService.class, "doWork", String.class, Integer.class, Instant.class)).isFalse();
        assertThat(scheduledJobMatcher.matches(TestServiceForIoC.class, "doWork", UUID.class, int.class, Instant.class)).isFalse();
        assertThat(scheduledJobMatcher.matches(TestService.class, "wrongMethodName", UUID.class, int.class, Instant.class)).isFalse();
    }

}