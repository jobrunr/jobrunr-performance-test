package org.jobrunr.jobs.filters;

import org.jobrunr.JobRunrException;
import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobParameter;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.AwaitingRateLimiterState;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.JobHolderContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.time.Duration;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_SERVER_TAG;
import static org.jobrunr.stubs.TestService.DEFAULT_MUTEX;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LowPrioQueue;
import static org.jobrunr.stubs.TestService.WINDOWS;

class DefaultJobFilterTest {

    private UUID jobRunrServerId;
    private DefaultJobFilter jobFilter;
    private TestService testService;

    @BeforeEach
    void setup() {
        jobRunrServerId = UUID.randomUUID();
        jobFilter = new DefaultJobFilter(jobRunrServerId, new Queues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue));
    }

    @AfterEach
    void tearDown() {
        JobHolderContext.clear();
    }

    @Test
    void testDisplayNameByAnnotationReplacesVariables() {
        Job job = anEnqueuedJob().withoutName()
                .withJobDetails(() -> testService.doWorkWithAnnotationAndJobContext(67656, "the almighty user", JobContext.Null))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasJobName("Doing some hard work for user the almighty user with id 67656");
    }

    @Test
    void testDisplayNameIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withName("My job name")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasJobName("My job name");
    }

    @Test
    void testDisplayNameIsUsedIfProvidedByAnnotation() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasJobName("Doing some work");
    }

    @Test
    void testDisplayNameWithAnnotationUsingJobParametersAndMDCVariables() {
        MDC.put("customer.id", "1");
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkWithAnnotation")
                        .withJobParameter(5)
                        .withJobParameter("John Doe"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getJobName()).isEqualTo("Doing some hard work for user John Doe (customerId: 1)");
    }

    @Test
    void testDisplayNameWithAnnotationUsingJobParametersAndMDCVariablesThatDoNotExist() {
        MDC.put("key-not-used-in-annotation", "1");
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkWithAnnotation")
                        .withJobParameter(5)
                        .withJobParameter("John Doe"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getJobName()).isEqualTo("Doing some hard work for user John Doe (customerId: (customer.id is not found in MDC))");
    }

    @Test
    void testDisplayNameAlsoWorksWithJobContext() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkWithAnnotationAndJobContext")
                        .withJobParameter(5)
                        .withJobParameter("John Doe")
                        .withJobParameter(JobParameter.JobContext))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getJobName()).isEqualTo("Doing some hard work for user John Doe with id 5");
    }

    @Test
    void testDisplayNameIsCalculatedFromJobDetailsNormalMethod() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(5.5))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getJobName()).isEqualTo("org.jobrunr.stubs.TestService.doWork(5.5)");
    }

    @Test
    void testDisplayNameIsCalculatedFromJobDetailsStaticMethod() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getJobName()).isEqualTo("java.lang.System.out.println(some message)");
    }

    @Test
    void testAmountOfRetriesIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withAmountOfRetries(3)
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasAmountOfRetries(3);
    }

    @Test
    void testAmountOfRetriesIsUsedIfProvidedByAnnotation() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkThatFailsAndThenSucceeds")
                        .withJobParameter(2)
                        .withJobParameter(JobParameter.JobContext))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasAmountOfRetries(1);
    }

    @Test
    void testLabelsIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withLabels("TestLabel", "Email")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasLabels(Set.of("TestLabel", "Email"));
    }

    @Test
    void testLabelsIsUsedIfProvidedByAnnotation() {
        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWorkWithJobAnnotationAndLabels(3, "customer name"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasLabels(Set.of("label-3 - customer name"));
    }

    @Test
    void testLabelsFromBatchJobAreAddedToChildJobs() {
        BatchJob batchJob = anEnqueuedBatchJob()
                .withLabels("batch label 1", "batch label 2")
                .build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWorkWithJobAnnotationAndLabels(3, "customer name"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasLabels(Set.of("batch label 1", "batch label 2", "label-3 - customer name"));
    }

    @Test
    void testLabelsFromBatchJobAreAddedToChildJobsIfNoAnnotationOnChildJobIsPresent() {
        BatchJob batchJob = anEnqueuedBatchJob().withLabels("batch label 1", "batch label 2").build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWork(UUID.randomUUID()))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasLabels(Set.of("batch label 1", "batch label 2"));
    }

    @Test
    void testPriorityIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withPriority(2) //1 is default
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasPriority(2);
    }

    @Test
    void testPriorityWithoutQueueSpecifiedIsDefaultQueue() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getPriority()).isEqualTo(1);
    }

    @Test
    void testPriorityWithHighPrioQueueSpecified() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::startJobOnHighPrioQueue)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getPriority()).isEqualTo(0);
    }

    @Test
    void testPriorityWithLowPrioQueueSpecified() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::startJobOnLowPrioQueue)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getPriority()).isEqualTo(2);
    }

    @Test
    void testServerTagIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withServerTag("My server tag")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag("My server tag");
    }

    @Test
    void testServerTagWithoutAnnotationIsDefaultServerTag() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getServerTag()).isEqualTo(DEFAULT_SERVER_TAG);
    }

    @Test
    void testServerTagWithAnnotationIsGivenServerTag() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkOnServerThatMatches)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getServerTag()).isEqualTo(TestService.LINUX);
    }

    @Test
    void testServerTagFromBatchJobIsInheritedByChildJobIfChildJobHasNoServerTag() {
        BatchJob batchJob = anEnqueuedBatchJob()
                .withServerTag("microservice-A")
                .build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWork(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag("microservice-A");
    }

    @Test
    void testServerTagFromBatchJobIsInheritedByChildJobIfChildJobHasAnnotationButNoServerTag() {
        BatchJob batchJob = anEnqueuedBatchJob()
                .withServerTag("microservice-A")
                .build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWorkWithJobAnnotationAndLabels(2, "a string"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag("microservice-A");
    }

    @Test
    void testServerTagFromBatchJobIsNotInheritedByChildJobIfNotProvided() {
        BatchJob batchJob = anEnqueuedBatchJob().build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(() -> testService.doWork(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag(DEFAULT_SERVER_TAG);
    }

    @Test
    void testServerTagFromBatchJobIsNotInheritedByChildJobIfChildJobHasServerTagFromAnnotation() {
        BatchJob batchJob = anEnqueuedBatchJob()
                .withServerTag(WINDOWS)
                .build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkOnServerThatMatches)
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag(TestService.LINUX);
    }

    @Test
    void testServerTagFromBatchJobIsNotInheritedByChildJobIfChildJobHasServerTagFromJobBuilder() {
        BatchJob batchJob = anEnqueuedBatchJob()
                .withServerTag(WINDOWS)
                .build();
        JobHolderContext.setJob(batchJob);

        Job job = anEnqueuedJob()
                .withServerTag("my-server-tag")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasServerTag("my-server-tag");
    }

    @Test
    void testServerTagWithAnnotationIsCurrentServerIfGivenServerTagMatchesCurrentServerPlaceHolder() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkOnCurrentServerThatMatches)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getServerTag()).isEqualTo("SERVER=" + jobRunrServerId);
    }

    @Test
    void testServerTagWithAnnotationThrowsExceptionIfGivenServerTagMatchesCurrentServerPlaceHolderAndServerIdIsNull() {
        jobRunrServerId = null;
        jobFilter = new DefaultJobFilter(jobRunrServerId, new Queues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue));

        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkOnCurrentServerThatMatches)
                .build();

        assertThatThrownBy(() -> jobFilter.onCreating(job))
                .isInstanceOf(JobRunrException.class);
    }

    @Test
    void testMutexIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withMutex("My mutex")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasMutex("My mutex");
    }

    @Test
    void testMutexWithoutMutexSpecifiedIsNull() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getMutex()).isNotPresent();
    }

    @Test
    void testMutexWithMutexSpecified() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWork1WithMutexToPreventConcurrency)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getMutex())
                .isPresent()
                .contains(DEFAULT_MUTEX);
    }

    @Test
    void testMutexWithMutexSpecifiedAndParameterSubstitution() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkWithAnnotation")
                        .withJobParameter(5)
                        .withJobParameter("John Doe"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getMutex())
                .isPresent()
                .contains(DEFAULT_MUTEX + ":" + 5);
    }

    @Test
    void testRateLimiterIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withRateLimiter("my-rate-limiter")
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        // job builder is changing state to AWAITING by calling method job.setRateLimiter();
        assertThat(job).hasRateLimiter("my-rate-limiter");
    }

    @Test
    void testRateLimiterWithoutRateLimiterSpecifiedDoesNotChangeState() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasState(ENQUEUED);
    }

    @Test
    void testRateLimiterIsUsedIfProvidedByAnnotationAndStateIsChangedToAwaiting() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkWithRateLimiter)
                .build();

        jobFilter.onCreating(job);

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "my-concurrent-rate-limiter".equals(s.getWaitingOnRateLimiter()));
    }

    @Test
    void testRateLimiterIsUsedIfProvidedByAnnotationUsingParameterSubstitutionAndStateIsChangedToAwaiting() {
        Job job = anEnqueuedJob()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkWithRateLimiterAndParamSubstitution")
                        .withJobParameter(5))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getRateLimiter())
                .isNotNull()
                .contains("my-concurrent-rate-limiter-5");
    }

    @Test
    void testProcessTimeOutIsUsedIfProvidedByJobBuilder() {
        Job job = anEnqueuedJob()
                .withProcessTimeOut(Duration.ofMinutes(3))
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(2))
                .build();

        jobFilter.onCreating(job);

        assertThat(job).hasProcessTimeOut(Duration.ofMinutes(3));
    }

    @Test
    void testProcessTimeOutWithoutProcessTimeOutSpecifiedIsNull() {
        Job job = anEnqueuedJob()
                .withJobDetails(systemOutPrintLnJobDetails("some message"))
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getProcessTimeOut()).isNull();
    }

    @Test
    void testProcessTimeOutWithProcessTimeOutSpecified() {
        Job job = anEnqueuedJob()
                .withJobDetails(TestService::doWorkThatTakesLongButTimesOut)
                .build();

        jobFilter.onCreating(job);

        assertThat(job.getProcessTimeOut()).isEqualTo(Duration.ofSeconds(2));
    }

}