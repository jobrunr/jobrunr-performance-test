package org.jobrunr.jobs.filters.retry;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;

class JobRetryPolicyTest {

    @Test
    void jobRetryPolicySupportsFilteringOnJob() {
        JobRetryPolicy jobRetryPolicy = new JobRetryPolicy(j -> j.getLabels().contains("A"), null, new ExponentialBackoffRetryPolicy());

        assertThat(jobRetryPolicy.matches(aFailedJob().withLabels("A").build(), new Exception())).isTrue();
        assertThat(jobRetryPolicy.matches(aFailedJob().withLabels("B").build(), new Exception())).isFalse();
        assertThat(jobRetryPolicy.matches(aFailedJob().build(), new Exception())).isFalse();
    }

    @Test
    void jobRetryPolicySupportsFilteringOnException() {
        JobRetryPolicy jobRetryPolicy = new JobRetryPolicy(null, e -> e instanceof IllegalArgumentException, new ExponentialBackoffRetryPolicy());

        assertThat(jobRetryPolicy.matches(aFailedJob().build(), new IllegalArgumentException())).isTrue();
        assertThat(jobRetryPolicy.matches(aFailedJob().build(), new Exception())).isFalse();
        assertThat(jobRetryPolicy.matches(aFailedJob().build(), new RuntimeException())).isFalse();
    }

    @Test
    void jobRetryPolicySupportsFilteringOnJobAndException() {
        JobRetryPolicy jobRetryPolicy = new JobRetryPolicy(
                j -> j.getLabels().contains("A"),
                e -> e instanceof IllegalArgumentException,
                new ExponentialBackoffRetryPolicy());

        assertThat(jobRetryPolicy.matches(aFailedJob().withLabels("A").build(), new IllegalArgumentException())).isTrue();
        assertThat(jobRetryPolicy.matches(aFailedJob().withLabels("A").build(), new Exception())).isFalse();
        assertThat(jobRetryPolicy.matches(aFailedJob().withLabels("B").build(), new IllegalArgumentException())).isFalse();
        assertThat(jobRetryPolicy.matches(aFailedJob().build(), new RuntimeException())).isFalse();
    }

}