package org.jobrunr.jobs.queues;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class QueuesTest {

    @Test
    void queuesAreValidated_DefaultQueueMustBeInQueues() {
        assertThatCode(() -> new Queues("default", "high-prio", "default", "low-prio"))
                .doesNotThrowAnyException();
    }

    @Test
    void queuesAreValidated_5QueuesAllowed() {
        assertThatCode(() -> new Queues("default", "highest-prio","high-prio", "default", "low-prio", "lowest-prio"))
                .doesNotThrowAnyException();
    }

    @Test
    void queuesAreValidated_MoreThan5QueuesThrowsException() {
        assertThatCode(() -> new Queues("queue1", "queue0", "queue1", "queue2", "queue3", "queue4", "queue5"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("You can only define 5 different queues.");
    }

    @Test
    void queuesAreValidated_AllQueuesMustBeUnique() {
        assertThatCode(() -> new Queues("queue1", "queue0", "queue1", "queue1", "queue3", "queue3"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("All your queues should be unique.");
    }

    @Test
    void queuesAreValidated_ExceptionIfDefaultQueueNotInQueues() {
        assertThatThrownBy(() -> new Queues("default", "high-prio", "defaultIsMissing", "low-prio"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Your default queue should be part of all given queues.");
    }

}