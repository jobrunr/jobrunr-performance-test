package org.jobrunr.jobs.filters.retry;

import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;

class PerJobRetryPolicyTest {

    @Test
    void perJobRetryPolicySupportsADefaultPolicy() {
        CustomRetryPolicy defaultRetryPolicy = new CustomRetryPolicy(2);
        PerJobRetryPolicy perJobRetryPolicy = new PerJobRetryPolicy(defaultRetryPolicy);

        Job job = aFailedJob().build();

        RetryPolicy actualRetryPolicy = perJobRetryPolicy.getRetryPolicy(job, new Exception());
        assertThat(actualRetryPolicy)
                .hasMaxAmountOfRetries(1)
                .hasSecondsToAddGivenFailureCount(2, 1);
    }

    @Test
    void perJobRetryPolicySupportsACustomPolicyForJobs() {
        UUID id = UUID.randomUUID();
        PerJobRetryPolicy perJobRetryPolicy = new PerJobRetryPolicy(
                new CustomRetryPolicy(2),
                new CustomRetryPolicy(3, 4).ifJob(job1 -> id.equals(job1.getId())),
                new CustomRetryPolicy(9, 10).ifJob(job2 -> !id.equals(job2.getId())));

        Job job = aFailedJob().withId(id).build();

        RetryPolicy actualRetryPolicy = perJobRetryPolicy.getRetryPolicy(job, new Exception());
        assertThat(actualRetryPolicy)
                .hasMaxAmountOfRetries(2)
                .hasSecondsToAddGivenFailureCount(3, 1)
                .hasSecondsToAddGivenFailureCount(4, 2);
    }

    @Test
    void perJobRetryPolicySupportsACustomPolicyForExceptions() {
        UUID id = UUID.randomUUID();
        PerJobRetryPolicy perJobRetryPolicy = new PerJobRetryPolicy(
                new CustomRetryPolicy(2),
                new CustomRetryPolicy(3, 4).ifException(e -> e instanceof IllegalStateException),
                new CustomRetryPolicy(9, 10).ifException(e -> e instanceof IllegalArgumentException));

        Job job = aFailedJob().withId(id).build();

        RetryPolicy actualRetryPolicy = perJobRetryPolicy.getRetryPolicy(job, new IllegalArgumentException());
        assertThat(actualRetryPolicy)
                .hasMaxAmountOfRetries(2)
                .hasSecondsToAddGivenFailureCount(9, 1)
                .hasSecondsToAddGivenFailureCount(10, 2);
    }

    @Test
    void perJobRetryPolicySupportsACustomPolicyForCombinationOfJobAndException() {
        UUID id = UUID.randomUUID();
        PerJobRetryPolicy perJobRetryPolicy = new PerJobRetryPolicy(
                new CustomRetryPolicy(2),
                new CustomRetryPolicy(3, 4).ifJobAndException(job1 -> id.equals(job1.getId()), e -> e instanceof IllegalStateException),
                new CustomRetryPolicy(9, 10).ifException(e -> e instanceof IllegalArgumentException));

        Job job1 = aFailedJob().withId(id).build();
        RetryPolicy actualRetryPolicy1 = perJobRetryPolicy.getRetryPolicy(job1, new IllegalStateException());
        assertThat(actualRetryPolicy1)
                .hasMaxAmountOfRetries(2)
                .hasSecondsToAddGivenFailureCount(3, 1)
                .hasSecondsToAddGivenFailureCount(4, 2);

        Job job2 = aFailedJob().build();
        RetryPolicy actualRetryPolicy2 = perJobRetryPolicy.getRetryPolicy(job2, new IllegalArgumentException());
        assertThat(actualRetryPolicy2)
                .hasMaxAmountOfRetries(2)
                .hasSecondsToAddGivenFailureCount(9, 1)
                .hasSecondsToAddGivenFailureCount(10, 2);

        Job job3 = aFailedJob().build();
        RetryPolicy actualRetryPolicy3 = perJobRetryPolicy.getRetryPolicy(job3, new IllegalStateException());
        assertThat(actualRetryPolicy3)
                .hasMaxAmountOfRetries(1)
                .hasSecondsToAddGivenFailureCount(2, 1);
    }
}