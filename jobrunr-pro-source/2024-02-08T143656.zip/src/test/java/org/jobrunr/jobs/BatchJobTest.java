package org.jobrunr.jobs;


import org.jobrunr.jobs.BatchJob.BatchJobUpdateStatus;
import org.jobrunr.jobs.states.AwaitingRateLimiterState;
import org.jobrunr.jobs.states.AwaitingState;
import org.jobrunr.server.BackgroundJobServer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJobInProgress;
import static org.jobrunr.jobs.BatchJobTestBuilder.aFailedBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.aProcessedBatchJob;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.PROCESSED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class BatchJobTest {

    @Mock
    private BackgroundJobServer backgroundJobServer;

    @BeforeEach
    void setUpBackgroundJobServer() {
        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());
    }

    @Test
    void testAllOkWhileProcessed() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();

        //WHEN
        batchJob.updateChildJobStatus(5L, 1L, 0L);

        //THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED);
    }

    @Test
    void testFailWhileProcessed() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();

        //WHEN
        batchJob.updateChildJobStatus(5L, 0L, 1L);

        //THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED, FAILED);
    }

    @Test
    void testFailWhileAlreadyFailed() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();

        //WHEN
        batchJob.updateChildJobStatus(5L, 0L, 1L);
        batchJob.updateChildJobStatus(5L, 0L, 2L);

        //THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED, FAILED);
    }

    @Test
    void testNoMoreFailsAfterAlreadyFailed() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();

        //WHEN
        batchJob.updateChildJobStatus(5L, 0L, 1L);
        batchJob.updateChildJobStatus(5L, 1L, 0L);

        //THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED, FAILED, PROCESSED);
    }

    @Test
    void testBatchJobSucceedsIfAllChildJobsSucceed() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();

        //WHEN
        batchJob.updateChildJobStatus(6L, 5L, 1L);
        batchJob.updateChildJobStatus(6L, 6L, 0L);

        //THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED, FAILED, PROCESSED, SUCCEEDED);
    }

    @Test
    void testBatchJobSucceedsIfNoChildJobs() {
        // GIVEN
        BatchJob batchJob = aBatchJobInProgress().build();

        // WHEN
        batchJob.succeeded();

        // THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED);

        // WHEN
        batchJob.updateChildJobStatus(0L, 0L, 0L);

        // THEN
        assertThat(batchJob)
                .hasStates(ENQUEUED, PROCESSING, PROCESSED, SUCCEEDED);
    }

    @Test
    void testBatchJobThatIsUpdatedWithoutBeingProcessedDoesNotThrowException() {
        // GIVEN
        BatchJob batchJob = aFailedBatchJob().build();

        // WHEN
        assertThatCode(() -> batchJob.updateChildJobStatus(0L, 0L, 0L)).doesNotThrowAnyException();
    }

    @Test
    void testBatchJobUpdateStatus() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();
        BatchJobUpdateStatus batchJobUpdateStatus;

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 0L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isFalse();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(0L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isFalse();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 2L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(2L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 4L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isTrue();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(4L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 4L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isFalse();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isTrue();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(4L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 2L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(2L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 4L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(4L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 6L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isTrue();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(6L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);
    }

    @Test
    void testBatchJobUpdateStatusSucceedsIfChildJobsHaveBeenDeleted() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();
        BatchJobUpdateStatus batchJobUpdateStatus;

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 3L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 3L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 3L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 5L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isTrue();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(5L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);
    }

    @Test
    void testBatchJobUpdateStatusUpdatesProgressBarIfAmountChanges() {
        // GIVEN
        BatchJob batchJob = aProcessedBatchJob().build();
        BatchJobUpdateStatus batchJobUpdateStatus;

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(6L, 3L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 3L, 1L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isFalse();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(1L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 3L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isFalse();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(3L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);

        // WHEN & THEN
        batchJobUpdateStatus = batchJob.updateChildJobStatus(5L, 5L, 0L);
        assertThat(batchJobUpdateStatus.isBatchJobUpdated()).isTrue();
        assertThat(batchJobUpdateStatus.isBatchJobFinished()).isTrue();
        assertThat(batchJobUpdateStatus.hasStateChange()).isTrue();
        assertThat(batchJobUpdateStatus.getSucceededChildJobCount()).isEqualTo(5L);
        assertThat(batchJobUpdateStatus.getFailedChildJobCount()).isEqualTo(0L);
    }

    @Test
    void whenBatchJobIsAwaitingOrScheduledAndRateLimiterIsSetStateIsKept() {
        BatchJob batchJob = aBatchJob()
                .withAwaitingState(UUID.randomUUID())
                .build();

        batchJob.setRateLimiter("rateLimiterName");

        assertThat(batchJob)
                .hasState(AWAITING, s -> s instanceof AwaitingState)
                .hasRateLimiter("rateLimiterName");
    }

    @Test
    void whenBatchJobIsScheduledAndRateLimiterIsSetStateIsKept() {
        BatchJob batchJob = aBatchJob()
                .withScheduledState()
                .build();

        batchJob.setRateLimiter("rateLimiterName");

        assertThat(batchJob)
                .hasState(SCHEDULED)
                .hasRateLimiter("rateLimiterName");
    }

    @Test
    void whenBatchJobIsEnqueuedAndRateLimiterIsSetStateIsChangedToAwaiting() {
        BatchJob job = anEnqueuedBatchJob().build();

        job.setRateLimiter("rateLimiterName");

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "rateLimiterName".equals(s.getWaitingOnRateLimiter()))
                .hasRateLimiter("rateLimiterName");
    }
}