package org.jobrunr.jobs.mappers;

import org.jobrunr.JobRunrException;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobParameterNotDeserializableException;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.runner.RunnerJobContext;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.mapper.JobParameterJsonMapperException;
import org.jobrunr.utils.mapper.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.assertThatJson;
import static org.jobrunr.JobRunrAssertions.contentOfResource;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobParameterThatDoesNotExistJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
abstract class JobMapperTest {

    @Mock
    private BackgroundJobServer backgroundJobServer;

    private TestService testService;

    private JobMapper jobMapper;

    @BeforeEach
    void setUp() {
        jobMapper = new JobMapper(getJsonMapper());
        testService = new TestService();

        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration());
    }

    protected abstract JsonMapper getJsonMapper();

    @Test
    void testSerializeAndDeserializeJobWithVersion() {
        Job job = anEnqueuedJobWithName()
                .withVersion(2)
                .build();

        String jobAsString = jobMapper.serializeJob(job);
        final Job actualJob = jobMapper.deserializeJob(jobAsString);

        assertThat(actualJob).isEqualTo(job);
    }

    @Test
    void testSerializeAndDeserializeProcessingJobWithRateLimiterAndLogs() {
        Job job = aJob()
                .withName("a job in progress")
                .withAwaitingRateLimiterState("my-rate-limiter")
                .withEnqueuedState()
                .withProcessingState()
                .build();
        final RunnerJobContext jobContext = new RunnerJobContext(job);
        jobContext.logger().info("test 1");
        jobContext.logger().warn("test 2");
        jobContext.progressBar(10).setValue(4);

        String jobAsString = jobMapper.serializeJob(job);
        assertThatJson(jobAsString).isEqualTo(contentOfResource("/org/jobrunr/jobs/mappers/job-in-progress-with-logs-and-progressbar.json"));
        final Job actualJob = jobMapper.deserializeJob(jobAsString);

        assertThat(actualJob).isEqualTo(job);
    }

    @Test
    void testSerializeAndDeserializeJobWithPath() {
        Job job = anEnqueuedJobWithName().withJobDetails(() -> testService.doWorkWithPath(Paths.get("/tmp", "jobrunr", "log.txt"))).build();

        String jobAsString = jobMapper.serializeJob(job);

        assertThatCode(() -> jobMapper.deserializeJob(jobAsString)).doesNotThrowAnyException();
    }

    @Test
    void testSerializeAndDeserializeJobWithLabel() {
        Job job = anEnqueuedJobWithName().withLabels("first label", "second label").build();

        String jobAsString = jobMapper.serializeJob(job);
        assertThatJson(jobAsString).isEqualTo(contentOfResource("/org/jobrunr/jobs/mappers/enqueued-job-with-labels.json"));

        final Job actualJob = jobMapper.deserializeJob(jobAsString);
        assertThat(actualJob).isEqualTo(job);
    }

    @Test
    void serializeAndDeserializeRecurringJob() {
        RecurringJob recurringJob = aDefaultRecurringJob().build();

        String jobAsString = jobMapper.serializeRecurringJob(recurringJob);
        final RecurringJob actualRecurringJob = jobMapper.deserializeRecurringJob(jobAsString);

        assertThat(actualRecurringJob).isEqualTo(recurringJob);
    }

    @Test
    void canSerializeAndDeserializeWithJobContext() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWork")
                        .withJobParameter(5)
                        .withJobParameter(JobContext.Null)
                )
                .build();

        String jobAsJson = jobMapper.serializeJob(job);
        Job actualJob = jobMapper.deserializeJob(jobAsJson);

        assertThat(actualJob).isEqualTo(job);
    }

    @Test
    void canSerializeAndDeserializeJobWithAllStatesAndMetadata() {
        Job job = anEnqueuedJobWithName()
                .withMetadata("metadata1", new TestMetadata("input"))
                .withMetadata("metadata2", "a string")
                .withMetadata("metadata3", 15.1)
                .withMetadata("metadata6", 16.0)
                .withMetadata("metadata7", true)
                .build();
        job.startProcessingOn(backgroundJobServer);
        job.failed("exception", new Exception("Test"));
        job.enqueue();
        job.succeeded();
        job.setDeleteAt(Instant.now());

        String jobAsJson = jobMapper.serializeJob(job);
        Job actualJob = jobMapper.deserializeJob(jobAsJson);

        assertThat(actualJob).isEqualTo(job);
    }

    @Test
    void canSerializeAndDeserializeJobWithDeleteOnSuccess() {
        Job job = anEnqueuedJobWithName()
                .withDeleteOnSuccess("PT5S!PT7D")
                .build();

        String jobAsString = jobMapper.serializeJob(job);
        assertThatJson(jobAsString).isEqualTo(contentOfResource("/org/jobrunr/jobs/mappers/enqueued-job-delete-on-success.json"));

        assertThatCode(() -> jobMapper.deserializeJob(jobAsString)).doesNotThrowAnyException();
    }

    @Test
    void canSerializeAndDeserializeJobWithDeleteOnFailure() {
        Job job = anEnqueuedJobWithName()
                .withDeleteOnFailure("PT5S!PT7D")
                .build();

        String jobAsString = jobMapper.serializeJob(job);
        assertThatJson(jobAsString).isEqualTo(contentOfResource("/org/jobrunr/jobs/mappers/enqueued-job-delete-on-failure.json"));

        assertThatCode(() -> jobMapper.deserializeJob(jobAsString)).doesNotThrowAnyException();
    }

    @Test
    void onIllegalJobParameterCorrectExceptionIsThrown() {
        TestService.IllegalWork illegalWork = new TestService.IllegalWork(5);
        Job job = anEnqueuedJobWithName()
                .withJobDetails(() -> testService.doIllegalWork(illegalWork))
                .build();

        assertThatCode(() -> jobMapper.serializeJob(job))
                .isInstanceOf(JobParameterJsonMapperException.class)
                .isNotExactlyInstanceOf(JobRunrException.class);
    }

    @Test
    void onJobWithParameterThatCannotBeDeserializedAnymoreNoExceptionIsThrown() {
        Job job = anEnqueuedJobWithName()
                .withJobDetails(jobParameterThatDoesNotExistJobDetails())
                .build();

        String jobAsJson = jobMapper.serializeJob(job);
        Job actualJob = jobMapper.deserializeJob(jobAsJson);

        assertThat(actualJob).isNotNull();

        assertThat(actualJob.getJobDetails())
                .hasClassName(TestService.class.getName())
                .hasMethodName("doWork")
                .hasArg(arg -> arg instanceof JobParameterNotDeserializableException
                        && ((JobParameterNotDeserializableException) arg).getClassName().equals("i.dont.exist.Class"));

        String jobAsJsonAfterDeserialization = jobMapper.serializeJob(actualJob);
        Job actualJobAfterDeserialization = jobMapper.deserializeJob(jobAsJsonAfterDeserialization);
        assertThat(actualJobAfterDeserialization.getJobDetails())
                .hasClassName(TestService.class.getName())
                .hasMethodName("doWork")
                .hasArg(arg -> arg instanceof JobParameterNotDeserializableException
                        && ((JobParameterNotDeserializableException) arg).getClassName().equals("i.dont.exist.Class"));
    }

    public static class TestMetadata implements JobContext.Metadata {
        private String input;
        private Instant instant;
        private Path path;
        private File file;

        protected TestMetadata() {
        }

        public TestMetadata(String input) {
            this.input = input;
            this.instant = Instant.now();
            this.path = Paths.get("/tmp");
            this.file = new File("/tmp");
        }

        public String getInput() {
            return input;
        }

        public Instant getInstant() {
            return instant;
        }

        public Path getPath() {
            return path;
        }

        public File getFile() {
            return file;
        }
    }
}