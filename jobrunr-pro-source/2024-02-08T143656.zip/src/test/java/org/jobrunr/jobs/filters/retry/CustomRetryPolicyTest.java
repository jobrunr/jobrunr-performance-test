package org.jobrunr.jobs.filters.retry;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CustomRetryPolicyTest {

    @Test
    void customRetryPolicyWithOnly1Retry() {
        RetryPolicy retryPolicy = new CustomRetryPolicy(5);

        assertThat(retryPolicy.getMaxAmountOfRetries()).isEqualTo(1);
        assertThat(retryPolicy.getSecondsToAdd(1)).isEqualTo(5);
        assertThat(retryPolicy.getSecondsToAdd(1)).isEqualTo(5);
    }

    @Test
    void customRetryPolicyWithManyRetries() {
        RetryPolicy retryPolicy = new CustomRetryPolicy(5, 6, 7,8);

        assertThat(retryPolicy.getMaxAmountOfRetries()).isEqualTo(4);
        assertThat(retryPolicy.getSecondsToAdd(1)).isEqualTo(5);
        assertThat(retryPolicy.getSecondsToAdd(2)).isEqualTo(6);
        assertThat(retryPolicy.getSecondsToAdd(3)).isEqualTo(7);
        assertThat(retryPolicy.getSecondsToAdd(4)).isEqualTo(8);
        assertThat(retryPolicy.getSecondsToAdd(24)).isEqualTo(8);
    }

}