package org.jobrunr.jobs;

import org.jobrunr.jobs.lambdas.IocJobLambda;
import org.jobrunr.jobs.lambdas.JobLambda;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.scheduling.ScheduleExpressionType;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.stubs.TestService;
import org.jobrunr.stubs.recurringjobs.insomeverylongpackagename.with.nestedjobrequests.SimpleJobRequest;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;

import static java.time.Duration.ofSeconds;
import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.MILLIS;
import static java.time.temporal.ChronoUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aRecurringJob;
import static org.jobrunr.jobs.states.StateName.AWAITING;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE;
import static org.mockito.InstantMocker.FIXED_INSTANT_RIGHT_ON_THE_MINUTE;
import static org.mockito.InstantMocker.mockTime;

class RecurringJobTest {

    @Test
    void onlyValidIdsAreAllowed() {
        assertThatCode(() -> aDefaultRecurringJob().withoutId().build()).doesNotThrowAnyException();
        assertThatCode(() -> aDefaultRecurringJob().withId("this-is-allowed-with-a-1").build()).doesNotThrowAnyException();
        assertThatCode(() -> aDefaultRecurringJob().withId("this_is_ALSO_allowed_with_a_2").build()).doesNotThrowAnyException();
        assertThatCode(() -> aDefaultRecurringJob().withId("this_is_ALSO_allowed_with_a_2").build()).doesNotThrowAnyException();
        assertThatCode(() -> aDefaultRecurringJob().withId("some-id".repeat(20).substring(0, 127)).build()).doesNotThrowAnyException();
        assertThatCode(() -> aDefaultRecurringJob().withoutId().withJobDetails(new JobDetails(new SimpleJobRequest())).build()).doesNotThrowAnyException();
        assertThatThrownBy(() -> aDefaultRecurringJob().withId("some-id".repeat(20)).build()).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> aDefaultRecurringJob().withId("this is not allowed").build()).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> aDefaultRecurringJob().withId("this is not allowed").build()).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> aDefaultRecurringJob().withId("this-is-also-not-allowed-because-of-$").build()).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testIsRunningMoreThanOncePerMinute() {
        // CRON JOBS
        assertThat(aDefaultRecurringJob().withCronExpression("*/5 * * * * *").build()).hasRunningMoreThanOncePerMinute(true);
        assertThat(aDefaultRecurringJob().withCronExpression("* * * * *").build()).hasRunningMoreThanOncePerMinute(false);
        assertThat(aDefaultRecurringJob().withCronExpression("5 * * * *").build()).hasRunningMoreThanOncePerMinute(false);

        // INTERVAL JOBS
        assertThat(aDefaultRecurringJob().withIntervalExpression("PT10S").build()).hasRunningMoreThanOncePerMinute(true);
        assertThat(aDefaultRecurringJob().withIntervalExpression("PT1M").build()).hasRunningMoreThanOncePerMinute(false);
        assertThat(aDefaultRecurringJob().withIntervalExpression("P1D").build()).hasRunningMoreThanOncePerMinute(false);
    }

    @Test
    void testScheduleJobsSkippedDuringDowntimeThrowsExceptionIfRecurringJobIsRunningMoreThanOncePerMinute() {
        assertThatCode(() -> aDefaultRecurringJob().withCronExpression("*/5 * * * * *").withScheduleJobsSkippedDuringDowntime().build())
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Recurring jobs that run more than once per minute cannot be scheduled after downtime.");

        assertThatCode(() -> aDefaultRecurringJob().withCronExpression("*/5 * * * * *").build())
                .doesNotThrowAnyException();

        assertThatCode(() -> aDefaultRecurringJob().withCronExpression("0 0 * * * *").build())
                .doesNotThrowAnyException();

        assertThatCode(() -> aDefaultRecurringJob().withCronExpression("* * * * *").build())
                .doesNotThrowAnyException();
    }

    @Test
    void recurringJobWithAVeryLongIdUsesMD5HashingForId() {
        RecurringJob recurringJob = aDefaultRecurringJob().withoutId().withJobDetails(new JobDetails(new SimpleJobRequest())).build();
        assertThat(recurringJob.getId()).isEqualTo("045101544c9006c596e6bc7c59506913");
    }

    @Test
    void ifNoIdGivenItUsesJobSignature() {
        TestService testService = new TestService();
        final RecurringJob recurringJob1 = aDefaultRecurringJob().withoutId().withJobDetails(() -> System.out.println("This is a test")).build();
        assertThat(recurringJob1.getId()).isEqualTo("java.lang.System.out.println(java.lang.String)");

        IocJobLambda<TestService> iocJobLambda = (x) -> x.doWork(3, 97693);
        final RecurringJob recurringJob2 = aDefaultRecurringJob().withoutId().withJobDetails(iocJobLambda).build();
        assertThat(recurringJob2.getId()).isEqualTo("org.jobrunr.stubs.TestService.doWork(java.lang.Integer,java.lang.Integer)");

        final RecurringJob recurringJob3 = aDefaultRecurringJob().withoutId().withJobDetails((JobLambda) testService::doWork).build();
        assertThat(recurringJob3.getId()).isEqualTo("org.jobrunr.stubs.TestService.doWork()");
    }

    @Test
    void testToScheduledJobsGetsOneJobBetweenFromAndUpTo() {
        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withCronExpression("*/5 * * * * *")
                .build();

        final List<Job> jobs = recurringJob.toScheduledJobs(now(), now().plusSeconds(5));

        assertThat(jobs).hasSize(1);
        ScheduledState scheduledState = jobs.get(0).getJobState();
        assertThat(scheduledState.getScheduledAt()).isAfter(now());
    }

    @Test
    void testToScheduledJobsGetsAllJobsBetweenFromAndUpTo() {
        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withCronExpression("*/5 * * * * *")
                .build();

        Instant from = now().minusSeconds(15);
        Instant upTo = now().plusSeconds(5);
        final List<Job> jobs = recurringJob.toScheduledJobs(from, upTo);

        assertThat(jobs).hasSize(4);
        ScheduledState scheduledStateJob0 = jobs.get(0).getJobState();
        assertThat(scheduledStateJob0.getScheduledAt()).isBefore(now());
        ScheduledState scheduledStateJob3 = jobs.get(3).getJobState();
        assertThat(scheduledStateJob3.getScheduledAt()).isAfter(now());

        assertThat(recurringJob.getLastRunAt()).isEqualTo(upTo);
    }

    @Test
    void testToScheduledJobsGetsAllJobsBetweenFromAndUpToAlsoForMinuteJobs() {
        //2023-04-28 10:02:58.971 TRACE 28298 --- [pool-1-thread-2] org.jobrunr.server.JobZooKeeper          : Recurring job 'com.vadion.jobschedulingpoc.jobrunr.JobRunrJob.printLog1() (lastRun at 2023-04-28T08:03:00Z, nextRun at 2023-04-28T08:03:00Z)' resulted in 0 scheduled job in time range 2023-04-28T08:03:00Z - 2023-04-28T08:04:00Z.
        // GIVEN
        try (MockedStatic<Instant> instantMock = mockTime("2023-04-28T08:02:58.971Z")) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("0 * * * * *")
                    .build();

            Instant from = Instant.parse("2023-04-28T08:03:00Z");
            Instant upTo = Instant.parse("2023-04-28T08:04:00Z");
            final List<Job> jobs = recurringJob.toScheduledJobs(from, upTo);

            assertThat(jobs).hasSize(1);
            ScheduledState scheduledStateJob0 = jobs.get(0).getJobState();
            assertThat(scheduledStateJob0.getScheduledAt()).isEqualTo(from);

            assertThat(recurringJob.getLastRunAt()).isEqualTo(upTo);
        }

        try (MockedStatic<Instant> instantMock = mockTime("2023-04-28T08:03:59.271Z")) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("0 * * * * *")
                    .build();

            Instant from = Instant.parse("2023-04-28T08:04:00Z");
            Instant upTo = Instant.parse("2023-04-28T08:05:00Z");
            final List<Job> jobs = recurringJob.toScheduledJobs(from, upTo);

            assertThat(jobs).hasSize(1);
            ScheduledState scheduledStateJob0 = jobs.get(0).getJobState();
            assertThat(scheduledStateJob0.getScheduledAt()).isEqualTo(from);

            assertThat(recurringJob.getLastRunAt()).isEqualTo(upTo);
        }
    }

    @Test
    void testToScheduledJobsGetsAllJobsBetweenFromAndUpToAlsoForMinuteJobsDuringDSTSwitchWhenZoneIdIsUTC() {
        // GIVEN UTC Timezone
        try (MockedStatic<Instant> instantMock = mockTime("2022-10-30T00:59:56.596502Z")) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("0 * * * * *")
                    .withZoneId(ZoneOffset.UTC)
                    .build();

            Instant from = Instant.parse("2022-10-30T01:00:00Z");
            Instant upTo = Instant.parse("2022-10-30T01:01:00Z");
            final List<Job> jobs = recurringJob.toScheduledJobs(from, upTo);

            assertThat(jobs).hasSize(1);
            ScheduledState scheduledStateJob0 = jobs.get(0).getJobState();
            assertThat(scheduledStateJob0.getScheduledAt()).isEqualTo(from);

            assertThat(recurringJob.getLastRunAt()).isEqualTo(upTo);
        }
    }

    @Test
    @Disabled("Not relevant but good as documentation. This test also depends on the server timezone")
    void testToScheduledJobsGetsNoJobsBetweenFromAndUpToForMinuteJobsDuringDSTSwitchWhenZoneIdHasDST() {
        // GIVEN
        try (MockedStatic<Instant> instantMock = mockTime(LocalDateTime.parse("2022-10-30T02:59:56.596502"), ZoneId.of("Europe/Brussels"))) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression("0 * * * * *")
                    .build();

            Instant from = Instant.parse("2022-10-30T01:00:00Z");
            Instant upTo = Instant.parse("2022-10-30T01:01:00Z");
            final List<Job> jobs = recurringJob.toScheduledJobs(from, upTo);

            // THIS TEST IS NOT RELEVANT.
            // What in fact happens is that the RecurringJob will be saved to the StorageProvider with the nextRunAt = 01:00:00
            // however, as time is turned back by an hour (so 00:00:00), there will no jobs generated as it is queried with a range from T00:00:00 to T00:01:00
            assertThat(jobs).hasSize(59);
        }
    }

    @Test
    void testToScheduledJobsGetsAllJobsBetweenFromAndUpToNoResults() {
        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withCronExpression(Cron.weekly())
                .build();


        final List<Job> jobs = recurringJob.toScheduledJobs(now(), now().plusSeconds(5));

        assertThat(jobs).isEmpty();
        assertThat(recurringJob.getLastRunAt()).isNull();
    }

    @Test
    void recurringJobThatHasNotRunYetHasNextRunButNoLastRun() {
        try (MockedStatic<Instant> instantMock = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE)) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression(Cron.minutely())
                    .build();

            assertThat(recurringJob)
                    .hasLastRun(null)
                    .hasNextRun(FIXED_INSTANT_RIGHT_ON_THE_MINUTE.truncatedTo(SECONDS));
        }
    }

    @Test
    void testToScheduledJobsUpdatesLastRunAndNextRun() {
        try (MockedStatic<Instant> instantMock = mockTime(FIXED_INSTANT_RIGHT_BEFORE_THE_MINUTE)) {
            final RecurringJob recurringJob = aDefaultRecurringJob()
                    .withCronExpression(Cron.minutely())
                    .build();
            Instant from = now();
            Instant upTo = now().plusSeconds(15);
            recurringJob.toScheduledJobs(from, upTo);

            assertThat(recurringJob)
                    .hasLastRun(upTo)
                    .hasNextRun(from.plusSeconds(65).truncatedTo(SECONDS));
        }
    }

    @Test
    void testToScheduledJob() {
        final RecurringJob recurringJob = aRecurringJob()
                .withCronExpression("* * * * *")
                .withZoneId(ZoneId.systemDefault())
                .withId("the-recurring-job")
                .withName("the recurring job")
                .withJobDetails(defaultJobDetails())
                .withAmountOfRetries(6)
                .withPriority(3)
                .withLabels("some label", "my other label")
                .withServerTag("some-tag")
                .withMutex("my-mutex")
                .withRateLimiter("my-rate-limiter")
                .withProcessTimeOut(Duration.ofSeconds(4))
                .withDeleteOnSuccess("PT10S")
                .withDeleteOnFailure("P1D")
                .build();

        final Job job = recurringJob.toScheduledJob();

        assertThat(job)
                .hasRecurringJobId("the-recurring-job")
                .hasJobName("the recurring job")
                .hasState(SCHEDULED)
                .hasJobDetails(TestService.class, "doWork", 5)
                .hasAmountOfRetries(6)
                .hasPriority(3)
                .hasLabels("some label", "my other label")
                .hasServerTag("some-tag")
                .hasMutex("my-mutex")
                .hasRateLimiter("my-rate-limiter")
                .hasProcessTimeOut(Duration.ofSeconds(4))
                .hasDeleteOnSuccess("PT10S")
                .hasDeleteOnFailure("P1D");
    }

    @Test
    void testToEnqueuedJobWithoutRateLimiter() {
        final RecurringJob recurringJob = aRecurringJob()
                .withCronExpression("* * * * *")
                .withZoneId(ZoneId.systemDefault())
                .withId("the-recurring-job")
                .withName("the recurring job")
                .withJobDetails(defaultJobDetails())
                .withAmountOfRetries(6)
                .withPriority(3)
                .withLabels("some label", "my other label")
                .withServerTag("some-tag")
                .withMutex("my-mutex")
                .withProcessTimeOut(Duration.ofSeconds(4))
                .withDeleteOnSuccess("PT10S")
                .withDeleteOnFailure("P1D")
                .build();

        final Job job = recurringJob.toEnqueuedJob("The reason");

        assertThat(job)
                .hasRecurringJobId("the-recurring-job")
                .hasJobName("the recurring job")
                .hasState(ENQUEUED)
                .hasJobDetails(TestService.class, "doWork", 5)
                .hasAmountOfRetries(6)
                .hasPriority(3)
                .hasLabels("some label", "my other label")
                .hasServerTag("some-tag")
                .hasMutex("my-mutex")
                .hasProcessTimeOut(Duration.ofSeconds(4))
                .hasDeleteOnSuccess("PT10S")
                .hasDeleteOnFailure("P1D");
    }

    @Test
    void testToEnqueuedJobWithRateLimiterChangesStateToAwaiting() {
        final RecurringJob recurringJob = aRecurringJob()
                .withCronExpression("* * * * *")
                .withZoneId(ZoneId.systemDefault())
                .withId("the-recurring-job")
                .withName("the recurring job")
                .withJobDetails(defaultJobDetails())
                .withRateLimiter("my-rate-limiter")
                .build();

        final Job job = recurringJob.toEnqueuedJob("The reason");

        assertThat(job)
                .hasRecurringJobId("the-recurring-job")
                .hasJobName("the recurring job")
                .hasState(AWAITING)
                .hasJobDetails(TestService.class, "doWork", 5)
                .hasRateLimiter("my-rate-limiter");
    }

    @Test
    void nextInstantWithCronExpressionIsCorrect() {
        LocalDateTime localDateTime = LocalDateTime.now();
        LocalDateTime timeForCron = localDateTime.plusMinutes(-1);

        int hour = timeForCron.getHour();
        int minute = timeForCron.getMinute();

        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withName("the recurring job")
                .withCronExpression(Cron.daily(hour, (minute)))
                .withZoneId(ZoneOffset.of("+02:00"))
                .build();
        Instant nextRun = recurringJob.getNextRunAt();
        assertThat(nextRun).isAfter(now());
    }

    @Test
    void nextInstantWithIntervalIsCorrect() {
        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withName("the recurring job")
                .withIntervalExpression(Duration.ofHours(1).toString())
                .withZoneId(ZoneOffset.of("+02:00"))
                .build();
        Instant nextRun = recurringJob.getNextRunAt();
        assertThat(nextRun).isAfter(now());
    }

    @Test
    void testDurationBetweenRecurringJobInstancesForCronJob() {
        RecurringJob recurringJob1 = aDefaultRecurringJob().withCronExpression("* * * * * *").build();
        assertThat(recurringJob1.durationBetweenRecurringJobInstances()).isEqualTo(ofSeconds(1));

        RecurringJob recurringJob2 = aDefaultRecurringJob().withCronExpression("*/5 * * * * *").build();
        assertThat(recurringJob2.durationBetweenRecurringJobInstances()).isEqualTo(ofSeconds(5));
    }

    @Test
    void testDurationBetweenRecurringJobInstancesForIntervalJob() {
        RecurringJob recurringJob1 = aDefaultRecurringJob().withIntervalExpression(ofSeconds(1).toString()).build();
        assertThat(recurringJob1.durationBetweenRecurringJobInstances()).isEqualTo(ofSeconds(1));

        RecurringJob recurringJob2 = aDefaultRecurringJob().withIntervalExpression(ofSeconds(5).toString()).build();
        assertThat(recurringJob2.durationBetweenRecurringJobInstances()).isEqualTo(ofSeconds(5));
    }

    @Test
    void maxConcurrentJobsMustBeAtLeast1() {
        final RecurringJob recurringJob = aDefaultRecurringJob().build();

        assertThatCode(() -> recurringJob.setMaxConcurrentJobs(0))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The minimum value for maxConcurrentJobs must be greater than 0");
    }

    @Test
    void nextRunIsUpdatedWhenScheduleIsChanged() {
        final RecurringJob recurringJob = aDefaultRecurringJob().withCronExpression(Cron.every5minutes()).build();

        recurringJob.updateSchedule(ScheduleExpressionType.getSchedule(Cron.every15seconds()));
        System.out.println(recurringJob.getNextRunAt());
        System.out.println(now());
        assertThat(recurringJob.getNextRunAt())
                .isCloseTo(now(), within(15, SECONDS));
    }

    @Test
    void updatedAtIsUpdatedWhenScheduleIsChanged() {
        final RecurringJob recurringJob = aDefaultRecurringJob()
                .withCreatedAt(now().minusSeconds(30))
                .withUpdatedAt(now().minusSeconds(29))
                .build();

        recurringJob.updateSchedule(ScheduleExpressionType.getSchedule(Cron.every15seconds()));
        assertThat(recurringJob.getUpdatedAt())
                .isCloseTo(now(), within(200, MILLIS));
    }
}