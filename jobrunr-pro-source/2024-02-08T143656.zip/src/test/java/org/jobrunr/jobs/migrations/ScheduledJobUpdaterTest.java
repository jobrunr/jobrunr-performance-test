package org.jobrunr.jobs.migrations;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.stubs.TestService;
import org.jobrunr.stubs.TestServiceForIoC;
import org.jobrunr.utils.mapper.JsonMapper;
import org.jobrunr.utils.mapper.gson.GsonJsonMapper;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.jobrunr.utils.mapper.jsonb.JsonbJsonMapper;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrAssertions.contentOfResource;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.states.StateName.DELETED;

class ScheduledJobUpdaterTest {

    private TestService testService;

    @Test
    void scheduledJobCanBeDeleted() {
        final Job scheduledJob = aScheduledJob().build();

        final ScheduledJobUpdater scheduledJobUpdater = new ScheduledJobUpdater(scheduledJob);
        scheduledJobUpdater.deleteJob();
        Job updatedScheduledJob = scheduledJobUpdater.toUpdatedJob();

        assertThat(updatedScheduledJob).hasState(DELETED);
    }

    @Test
    void ifUpdatedScheduledJobClassIsNotFoundExceptionIsThrown() {
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestServiceForIoC.class).withMethodName("doWork"))
                .build();

        final ScheduledJobUpdater scheduledJobUpdater = new ScheduledJobUpdater(scheduledJob);

        scheduledJobUpdater.updateClassName(originalClass -> "something.that.does.not.exist");
        assertThatThrownBy(scheduledJobUpdater::toUpdatedJob)
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("The updated job with jobSignature 'something.that.does.not.exist.doWork()' does not exist.");
    }

    @Test
    void scheduledJobClassCanBeUpdated() {
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestServiceForIoC.class).withMethodName("doWork"))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .updateClass(originalClass -> TestService.class)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails()).hasClass(TestService.class);
    }

    @Test
    void scheduledJobClassNameCanBeUpdated() {
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(jobDetails().withClassName("some.class.that.does.not.Exist").withMethodName("doWork"))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .updateClassName(originalClassName -> TestService.class.getName())
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails()).hasClass(TestService.class);
    }

    @Test
    void scheduledJobMethodNameCanBeUpdated() {
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("dontDoWork"))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .updateMethodName(originalMethodName -> originalMethodName.replace("dontD", "d"))
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork");
    }

    @Test
    void scheduledJobParameterClassesThatDoNotExistCanBeHandledByJackson() {
        final Job scheduledJob = scheduledJobParameterClassesThatDoNotExistCanBeHandled(new JacksonJsonMapper());

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .removeParametersOfType("org.jobrunr.stubs.TestService$WorkDoesNotExist")
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork");
    }

    @Test
    void scheduledJobParameterClassesThatDoNotExistCanBeHandledByGson() {
        final Job scheduledJob = scheduledJobParameterClassesThatDoNotExistCanBeHandled(new GsonJsonMapper());

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .removeParametersOfType("org.jobrunr.stubs.TestService$WorkDoesNotExist")
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork");
    }

    @Test
    void scheduledJobParameterClassesThatDoNotExistCanBeHandledByJsonB() {
        final Job scheduledJob = scheduledJobParameterClassesThatDoNotExistCanBeHandled(new JsonbJsonMapper());

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .removeParametersOfType("org.jobrunr.stubs.TestService$WorkDoesNotExist")
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork");
    }

    @Test
    void scheduledJobParametersCanBeAdded() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(() -> testService.doWork(id))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .addParameter(count)
                .addParameter(time)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id, 5, time);
    }

    @Test
    void scheduledJobParametersCanBeAddedAtACertainIndex() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(jobDetails().withClassName(TestService.class).withMethodName("doWork").withJobParameter(time))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .addParameterAtIndex(0, id)
                .addParameterAtIndex(1, count)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id, 5, time);
    }

    @Test
    void scheduledJobParametersCanBeRemoved() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(() -> testService.doWork(id, count, time))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .removeParameterAtIndex(1)
                .removeParameterAtIndex(1)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id);
    }

    @Test
    void scheduledJobParametersCanBeRemovedByType() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(() -> testService.doWork(id, count, time))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .removeParametersOfType(Instant.class)
                .removeParametersOfType(Integer.class)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id);
    }

    @Test
    void scheduledJobParametersCanBeReplaced() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(() -> testService.doWork(id, count, time))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .replaceParameter(1, 10)
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id, 10, time);
    }

    @Test
    void scheduledJobParametersCanBeUpdated() {
        UUID id = UUID.randomUUID();
        int count = 5;
        Instant time = Instant.now();
        final Job scheduledJob = aScheduledJob()
                .withJobDetails(() -> testService.doWork(id, count, time))
                .build();

        Job updatedScheduledJob = new ScheduledJobUpdater(scheduledJob)
                .updateParameter(1, obj -> ((int)obj + 5))
                .toUpdatedJob();

        assertThat(updatedScheduledJob.getJobDetails())
                .hasClass(TestService.class)
                .hasMethodName("doWork")
                .hasArgs(id, 10, time);
    }

    private Job scheduledJobParameterClassesThatDoNotExistCanBeHandled(JsonMapper jsonMapper) {
        return new JobMapper(jsonMapper).deserializeJob(contentOfResource("/org/jobrunr/utils/mapper/scheduled-job-custom-object-parameter-that-does-not-exist.json"));
    }
}