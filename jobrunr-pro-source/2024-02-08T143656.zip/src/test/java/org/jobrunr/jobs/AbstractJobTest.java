package org.jobrunr.jobs;

import org.jobrunr.utils.resilience.Lock;
import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;

class AbstractJobTest {

    @Test
    void increaseVersion() {
        Job job = anEnqueuedJobWithName().build();
        assertThat(job.getVersion()).isZero();

        assertThat(job.increaseVersion()).isEqualTo(1);
        assertThat(job.getVersion()).isEqualTo(1);

        assertThat(job.increaseVersion()).isEqualTo(2);
        assertThat(job.getVersion()).isEqualTo(2);
    }

    @Test
    void jobWithJobSignatureThatIsTooLongThrowsException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withJobDetails(defaultJobDetails()
                        .withClassName("sommmmmmmmmmmmmmmmmmmmmmmmmmmmme.classssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss.in.a.reaaalllllllllllllyyyyyyyyyyyy.loooooooooooooooooooooooong.paaaaaaapaaaaaaapaaaaaaapaaaaaaapaaaaaaapaaaaaaapaaaaaaackaaaaaaaaaaaaaaaaaaagggggeeeee.wiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiitttttttthoooooooooouuuuutttt.aaaaaaaaaa.loooooooooooooooooooootttt.offfffffffffff.paaaaaaaarrraaaaaammmeeeetttteeerrrss")
                        .withMethodName("aReallllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllyyyyyyyyLooooooooooooooooooooooooooooooooooooooooooooooooooooooonnnnnnnnggggMethooooooooooooooooooooooooooooooooooooooooooddNaaaaaaaaaaaaaaaaaaaaaaaaaaammmmmme")
                )
                .build())
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void jobWithJobNameThatIsTooLongDoesNotThrowException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName("A very long display name".repeat(50))
                .build())
                .doesNotThrowAnyException();
    }

    @Test
    void jobWithoutJobNameDoesNotThrowException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName(null)
                .build())
                .doesNotThrowAnyException();
    }

    @Test
    void jobWithServerTagThatIsTooLongThrowsException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName("A job")
                .withServerTag("some-server-tag-that-is-too-long".repeat(10))
                .build())
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void jobWithoutServerTagDoesNotThrowException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName("A job")
                .withServerTag(null)
                .build())
                .doesNotThrowAnyException();
    }

    @Test
    void jobWithMutexThatIsTooLongThrowsException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName("A job")
                .withMutex("some-mutex-that-is-too-long".repeat(10))
                .build())
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void jobWithoutMutexDoesNotThrowException() {
        assertThatCode(() -> anEnqueuedJobWithName()
                .withName("A job")
                .withoutMutex()
                .build())
                .doesNotThrowAnyException();
    }

    @Test
    void whileLockedJobCannotBeLockedForOtherSaveAction() {
        Job job = anEnqueuedJobWithName().build();
        final AtomicBoolean atomicBoolean = new AtomicBoolean();

        final Lock lock = job.lock();
        await()
                .during(1, TimeUnit.SECONDS)
                .atMost(2, TimeUnit.SECONDS)
                .pollInterval(200, TimeUnit.MILLISECONDS)
                .untilAsserted(() -> {
                    new Thread(() -> {
                        job.lock();
                        atomicBoolean.set(true);
                    }).start();

                    assertThat(lock.isLocked()).isTrue();
                    assertThat(atomicBoolean).isFalse();
                });
    }

    @Test
    void testRedactJob() {
        Job job = aFailedJob().withFailedState().build();
        job.redact();
        JobDetailsAssert.assertThat(job.getJobDetails()).isRedacted();
    }
}