package org.jobrunr.jobs.states;

import org.jobrunr.jobs.Job;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.*;


class AwaitingStateTest {

    @Test
    void testIfJobIsNotInAwaitingStateItThrowsAnException() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED);

        Job job = anEnqueuedJobWithName().build();
        assertThatCode(() -> awaitingState.moveToNextState(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("Only jobs in AWAITING state can move to a next state");
    }

    @Test
    void testIfJobDoesNotHaveSameExactAwaitingStateItThrowsAnException() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED);

        Job job = aJob().withAwaitingState(UUID.randomUUID()).build();

        assertThatCode(() -> awaitingState.moveToNextState(job))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("Only jobs in AWAITING state can move to a next state");
    }

    @Test
    void testToNextStateForAwaitingJobWillGoToEnqueued() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED);
        Job job = aJob().withState(awaitingState).build();

        awaitingState.moveToNextState(job);

        assertThat(job).hasState(ENQUEUED);
    }

    @Test
    void testToNextStateForAwaitingJobWillGoToEnqueuedIfDurationIsZero() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED, Duration.ZERO);

        Job job = aJob().withState(awaitingState).build();

        awaitingState.moveToNextState(job);

        assertThat(job).hasState(ENQUEUED);
    }

    @Test
    void testToNextStateForAwaitingJobWillGoToScheduledIfDurationIsProvided() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED, Duration.ofDays(3));

        Job job = aJob().withState(awaitingState).build();

        awaitingState.moveToNextState(job);

        assertThat(job).hasState(SCHEDULED);
    }

    @Test
    void testToNextStateForAwaitingJobWillGoToAwaitingIfRateLimiterIsProvided() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED);

        Job job = aJob()
                .withRateLimiter("my-rate-limiter")
                .withState(awaitingState)
                .build();

        awaitingState.moveToNextState(job);

        assertThat(job)
                .<AwaitingRateLimiterState>hasState(AWAITING, s -> "my-rate-limiter".equals(s.getWaitingOnRateLimiter()));
    }

    @Test
    void testToNextStateForAwaitingJobWillGoToScheduledIfDurationAndRateLimiterIsProvided() {
        AwaitingState awaitingState = new AwaitingState(UUID.randomUUID(), SUCCEEDED, Duration.ofDays(3));

        Job job = aJob()
                .withRateLimiter("my-rate-limiter")
                .withState(awaitingState)
                .build();

        awaitingState.moveToNextState(job);

        assertThat(job).hasState(SCHEDULED);
    }

}