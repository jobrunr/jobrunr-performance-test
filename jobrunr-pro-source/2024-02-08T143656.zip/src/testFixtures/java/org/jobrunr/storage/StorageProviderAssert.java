package org.jobrunr.storage;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.storage.nosql.mongo.MongoDBStorageProvider;

import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;

public class StorageProviderAssert extends AbstractAssert<StorageProviderAssert, StorageProvider> {

    private StorageProviderAssert(StorageProvider storageProvider) {
        super(storageProvider, StorageProviderAssert.class);
    }

    public static StorageProviderAssert assertThat(StorageProvider storageProvider) {
        return new StorageProviderAssert(storageProvider);
    }

    public StorageProviderAssert hasJobs(StateName stateName, int count) {
        return hasJobs(aJobSearchRequest().withStateName(stateName), count);
    }

    public StorageProviderAssert hasJobs(JobSearchRequestBuilder searchRequestTestBuilder, int count) {
        return hasJobs(searchRequestTestBuilder.build(), count);
    }

    public StorageProviderAssert hasJobs(JobSearchRequest jobSearchRequest, int count) {
        Assertions.assertThat(actual.countJobs(jobSearchRequest)).isEqualTo(count);
        return this;
    }

    public StorageProviderAssert hasJobMapper() {
        String jobMapperField = "jobMapper";
        if (MongoDBStorageProvider.class.equals(actual.getClass())) {
            jobMapperField = "jobDocumentMapper";
        }

        Assertions.assertThat(actual).extracting(jobMapperField).isNotNull();
        return this;
    }
}
