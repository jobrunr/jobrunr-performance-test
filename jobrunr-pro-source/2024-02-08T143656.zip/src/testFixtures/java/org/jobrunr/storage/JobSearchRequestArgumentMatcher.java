package org.jobrunr.storage;

import org.mockito.ArgumentMatcher;

public class JobSearchRequestArgumentMatcher implements ArgumentMatcher<JobSearchRequest> {

    private final JobSearchRequest expected;

    public JobSearchRequestArgumentMatcher(JobSearchRequest expectedJobSearchRequest) {
        this.expected = expectedJobSearchRequest;
    }

    @Override
    public boolean matches(JobSearchRequest actual) {
        return expected.getState().equals(actual.getState())
                && (expected.getScheduledAtFrom() == null || expected.getScheduledAtFrom().equals(actual.getScheduledAtFrom()))
                && (expected.getScheduledAtTo() == null || expected.getScheduledAtTo().equals(actual.getScheduledAtTo()));
    }
}
