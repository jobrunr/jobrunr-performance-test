package org.jobrunr.storage;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.jobs.states.StateName;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static java.time.temporal.ChronoUnit.MILLIS;
import static org.assertj.core.api.Assertions.within;

public class JobSearchRequestAssert extends AbstractAssert<JobSearchRequestAssert, JobSearchRequest> {

    protected JobSearchRequestAssert(JobSearchRequest jobSearchRequest) {
        super(jobSearchRequest, JobSearchRequestAssert.class);
    }

    public static JobSearchRequestAssert assertThat(JobSearchRequest jobSearchRequest) {
        return new JobSearchRequestAssert(jobSearchRequest);
    }

    public JobSearchRequestAssert hasState(StateName stateName) {
        if (actual.getState() != null) {
            Assertions.assertThat(actual.getState()).isEqualTo(stateName);
        } else if (actual.getStates() != null) {
            Assertions.assertThat(actual.getStates()).contains(stateName);
        } else {
            throw new IllegalStateException("Expected JobSearchRequest to have state " + stateName);
        }
        return this;
    }

    public JobSearchRequestAssert hasStates(StateName... stateName) {
        Assertions.assertThat(actual.getStates()).contains(stateName);
        return this;
    }


    public JobSearchRequestAssert hasJobIds(UUID... jobIds) {
        return hasJobIds(Arrays.asList(jobIds));
    }

    public JobSearchRequestAssert hasJobIds(List<UUID> jobIds) {
        Assertions.assertThat(actual.getJobIds()).isEqualTo(jobIds);
        return this;
    }

    public JobSearchRequestAssert hasRateLimiter(String rateLimiter) {
        Assertions.assertThat(actual.getRateLimiter()).isEqualTo(rateLimiter);
        return this;
    }

    public JobSearchRequestAssert hasScheduledAtFrom(Instant scheduledAtFrom) {
        Assertions.assertThat(actual.getScheduledAtFrom()).isEqualTo(scheduledAtFrom);
        return this;
    }

    public JobSearchRequestAssert hasScheduledAtTo(Instant scheduledAtTo) {
        Assertions.assertThat(actual.getScheduledAtTo()).isEqualTo(scheduledAtTo);
        return this;
    }

    public JobSearchRequestAssert hasScheduledAt(Instant scheduledAtFrom, Instant scheduledAtTo) {
        hasScheduledAtFrom(scheduledAtFrom);
        hasScheduledAtTo(scheduledAtTo);
        return this;
    }

    public JobSearchRequestAssert hasParentId(UUID jobId) {
        Assertions.assertThat(actual.getParentId()).isEqualTo(jobId);
        return this;
    }

    public JobSearchRequestAssert hasDeleteAtTo(Instant deleteAtTo) {
        Assertions.assertThat(actual.getDeleteAtTo()).isEqualTo(deleteAtTo);
        return this;
    }

    public JobSearchRequestAssert hasDeleteAtToNear(Instant deleteAtTo) {
        Assertions.assertThat(actual.getDeleteAtTo()).isCloseTo(deleteAtTo, within(250, MILLIS));
        return this;
    }


}