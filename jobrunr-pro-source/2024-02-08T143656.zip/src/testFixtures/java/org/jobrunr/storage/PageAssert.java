package org.jobrunr.storage;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.JobRunrAssertions;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;

import java.util.List;
import java.util.function.Consumer;

public class PageAssert<T> extends AbstractAssert<PageAssert<T>, Page> {

    private PageAssert(Page page) {
        super(page, PageAssert.class);
    }

    public static <T> PageAssert<T> assertThat(Page<T> page) {
        return new PageAssert(page);
    }

    public PageAssert<T> hasTotal(long total) {
        Assertions.assertThat(actual.getTotal()).isEqualTo(total);
        return this;
    }

    public PageAssert<T> hasLimit(int limit) {
        //Assertions.assertThat(actual.getLimit()).isEqualTo(limit);
        throw new UnsupportedOperationException();
    }

    public PageAssert<T> hasNoItems() {
        Assertions.assertThat(actual.getTotal()).isZero();
        Assertions.assertThat(actual.getItems()).isEmpty();
        return this;
    }

    public PageAssert<T> hasItems(int size) {
        Assertions.assertThat(actual.getItems().size()).isEqualTo(size);
        return this;
    }

    public PageAssert<T> containsExactly(Object... objects) {
        return containsExactly(List.of(objects));
    }

    public PageAssert<T> containsExactly(List<?> objectList) {
        if (objectList.get(0) instanceof RecurringJob) {
            JobRunrAssertions.assertThatRecurringJobs((List<RecurringJob>) actual.getItems()).containsExactlyElementsOf((List<RecurringJob>) objectList);
        } else if (objectList.get(0) instanceof Job) {
            JobRunrAssertions.assertThatJobs((List<Job>) actual.getItems()).containsExactlyElementsOf((List<Job>) objectList);
        } else {
            throw new UnsupportedOperationException("Unsupported object");
        }
        return this;
    }

    public PageAssert<T> hasItem(int index, Consumer<T> consumer) {
        consumer.accept((T) actual.getItems().get(index));
        return this;
    }

    public PageAssert<T> allMatch(Consumer<T> consumer) {
        actual.getItems().forEach(x -> consumer.accept((T) x));
        return this;
    }
}
