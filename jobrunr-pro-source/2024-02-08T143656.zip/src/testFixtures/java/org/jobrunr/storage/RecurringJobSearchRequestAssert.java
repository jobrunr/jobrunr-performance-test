package org.jobrunr.storage;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

import java.time.Instant;

public class RecurringJobSearchRequestAssert extends AbstractAssert<RecurringJobSearchRequestAssert, RecurringJobSearchRequest> {

    protected RecurringJobSearchRequestAssert(RecurringJobSearchRequest searchRequest) {
        super(searchRequest, RecurringJobSearchRequestAssert.class);
    }

    public static RecurringJobSearchRequestAssert assertThat(RecurringJobSearchRequest searchRequest) {
        return new RecurringJobSearchRequestAssert(searchRequest);
    }

    public RecurringJobSearchRequestAssert hasRunsMoreThanOncePerMinute(boolean value) {
        Assertions.assertThat(actual.getRunsMoreThanOncePerMinute()).isEqualTo(value);
        return this;
    }

    public RecurringJobSearchRequestAssert hasNextRunTo(Instant nextRunTo) {
        Assertions.assertThat(actual.getNextRunTo()).isEqualTo(nextRunTo);
        return this;
    }

    public RecurringJobSearchRequestAssert hasPaused(boolean paused) {
        Assertions.assertThat(actual.getPaused()).isEqualTo(paused);
        return this;
    }

    public RecurringJobSearchRequestAssert hasUpdatedAtFrom(Instant updatedAtFrom) {
        Assertions.assertThat(actual.getUpdatedAtFrom()).isEqualTo(updatedAtFrom);
        return this;
    }
}