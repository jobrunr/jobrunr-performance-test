package org.jobrunr.storage;

import com.github.javafaker.Faker;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.states.ScheduledState;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static java.time.Instant.now;
import static org.jobrunr.jobs.JobTestBuilder.*;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;

public class StubDataProvider {

    private final StorageProvider storageProvider;

    private StubDataProvider(StorageProvider storageProvider) {
        this.storageProvider = storageProvider;
    }

    public static StubDataProvider using(StorageProvider storageProvider) {
        return new StubDataProvider(storageProvider);
    }

    public StubDataProvider addALotOfEnqueuedJobsThatTakeSomeTime() {
        Faker faker = new Faker();
        List<Job> jobs = new ArrayList<>();
        for (int i = 0; i < 13; i++) {
            for(int j = 0; j < 1000; j++) {
                UUID orderId = UUID.randomUUID();
                String fullName = faker.name().fullName();
                jobs.add(aFailedJobThatEventuallySucceeded()
                        .withName("Order " + orderId + " - send shipping instructions to warehouse")
                        .build());
                jobs.add(anEnqueuedJobThatTakesLong()
                        .withName("Order " + orderId + " - generate invoice for " + fullName)
                        .build());
                jobs.add(anEnqueuedJobThatTakesLong()
                        .withName("Order " + orderId + " - email invoice to " + fullName)
                        .build());
            }
            storageProvider.save(jobs);
            jobs.clear();
        }
        storageProvider.save(aJob().withState(new ScheduledState(now().plusSeconds(60L * 60 * 5))).build());
        storageProvider.save(aSucceededJob().build());
        storageProvider.save(aFailedJobWithRetries().withSucceededState().build());
        storageProvider.save(aFailedJobWithRetries().build());
        storageProvider.save(aFailedJobThatEventuallySucceeded().build());
        return this;
    }

    public StubDataProvider addSomeRecurringJobs() {
        for (int i = 0; i < 10; i++) {
            storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("import-sales-data-" + i).withName("Import all sales data at midnight").withLabels("some label a", "another label").build());
            storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("generate-sales-reports-" + i).withName("Generate sales report at 3am").withCronExpression("0 3 * * *").build());
        }
        return this;
    }
}
