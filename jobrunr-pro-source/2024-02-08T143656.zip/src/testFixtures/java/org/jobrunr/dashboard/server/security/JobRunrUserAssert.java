package org.jobrunr.dashboard.server.security;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

public class JobRunrUserAssert extends AbstractAssert<JobRunrUserAssert, JobRunrUser> {

    protected JobRunrUserAssert(JobRunrUser jobRunrUser) {
        super(jobRunrUser, JobRunrUserAssert.class);
    }

    public static final JobRunrUserAssert assertThat(JobRunrUser jobRunrUser) {
        return new JobRunrUserAssert(jobRunrUser);
    }

    public JobRunrUserAssert hasAuthorizationRulesAllowAll() {
        return this
                .hasAuthorizationRuleCanAccessJobs()
                .hasAuthorizationRuleCanEnqueueJobs()
                .hasAuthorizationRuleCanDeleteJobs()
                .hasAuthorizationRuleCanAccessRecurringJobs()
                .hasAuthorizationRuleCanControlRecurringJobs()
                .hasAuthorizationRuleCanDeleteRecurringJobs()
                .hasAuthorizationRuleCanAccessBackgroundJobServers()
                .hasAuthorizationRuleCanControlBackgroundJobServers();
    }

    public JobRunrUserAssert hasAuthorizationRulesReadOnly() {
        this
                .hasAuthorizationRuleCanAccessJobs()
                .hasAuthorizationRuleCanAccessRecurringJobs()
                .hasAuthorizationRuleCanAccessBackgroundJobServers();

        Assertions.assertThat(actual.getAuthorizationRules().canEnqueueJobs()).isFalse();
        Assertions.assertThat(actual.getAuthorizationRules().canDeleteJobs()).isFalse();
        Assertions.assertThat(actual.getAuthorizationRules().canControlRecurringJobs()).isFalse();
        Assertions.assertThat(actual.getAuthorizationRules().canDeleteRecurringJobs()).isFalse();
        Assertions.assertThat(actual.getAuthorizationRules().canControlBackgroundJobServers()).isFalse();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanAccessJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canAccessJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanAccessRecurringJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canAccessRecurringJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanAccessBackgroundJobServers() {
        Assertions.assertThat(actual.getAuthorizationRules().canAccessBackgroundJobServers()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanEnqueueJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canEnqueueJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanDeleteJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canDeleteJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanControlRecurringJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canControlRecurringJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanDeleteRecurringJobs() {
        Assertions.assertThat(actual.getAuthorizationRules().canDeleteRecurringJobs()).isTrue();
        return this;
    }

    public JobRunrUserAssert hasAuthorizationRuleCanControlBackgroundJobServers() {
        Assertions.assertThat(actual.getAuthorizationRules().canControlBackgroundJobServers()).isTrue();
        return this;
    }
}