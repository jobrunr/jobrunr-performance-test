package org.jobrunr.dashboard.server.http.client;

import org.jobrunr.utils.exceptions.Exceptions;

import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.HashMap;
import java.util.Map;

public class TeenyHttpClient {

    private final String baseUri;
    private final HttpClient httpClient;

    private final Map<String, String> headers;

    public TeenyHttpClient(String baseUri) {
        this.baseUri = baseUri;
        this.headers = new HashMap<>();
        this.httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .build();

    }

    public TeenyHttpClient withHeader(String name, String value) {
        this.headers.put(name, value);
        return this;
    }

    public TeenyHttpClient withCookie(String name, String value) {
        String cookies = this.headers.getOrDefault("Cookie", "");
        cookies += name + "=" + value + "; ";
        this.headers.put("Cookie", cookies);
        return this;
    }

    public HttpResponse<String> get(String relativeUrl) {
        final HttpRequest httpRequest = httpRequest()
                .uri(relativeUrlToUri(relativeUrl))
                .build();

        return unchecked(() -> httpClient.send(httpRequest, BodyHandlers.ofString()));
    }

    public HttpResponse<String> get(String url, Object... params) {
        final HttpRequest httpRequest = httpRequest()
                .uri(URI.create(baseUri + String.format(url, params)))
                .build();

        return unchecked(() -> httpClient.send(httpRequest, BodyHandlers.ofString()));
    }

    public HttpResponse<String> delete(String url, Object... params) {
        final HttpRequest httpRequest = httpRequest()
                .uri(URI.create(baseUri + String.format(url, params)))
                .DELETE()
                .build();

        return unchecked(() -> httpClient.send(httpRequest, BodyHandlers.ofString()));
    }

    public HttpResponse<String> post(String url, Object... params) {
        final HttpRequest httpRequest = httpRequest()
                .uri(URI.create(baseUri + String.format(url, params)))
                .POST(HttpRequest.BodyPublishers.noBody())
                .build();

        return unchecked(() -> httpClient.send(httpRequest, BodyHandlers.ofString()));
    }

    private URI relativeUrlToUri(String relativeUrl) {
        try {
            URL url = new URL(baseUri + relativeUrl);
            URI uri = new URI(url.getProtocol(), url.getUserInfo(), IDN.toASCII(url.getHost()), url.getPort(), url.getPath(), url.getQuery(), url.getRef());
            return uri;
        } catch (MalformedURLException | URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private HttpRequest.Builder httpRequest() {
        HttpRequest.Builder builder = HttpRequest.newBuilder();
        for (String header : headers.keySet()) {
            builder.setHeader(header, headers.get(header));
        }
        return builder;
    }

    private <T> T unchecked(Exceptions.ThrowingSupplier<T> throwingSupplier) {
        try {
            return throwingSupplier.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
