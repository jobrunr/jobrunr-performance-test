package org.jobrunr.stubs;

import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.lambdas.JobRequestHandler;
import org.jobrunr.scheduling.BackgroundJobRequest;

import static org.jobrunr.jobs.states.StateName.FAILED_STATES;

public class TestEnqueueNewWorkWithoutAnnotationJobRequest implements JobRequest {

    private final int amount;
    private int exceptionOnNbr;
    private int succeedOnRetryNbr;

    protected TestEnqueueNewWorkWithoutAnnotationJobRequest() {
        this(0);
    }

    public TestEnqueueNewWorkWithoutAnnotationJobRequest(int amount) {
        this.amount = amount;
        this.exceptionOnNbr = -1;
        this.succeedOnRetryNbr = -1;
    }

    public TestEnqueueNewWorkWithoutAnnotationJobRequest(int amount, int exceptionOnNbr, int succeedOnRetryNbr) {
        this.amount = amount;
        this.exceptionOnNbr = exceptionOnNbr;
        this.succeedOnRetryNbr = succeedOnRetryNbr;
    }

    @Override
    public Class<TestEnqueueNewWorkWithoutAnnotationJobRequestHandler> getJobRequestHandler() {
        return TestEnqueueNewWorkWithoutAnnotationJobRequestHandler.class;
    }

    public Integer getAmount() {
        return amount;
    }

    public static class TestEnqueueNewWorkWithoutAnnotationJobRequestHandler implements JobRequestHandler<TestEnqueueNewWorkWithoutAnnotationJobRequest> {

        @Override
        public void run(TestEnqueueNewWorkWithoutAnnotationJobRequest jobRequest) {
            for (int i = 0; i < jobRequest.amount; i++) {
                if (i == jobRequest.exceptionOnNbr && jobContext().getJobStates().stream().filter(FAILED_STATES).count() < (jobRequest.succeedOnRetryNbr - 1)) {
                    throw new IllegalStateException("An error has occurred processing item " + i);
                } else {
                    BackgroundJobRequest.enqueue(new TestJobRequest("Running child job " + i));
                }
            }
        }
    }
}
