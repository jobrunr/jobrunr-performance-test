package org.jobrunr.stubs;

import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.context.JobDashboardProgressBar;
import org.jobrunr.jobs.context.JobRunrDashboardLogger;
import org.jobrunr.jobs.filters.ApplyStateFilter;
import org.jobrunr.jobs.filters.ElectStateFilter;
import org.jobrunr.jobs.filters.JobServerFilter;
import org.jobrunr.jobs.filters.RetryFilter;
import org.jobrunr.jobs.states.JobState;
import org.jobrunr.scheduling.BackgroundJob;
import org.jobrunr.scheduling.JobProId;
import org.jobrunr.utils.SleepUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.io.File;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThat;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.FAILED_STATES;
import static org.jobrunr.jobs.states.StateName.PROCESSING;

public class TestService implements TestServiceInterface {

    private static final Logger LOGGER = new JobRunrDashboardLogger(LoggerFactory.getLogger(TestService.class));

    public static final String DEFAULT_MUTEX = "some-resource";
    public static final String CONCURRENT_JOB_RATE_LIMITER = "my-concurrent-rate-limiter";
    private static final int CONCURRENT_JOB_RATE_LIMITER_AMOUNT = 4;


    public static final String HighPrioQueue = "high-prio";
    public static final String DefaultQueue = "default";
    public static final String LowPrioQueue = "low-prio";

    public static final String WINDOWS = "WINDOWS";
    public static final String LINUX = "LINUX";
    public static final String CURRENT_SERVER = "%CURRENT_SERVER";

    private static int processedJobs = 0;

    private static final AtomicInteger atomicIntegerConcurrentJobLimiter = new AtomicInteger(0);

    public int getProcessedJobs() {
        return processedJobs;
    }

    public static void doStaticWork() {
        LOGGER.debug("Doing some work from a static method... ");
    }

    public void doWork(Runnable runnable) throws Exception {
        runnable.run();
    }

    public void doWorkWithCommand(Command command) throws Exception {
        LOGGER.debug("Doing some work... ");
        command.doWork();
    }

    public void doWorkWithFile(File file) throws Exception {
        LOGGER.debug("Doing some work... " + file.getAbsolutePath());
    }

    public void doWorkWithPath(Path path) throws Exception {
        LOGGER.debug("Doing some work... " + path.toFile().getAbsolutePath());
    }

    public void doWork(Work work) throws Exception {
        processedJobs += work.workCount;
        LOGGER.debug("Doing some work... " + work.workCount + "; " + work.someString);
    }

    public void doWork(Double count) {
        LOGGER.debug("Doing some work... " + processedJobs + count);
    }

    public void doWork(double[] xValues, double[] yValues) {
        LOGGER.debug("Doing some work with coordinates... ");
    }

    public void doWork(Integer count) {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs + "; " + now());
    }

    public void doWork(Long count) {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    public void doWork(Integer count, JobContext jobContext) throws InterruptedException {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs + "; jobId: " + jobContext.getJobId());
        jobContext.saveMetadata("test", "test");
        Thread.sleep(600L);
    }

    public void doWork(int countA, int countB) {
        processedJobs += (countA + countB);
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    @Job(name = "Doing some hard work for user %1 (customerId: %X{customer.id})", mutex = DEFAULT_MUTEX + ":%0")
    public void doWorkWithAnnotation(Integer userId, String userName) {
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    @Job(name = "Doing some hard work for user %1 with id %0")
    public void doWorkWithAnnotationAndJobContext(Integer userId, String userName, JobContext jobContext) {
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    public void doWork(int count, String aString, Instant instant) {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs + " " + aString + " " + instant);
    }

    public void doWork(UUID uuid) {
        LOGGER.debug("Doing some work... " + uuid);
    }

    public String doWorkWithUUID(UUID uuid) {
        LOGGER.debug("Doing some work... " + uuid);
        return "The result " + uuid;
    }

    public void doWorkWithLong(Long value) {
        LOGGER.debug("Doing some work... " + value);
    }

    public void doWork(UUID uuid, int count, Instant instant) {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs + " " + uuid + " " + instant);
    }

    public void doWork(String aString, int count, Instant instant) {
        processedJobs += count;
        LOGGER.debug("Doing some work... " + processedJobs + " " + aString + " " + instant);
    }

    public void doWork(LocalDateTime localDateTime) {
        LOGGER.debug("Doing some work... " + processedJobs + " " + localDateTime.toString());
    }

    public void doWork(boolean bool, int i, long l, float f, double d) {
        LOGGER.debug("Doing some work... " + bool + "; " + i + "; " + l + "; " + f + "; " + d);
    }

    public void doWork(byte b, short s, char c) {
        LOGGER.debug("Doing some work... " + b + "; " + s + "; " + c);
    }

    public void doWorkWithEnum(Task task) {
        LOGGER.debug("Doing some work: " + task.executeTask());
    }

    @Job(name = "Doing some work")
    public void doWork() {
        processedJobs++;
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    @Job(name = "Doing some work with input")
    public void doWork(String input) {
        LOGGER.debug("Doing some work with input " + input);
    }

    @Job(labels = "label-%0 - %1")
    public void doWorkWithJobAnnotationAndLabels(int i, String s) {
        processedJobs++;
        LOGGER.debug("Doing some work... " + processedJobs);
    }

    @Job(jobFilters = {TheSunIsAlwaysShiningElectStateFilter.class, TestFilter.class})
    public void doWorkWithCustomJobFilters() {
        LOGGER.debug("I will always succeed thanks to my SunIsAlwaysShiningElectStateFilter... ");
    }

    @Job(jobFilters = {JobFilterWithNoDefaultConstructor.class})
    public void doWorkWithCustomJobFilterThatNeedsDependencyInjection() {
        LOGGER.debug("I will never succeed... ");
    }

    public String doWorkAndReturnResult(String someString) {
        return "Hello to you to " + someString;
    }

    public void doWorkThatFails() {
        processedJobs++;
        LOGGER.debug("Whoopsie, an error will occur " + processedJobs);
        throw new RuntimeException("Whoopsie, an error occurred");
    }

    @Job(name = "Doing some work", retries = 1, labels = {"Just a label", "Another label"})
    public void doWorkThatFailsWithAnnotation() {
        processedJobs++;
        LOGGER.debug("Whoopsie, an error will occur " + processedJobs);
        throw new RuntimeException("Whoopsie, an error occurred");
    }

    @Job(name = "Doing some work", retries = 1)
    public void doWorkThatFailsAndThenSucceeds(int succeedOnRetryNbr, JobContext jobContext) {
        if (jobContext.getJobStates().stream().filter(FAILED_STATES).count() < (succeedOnRetryNbr - 1)) {
            processedJobs++;
            LOGGER.debug("Whoopsie, an error will occur " + processedJobs);
            throw new RuntimeException("Whoopsie, an error occurred");
        } else {
            LOGGER.debug("I will succeed now");
        }
    }

    public void doWorkThatTakesLong(JobContext jobContext) throws InterruptedException {
        final JobDashboardProgressBar progressBar = jobContext.progressBar(9);
        for (int i = 0; i < 10; i++) {
            jobContext.logger().info("This is an info message test " + i);
            Thread.sleep(100);
            jobContext.logger().warn("This is an warning message test " + i);
            Thread.sleep(100);
            jobContext.logger().error("This is an error message test " + i);
            Thread.sleep(100);
            jobContext.logger().info("This is an info message again " + i);
            Thread.sleep(100);
            doWorkThatTakesLong(5 + ThreadLocalRandom.current().nextInt(0, 5));
            progressBar.setValue(i);
        }
    }

    public void doWorkThatTakesLong(int seconds) throws InterruptedException {
        doWorkThatTakesLongUsingMillis(seconds * 1000L);
    }

    public void doWorkThatTakesLongUsingMillis(Long millis) throws InterruptedException {
        try {
            //LOGGER.info("Starting work");
            TimeUnit.MILLISECONDS.sleep(millis / 2);
            //LOGGER.info("Halfway there");
            TimeUnit.MILLISECONDS.sleep(millis / 2);
            //LOGGER.info("WORK IS DONE!!!!!!!!");
            //LOGGER.debug();("WORK IS DONE!!!!!!!!");
        } catch (InterruptedException e) {
            LOGGER.debug("Thread has been interrupted");
            throw e;
        }
    }

    public void doWorkThatTakesLongInterruptThread(int seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
            LOGGER.debug("WORK IS DONE!!!!!!!!");
        } catch (InterruptedException e) {
            LOGGER.debug("Thread has been interrupted");
            Thread.currentThread().interrupt();
        }
    }

    public void doWorkThatTakesLongCatchInterruptException(int seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
            LOGGER.debug("WORK IS DONE!!!!!!!!");
        } catch (InterruptedException e) {
            LOGGER.debug("Thread has been interrupted - not rethrowing nor interrupting again");
        }
    }

    public void doWorkThatCanBeInterrupted(int seconds) throws InterruptedException {
        final Instant start = now();
        long initialNbr = 0;
        while (start.plusSeconds(seconds).isAfter(now())) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
            if (Duration.between(start, now()).getSeconds() > initialNbr) {
                LOGGER.debug("WORK IS BEING DONE: " + Duration.between(start, now()).getSeconds());
                initialNbr = Duration.between(start, now()).getSeconds();
            }
        }
    }

    public void doWorkThatTakesLong(long seconds) throws InterruptedException {
        doWorkThatTakesLong((int) seconds);
    }

    @Job(labels = "my-batch-label")
    public void enqueueNewBatchWork(int amount) {
        for (int i = 0; i < amount; i++) {
            int finalI = i;
            BackgroundJob.enqueue(() -> doWorkWithJobAnnotationAndLabels(finalI, "an argument"));
        }
        LOGGER.debug("Created " + amount + " child jobs.");
    }

    @Job(labels = "my-batch-label", runOnServerWithTag = TestService.LINUX)
    public void enqueueNewBatchWorkWithServerTag(int amount) {
        for (int i = 0; i < amount; i++) {
            int finalI = i;
            BackgroundJob.enqueue(() -> doWorkWithJobAnnotationAndLabels(finalI, "an argument"));
            SleepUtils.sleep(50);
        }
    }

    public void enqueueNewBatchWork(int amount, int exceptionOnNbr, int succeedOnRetryNbr, JobContext jobContext) {
        for (int i = 0; i < amount; i++) {
            if (i == exceptionOnNbr && jobContext.getJobStates().stream().filter(FAILED_STATES).count() < (succeedOnRetryNbr - 1)) {
                throw new IllegalStateException("An error has occurred processing item " + i);
            } else {
                int finalI = i;
                BackgroundJob.enqueue(() -> doWork(finalI));
            }
        }
    }

    public void enqueueNewWorkWithChildJobThatFails(int amount, int exceptionOnNbr, JobContext jobContext) {
        LOGGER.debug("Enqueueing child job for " + jobContext.getJobId());
        for (int i = 0; i < amount; i++) {
            int finalI = i;
            if (i == exceptionOnNbr) {
                JobProId id = BackgroundJob.enqueue(() -> doWorkThatFailsAndThenSucceeds(3, JobContext.Null));
                LOGGER.debug("Enqueued child job " + id + " for batch job " + jobContext.getJobId());
            } else {
                JobProId id = BackgroundJob.enqueue(() -> doWork(finalI));
                LOGGER.debug("Enqueued child job " + id + " for batch job " + jobContext.getJobId());
            }
        }
    }

    @Job(labels = "my-batch-label")
    public void enqueueNewRateLimitedBatchWork(int amount) {
        for (int i = 0; i < amount; i++) {
            BackgroundJob.enqueue(() -> doWorkWithRateLimiter());
        }
    }

    @Job(labels = "my-batch-label")
    public void enqueueNewBatchWorkWithChainingWithinBatchJob() {
        BackgroundJob.enqueue(() -> scheduleNewWorkNothingToDo(JobContext.Null))
                .continueWith(() -> doWorkThatTakesLong(2))
                .continueWith(() -> doWorkThatTakesLong(2));
    }

    public void scheduleNewWorkThatTakesLong(int amount) {
        scheduleNewWorkThatTakesLong(amount, -1);
    }

    public void scheduleNewWorkThatTakesLong(int amount, int exceptionOnNbr) {
        for (int i = 0; i < amount; i++) {
            if (i == exceptionOnNbr) {
                throw new IllegalStateException("An error has occurred processing item " + i);
            } else {
                int finalI = i;
                BackgroundJob.enqueue(() -> doWorkThatTakesLong(finalI));
            }
        }
    }

    public void scheduleNewWorkNothingToDo(JobContext jobContext) {
        LOGGER.debug("Nothing to do.");
        jobContext.logger().info("Nothing to do.");
    }

    public void scheduleNewWorkSlowly(int amount) throws InterruptedException {
        for (int i = 0; i < amount; i++) {
            int finalI = i;
            BackgroundJob.enqueue(() -> doWork(finalI));
            Thread.sleep(1400);
        }
        System.out.println("scheduleNewWorkSlowly is done");
    }

    @Job(queue = HighPrioQueue)
    public void startJobOnHighPrioQueue() throws InterruptedException {
        Thread.sleep(5000);
        LOGGER.debug("Finished job on high prio queue");
    }

    @Job(queue = HighPrioQueue, runOnServerWithTag = "WINDOWS")
    public void startJobOnHighPrioQueueWithWindowsTag() throws InterruptedException {
        Thread.sleep(5000);
        LOGGER.debug("Finished job on high prio queue");
    }

    @Job(queue = DefaultQueue)
    public void startJobOnDefaultQueue() throws InterruptedException {
        Thread.sleep(1500);
        LOGGER.debug("Finished job on default queue");
    }

    @Job(queue = LowPrioQueue)
    public void startJobOnLowPrioQueue() throws InterruptedException {
        Thread.sleep(1500);
        LOGGER.debug("Finished job on low prio queue");
    }

    @Job(queue = "UnkownQueue")
    public void startJobOnUnknownQueue() throws InterruptedException {
        throw new IllegalStateException("Should not arrive here as the queue is unknown and that should thrown an exception");
    }

    @Job(jobFilters = {SkipProcessingElectStateFilter.class})
    public void tryToDoWorkButDontBecauseOfSomeBusinessRuleDefinedInTheOnStateElectionFilter() {
        LOGGER.debug("This should not be executed");
    }

    public void doIllegalWork(IllegalWork illegalWork) {
        LOGGER.debug("Doing some illegal work:" + illegalWork);
    }

    public void doWorkWithoutParameters() {
        doWork(); // why: for kotlin method resolution
    }

    @Job(runOnServerWithTag = WINDOWS)
    public void doWorkOnServerThatDoesNotMatch() {
        LOGGER.debug("This will not run as server tags does not match");
    }

    @Job(runOnServerWithTag = LINUX)
    public void doWorkOnServerThatMatches() {
        LOGGER.debug("This will run as server tags matches");
    }

    @Job(runOnServerWithTag = CURRENT_SERVER)
    public void doWorkOnCurrentServerThatMatches() {
        LOGGER.debug("This will run as server tags matches");
    }

    @Job(mutex = DEFAULT_MUTEX)
    public void doWork1WithMutexToPreventConcurrency() throws InterruptedException {
        LOGGER.debug("This will block other jobs with the same mutex.");
        Thread.sleep(3000);
    }

    @Job(mutex = DEFAULT_MUTEX)
    public void doWork2WithMutexToPreventConcurrency() throws InterruptedException {
        LOGGER.debug("This will block other jobs with the same mutex.");
        Thread.sleep(2000);
    }

    @Job(rateLimiter = CONCURRENT_JOB_RATE_LIMITER)
    public void doWorkWithRateLimiter() throws InterruptedException {
        try {
            int i = atomicIntegerConcurrentJobLimiter.incrementAndGet();
            if (i > CONCURRENT_JOB_RATE_LIMITER_AMOUNT) {
                LOGGER.error("=============================================================");
                LOGGER.error("Concurrent job rate limit was passed: {}", i);
                LOGGER.error("=============================================================");
                throw new IllegalStateException("Concurrent job rate limiter exception");
            }
            Thread.sleep(230);
        } finally {
            atomicIntegerConcurrentJobLimiter.decrementAndGet();
        }
    }

    @Job(rateLimiter = "my-concurrent-rate-limiter-%0")
    public void doWorkWithRateLimiterAndParamSubstitution(int customerId) {
        LOGGER.debug("Doing work with rate-limiter for customer id " + customerId);
    }

    @Job(deleteOnSuccess = "PT0S!PT1S")
    public void doWorkAndDeleteJobImmediately() throws InterruptedException {
        LOGGER.debug("This job will be deleted immediately");
        Thread.sleep(200);
    }

    @Job(retries = 0, deleteOnFailure = "PT1S!PT1S")
    public void doWorkThatFailsAndDeleteJob() throws InterruptedException {
        LOGGER.debug("This failing job will be deleted immediately");
        throw new RuntimeException("The job failed but must be deleted");
    }

    @Job(processTimeOut = "PT2S", retries = 0)
    public void doWorkThatTakesLongButTimesOut() throws InterruptedException {
        LOGGER.debug("This job will timeout after 4 seconds");
        TimeUnit.SECONDS.sleep(10);
    }

    public void reset() {
        processedJobs = 0;
    }

    public UUID getAnUUID() {
        return UUID.randomUUID();
    }

    void aPackagePrivateMethod() {
        LOGGER.debug("This method will be executed");
    }

    private void aPrivateMethod(String string, int someNumber) {
        LOGGER.debug("Nothing to do");
    }

    public void jobRunBatchWrappers(Long id, Long env, String param, String currentLogin) {
        LOGGER.debug("Do work:" + id + "; " + env + "; " + param + "; " + currentLogin);
    }

    public void jobRunBatchPrimitives(long id, long env, String param, String currentLogin) {
        LOGGER.debug("Do work:" + id + "; " + env + "; " + param + "; " + currentLogin);
    }

    public static void doWorkInStaticMethod(UUID id) {
        LOGGER.debug("Doing work in static method:" + id);
    }

    public void doWorkWithCollection(Set<Long> singleton) {
        LOGGER.debug("Doing work with collections: " + singleton.size());
    }

    public void doWorkWithMDC(String key) {
        assertThat(MDC.get(key)).isNotNull();
        String result = key + ": " + MDC.get(key) + "; ";
        LOGGER.debug("Found following MDC keys: " + result);
    }

    public void doWorkWithPrimitiveInt(int intValue) {
        LOGGER.debug("Doing some work with a primitive int: " + intValue);
    }

    public void doWorkForIssue645(Long id, GithubIssue645 someObject) {
        LOGGER.debug("Doing work for github issue 645 " + id.toString() + "; " + someObject);
    }

    public CustomObjectThatIsSerializable doWorkWithSerializableCustomObjectResult() {
        LOGGER.debug("doWorkWithSerializableCustomObjectResult");
        return new CustomObjectThatIsSerializable(UUID.fromString("a3bda47a-9787-4068-adec-12d4e4b82577"));
    }

    public CustomObjectThatIsNotSerializable doWorkWithUnSerializableCustomObjectResult() {
        LOGGER.debug("doWorkWithUnSerializableCustomObjectResult");
        return new CustomObjectThatIsNotSerializable(UUID.fromString("a3bda47a-9787-4068-adec-12d4e4b82577"));
    }

    public static class Work {

        private int workCount;
        private String someString;
        private UUID uuid;

        protected Work() {

        }

        public Work(int workCount, String someString, UUID uuid) {
            this.workCount = workCount;
            this.someString = someString;
            this.uuid = uuid;
        }

        public int getWorkCount() {
            return workCount;
        }

        public String getSomeString() {
            return someString;
        }

        public UUID getUuid() {
            return uuid;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Work work = (Work) o;

            if (workCount != work.workCount) return false;
            if (!Objects.equals(someString, work.someString)) return false;
            return Objects.equals(uuid, work.uuid);
        }

        @Override
        public int hashCode() {
            int result = workCount;
            result = 31 * result + (someString != null ? someString.hashCode() : 0);
            result = 31 * result + (uuid != null ? uuid.hashCode() : 0);
            return result;
        }

        public static Work from(int workCount, String someString, UUID uuid) {
            return new Work(workCount, someString, uuid);
        }
    }

    public static class IllegalWork {
        private long number;
        private IllegalWork illegalWork;

        public IllegalWork(long number) {
            this.number = number;
            this.illegalWork = this;
        }

        public IllegalWork getIllegalWork() {
            return illegalWork;
        }

        public long getNumber() {
            return number;
        }
    }

    public static class TheSunIsAlwaysShiningElectStateFilter implements RetryFilter {

        @Override
        public void onStateElection(org.jobrunr.jobs.Job job, JobState newState) {
            if (ENQUEUED.equals(newState.getName())) {
                job.succeeded();
            }
        }
    }

    public static class JobFilterWithNoDefaultConstructor implements JobServerFilter {

        public JobFilterWithNoDefaultConstructor(String justAnArgumentSoAnExceptionIsThrown) {
            // filters in the free version need a no-arg constructor
        }
    }

    public static class FailedToDeleteRetryFilter implements RetryFilter {

        @Override
        public void onStateElection(org.jobrunr.jobs.Job job, JobState newState) {
            if (FAILED.equals(newState.getName())) {
                job.delete("Because it failed");
            }
        }
    }

    public static class SkipProcessingElectStateFilter implements ElectStateFilter {

        @Override
        public void onStateElection(org.jobrunr.jobs.Job job, JobState newState) {
            if (PROCESSING.equals(newState.getName())) {
                job.delete("Should not run due to business rule.");
                job.scheduleAt(Instant.now().plus(5, ChronoUnit.MINUTES), "Rescheduled by business rule.");
            }
        }
    }

    public static class TestFilter implements JobServerFilter, ApplyStateFilter {

        @Override
        public void onStateApplied(org.jobrunr.jobs.Job job, JobState oldState, JobState newState) {
            job.getMetadata().put("onStateApplied", "");
        }

        @Override
        public void onProcessing(org.jobrunr.jobs.Job job) {
            job.getMetadata().put("onProcessing", "");
        }

    }

    public interface Command<T> {
        T doWork();
    }

    public static class SimpleCommand implements Command<Void> {

        private String string;
        private int integer;

        protected SimpleCommand() {

        }

        public SimpleCommand(String string, int integer) {
            this.string = string;
            this.integer = integer;
        }

        @Override
        public Void doWork() {
            LOGGER.debug("Simple Command " + string + " " + integer);
            return null;
        }
    }

    public static class GithubIssue335 {

        public void run(UUID id) {
            LOGGER.debug("Running job for issue 335 " + id);
        }

    }

    public static class GithubIssue645 {
        private Long id;

        public GithubIssue645() {
            this.id = 2L;
        }

        public Long getId() {
            return id;
        }
    }

    public static class CustomObjectThatIsSerializable {

        private final UUID uuid;

        protected CustomObjectThatIsSerializable() {
            this(null);
        }

        public CustomObjectThatIsSerializable(UUID uuid) {
            this.uuid = uuid;
        }
    }

    public static class CustomObjectThatIsNotSerializable {

        private final UUID uuid;

        public CustomObjectThatIsNotSerializable(UUID uuid) {
            this.uuid = uuid;
        }
    }

    public enum Task {

        PROGRAMMING {
            @Override
            public String executeTask() {
                return "In the zone";
            }
        },
        CLEANING {
            @Override
            public String executeTask() {
                return "Cleaning the house - wishing I were in zone";
            }
        };

        public abstract String executeTask();
    }
}
