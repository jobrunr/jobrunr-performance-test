package org.jobrunr.stubs;

import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.lambdas.JobResultRequestHandler;

public class TestJobWithResultRequest implements JobRequest {

    private final String input;

    protected TestJobWithResultRequest() {
        this(null);
    }

    public TestJobWithResultRequest(String input) {
        this.input = input;
    }

    @Override
    public Class<TestJobWithResultRequestHandler> getJobRequestHandler() {
        return TestJobWithResultRequestHandler.class;
    }

    public String getInput() {
        return input;
    }

    public static class TestJobWithResultRequestHandler implements JobResultRequestHandler<TestJobWithResultRequest> {

        @Override
        public Object runAndReturn(TestJobWithResultRequest jobRequest) throws Exception {
            return "The result " + jobRequest.getInput();
        }
    }
}
