package org.jobrunr.stubs;

import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.jobs.lambdas.JobRequest;
import org.jobrunr.jobs.lambdas.JobRequestHandler;
import org.jobrunr.scheduling.BackgroundJobRequest;

import static org.jobrunr.jobs.states.StateName.FAILED_STATES;

public class TestEnqueueNewWorkJobRequest implements JobRequest {

    private final int amount;
    private int exceptionOnNbr;
    private int succeedOnRetryNbr;

    protected TestEnqueueNewWorkJobRequest() {
        this(0);
    }

    public TestEnqueueNewWorkJobRequest(int amount) {
        this.amount = amount;
        this.exceptionOnNbr = -1;
        this.succeedOnRetryNbr = -1;
    }

    public TestEnqueueNewWorkJobRequest(int amount, int exceptionOnNbr, int succeedOnRetryNbr) {
        this.amount = amount;
        this.exceptionOnNbr = exceptionOnNbr;
        this.succeedOnRetryNbr = succeedOnRetryNbr;
    }

    @Override
    public Class<TestEnqueueNewWorkJobRequestHandler> getJobRequestHandler() {
        return TestEnqueueNewWorkJobRequestHandler.class;
    }

    public Integer getAmount() {
        return amount;
    }

    public static class TestEnqueueNewWorkJobRequestHandler implements JobRequestHandler<TestEnqueueNewWorkJobRequest> {

        @Override
        @Job(name = "Some neat Job Display Name")
        public void run(TestEnqueueNewWorkJobRequest jobRequest) {
            for (int i = 0; i < jobRequest.amount; i++) {
                if (i == jobRequest.exceptionOnNbr && jobContext().getJobStates().stream().filter(FAILED_STATES).count() < (jobRequest.succeedOnRetryNbr - 1)) {
                    throw new IllegalStateException("An error has occurred processing item " + i);
                } else {
                    BackgroundJobRequest.enqueue(new TestJobRequest("Running child job " + i));
                }
            }
        }
    }
}
