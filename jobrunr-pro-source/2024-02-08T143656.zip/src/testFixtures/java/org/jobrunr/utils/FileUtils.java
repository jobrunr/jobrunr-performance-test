package org.jobrunr.utils;

import java.io.File;

public class FileUtils {

    public static void deleteAllFiles(String directory) {
        deleteAllFiles(new File(directory));
    }

    public static void deleteAllFiles(File directory) {
        if (directory.exists()) {
            for (File file : directory.listFiles()) {
                if (!file.isDirectory()) {
                    file.delete();
                }
            }
        }
    }
}
