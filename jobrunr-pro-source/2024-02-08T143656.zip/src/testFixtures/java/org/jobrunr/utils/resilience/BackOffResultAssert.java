package org.jobrunr.utils.resilience;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

public class BackOffResultAssert extends AbstractAssert<BackOffResultAssert, BackOffResult> {

    protected BackOffResultAssert(BackOffResult backOffResult) {
        super(backOffResult, BackOffResultAssert.class);
    }

    public static BackOffResultAssert assertThat(BackOffResult backOffResult) {
        return new BackOffResultAssert(backOffResult);
    }

    public BackOffResultAssert isUnavailable() {
        Assertions.assertThat(actual.isAvailable()).isFalse();
        return this;
    }

    public BackOffResultAssert isAvailable() {
        Assertions.assertThat(actual.isAvailable()).isTrue();
        return this;
    }

    public BackOffResultAssert hasBackOffPeriod(Duration duration) {
        Assertions.assertThat(actual.backOffPeriod()).isCloseTo(duration, Duration.of(400, ChronoUnit.MILLIS));
        return this;
    }

    public BackOffResultAssert hasBackOffPeriodGreaterThan(Duration duration) {
        Assertions.assertThat(actual.backOffPeriod()).isGreaterThan(duration);
        return this;
    }

    public BackOffResultAssert hasBackOffPeriodBetween(Duration duration1, Duration duration2) {
        Assertions.assertThat(actual.backOffPeriod()).isBetween(duration1, duration2);
        return this;
    }

    public BackOffResultAssert hasCheckAgainAfterBetween(Instant instant1, Instant instant2) {
        Assertions.assertThat(actual.checkAgainAfter()).isBetween(instant1, instant2);
        return this;
    }

    public BackOffResultAssert hasCheckAgainAfterBefore(Instant instant) {
        Assertions.assertThat(actual.checkAgainAfter()).isBefore(instant);
        return this;
    }

    public BackOffResultAssert hasResult(Object o) {
        Assertions.assertThat((Object) actual.getResult()).isEqualTo(o);
        return this;
    }


}
