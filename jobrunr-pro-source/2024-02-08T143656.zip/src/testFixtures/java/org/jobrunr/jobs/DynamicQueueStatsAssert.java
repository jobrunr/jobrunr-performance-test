package org.jobrunr.jobs;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.InstanceOfAssertFactories;
import org.jobrunr.jobs.states.StateName;

import java.util.Set;
import java.util.function.Consumer;

import static org.mockito.internal.util.reflection.Whitebox.getInternalState;

public class DynamicQueueStatsAssert extends AbstractAssert<DynamicQueueStatsAssert, DynamicQueueStats> {

    protected DynamicQueueStatsAssert(DynamicQueueStats dynamicQueueStats) {
        super(dynamicQueueStats, DynamicQueueStatsAssert.class);
    }

    public static DynamicQueueStatsAssert assertThat(DynamicQueueStats dynamicQueueStats) {
        return new DynamicQueueStatsAssert(dynamicQueueStats);
    }

    public DynamicQueueStatsAssert hasDefaultQueueStats(Consumer<DynamicQueueStatsDetailsAssert> defaultQueueStatsAssert) {
        defaultQueueStatsAssert.accept(new DynamicQueueStatsDetailsAssert(getInternalState(actual, "defaultQueue")));
        return this;
    }

    public DynamicQueueStatsAssert hasQueueStats(String name, Consumer<DynamicQueueStatsDetailsAssert> queueStatsAssert) {
        DynamicQueueStats.DynamicQueueDetails defaultQueue = ((Set<DynamicQueueStats.DynamicQueueDetails>) getInternalState(actual, "allQueues"))
                .stream()
                .filter(i -> name.equals(i.getName()))
                .findFirst()
                .orElseThrow();
        queueStatsAssert.accept(new DynamicQueueStatsDetailsAssert(defaultQueue));
        return this;
    }

    public static class DynamicQueueStatsDetailsAssert extends AbstractAssert<DynamicQueueStatsDetailsAssert, DynamicQueueStats.DynamicQueueDetails> {

        protected DynamicQueueStatsDetailsAssert(DynamicQueueStats.DynamicQueueDetails dynamicQueueDetails) {
            super(dynamicQueueDetails, DynamicQueueStatsDetailsAssert.class);
        }

        public DynamicQueueStatsDetailsAssert hasStats(StateName stateName, long amount) {
            Assertions.assertThat(actual)
                    .extracting("jobStats")
                    .asInstanceOf(InstanceOfAssertFactories.MAP)
                    .containsEntry(stateName, amount);
            return this;
        }
    }
}