package org.jobrunr.jobs;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Condition;
import org.assertj.core.data.TemporalOffset;
import org.jobrunr.JobRunrAssertions;
import org.jobrunr.jobs.context.JobDashboardLogger;
import org.jobrunr.jobs.context.JobDashboardProgressBar;
import org.jobrunr.jobs.states.*;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.within;
import static org.assertj.core.condition.AnyOf.anyOf;
import static org.jobrunr.utils.StringUtils.isNotNullOrEmpty;

public class JobAssert extends AbstractAssert<JobAssert, Job> {

    public static Condition<Job> scheduledAt(Instant instant) {
        return new Condition<>(job ->
                job.hasState(StateName.SCHEDULED) && ((ScheduledState) job.getJobState()).getScheduledAt().equals(instant),
                "Expected Job to have SCHEDULED state at " + instant.toString());
    }

    public static Condition<Job> scheduledNear(Instant instant) {
        return new Condition<>(job ->
                job.hasState(StateName.SCHEDULED) && Duration.between(((ScheduledState) job.getJobState()).getScheduledAt(), instant).abs().toMillis() < 5500,
                "Expected Job to have SCHEDULED state at " + instant.toString());
    }

    private JobAssert(Job job) {
        super(job, JobAssert.class);
    }

    public static JobAssert assertThat(Job job) {
        return new JobAssert(job);
    }

    public JobAssert hasId() {
        Assertions.assertThat(actual.getId()).isNotNull();
        return this;
    }


    public JobAssert hasId(UUID id) {
        Assertions.assertThat(actual.getId())
                .isNotNull()
                .isEqualTo(id);
        return this;
    }

    public JobAssert hasJobName(String name) {
        Assertions.assertThat(actual.getJobName()).isEqualTo(name);
        return this;
    }

    public JobAssert hasJobDetails(Class<?> clazz, String methodName, Object... args) {
        JobRunrAssertions.assertThat(actual.getJobDetails())
                .hasClass(clazz)
                .hasMethodName(methodName)
                .hasArgs(args);
        return this;
    }

    public JobAssert hasUpdatedAtCloseTo(Instant instant, TemporalOffset<Temporal> temporalOffset) {
        Assertions.assertThat(actual.getUpdatedAt()).isCloseTo(instant, temporalOffset);
        return this;
    }

    public JobAssert hasState(StateName state) {
        Assertions.assertThat(actual.getState()).isEqualTo(state);
        return this;
    }

    public JobAssert hasOneOfTheFollowingStates(StateName... states) {
        Assertions.assertThat(actual).has(anyOf(Arrays.stream(states).map(JobStateCondition::new).collect(Collectors.toList())));
        return this;
    }

    public <X extends JobState> JobAssert hasState(StateName state, Predicate<X> matcher) {
        Assertions.assertThat(actual.getState()).isEqualTo(state);
        Assertions.assertThat(matcher.test(actual.getJobState())).isTrue();
        return this;
    }

    public JobAssert doesNotHaveState(StateName stateName) {
        Assertions.assertThat(actual.getState()).isNotEqualTo(stateName);
        return this;
    }

    public JobAssert hasStates(StateName... state) {
        List<StateName> jobStates = actual.getJobStates().stream().map(JobState::getName).collect(Collectors.toList());
        Assertions.assertThat(jobStates).containsExactly(state);
        return this;
    }

    public JobAssert isReplacingExistingJob() {
        Assertions.assertThat(((InitialState) actual.getJobState()).isReplacingExistingJob()).isTrue();
        return this;
    }

    public JobAssert hasServerTag(String serverTag) {
        Assertions.assertThat(actual.getServerTag()).isEqualTo(serverTag);
        return this;
    }

    public JobAssert hasMutex(String mutex) {
        Assertions.assertThat(actual.getMutex().orElseThrow()).isEqualTo(mutex);
        return this;
    }

    public JobAssert hasRateLimiter(String rateLimiterName) {
        Assertions.assertThat(actual.getRateLimiter()).isEqualTo(rateLimiterName);
        return this;
    }

    public JobAssert hasPriority(int priority) {
        Assertions.assertThat(actual.getPriority()).isEqualTo(priority);
        return this;
    }

    public JobAssert hasMetadata(String key) {
        Assertions.assertThat(actual.getMetadata()).containsKey(key);
        return this;
    }

    public JobAssert hasMetadata(String key, String value) {
        Assertions.assertThat(actual.getMetadata()).containsEntry(key, value);
        return this;
    }

    public JobAssert hasMetadata(Condition condition) {
        Assertions.assertThat(actual.getMetadata()).has(condition);
        return this;
    }

    public JobAssert hasMetadataOnlyContainingObservabilityInfoJobProgressAndLogging() {
        for (String key : actual.getMetadata().keySet()) {
            if (!(key.startsWith(JobDashboardLogger.JOBRUNR_LOG_KEY)
                    || key.startsWith(JobDashboardProgressBar.JOBRUNR_PROGRESSBAR_KEY)
                    || "constructing.traceId".equals(key)
                    || "constructing.spanId".equals(key)
                    || "traceId".equals(key)
                    || "spanId".equals(key))) {
                throw new AssertionError("Job has metadata key '" + key + "' which is not allowed");
            }
        }
        return this;
    }

    public JobAssert hasNoMetadata() {
        Assertions.assertThat(actual.getMetadata()).isEmpty();
        return this;
    }

    public JobAssert hasVersion(int version) {
        Assertions.assertThat(actual.getVersion()).isEqualTo(version);
        return this;
    }

    public JobAssert hasAmountOfRetries(Integer amountOfRetries) {
        Assertions.assertThat(actual.getAmountOfRetries()).isEqualTo(amountOfRetries);
        return this;
    }

    public JobAssert hasDeletedAt(Instant deleteAt) {
        if (deleteAt == null) {
            Assertions.assertThat(actual.getDeleteAt()).isNull();
        } else {
            Assertions.assertThat(actual.getDeleteAt()).isCloseTo(deleteAt, within(500, ChronoUnit.MILLIS));
        }
        return this;
    }

    public JobAssert hasDeletedAtNotNull() {
        Assertions.assertThat(actual.getDeleteAt()).isNotNull();
        return this;
    }

    public JobAssert hasDeleteOnSuccess(String deleteOnSuccess) {
        Assertions.assertThat(actual.getDeleteOnSuccess()).isEqualTo(deleteOnSuccess);
        return this;
    }

    public JobAssert hasDeleteOnFailure(String deleteOnFailure) {
        Assertions.assertThat(actual.getDeleteOnFailure()).isEqualTo(deleteOnFailure);
        return this;
    }

    public JobAssert hasProcessTimeOut(Duration processTimeOut) {
        Assertions.assertThat(actual.getProcessTimeOut()).isEqualTo(processTimeOut);
        return this;
    }

    public JobAssert hasLabels(String... labels) {
        return hasLabels(Set.of(labels));
    }

    public JobAssert hasLabels(Set<String> labels) {
        Assertions.assertThat(actual.getLabels()).isEqualTo(labels);
        return this;
    }

    public JobAssert hasDynamicQueue(String dynamicQueue) {
        Assertions.assertThat(actual.getDynamicQueue()).isEqualTo(dynamicQueue);
        return this;
    }

    public JobAssert hasNoDynamicQueue() {
        Assertions.assertThat(actual.getDynamicQueue()).isNull();
        return this;
    }

    public JobAssert hasRecurringJobId(String recurringJobId) {
        Assertions.assertThat(actual.getRecurringJobId())
                .isPresent()
                .contains(recurringJobId);
        return this;
    }

    public JobAssert isBatchJob(boolean isBatchJob) {
        Assertions.assertThat(actual.isBatchJob()).isEqualTo(isBatchJob);
        return this;
    }

    public JobAssert isEqualTo(Job otherJob) {
        return isEqualTo(otherJob, "locker", "newState", "jobHistory.exception", "stateIndexBeforeStateChange");
    }

    public JobAssert isEqualTo(Job otherJob, String... fieldNamesToIgnore) {
        Assertions.assertThat(actual)
                .usingRecursiveComparison()
                .usingOverriddenEquals()
                .ignoringFields(fieldNamesToIgnore)
                .isEqualTo(otherJob);
        return this;
    }

    public JobAssert isRedactedIfComparedToUnredactedJob(Job unredactedJob) {
        hasJobName(actual.getJobSignature());
        JobDetailsAssert.assertThat(actual.getJobDetails()).isRedacted();
        unredactedJob.getMetadata().keySet().forEach(
                (key) -> {
                    Assertions.assertThat(key).doesNotContain(JobDashboardLogger.JOBRUNR_LOG_KEY);
                    Assertions.assertThat(key).doesNotContain(JobDashboardProgressBar.JOBRUNR_PROGRESSBAR_KEY);
                }
        );
        for (int i = 0; i < unredactedJob.getJobStates().size(); i++) {
            JobState jobState = unredactedJob.getJobState(i);
            if (!(jobState instanceof FailedState)) continue;

            FailedState unredactedFailedState = (FailedState) jobState;
            FailedState redactedFailedState = actual.getJobState(i);

            Assertions.assertThat(redactedFailedState.getExceptionMessage()).isNull();
            Assertions.assertThat(redactedFailedState.getExceptionCauseMessage()).isNull();

            Throwable throwable = unredactedFailedState.getException();
            while (throwable != null) {
                String message = throwable.getMessage();
                if (isNotNullOrEmpty(message)) {
                    Assertions.assertThat(redactedFailedState.getStackTrace()).doesNotContain(message);
                }
                throwable = throwable.getCause();
            }
        }
        return this;
    }

    private static class JobStateCondition extends Condition<Job> {

        public JobStateCondition(StateName stateName) {
            super(job -> job.hasState(stateName), "Job should have state %s", stateName);
        }
    }

}
