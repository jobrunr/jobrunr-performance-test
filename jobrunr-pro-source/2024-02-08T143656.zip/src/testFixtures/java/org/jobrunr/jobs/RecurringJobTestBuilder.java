package org.jobrunr.jobs;

import org.jobrunr.jobs.details.JobDetailsAsmGenerator;
import org.jobrunr.jobs.lambdas.IocJobLambda;
import org.jobrunr.jobs.lambdas.JobLambda;
import org.jobrunr.scheduling.Schedule;
import org.jobrunr.scheduling.ScheduleExpressionType;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.scheduling.cron.CronExpression;
import org.jobrunr.scheduling.interval.Interval;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Set;

import static java.util.Optional.ofNullable;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.scheduling.ScheduleExpressionType.getSchedule;
import static org.jobrunr.utils.CollectionUtils.asSet;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

public class RecurringJobTestBuilder {

    private String id;
    private int version = 0;
    private String name;
    private Schedule schedule;
    private JobDetails jobDetails;
    private ZoneId zoneId;
    private Integer amountOfRetries;
    private Set<String> labels;
    private int priority;
    private boolean scheduleJobsSkippedDuringDowntime;
    private String serverTag = "DEFAULT";
    private String mutex;
    private String rateLimiter;
    private Integer maxConcurrentJobs;
    private boolean isPaused;
    private Instant lastRun;
    private Instant nextRun;
    private Instant createdAt = Instant.now();
    private Instant updatedAt;
    private Duration processTimeOut;
    private String deleteOnSuccess;
    private String deleteOnFailure;

    private RecurringJobTestBuilder() {

    }

    public static RecurringJobTestBuilder aRecurringJob() {
        return new RecurringJobTestBuilder();
    }

    public static RecurringJobTestBuilder aCopyOf(RecurringJob job) {
        return new RecurringJobTestBuilder()
                .withId(job.getId())
                .withVersion(job.getVersion())
                .withName(job.getJobName())
                .withScheduleExpression(getSchedule(job.getScheduleExpression()))
                .withJobDetails(job.getJobDetails())
                .withZoneId(ZoneId.of(job.getZoneId()))
                .withAmountOfRetries(job.getAmountOfRetries())
                .withPriority(job.getPriority())
                .withServerTag(job.getServerTag())
                .withLabels(job.getLabels().toArray(new String[0]))
                .withIsPaused(job.isPaused())
                .withScheduleJobsSkippedDuringDowntime(job.mustScheduleJobsSkippedDuringDowntime());
    }

    public static RecurringJobTestBuilder aDefaultRecurringJob() {
        return aRecurringJob()
                .withId("anId")
                .withName("a recurring job")
                .withJobDetails(defaultJobDetails())
                .withCronExpression(Cron.daily())
                .withZoneId(ZoneId.systemDefault());
    }

    public RecurringJobTestBuilder withId(String id) {
        this.id = id;
        return this;
    }

    public RecurringJobTestBuilder withoutId() {
        this.id = null;
        return this;
    }

    public RecurringJobTestBuilder withVersion(int version) {
        this.version = version;
        return this;
    }

    public RecurringJobTestBuilder withName(String name) {
        this.name = name;
        return this;
    }

    public RecurringJobTestBuilder withAmountOfRetries(Integer amountOfRetries) {
        this.amountOfRetries = amountOfRetries;
        return this;
    }

    public RecurringJobTestBuilder withJobDetails(JobLambda jobLambda) {
        this.jobDetails = new JobDetailsAsmGenerator().toJobDetails(jobLambda);
        return this;
    }

    public RecurringJobTestBuilder withJobDetails(IocJobLambda jobLambda) {
        this.jobDetails = new JobDetailsAsmGenerator().toJobDetails(jobLambda);
        return this;
    }

    public RecurringJobTestBuilder withJobDetails(JobDetailsTestBuilder jobDetailsBuilder) {
        withJobDetails(jobDetailsBuilder.build());
        return this;
    }

    public RecurringJobTestBuilder withJobDetails(JobDetails jobDetails) {
        this.jobDetails = jobDetails;
        return this;
    }

    public RecurringJobTestBuilder withCronExpression(String cronExpression) {
        this.schedule = CronExpression.create(cronExpression);
        return this;
    }

    public RecurringJobTestBuilder withCustomSchedule(String customScheduleExpression) {
        this.schedule = ScheduleExpressionType.getSchedule(customScheduleExpression);
        return this;
    }

    public RecurringJobTestBuilder withIntervalExpression(String intervalExpression) {
        return this.withIntervalExpression(intervalExpression, Instant.now());
    }

    public RecurringJobTestBuilder withIntervalExpression(String intervalExpression, Instant createdAt) {
        this.schedule = new Interval(Duration.parse(intervalExpression));
        this.createdAt = createdAt;
        return this;
    }

    public RecurringJobTestBuilder withScheduleExpression(Schedule schedule) {
        this.schedule = schedule;
        return this;
    }

    public RecurringJobTestBuilder withZoneId(ZoneId zoneId) {
        this.zoneId = zoneId;
        return this;
    }

    public RecurringJobTestBuilder withPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public RecurringJobTestBuilder withServerTag(String serverTag) {
        this.serverTag = serverTag;
        return this;
    }

    public RecurringJobTestBuilder withMutex(String mutex) {
        this.mutex = mutex;
        return this;
    }

    public RecurringJobTestBuilder withRateLimiter(String rateLimiter) {
        this.rateLimiter = rateLimiter;
        return this;
    }

    public RecurringJobTestBuilder withProcessTimeOut(Duration processTimeOut) {
        this.processTimeOut = processTimeOut;
        return this;
    }

    public RecurringJobTestBuilder withDeleteOnSuccess(String deleteOnSuccess) {
        this.deleteOnSuccess = deleteOnSuccess;
        return this;
    }

    public RecurringJobTestBuilder withDeleteOnFailure(String deleteOnFailure) {
        this.deleteOnFailure = deleteOnFailure;
        return this;
    }

    public RecurringJobTestBuilder withScheduleJobsSkippedDuringDowntime(boolean scheduleJobsSkippedDuringDowntime) {
        this.scheduleJobsSkippedDuringDowntime = scheduleJobsSkippedDuringDowntime;
        return this;
    }

    public RecurringJobTestBuilder withScheduleJobsSkippedDuringDowntime() {
        this.scheduleJobsSkippedDuringDowntime = true;
        return this;
    }

    public RecurringJobTestBuilder withMaxConcurrentJobs(int maxConcurrentJobs) {
        this.maxConcurrentJobs = maxConcurrentJobs;
        return this;
    }

    public RecurringJobTestBuilder withIsPaused(boolean isPaused) {
        this.isPaused = isPaused;
        return this;
    }

    public RecurringJobTestBuilder withIsPaused() {
        this.isPaused = true;
        return this;
    }

    public RecurringJobTestBuilder withLastRun(Instant lastRun) {
        this.lastRun = lastRun;
        return this;
    }

    public RecurringJobTestBuilder withNextRun(Instant nextRun) {
        this.nextRun = nextRun;
        return this;
    }

    public RecurringJobTestBuilder withLabels(String... labels) {
        this.labels = asSet(labels);
        return this;
    }

    public RecurringJobTestBuilder withCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public RecurringJobTestBuilder withUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public RecurringJob build() {
        final RecurringJob recurringJob = new RecurringJob(id, version, jobDetails, schedule, zoneId, createdAt, scheduleJobsSkippedDuringDowntime);
        if (amountOfRetries != null) {
            recurringJob.setAmountOfRetries(amountOfRetries);
        }
        recurringJob.setJobName(name);
        recurringJob.setLabels(labels);
        recurringJob.setPriority(priority);
        recurringJob.setServerTag(serverTag);
        recurringJob.setMutex(mutex);
        recurringJob.setRateLimiter(rateLimiter);
        recurringJob.setProcessTimeOut(processTimeOut);
        recurringJob.setDeleteOnSuccess(deleteOnSuccess);
        recurringJob.setDeleteOnFailure(deleteOnFailure);
        recurringJob.setPaused(isPaused);
        ofNullable(maxConcurrentJobs).ifPresent(recurringJob::setMaxConcurrentJobs);
        ofNullable(lastRun).ifPresent(lastRun -> {
            setInternalState(recurringJob, "lastRunAt", lastRun);
            setInternalState(recurringJob, "nextRunAt", schedule.next(createdAt, lastRun, zoneId));
        });
        ofNullable(nextRun).ifPresent(nextRun -> setInternalState(recurringJob, "nextRunAt", nextRun));
        ofNullable(updatedAt).ifPresent(updatedAt -> setInternalState(recurringJob, "updatedAt", updatedAt));
        return recurringJob;
    }
}