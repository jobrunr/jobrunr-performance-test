package org.jobrunr.jobs;

import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.details.JobDetailsAsmGenerator;
import org.jobrunr.jobs.lambdas.IocJobLambda;
import org.jobrunr.jobs.lambdas.JobLambda;
import org.jobrunr.jobs.states.AwaitingRateLimiterState;
import org.jobrunr.jobs.states.AwaitingState;
import org.jobrunr.jobs.states.DeletedState;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.JobState;
import org.jobrunr.jobs.states.ProcessedState;
import org.jobrunr.jobs.states.ProcessingState;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.jobs.states.SucceededState;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.resilience.Lock;
import org.mockito.internal.util.reflection.Whitebox;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static java.time.Duration.ofMillis;
import static java.time.Instant.now;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_SERVER_TAG;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.DEFAULT_SERVER_NAME;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

public class BatchJobTestBuilder {

    private UUID id;
    private Integer version;
    private String name;
    private JobDetails jobDetails;
    private final List<JobState> states = new ArrayList<>();
    private Map<String, Object> metadata = new HashMap<>();
    private Lock lock;
    private int priority = -1;
    private String rateLimiter;
    private Set<String> labels;
    private String serverTag = DEFAULT_SERVER_TAG;

    private BatchJobTestBuilder() {
    }

    public static BatchJobTestBuilder aBatchJob() {
        return new BatchJobTestBuilder()
                .withName("the job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"));
    }

    public static BatchJobTestBuilder aCopyOf(BatchJob job) {
        return new BatchJobTestBuilder()
                .withId(job.getId())
                .withName(job.getJobName())
                .withVersion(job.getVersion())
                .withLock(Whitebox.getInternalState(job, "lock"))
                .withJobDetails(job.getJobDetails())
                .withStates(job.getJobStates())
                .withMetadata(job.getMetadata())
                .withPriority(job.getPriority());
    }

    private BatchJobTestBuilder withStates(List<JobState> jobStates) {
        jobStates.forEach(this::withState);
        return this;
    }

    public static BatchJobTestBuilder anEnqueuedBatchJob() {
        return aBatchJob()
                .withName("an enqueued job")
                .withState(new EnqueuedState())
                .withPriority(0);
    }

    public static BatchJobTestBuilder anEnqueuedBatchJobThatTakesLong() {
        return aBatchJob()
                .withoutId()
                .withName("an enqueued job that takes long")
                .withState(new EnqueuedState())
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkThatTakesLong")
                        .withJobParameter(JobContext.Null));
    }

    public static BatchJobTestBuilder aBatchJobInProgress() {
        return anEnqueuedBatchJob().withId().withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME));
    }

    public static BatchJobTestBuilder aScheduledBatchJob() {
        return aBatchJob()
                .withName("a scheduled job")
                .withState(new ScheduledState(now().minusSeconds(1)));
    }

    public static BatchJobTestBuilder aFailedBatchJob() {
        return anEnqueuedBatchJob()
                .withName("a failed job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withProcessingState()
                .withFailedState();
    }

    public static BatchJobTestBuilder aProcessedBatchJob() {
        return anEnqueuedBatchJob()
                .withName("a processed job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME))
                .withState(new ProcessedState(Duration.ofSeconds(10), Duration.ofSeconds(20)));
    }

    public static BatchJobTestBuilder aSucceededBatchJob() {
        return aProcessedBatchJob()
                .withId()
                .withName("a succeeded job")
                .withState(new SucceededState(Duration.of(230, ChronoUnit.SECONDS), Duration.ofSeconds(10L, 7345L)));
    }

    public static BatchJobTestBuilder aDeletedJob() {
        return anEnqueuedBatchJob()
                .withId()
                .withName("a deleted job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withDeletedState();
    }

    public BatchJobTestBuilder withoutId() {
        id = null;
        return this;
    }

    public BatchJobTestBuilder withId() {
        return withId(UUID.randomUUID());
    }

    public BatchJobTestBuilder withId(UUID uuid) {
        this.id = uuid;
        return this;
    }

    public BatchJobTestBuilder withVersion(int version) {
        this.version = version;
        return this;
    }

    public BatchJobTestBuilder withName(String name) {
        this.name = name;
        return this;
    }

    public BatchJobTestBuilder withoutName() {
        this.name = null;
        return this;
    }

    public BatchJobTestBuilder withPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public BatchJobTestBuilder withLabels(String... labels) {
        this.labels = Set.of(labels);
        return this;
    }

    public BatchJobTestBuilder withServerTag(String serverTag) {
        this.serverTag = serverTag;
        return this;
    }

    public BatchJobTestBuilder withLock(Lock lock) {
        this.lock = lock;
        return this;
    }

    public BatchJobTestBuilder withJobDetails(JobDetails jobDetails) {
        this.jobDetails = jobDetails;
        return this;
    }

    public BatchJobTestBuilder withJobDetails(JobLambda jobLambda) {
        this.jobDetails = new JobDetailsAsmGenerator().toJobDetails(jobLambda);
        return this;
    }

    public BatchJobTestBuilder withJobDetails(IocJobLambda jobLambda) {
        this.jobDetails = new JobDetailsAsmGenerator().toJobDetails(jobLambda);
        return this;
    }

    public BatchJobTestBuilder withJobDetails(JobDetailsTestBuilder jobDetailsTestBuilder) {
        this.jobDetails = jobDetailsTestBuilder.build();
        return this;
    }

    public BatchJobTestBuilder withState(JobState state) {
        this.states.add(state);
        return this;
    }

    public BatchJobTestBuilder withState(JobState state, Instant createdAt) {
        setInternalState(state, "createdAt", createdAt);
        if (state instanceof ProcessingState) setInternalState(state, "updatedAt", createdAt);
        this.states.add(state);
        return this;
    }

    public BatchJobTestBuilder withEnqueuedState(Instant createdAt) {
        withState(new EnqueuedState(), createdAt);
        return this;
    }

    public BatchJobTestBuilder withAwaitingState(UUID otherJob) {
        this.states.add(new AwaitingState(otherJob));
        return this;
    }

    public BatchJobTestBuilder withAwaitingRateLimiterState(String rateLimiter) {
        this.states.add(new AwaitingRateLimiterState(rateLimiter));
        this.rateLimiter = rateLimiter;
        return this;
    }

    public BatchJobTestBuilder withScheduledState() {
        return withState(new ScheduledState(now().minusSeconds(10)));
    }

    public BatchJobTestBuilder withProcessingState() {
        return withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME));
    }

    public BatchJobTestBuilder withSucceededState() {
        return withState(new SucceededState(ofMillis(10), ofMillis(3)));
    }

    public BatchJobTestBuilder withFailedState() {
        return withFailedState("Exception", new Exception());
    }

    public BatchJobTestBuilder withFailedState(String message, Exception exception) {
        return withState(new FailedState(message, exception, Duration.ofSeconds(15), Duration.ofSeconds(14)));
    }

    public BatchJobTestBuilder withDeletedState() {
        return withState(new DeletedState("Job deleted by test builder", null));
    }

    public BatchJobTestBuilder withMetadata(String key, Object metadata) {
        this.metadata.put(key, metadata);
        return this;
    }

    public BatchJobTestBuilder withMetadata(Map<String, Object> metadata) {
        this.metadata = new HashMap<>(metadata);
        return this;
    }

    public BatchJob build() {
        BatchJob job = new BatchJob(id, jobDetails, states.remove(0));
        if (version != null) {
            Whitebox.setInternalState(job, "version", version);
        }
        if (lock != null) {
            Whitebox.setInternalState(job, "lock", lock);
        }
        job.setJobName(name);
        job.setPriority(priority);
        job.setLabels(labels);
        job.setServerTag(serverTag);
        job.getMetadata().putAll(metadata);

        List<JobState> jobHistory = Whitebox.getInternalState(job, "jobHistory");
        jobHistory.addAll(states);
        return job;
    }
}
