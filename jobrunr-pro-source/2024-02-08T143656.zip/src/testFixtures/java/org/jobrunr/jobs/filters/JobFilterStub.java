package org.jobrunr.jobs.filters;

import org.jobrunr.jobs.AbstractJob;
import org.jobrunr.jobs.Job;

public class JobFilterStub implements JobClientFilter, JobServerFilter {

    @Override
    public void onCreating(AbstractJob job) {
        System.out.println("On Job Creation");
    }

    @Override
    public void onCreated(AbstractJob job) {
        System.out.println("On Job Created");
    }

    @Override
    public void onProcessing(Job job) {
        System.out.println("On Job Processing");
    }
}
