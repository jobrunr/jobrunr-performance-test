package org.jobrunr.jobs;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.assertj.core.data.TemporalUnitOffset;
import org.jobrunr.JobRunrAssertions;

import java.time.Instant;
import java.util.Set;

public class RecurringJobAssert extends AbstractAssert<RecurringJobAssert, RecurringJob> {

    private RecurringJobAssert(RecurringJob recurringJob) {
        super(recurringJob, RecurringJobAssert.class);
    }

    public static RecurringJobAssert assertThat(RecurringJob recurringJob) {
        return new RecurringJobAssert(recurringJob);
    }

    public RecurringJobAssert hasId() {
        Assertions.assertThat(actual.getId()).isNotNull();
        return this;
    }

    public RecurringJobAssert hasId(String id) {
        Assertions.assertThat(actual.getId()).isEqualTo(id);
        return this;
    }

    public RecurringJobAssert hasVersion(int version) {
        Assertions.assertThat(actual.getVersion()).isEqualTo(version);
        return this;
    }

    public RecurringJobAssert hasJobName(String name) {
        Assertions.assertThat(actual.getJobName()).isEqualTo(name);
        return this;
    }

    public RecurringJobAssert hasJobDetails(Class<?> clazz, String methodName, Object... args) {
        JobRunrAssertions.assertThat(actual.getJobDetails())
                .hasClass(clazz)
                .hasMethodName(methodName)
                .hasArgs(args);
        return this;
    }

    public RecurringJobAssert hasRetries(int amountOfRetries) {
        Assertions.assertThat(actual.getAmountOfRetries()).isEqualTo(amountOfRetries);
        return this;
    }

    public RecurringJobAssert hasLabels(Set<String> labels) {
        Assertions.assertThat(actual.getLabels()).isEqualTo(labels);
        return this;
    }

    public RecurringJobAssert hasScheduleExpression(String scheduleExpression) {
        Assertions.assertThat(actual.getScheduleExpression()).isEqualTo(scheduleExpression);
        return this;
    }

    public RecurringJobAssert hasUpdatedSchedule(boolean isScheduleUpdated) {
        Assertions.assertThat(actual.isScheduleUpdated()).isEqualTo(isScheduleUpdated);
        return this;
    }

    public RecurringJobAssert hasZoneId(String zoneId) {
        Assertions.assertThat(actual.getZoneId()).isEqualTo(zoneId);
        return this;
    }

    public RecurringJobAssert hasServerTag(String serverTag) {
        Assertions.assertThat(actual.getServerTag()).isEqualTo(serverTag);
        return this;
    }

    public RecurringJobAssert hasMutex(String mutex) {
        Assertions.assertThat(actual.getMutex().orElseThrow()).isEqualTo(mutex);
        return this;
    }


    public RecurringJobAssert hasRateLimiter(String rateLimiter) {
        Assertions.assertThat(actual.getRateLimiter()).isEqualTo(rateLimiter);
        return this;
    }

    public RecurringJobAssert hasPriority(int priority) {
        Assertions.assertThat(actual.getPriority()).isEqualTo(priority);
        return this;
    }

    public RecurringJobAssert hasPaused(boolean isPaused) {
        Assertions.assertThat(actual.isPaused()).isEqualTo(isPaused);
        return this;
    }

    public RecurringJobAssert hasScheduleJobsSkippedDuringDowntime(boolean mustScheduleJobsSkippedDuringDowntime) {
        Assertions.assertThat(actual.mustScheduleJobsSkippedDuringDowntime()).isEqualTo(mustScheduleJobsSkippedDuringDowntime);
        return this;
    }

    public RecurringJobAssert hasRunningMoreThanOncePerMinute(boolean isRunningMoreThanOncePerMinute) {
        Assertions.assertThat(actual.isRunningMoreThanOncePerMinute()).isEqualTo(isRunningMoreThanOncePerMinute);
        return this;
    }

    public RecurringJobAssert hasMaxConcurrentJobs(int maxConcurrentJobs) {
        Assertions.assertThat(actual.getMaxConcurrentJobs()).isEqualTo(maxConcurrentJobs);
        return this;
    }

    public RecurringJobAssert hasLastRun(Instant lastRun) {
        Assertions.assertThat(actual.getLastRunAt()).isEqualTo(lastRun);
        return this;
    }

    public RecurringJobAssert hasNextRun(Instant nextRun) {
        Assertions.assertThat(actual.getNextRunAt()).isEqualTo(nextRun);
        return this;
    }

    public RecurringJobAssert hasNextRunCloseTo(Instant nextRun, TemporalUnitOffset within) {
        Assertions.assertThat(actual.getNextRunAt()).isCloseTo(nextRun, within);
        return this;
    }

    public RecurringJobAssert isEqualTo(RecurringJob otherRecurringJob) {
        Assertions.assertThat(actual)
                .usingRecursiveComparison()
                .ignoringFields("locker")
                .isEqualTo(otherRecurringJob);
        return this;
    }


    public RecurringJobAssert hasDeleteOnSuccess(String deleteOnSuccess) {
        Assertions.assertThat(actual.getDeleteOnSuccess()).isEqualTo(deleteOnSuccess);
        return this;
    }

    public RecurringJobAssert hasDeleteOnFailure(String deleteOnFailure) {
        Assertions.assertThat(actual.getDeleteOnFailure()).isEqualTo(deleteOnFailure);
        return this;
    }

    public RecurringJobAssert isRedacted() {
        JobDetailsAssert.assertThat(actual.getJobDetails()).isRedacted();
        return this;
    }
}