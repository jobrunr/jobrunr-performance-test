package org.jobrunr.jobs.filters.retry;

import org.assertj.core.api.AbstractObjectAssert;
import org.assertj.core.api.Assertions;

public class RetryPolicyAssert extends AbstractObjectAssert<RetryPolicyAssert, RetryPolicy> {

    private RetryPolicyAssert(RetryPolicy retryPolicy) {
        super(retryPolicy, RetryPolicyAssert.class);
    }

    public static RetryPolicyAssert assertThat(RetryPolicy retryPolicy) {
        return new RetryPolicyAssert(retryPolicy);
    }

    public RetryPolicyAssert hasMaxAmountOfRetries(int maxAmountOfRetries) {
        Assertions.assertThat(actual.getMaxAmountOfRetries()).isEqualTo(maxAmountOfRetries);
        return this;
    }

    public RetryPolicyAssert hasSecondsToAddGivenFailureCount(int secondsToAdd, int failureCount) {
        Assertions.assertThat(actual.getSecondsToAdd(failureCount))
                .isEqualTo(secondsToAdd);
        return this;
    }
}
