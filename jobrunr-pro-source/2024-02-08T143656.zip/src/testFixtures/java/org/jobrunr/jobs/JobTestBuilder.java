package org.jobrunr.jobs;

import org.jobrunr.jobs.context.JobContext;
import org.jobrunr.jobs.details.CachingJobDetailsGenerator;
import org.jobrunr.jobs.details.JobDetailsAsmGenerator;
import org.jobrunr.jobs.lambdas.IocJobLambda;
import org.jobrunr.jobs.lambdas.JobLambda;
import org.jobrunr.jobs.states.AwaitingBatchJobState;
import org.jobrunr.jobs.states.AwaitingRateLimiterState;
import org.jobrunr.jobs.states.AwaitingState;
import org.jobrunr.jobs.states.DeletedState;
import org.jobrunr.jobs.states.EnqueuedState;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.InitialState;
import org.jobrunr.jobs.states.JobState;
import org.jobrunr.jobs.states.ProcessingState;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.jobs.states.SucceededState;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.JobHolderContext;
import org.jobrunr.utils.resilience.Lock;
import org.mockito.internal.util.reflection.Whitebox;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.IntStream;

import static java.time.Duration.ofMillis;
import static java.time.Instant.now;
import static java.util.stream.Collectors.toList;
import static org.jobrunr.jobs.BatchJobTestBuilder.aBatchJobInProgress;
import static org.jobrunr.jobs.JobDetailsTestBuilder.jobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.server.BackgroundJobServerConfiguration.DEFAULT_SERVER_TAG;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.DEFAULT_SERVER_NAME;
import static org.jobrunr.utils.CollectionUtils.asSet;
import static org.jobrunr.utils.reflection.ReflectionUtils.cast;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

public class JobTestBuilder {

    public static List<Job>[] emptyJobList() {
        List<Job>[] result = cast(new ArrayList[1]);
        result[0] = new ArrayList<>();
        return result;
    }

    public static List<Job> create(int amount, Supplier<JobTestBuilder> supplier) {
        return IntStream.range(0, amount).boxed()
                .map(i -> supplier.get())
                .map(JobTestBuilder::build)
                .collect(toList());
    }


    private UUID id;
    private Integer version;
    private String name;
    private Integer amountOfRetries;
    private String recurringJobId;
    private Set<String> labels;
    private String dynamicQueue;
    private String serverTag = DEFAULT_SERVER_TAG;
    private String mutex;
    private String rateLimiter;
    private String deleteOnSuccess;
    private String deleteOnFailure;
    private Duration processTimeOut;
    private int priority = -1;
    private Instant deleteAt;
    private JobDetails jobDetails;
    private final List<JobState> states = new ArrayList<>();
    private Map<String, Object> metadata = new HashMap<>();
    private Lock locker;
    private JobResult jobResult;

    private JobTestBuilder() {
    }

    public static JobTestBuilder aJob() {
        return new JobTestBuilder()
                .withId()
                .withPriority(0)
                .withName("the job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"));
    }

    public static JobTestBuilder aCopyOf(Job job) {
        return new JobTestBuilder()
                .withId(job.getId())
                .withName(job.getJobName())
                .withVersion(job.getVersion())
                .withLock(getInternalState(job, "locker"))
                .withJobDetails(job.getJobDetails())
                .withStates(job.getJobStates())
                .withMetadata(job.getMetadata());
    }

    private JobTestBuilder withStates(List<JobState> jobStates) {
        jobStates.forEach(this::withState);
        return this;
    }

    public static JobTestBuilder anEnqueuedJob() {
        return aJob()
                .withoutName()
                .withPriority(-1)
                .withState(new EnqueuedState());
    }

    public static JobTestBuilder anEnqueuedJobWithName() {
        return aJob()
                .withName("an enqueued job")
                .withState(new EnqueuedState());
    }

    public static JobTestBuilder anEnqueuedJobReplacing(Job otherJob) {
        EnqueuedState enqueuedState = new EnqueuedState();
        return aJobReplacing(otherJob, enqueuedState);
    }

    public static JobTestBuilder anEnqueuedJobThatTakesLong() {
        return aJob()
                .withName("an enqueued job that takes long")
                .withState(new EnqueuedState())
                .withJobDetails(jobDetails()
                        .withClassName(TestService.class)
                        .withMethodName("doWorkThatTakesLong")
                        .withJobParameter(JobContext.Null));
    }

    public static JobTestBuilder aJobInProgress() {
        return anEnqueuedJobWithName().withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME));
    }

    public static JobTestBuilder aScheduledJob() {
        return aJob()
                .withName("a scheduled job")
                .withState(new ScheduledState(now().minusSeconds(1)));
    }

    public static JobTestBuilder aScheduledJobReplacing(Job otherJob) {
        ScheduledState scheduledState = new ScheduledState(now().plusSeconds(1));
        return aJobReplacing(otherJob, scheduledState);
    }

    public static JobTestBuilder aFailedJob() {
        return anEnqueuedJobWithName()
                .withName("a failed job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withProcessingState()
                .withFailedState("a message", new IllegalStateException());
    }

    public static JobTestBuilder aSucceededJob() {
        return anEnqueuedJobWithName()
                .withName("a succeeded job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withProcessingState()
                .withSucceededState(Duration.of(230, ChronoUnit.SECONDS), Duration.ofSeconds(10L, 7345L));
    }

    public static JobTestBuilder aDeletedJob() {
        return anEnqueuedJobWithName()
                .withName("a deleted job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withState(new DeletedState("no reason", null));
    }

    public static JobTestBuilder aFailedJobThatEventuallySucceeded() {
        return aFailedJobWithRetries(3)
                .withSucceededState(Duration.ofSeconds(230), Duration.ofSeconds(10));
    }

    public static JobTestBuilder aFailedJobWithRetries() {
        return aFailedJobWithRetries(10);
    }

    public static JobTestBuilder aFailedJobWithRetries(int amount) {
        final JobTestBuilder jobTestBuilder = aJob()
                .withName("failed job")
                .withJobDetails(systemOutPrintLnJobDetails("a test"))
                .withScheduledState(now().minusSeconds(11 * 60 * 60));

        for (int i = 0; i <= amount; i++) {
            jobTestBuilder
                    .withEnqueuedState()
                    .withProcessingState()
                    .withFailedState("An exception occurred", new IllegalStateException());

            if (i < amount) {
                jobTestBuilder.withState(new ScheduledState(now().minusSeconds((10 - i) * 60 * 60), "Retry attempt " + (i + 1) + " of " + 10));
            }
        }

        return jobTestBuilder;
    }

    public static JobTestBuilder aJobReplacing(Job otherJob, InitialState initialJobState) {
        initialJobState.isReplacingJobInState(otherJob.getState(), otherJob.getUpdatedAt());
        return aJob()
                .withId(otherJob.getId())
                .withName(otherJob.getJobName())
                .withVersion(otherJob.getVersion())
                .withLock(getInternalState(otherJob, "locker"))
                .withJobDetails(otherJob.getJobDetails())
                .withName("a job replacing another job.")
                .withState(initialJobState);
    }

    public JobTestBuilder withoutId() {
        id = null;
        return this;
    }

    public JobTestBuilder withId() {
        return withId(UUID.randomUUID());
    }

    public JobTestBuilder withId(UUID uuid) {
        this.id = uuid;
        return this;
    }

    public JobTestBuilder withVersion(int version) {
        this.version = version;
        return this;
    }

    public JobTestBuilder withName(String name) {
        this.name = name;
        return this;
    }

    public JobTestBuilder withAmountOfRetries(int amountOfRetries) {
        this.amountOfRetries = amountOfRetries;
        return this;
    }

    public JobTestBuilder withRecurringJobId(String recurringJobId) {
        this.recurringJobId = recurringJobId;
        return this;
    }

    public JobTestBuilder withDynamicQueue(String dynamicQueue) {
        this.dynamicQueue = dynamicQueue;
        return this;
    }

    public JobTestBuilder withoutDynamicQueue() {
        this.dynamicQueue = null;
        return this;
    }

    public JobTestBuilder withLabels(String... labels) {
        return withLabels(asSet(labels));
    }

    public JobTestBuilder withLabels(Set<String> labels) {
        this.labels = labels;
        return this;
    }

    public JobTestBuilder withoutName() {
        this.name = null;
        return this;
    }

    public JobTestBuilder withLock(Lock lock) {
        this.locker = lock;
        return this;
    }

    public JobTestBuilder withJobDetails(JobDetails jobDetails) {
        this.jobDetails = jobDetails;
        return this;
    }

    public JobTestBuilder withJobDetails(JobLambda jobLambda) {
        this.jobDetails = new CachingJobDetailsGenerator(new JobDetailsAsmGenerator()).toJobDetails(jobLambda);
        return this;
    }

    public <S> JobTestBuilder withJobDetails(IocJobLambda<S> jobLambda) {
        this.jobDetails = new CachingJobDetailsGenerator(new JobDetailsAsmGenerator()).toJobDetails(jobLambda);
        return this;
    }

    public JobTestBuilder withJobDetails(JobDetailsTestBuilder jobDetailsTestBuilder) {
        this.jobDetails = jobDetailsTestBuilder.build();
        return this;
    }

    public JobTestBuilder withState(JobState state) {
        this.states.add(state);
        return this;
    }

    public JobTestBuilder withState(JobState state, Instant createdAt) {
        setInternalState(state, "createdAt", createdAt);
        if (state instanceof ProcessingState) setInternalState(state, "updatedAt", createdAt);
        this.states.add(state);
        return this;
    }

    public JobTestBuilder withAwaitingState(UUID otherJob) {
        return withState(new AwaitingState(otherJob));
    }

    public JobTestBuilder withAwaitingState(UUID otherJob, Duration scheduleAfterDuration) {
        return withState(new AwaitingState(otherJob, scheduleAfterDuration));
    }

    public JobTestBuilder withAwaitingStateAndAwaitingBatchJobState(UUID otherJob, UUID parentJob) {
        try {
            JobHolderContext.setJob(aBatchJobInProgress().withId(parentJob).build());
            return withState(new AwaitingState(otherJob));
        } finally {
            JobHolderContext.clear();
        }
    }

    public JobTestBuilder withAwaitingBatchJobState(UUID parentJob) {
        try {
            JobHolderContext.setJob(aBatchJobInProgress().withId(parentJob).build());
            withState(new AwaitingBatchJobState(parentJob));
        } finally {
            JobHolderContext.clear();
        }
        return this;
    }

    public JobTestBuilder withAwaitingBatchJobState(UUID parentJob, Duration scheduleAfterDuration) {
        try {
            JobHolderContext.setJob(aBatchJobInProgress().withId(parentJob).build());
            withState(new AwaitingBatchJobState(parentJob, scheduleAfterDuration));
        } finally {
            JobHolderContext.clear();
        }
        return this;
    }

    public JobTestBuilder withAwaitingRateLimiterState(String rateLimiter) {
        withState(new AwaitingRateLimiterState(rateLimiter));
        this.rateLimiter = rateLimiter;
        return this;
    }

    public JobTestBuilder withAwaitingRateLimiterState(String rateLimiter, Instant createdAt) {
        withState(new AwaitingRateLimiterState(rateLimiter), createdAt);
        this.rateLimiter = rateLimiter;
        return this;
    }

    public JobTestBuilder withEnqueuedState() {
        withState(new EnqueuedState());
        return this;
    }

    public JobTestBuilder withEnqueuedState(Instant createdAt) {
        withState(new EnqueuedState(), createdAt);
        return this;
    }

    public JobTestBuilder withScheduledState() {
        return withScheduledState(now().minusSeconds(10));
    }

    public JobTestBuilder withScheduledState(Instant instant) {
        return withState(new ScheduledState(instant));
    }

    public JobTestBuilder withProcessingState() {
        return withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME));
    }

    public JobTestBuilder withProcessingState(Instant createdAt) {
        return withState(new ProcessingState(UUID.randomUUID(), DEFAULT_SERVER_NAME), createdAt);
    }

    public JobTestBuilder withProcessingState(UUID backgroundJobServerId) {
        return withState(new ProcessingState(backgroundJobServerId, DEFAULT_SERVER_NAME));
    }

    public JobTestBuilder withSucceededState() {
        return withSucceededState(ofMillis(10), ofMillis(3));
    }

    public JobTestBuilder withSucceededState(Instant createdAt) {
        return withSucceededState(createdAt, ofMillis(10), ofMillis(3));
    }

    public JobTestBuilder withSucceededState(Duration latencyDuration, Duration processingDuration) {
        return withState(new SucceededState(latencyDuration, processingDuration));
    }

    public JobTestBuilder withSucceededState(Instant createdAt, Duration latencyDuration, Duration processingDuration) {
        return withState(new SucceededState(latencyDuration, processingDuration), createdAt);
    }

    public JobTestBuilder withFailedState() {
        return withFailedState("Exception");
    }

    public JobTestBuilder withFailedState(String message) {
        return withFailedState(message, new Exception());
    }

    public JobTestBuilder withFailedState(String message, Exception exception) {
        return withState(new FailedState(message, exception, Duration.ofSeconds(20), Duration.ofSeconds(189)));
    }

    public JobTestBuilder withDeletedState() {
        return withState(new DeletedState("no reason", null));
    }

    public JobTestBuilder withoutServerTag() {
        this.serverTag = DEFAULT_SERVER_TAG;
        return this;
    }

    public JobTestBuilder withServerTag(String serverTag) {
        this.serverTag = serverTag;
        return this;
    }

    public JobTestBuilder withMutex(String mutex) {
        this.mutex = mutex;
        return this;
    }

    public JobTestBuilder withRateLimiter(String rateLimiter) {
        this.rateLimiter = rateLimiter;
        return this;
    }

    public JobTestBuilder withoutRateLimiter() {
        this.rateLimiter = null;
        return this;
    }

    public JobTestBuilder withoutMutex() {
        this.mutex = null;
        return this;
    }

    public JobTestBuilder withPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public JobTestBuilder withDeleteAt(Instant deleteAt) {
        this.deleteAt = deleteAt;
        return this;
    }

    public JobTestBuilder withProcessTimeOut(Duration processTimeout) {
        this.processTimeOut = processTimeout;
        return this;
    }

    public JobTestBuilder withMetadata(String key, Object metadata) {
        this.metadata.put(key, metadata);
        return this;
    }

    public JobTestBuilder withMetadata(Map<String, Object> metadata) {
        this.metadata = new HashMap<>(metadata);
        return this;
    }

    public JobTestBuilder withJobResult(Object object) {
        this.withJobResult(new JobResult(object.getClass().getName(), object));
        return this;
    }

    public JobTestBuilder withJobResult(JobResult jobResult) {
        this.jobResult = jobResult;
        return this;
    }

    public JobTestBuilder withDeleteOnSuccess(String deleteOnSuccess) {
        this.deleteOnSuccess = deleteOnSuccess;
        return this;
    }

    public JobTestBuilder withDeleteOnFailure(String deleteOnFailure) {
        this.deleteOnFailure = deleteOnFailure;
        return this;
    }

    public Job build() {
        if (states.isEmpty()) throw new IllegalStateException("A job should have an initial state (either AWAITING, SCHEDULED or ENQUEUED)");
        Job job = new Job(id, jobDetails, states.remove(0));
        if (version != null) {
            Whitebox.setInternalState(job, "version", version);
        }
        if (locker != null) {
            Whitebox.setInternalState(job, "locker", locker);
        }
        if (amountOfRetries != null) {
            job.setAmountOfRetries(amountOfRetries);
        }
        if (labels != null) {
            job.setLabels(labels);
        }
        job.setJobName(name);
        job.setRecurringJobId(recurringJobId);
        job.setDynamicQueue(dynamicQueue);
        job.setServerTag(serverTag);
        job.setDeleteAt(deleteAt);
        job.setMutex(mutex);
        if (rateLimiter != null) {
            Whitebox.setInternalState(job, "rateLimiter", rateLimiter);
        }
        job.setPriority(priority);
        job.getMetadata().putAll(metadata);
        job.setJobResult(jobResult);
        job.setRecurringJobId(recurringJobId);
        job.setDeleteOnSuccess(deleteOnSuccess);
        job.setDeleteOnFailure(deleteOnFailure);
        job.setProcessTimeOut(processTimeOut);

        List<JobState> jobHistory = getInternalState(job, "jobHistory");
        jobHistory.addAll(states);
        return job;
    }
}
