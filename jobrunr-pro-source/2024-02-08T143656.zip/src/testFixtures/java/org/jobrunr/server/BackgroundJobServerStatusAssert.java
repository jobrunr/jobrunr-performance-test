package org.jobrunr.server;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.storage.BackgroundJobServerStatus;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

import static org.assertj.core.api.Assertions.within;

public class BackgroundJobServerStatusAssert extends AbstractAssert<BackgroundJobServerStatusAssert, BackgroundJobServerStatus> {
    protected BackgroundJobServerStatusAssert(BackgroundJobServerStatus backgroundJobServerStatus) {
        super(backgroundJobServerStatus, BackgroundJobServerStatusAssert.class);
    }

    public static BackgroundJobServerStatusAssert assertThat(BackgroundJobServerStatus backgroundJobServerStatus) {
        return new BackgroundJobServerStatusAssert(backgroundJobServerStatus);
    }

    public BackgroundJobServerStatusAssert isPaused() {
        Assertions.assertThat(actual.isRunning()).isFalse();
        return this;
    }

    public BackgroundJobServerStatusAssert isProcessing() {
        Assertions.assertThat(actual.isRunning()).isTrue();
        return this;
    }

    public BackgroundJobServerStatusAssert hasSameSettingsAs(BackgroundJobServerStatus serverStatus) {
        Assertions.assertThat(actual).isEqualToComparingOnlyGivenFields(serverStatus, "id", "workerPoolSize", "pollIntervalInSeconds", "running");
        return this;
    }

    public BackgroundJobServerStatusAssert hasFirstHeartbeatCloseTo(Instant firstHeartbeat) {
        Assertions.assertThat(actual.getFirstHeartbeat()).isCloseTo(firstHeartbeat, within(1000, ChronoUnit.MICROS));
        return this;
    }

    public BackgroundJobServerStatusAssert hasLastHeartbeatCloseTo(Instant lastHeartbeat) {
        Assertions.assertThat(actual.getLastHeartbeat()).isCloseTo(lastHeartbeat, within(1000, ChronoUnit.MICROS));
        return this;
    }

    public BackgroundJobServerStatusAssert hasLastHeartbeatAfter(Instant instant) {
        Assertions.assertThat(actual.getLastHeartbeat()).isAfter(instant);
        return this;
    }
}
