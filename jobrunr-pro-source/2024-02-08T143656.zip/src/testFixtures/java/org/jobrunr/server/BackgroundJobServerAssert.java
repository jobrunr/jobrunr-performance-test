package org.jobrunr.server;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.jobs.filters.DefaultRetryFilter;
import org.jobrunr.jobs.filters.JobFilter;

import java.util.List;

import static org.mockito.internal.util.reflection.Whitebox.getInternalState;

public class BackgroundJobServerAssert extends AbstractAssert<BackgroundJobServerAssert, BackgroundJobServer> {
    protected BackgroundJobServerAssert(BackgroundJobServer backgroundJobServe) {
        super(backgroundJobServe, BackgroundJobServerAssert.class);
    }

    public static BackgroundJobServerAssert assertThat(BackgroundJobServer backgroundJobServer) {
        return new BackgroundJobServerAssert(backgroundJobServer);
    }

    public BackgroundJobServerAssert hasName(String name) {
        Assertions.assertThat(actual.getConfiguration().getName()).isEqualTo(name);
        return this;
    }

    public BackgroundJobServerAssert hasExponentialRetryPolicy(int defaultNbrOfRetries) {
        DefaultRetryFilter retryFilter = getDefaultJobRetryFilter();
        Assertions.assertThat((Integer) getInternalState(getInternalState(retryFilter, "retryPolicy"), "maxAmountOfRetries")).isEqualTo(defaultNbrOfRetries);
        return this;
    }

    public BackgroundJobServerAssert hasCustomBackOffRetryPolicy(int... customRetryPolicy) {
        DefaultRetryFilter retryFilter = getDefaultJobRetryFilter();
        Assertions.assertThat((int[]) getInternalState(getInternalState(retryFilter, "retryPolicy"), "retryAfterSeconds")).isEqualTo(customRetryPolicy);
        return this;
    }

    private DefaultRetryFilter getDefaultJobRetryFilter() {
        List<JobFilter> filters = getInternalState(actual.getJobFilters(), "filters");
        return filters.stream()
                .filter(filter -> filter instanceof DefaultRetryFilter)
                .reduce((first, second) -> second)
                .map(DefaultRetryFilter.class::cast)
                .orElseThrow(() -> new AssertionError("No retry filter found"));
    }

    public BackgroundJobServerAssert hasJobFilterOfType(Class<? extends JobFilter> jobFilterClass) {
        List<JobFilter> filters = getInternalState(actual.getJobFilters(), "filters");
        Assertions.assertThat(filters).anyMatch(jobFilter -> jobFilterClass.equals(jobFilter.getClass()));
        return this;
    }

    public BackgroundJobServerAssert hasServerTags(String... tags) {
        BackgroundJobServerConfiguration configuration = actual.getConfiguration();
        Assertions.assertThat(configuration.getServerTags()).contains(tags);
        return this;
    }
}
