package org.jobrunr.scheduling;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.jobs.filters.JobFilter;
import org.jobrunr.utils.multicast.JobEnqueuedMessagePublisher;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.mockito.internal.util.reflection.Whitebox.getInternalState;

public class JobSchedulerAssert extends AbstractAssert<JobSchedulerAssert, AbstractJobScheduler> {

    protected JobSchedulerAssert(AbstractJobScheduler jobScheduler) {
        super(jobScheduler, JobSchedulerAssert.class);
    }

    public static JobSchedulerAssert assertThat(AbstractJobScheduler jobScheduler) {
        return new JobSchedulerAssert(jobScheduler);
    }

    public JobSchedulerAssert hasJobFilterOfType(Class<? extends JobFilter> jobFilterClass) {
        List<JobFilter> filters = getInternalState(getJobDefaultFilters(), "filters");
        Assertions.assertThat(filters).anyMatch(jobFilter -> jobFilterClass.equals(jobFilter.getClass()));
        return this;
    }

    public JobSchedulerAssert hasJobFilter(JobFilter jobFilter) {
        List<JobFilter> filters = getInternalState(getJobDefaultFilters(), "filters");
        Assertions.assertThat(filters).contains(jobFilter);
        return this;
    }

    public JobSchedulerAssert hasJobEnqueuedMessagePublisherOfType(Class<? extends JobEnqueuedMessagePublisher> jobEnqueuedMessagePublisherClass) {
        JobEnqueuedMessagePublisher jobEnqueuedMessagePublisher = getInternalState(actual, "jobEnqueuedMessagePublisher");
        Assertions.assertThat(jobEnqueuedMessagePublisher).isInstanceOf(jobEnqueuedMessagePublisherClass);
        return this;
    }

    public JobSchedulerAssert hasCurrentServerId() {
        UUID jobRunrServerId = getInternalState(getJobDefaultFilters(),"jobRunrServerId");
        Assertions.assertThat(jobRunrServerId).isNotNull();
        return this;
    }

    public JobSchedulerAssert hasNoCurrentServerId() {
        UUID jobRunrServerId = getInternalState(getJobDefaultFilters(),"jobRunrServerId");
        Assertions.assertThat(jobRunrServerId).isNull();
        return this;
    }

    public JobSchedulerAssert hasQueues(String defaultQueueName, String... queueNames) {
        Assertions.assertThat(actual.queues)
                .isNotNull()
                .hasFieldOrPropertyWithValue("defaultQueue", defaultQueueName)
                .hasFieldOrPropertyWithValue("queues", Arrays.asList(queueNames));
        return this;
    }

    private JobDefaultFilters getJobDefaultFilters() {
        return getInternalState(
                getInternalState(actual, "jobFilterUtils"),
                "jobDefaultFilters");
    }
}
