package org.jobrunr.scheduling;

import org.assertj.core.api.Assertions;
import org.jobrunr.utils.resilience.BackOffResultAssert;

public class JobResultWithBackOffInfoAssert extends BackOffResultAssert {

    protected JobResultWithBackOffInfoAssert(JobResultWithBackOffInfo result) {
        super(result);
    }

    public static JobResultWithBackOffInfoAssert assertThat(JobResultWithBackOffInfo result) {
        return new JobResultWithBackOffInfoAssert(result);
    }

    public BackOffResultAssert hasState(JobResultState state) {
        Assertions.assertThat(((JobResultWithBackOffInfo)actual).getState()).isEqualTo(state);
        return this;
    }
}
