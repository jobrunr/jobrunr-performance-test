package org.jobrunr.scheduling.custom;

import java.time.Instant;
import java.time.ZoneId;

public class CustomScheduleTestImplementation extends CustomSchedule {

    public static final String CLASS_NAME = "org.jobrunr.scheduling.custom.CustomScheduleTestImplementation";

    public static final String SCHEDULE_EXPRESSION = CLASS_NAME + "(2050-01-01T01:00:00.000Z)";

    private static final String DELIMITER = ",";

    public static String myCustomSchedule(String... input) {
        return expressionFor(CustomScheduleTestImplementation.class, String.join(DELIMITER, input));
    }

    private final String input;

    public CustomScheduleTestImplementation(String input) {
        // parsing or validating the input
        int length = input.split(DELIMITER).length;
        if (length != 1) {
            throw new IllegalArgumentException(String.format("My test schedule expects one argument, %d given", length));
        }
        this.input = input;
    }

    @Override
    public Instant next(Instant createdAtInstant, Instant currentInstant, ZoneId zoneId) {
        Instant schedule = Instant.parse(this.input);
        if (currentInstant.isBefore(schedule)) return schedule;
        // Not interested in releasing new jobs? Put the next run outside of this frame.
        long myPollIntervalInSeconds = 5;
        return currentInstant.plusSeconds(myPollIntervalInSeconds * 3);
    }

    @Override
    public String asString() {
        return CustomScheduleTestImplementation.class.getName() + "(" + input + ")";
    }
}


