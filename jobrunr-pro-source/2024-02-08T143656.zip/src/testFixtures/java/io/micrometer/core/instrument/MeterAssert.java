package io.micrometer.core.instrument;

import io.micrometer.core.instrument.cumulative.CumulativeCounter;
import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

public class MeterAssert extends AbstractAssert<MeterAssert, Meter> {
    protected MeterAssert(Meter meter) {
        super(meter, MeterAssert.class);
    }

    public static MeterAssert assertThat(Meter meter) {
        return new MeterAssert(meter);
    }

    public MeterAssert hasIdWithTag(String tagName, String tagValue) {
        Assertions.assertThat(actual.getId().getTag(tagName))
                .describedAs("Could not find tag " + tagName + " on meter with id " + actual.getId())
                .isNotNull()
                .isEqualTo(tagValue);
        return this;
    }

    public MeterAssert hasValue(double value) {
        if (actual instanceof CumulativeCounter) {
            Assertions.assertThat(((CumulativeCounter) actual).count()).isEqualTo(value);
        } else {
            throw new UnsupportedOperationException("Meter " + actual + " does not support value assertion.");
        }
        return this;
    }
}
