package io.opentelemetry.sdk.trace.data;

import io.opentelemetry.api.common.AttributeKey;
import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

public class SpanDataAssert extends AbstractAssert<SpanDataAssert, SpanData> {

    protected SpanDataAssert(SpanData spanData) {
        super(spanData, SpanDataAssert.class);
    }

    public static SpanDataAssert assertThat(SpanData spanData) {
        return new SpanDataAssert(spanData);
    }

    public SpanDataAssert hasAttribute(String attributeKey) {
        Assertions.assertThat(actual.getAttributes().get(AttributeKey.stringKey(attributeKey))).isNotNull();
        return this;
    }

    public SpanDataAssert hasAttribute(String attributeKey, String value) {
        Assertions.assertThat(actual.getAttributes().get(AttributeKey.stringKey(attributeKey))).isEqualTo(value);
        return this;
    }


    public SpanDataAssert hasEvent(String s) {
        Assertions.assertThat(actual.getEvents().stream().filter(e -> s.equals(e.getName())).findFirst()).isPresent();
        return this;
    }
}
