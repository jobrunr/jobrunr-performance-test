package org.jobrunr.dashboard;

import org.jobrunr.SevereJobRunrException;
import org.jobrunr.dashboard.integrations.GitHubIssueTrackingIntegration;
import org.jobrunr.dashboard.integrations.JaegerObservabilityIntegration;
import org.jobrunr.dashboard.server.http.client.TeenyHttpClient;
import org.jobrunr.dashboard.ui.model.RegressionJobDetailsModels;
import org.jobrunr.dashboard.ui.model.problems.SevereJobRunrExceptionProblem;
import org.jobrunr.jobs.BatchJob;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.scheduling.cron.Cron;
import org.jobrunr.server.strategy.LabelPrefixDynamicQueueProvider;
import org.jobrunr.storage.BackgroundJobServerStatus;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.JobRunrMetadata;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.Paging;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.FreePortFinder;
import org.jobrunr.utils.mapper.JsonMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static java.util.Arrays.asList;
import static java.util.UUID.randomUUID;
import static java.util.concurrent.TimeUnit.SECONDS;
import static java.util.stream.Collectors.joining;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.dashboard.JobRunrDashboardWebServerConfiguration.usingStandardDashboardConfiguration;
import static org.jobrunr.jobs.BatchJobTestBuilder.anEnqueuedBatchJob;
import static org.jobrunr.jobs.JobAssert.scheduledAt;
import static org.jobrunr.jobs.JobDetailsTestBuilder.defaultJobDetails;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJobWithRetries;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.aScheduledJob;
import static org.jobrunr.jobs.JobTestBuilder.aSucceededJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.RecurringJobTestBuilder.aDefaultRecurringJob;
import static org.jobrunr.jobs.states.StateName.DELETED;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.PROCESSING;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;
import static org.jobrunr.jobs.states.StateName.SUCCEEDED;
import static org.jobrunr.storage.BackgroundJobServerStatusTestBuilder.aDefaultBackgroundJobServerStatus;
import static org.jobrunr.storage.JobSearchRequestBuilder.aJobSearchRequest;
import static org.jobrunr.storage.RecurringJobSearchRequestBuilder.aRecurringJobSearchRequest;
import static org.jobrunr.stubs.TestService.DefaultQueue;
import static org.jobrunr.stubs.TestService.HighPrioQueue;
import static org.jobrunr.stubs.TestService.LowPrioQueue;

public abstract class JobRunrDashboardWebServerTest {

    protected StorageProvider storageProvider;

    protected JobRunrDashboardWebServer dashboardWebServer;
    protected TeenyHttpClient http;

    protected abstract JsonMapper getJsonMapper();

    @BeforeEach
    protected void setUpWebServerAndClient() {
        int port = FreePortFinder.nextFreePort(8000);
        final JsonMapper jsonMapper = getJsonMapper();
        storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(jsonMapper));
        setUpWebServerAndClient(port, storageProvider, jsonMapper);
    }

    @AfterEach
    protected void stopWebServer() {
        dashboardWebServer.stop();
        storageProvider.close();
    }

    @Test
    void testGetFeatures() {
        HttpResponse<String> getResponse = http.get("/api/features");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasJsonBody(jb -> {
                    jb.inPath("dynamicQueues.title").isEqualTo("Tenants");
                    jb.inPath("observability").isEqualTo("Jaeger");
                    jb.inPath("issue-tracking").isEqualTo("GitHub issue");
                });
    }

    @Test
    void testGetDynamicQueueStats() {
        storageProvider.save(anEnqueuedJob().build());
        storageProvider.save(anEnqueuedJob().withLabels("tenant: Tenant-A").withDynamicQueue("Tenant-A").build());

        HttpResponse<String> getResponse = http.get("/api/dynamic-queues/stats");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/dynamic-queues.json");
    }

    @Test
    void testGetJobById_ForEnqueuedJob() {
        final Job job = anEnqueuedJobWithName().build();
        final Job savedJob = storageProvider.save(job);

        HttpResponse<String> getResponse = http.get("/api/jobs/%s", savedJob.getId());
        assertThat(getResponse).hasStatusCode(200);
    }

    @Test
    void testGetJobById_ForFailedJob() {
        final Job job = aFailedJobWithRetries().build();
        final Job savedJob = storageProvider.save(job);

        HttpResponse<String> getResponse = http.get("/api/jobs/%s", savedJob.getId());
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getJobById_ForFailedJob.json");
    }

    @Test
    void testRequeueJob() {
        final Job job = aFailedJobWithRetries().build();
        final Job savedJob = storageProvider.save(job);

        HttpResponse<String> requeue = http.post("/api/jobs/%s/requeue", savedJob.getId());
        assertThat(requeue).hasStatusCode(204);

        assertThat(storageProvider.getJobById(job.getId())).hasState(ENQUEUED);
    }

    @Test
    void testRequeueFailedJobsImmediately() {
        // GIVEN
        List<Job> jobs = failedJobs(5);

        // WHEN
        HttpResponse<String> requeueResponse = http.post("/api/jobs/requeue?jobIds=%s", getJobIdsAsCommaSeperatedString(jobs));

        // THEN
        assertThat(requeueResponse).hasStatusCode(204);
        jobs.forEach(job -> assertThat(storageProvider.getJobById(job.getId())).hasState(ENQUEUED));
    }

    @Test
    void testRescheduleFailedJobsSpreadOutOverTime() {
        // GIVEN
        List<Job> jobs = failedJobs(5);

        // WHEN
        HttpResponse<String> requeueResponse = http.post("/api/jobs/requeue?schedule-delta=10000&jobIds=%s", getJobIdsAsCommaSeperatedString(jobs));

        // THEN
        assertThat(requeueResponse).hasStatusCode(204);
        jobs.forEach(job -> assertThat(storageProvider.getJobById(job.getId())).hasState(SCHEDULED));

        Job job3 = storageProvider.getJobById(jobs.get(3).getId());
        Job job4 = storageProvider.getJobById(jobs.get(4).getId());
        Instant job3ScheduledAt = ((ScheduledState) job3.getJobState()).getScheduledAt();

        assertThat(job4).has(scheduledAt(job3ScheduledAt.plusMillis(10000)));
    }

    @Test
    void testRescheduleFailedJobsSelectedQueue() {
        // GIVEN
        List<Job> jobs = failedJobs(5);

        // WHEN
        HttpResponse<String> requeueResponse = http.post("/api/jobs/requeue?queue=3&jobIds=%s", getJobIdsAsCommaSeperatedString(jobs));

        // THEN
        assertThat(requeueResponse).hasStatusCode(204);
        jobs.forEach(job -> assertThat(storageProvider.getJobById(job.getId()))
                .hasState(ENQUEUED)
                .hasPriority(3)
        );
    }

    @Test
    void testRequeueALotOfFailedJobsImmediately() {
        // GIVEN
        List<Job> jobs = failedJobs(165);

        // WHEN
        HttpResponse<String> requeue = http.post("/api/jobs/requeue?state=FAILED");

        // THEN
        assertThat(requeue).hasStatusCode(204);
        jobs.forEach(job -> assertThat(storageProvider.getJobById(job.getId())).hasState(ENQUEUED));
    }

    @Test
    void testDeleteJob() {
        final Job job = aFailedJobWithRetries().build();
        final Job savedJob = storageProvider.save(job);

        HttpResponse<String> deleteResponse = http.delete("/api/jobs/%s", savedJob.getId());
        assertThat(deleteResponse).hasStatusCode(204);

        HttpResponse<String> getResponse = http.get("/api/jobs/%s", savedJob.getId());
        assertThat(getResponse).hasStatusCode(200);
        assertThat(storageProvider.getJobById(savedJob.getId()))
                .hasState(DELETED)
                .hasDeletedAtNotNull();
    }

    @Test
    void testGetJobById_JobNotFoundReturns404() {
        HttpResponse<String> getResponse = http.get("/api/jobs/%s", randomUUID());
        assertThat(getResponse).hasStatusCode(404);
    }

    @Test
    void testGetDistinctJobSignatures() {
        storageProvider.save(aScheduledJob().withJobDetails(systemOutPrintLnJobDetails("hello")).build());
        storageProvider.save(anEnqueuedJobWithName().withJobDetails(defaultJobDetails()).build());

        HttpResponse<String> getResponse = http.get("/api/job-signatures");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/distinct-job-signatures.json");
    }

    @Test
    void testGetJobExceptionTypes() {
        storageProvider.save(aFailedJob().build());
        storageProvider.save(anEnqueuedJobWithName().withJobDetails(defaultJobDetails()).build());

        HttpResponse<String> getResponse = http.get("/api/job-exception-types");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/job-exception-types.json");
    }

    @Test
    void testFindJobsByState() {
        storageProvider.save(anEnqueuedJobWithName().build());

        HttpResponse<String> getResponse = http.get("/api/jobs?state=ENQUEUED");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/findJobsByState.json");
    }

    @Test
    void testFindJobsBySearchRequest() {
        storageProvider.save(anEnqueuedJobWithName().withMutex("mutex").withServerTag("LINUX").withName("Some name").withPriority(2).build());
        storageProvider.save(aSucceededJob().withMutex("mutex").withServerTag("LINUX").withName("Some name").withPriority(2).build());

        HttpResponse<String> getResponseMatch = http.get("/api/jobs?state=ENQUEUED&mutex=mutex&serverTag=INUX&jobName=some name&priority=2");
        assertThat(getResponseMatch)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/findJobsBySearchRequest.json");

        HttpResponse<String> getResponseNoMatch = http.get("/api/jobs?state=ENQUEUED&mutex=mutex&serverTag=WINDOWS&jobName=other name&priority=2");
        assertThat(getResponseNoMatch)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/noResults.json");
    }

    @Test
    void testFindJobsBySearchRequestAndIds() {
        Job job1 = storageProvider.save(anEnqueuedJobWithName().withMutex("mutex").withServerTag("LINUX").withName("Some name").withPriority(2).build());
        Job job2 = storageProvider.save(aSucceededJob().withMutex("mutex").withServerTag("LINUX").withName("Some name").withPriority(2).build());

        HttpResponse<String> getResponseMatch = http.get("/api/jobs?jobIds=" + job1.getId() + "," + UUID.randomUUID());
        assertThat(getResponseMatch)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/findJobsBySearchRequest.json");
    }


    @Test
    void testDeleteJobsBySearchRequest() {
        final Job job1 = aSucceededJob().withLabels("my-label").build();
        final Job job2 = aSucceededJob().withLabels("my-label").build();
        List<Job> savedJobs = storageProvider.save(asList(job1, job2));

        HttpResponse<String> getResponseBeforeDelete = http.get("/api/jobs?state=SUCCEEDED&label=my-label");
        assertThat(getResponseBeforeDelete)
                .hasStatusCode(200)
                .hasBodyContaining(savedJobs.get(0).getId().toString(), savedJobs.get(1).getId().toString());

        HttpResponse<String> deleteResponse = http.delete("/api/jobs?state=SUCCEEDED&label=my-label");
        assertThat(deleteResponse)
                .hasStatusCode(204);

        HttpResponse<String> getResponseAfterDelete = http.get("/api/jobs?state=SUCCEEDED&label=my-label");
        assertThat(getResponseAfterDelete)
                .hasStatusCode(200)
                .hasBodyContaining("\"items\":[]");

        assertThat(storageProvider.getJobById(job1.getId()))
                .hasState(DELETED)
                .hasDeletedAtNotNull();
        assertThat(storageProvider.getJobById(job2.getId()))
                .hasState(DELETED)
                .hasDeletedAtNotNull();
    }

    @Test
    void testDeleteJobsBySearchRequestUsingIds() {
        final Job job1 = aSucceededJob().withLabels("my-label").build();
        final Job job2 = aSucceededJob().withLabels("my-label").build();
        List<Job> savedJobs = storageProvider.save(asList(job1, job2));

        HttpResponse<String> getResponseBeforeDelete = http.get("/api/jobs?state=SUCCEEDED&jobIds=" + job1.getId() + "," + job2.getId());
        assertThat(getResponseBeforeDelete)
                .hasStatusCode(200)
                .hasBodyContaining(savedJobs.get(0).getId().toString(), savedJobs.get(1).getId().toString());

        HttpResponse<String> deleteResponse = http.delete("/api/jobs?jobIds=" + job1.getId() + "," + job2.getId());
        assertThat(deleteResponse)
                .hasStatusCode(204);

        HttpResponse<String> getResponseAfterDelete = http.get("/api/jobs?state=SUCCEEDED&jobIds=" + job1.getId() + "," + job2.getId());
        assertThat(getResponseAfterDelete)
                .hasStatusCode(200)
                .hasBodyContaining("\"items\":[]");

        assertThat(storageProvider.getJobById(job1.getId()))
                .hasState(DELETED)
                .hasDeletedAtNotNull();
        assertThat(storageProvider.getJobById(job2.getId()))
                .hasState(DELETED)
                .hasDeletedAtNotNull();
    }

    @Test
    void testGetAndDeleteProblem() {
        storageProvider.saveMetadata(new JobRunrMetadata(SevereJobRunrException.class.getSimpleName(), "some id", "some value"));

        HttpResponse<String> getResponseBeforeDelete = http.get("/api/problems");
        assertThat(getResponseBeforeDelete)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/problems-severe-jobrunr-problem.json");


        http.delete("/api/problems/" + SevereJobRunrExceptionProblem.PROBLEM_TYPE);
        HttpResponse<String> getResponseAfterDelete = http.get("/api/problems");
        assertThat(getResponseAfterDelete)
                .hasStatusCode(200)
                .hasJsonBody("[]");
    }

    @Test
    void testGetQueues() {
        HttpResponse<String> getResponse = http.get("/api/priority-queues");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/priority-queues.json");
    }

    @Test
    void testGetBatchJobs() {
        storageProvider.save(anEnqueuedBatchJob().build());

        HttpResponse<String> getResponse = http.get("/api/batch-jobs?state=ENQUEUED");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/findBatchJobsByState.json");
    }

    @Test
    void testGetBatchChildJobs() {
        //GIVEN
        final BatchJob batchJob = (BatchJob) storageProvider.save(anEnqueuedBatchJob().build());

        Job batchChildJob1 = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        storageProvider.save(batchChildJob1);
        Job batchChildJob2 = aJob().withAwaitingBatchJobState(batchJob.getId()).build();
        storageProvider.save(batchChildJob2);

        HttpResponse<String> getResponse = http.get("/api/batch-jobs/" + batchJob.getId() + "/" + StateName.AWAITING);
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getBatchJobChildren.json");
    }


    @Test
    void testGetRecurringJobs() {
        RecurringJob recurringJob1 = aDefaultRecurringJob().withId("recurring-job-1").withName("Generate sales reports").withCronExpression("*/5 * * * * *").build();
        RecurringJob recurringJob2 = aDefaultRecurringJob().withId("recurring-job-2").withName("Import sales data").withCronExpression(Cron.every5minutes()).build();
        storageProvider.saveRecurringJobs(asList(aCopyOf(recurringJob1).build(), aCopyOf(recurringJob2).build())); // aCopyOf as we use InMemoryStorageProvider and it is updated by reference

        HttpResponse<String> getResponse = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobs.json");

        HttpResponse<String> getResponseWithOffsetAndLimit = http.get("/api/recurring-jobs?order=jobName:ASC&offset=0&limit=20");
        assertThat(getResponseWithOffsetAndLimit)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobs.json");

        await().atMost(6, SECONDS).until(() -> {
            Instant nextRunAtBeforeUpdate = recurringJob1.getNextRunAt();
            RecurringJob.updateForDashboard.accept(recurringJob1);
            Instant nextRunAtAfterUpdate = recurringJob1.getNextRunAt();
            return !nextRunAtAfterUpdate.equals(nextRunAtBeforeUpdate);
        });

        HttpResponse<String> getResponseToTestNextRun = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getResponseToTestNextRun).hasJsonBody(json -> json.inPath("items[0].nextRunAt").isEqualTo(recurringJob1.getNextRunAt().toString()));
    }

    @Test
    void testGetRecurringJobsByRecurringJobSearchRequest() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-1").withName("Import sales data").withCronExpression(Cron.every30seconds()).build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-2").withName("Generate sales reports").withCronExpression(Cron.every5minutes()).build());

        HttpResponse<String> getResponse = http.get("/api/recurring-jobs?jobName=import&order=jobName:ASC");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/findRecurringJobsByRecurringJobsSearchRequest.json");
    }

    @Test
    void testPauseResumeAndTriggerRecurringJobByIds() {
        // GIVEN
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-1").withName("Import sales data").withLabels("tenant: Tenant-A").build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-2").withName("Generate sales report").build());

        // WHEN PAUSING
        HttpResponse<String> pauseResponse = http.post("/api/recurring-jobs/pause?ids=recurring-job-1");
        assertThat(pauseResponse)
                .hasStatusCode(204);
        // THEN
        HttpResponse<String> getAfterPauseResponse = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getAfterPauseResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobsAfterPausing.json");

        // WHEN RESUMING
        HttpResponse<String> resumeResponse = http.post("/api/recurring-jobs/resume?ids=recurring-job-1");
        assertThat(resumeResponse)
                .hasStatusCode(204);
        // THEN
        HttpResponse<String> getAfterPauseResuming = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getAfterPauseResuming)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobsAfterResuming.json");

        // WHEN TRIGGERING
        HttpResponse<String> triggerResponse = http.post("/api/recurring-jobs/trigger?ids=recurring-job-1");
        assertThat(triggerResponse)
                .hasStatusCode(204);

        // THEN
        Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withRecurringJobId("recurring-job-1").build(), Paging.OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs)
                .hasItems(1)
                .<Job>hasItem(0, job -> assertThat(job)
                        .hasOneOfTheFollowingStates(ENQUEUED, PROCESSING, SUCCEEDED)
                        .hasRecurringJobId("recurring-job-1")
                        .hasDynamicQueue("Tenant-A"));
    }

    @Test
    void testPauseResumeAndTriggerRecurringJobByRecurringJobSearchRequest() {
        // GIVEN
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-1").withName("Import sales data").withLabels("tenant: Tenant-A").build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-2").withName("Generate sales report").build());

        // WHEN PAUSING
        HttpResponse<String> pauseResponse = http.post("/api/recurring-jobs/pause?jobName=import");
        assertThat(pauseResponse)
                .hasStatusCode(204);
        // THEN
        HttpResponse<String> getAfterPauseResponse = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getAfterPauseResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobsAfterPausing.json");

        // WHEN RESUMING
        HttpResponse<String> resumeResponse = http.post("/api/recurring-jobs/resume?jobName=import");
        assertThat(resumeResponse)
                .hasStatusCode(204);
        // THEN
        HttpResponse<String> getAfterPauseResuming = http.get("/api/recurring-jobs?order=jobName:ASC");
        assertThat(getAfterPauseResuming)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getRecurringJobsAfterResuming.json");

        // WHEN TRIGGERING
        HttpResponse<String> triggerResponse = http.post("/api/recurring-jobs/trigger?jobName=import");
        assertThat(triggerResponse)
                .hasStatusCode(204);
        // THEN
        Page<Job> jobs = storageProvider.getJobs(aJobSearchRequest().withRecurringJobId("recurring-job-1").build(), Paging.OffsetBasedPage.ascOnUpdatedAt(10));
        assertThat(jobs)
                .hasItems(1)
                .<Job>hasItem(0, job -> assertThat(job)
                        .hasOneOfTheFollowingStates(ENQUEUED, PROCESSING, SUCCEEDED)
                        .hasRecurringJobId("recurring-job-1")
                        .hasDynamicQueue("Tenant-A"));
    }

    @Test
    void testEditRecurringJobsWithCron() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("with-schedule-skipped-during-downtime").withScheduleJobsSkippedDuringDowntime().withCronExpression(Cron.daily()).build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("without-schedule-skipped-during-downtime").withIntervalExpression("P1D").build());

        HttpResponse<String> editWithSkippedDuringDownTimeResponse = http.post("/api/recurring-jobs/edit?id=%s&scheduleExpression=*/15+*+*+*+*+*", "with-schedule-skipped-during-downtime");
        HttpResponse<String> editWithoutSkippedDuringDownTimeResponse = http.post("/api/recurring-jobs/edit?id=%s&scheduleExpression=*/15+*+*+*+*+*", "without-schedule-skipped-during-downtime");

        assertThat(editWithSkippedDuringDownTimeResponse)
                .hasStatusCode(500);
        assertThat(storageProvider.getRecurringJobById("with-schedule-skipped-during-downtime"))
                .hasScheduleExpression(Cron.daily())
                .hasUpdatedSchedule(false)
                .hasVersion(1);

        assertThat(editWithoutSkippedDuringDownTimeResponse)
                .hasStatusCode(200);
        assertThat(storageProvider.getRecurringJobById("without-schedule-skipped-during-downtime"))
                .hasScheduleExpression(Cron.every15seconds())
                .hasUpdatedSchedule(true)
                .hasVersion(2);
    }

    @Test
    void testEditRecurringJobsWithDuration() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("with-schedule-skipped-during-downtime").withScheduleJobsSkippedDuringDowntime().withCronExpression(Cron.daily()).build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("without-schedule-skipped-during-downtime").withIntervalExpression("P1D").build());

        HttpResponse<String> editWithSkippedDuringDownTimeResponse = http.post("/api/recurring-jobs/edit?id=%s&scheduleExpression=PT15S", "with-schedule-skipped-during-downtime");
        HttpResponse<String> editWithoutSkippedDuringDownTimeResponse = http.post("/api/recurring-jobs/edit?id=%s&scheduleExpression=PT15S", "without-schedule-skipped-during-downtime");

        assertThat(editWithSkippedDuringDownTimeResponse)
                .hasStatusCode(500);
        assertThat(storageProvider.getRecurringJobById("with-schedule-skipped-during-downtime"))
                .hasScheduleExpression(Cron.daily())
                .hasUpdatedSchedule(false)
                .hasVersion(1);

        assertThat(editWithoutSkippedDuringDownTimeResponse)
                .hasStatusCode(200);
        assertThat(storageProvider.getRecurringJobById("without-schedule-skipped-during-downtime"))
                .hasScheduleExpression(Duration.ofSeconds(15).toString())
                .hasUpdatedSchedule(true)
                .hasVersion(2);
    }

    @Test
    void testEditRecurringJobsWithInvalidExpression() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("a-recurring-job").build());

        HttpResponse<String> invalidScheduleResponse = http.post("/api/recurring-jobs/edit?id=%s&scheduleExpression=invalid", "a-recurring-job");

        assertThat(invalidScheduleResponse)
                .hasStatusCode(500);
        assertThat(storageProvider.getRecurringJobById("a-recurring-job"))
                .hasUpdatedSchedule(false)
                .hasVersion(1);
    }

    @Test
    void testDeleteRecurringJob() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-1").withName("Import sales data").build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("recurring-job-2").withName("Generate sales reports").build());

        HttpResponse<String> deleteResponse = http.delete("/api/recurring-jobs?ids=%s", "recurring-job-1");
        assertThat(deleteResponse).hasStatusCode(204);
        assertThat(storageProvider.countRecurringJobs(aRecurringJobSearchRequest().build())).isEqualTo(1L);
    }

    @Test
    void testGetDistinctRecurringJobSignatures() {
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("rj-1").withJobDetails(systemOutPrintLnJobDetails("hello")).build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().withId("rj-2").withJobDetails(defaultJobDetails()).build());

        HttpResponse<String> getResponse = http.get("/api/recurring-job-signatures");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/distinct-recurring-job-signatures.json");
    }

    @Test
    void testGetBackgroundJobServers() {
        final BackgroundJobServerStatus serverStatus = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus);

        HttpResponse<String> getResponse = http.get("/api/servers");
        assertThat(getResponse)
                .hasStatusCode(200)
                .hasSameJsonBodyAsResource("/dashboard/api/getBackgroundJobServers.json");
    }

    @Test
    void testPauseAndResumeBackgroundJobProcessing() {
        // GIVEN
        final BackgroundJobServerStatus serverStatus1 = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        final BackgroundJobServerStatus serverStatus2 = aDefaultBackgroundJobServerStatus().withIsStarted().build();
        storageProvider.announceBackgroundJobServer(serverStatus1);
        storageProvider.announceBackgroundJobServer(serverStatus2);

        // WHEN
        HttpResponse<String> pauseResponse = http.post("/api/servers/%s/pause", serverStatus1.getId());
        assertThat(pauseResponse).hasStatusCode(200);

        // THEN
        BackgroundJobServerStatus pausedServerStatus1 = storageProvider.getBackgroundJobServers().stream().filter(x -> x.getId().equals(serverStatus1.getId())).findFirst().orElseThrow();
        assertThat(pausedServerStatus1).isPaused();

        // WHEN
        HttpResponse<String> resumeResponse = http.post("/api/servers/%s/resume", serverStatus1.getId());
        assertThat(resumeResponse).hasStatusCode(200);

        // THEN
        BackgroundJobServerStatus processingServerStatus1 = storageProvider.getBackgroundJobServers().stream().filter(x -> x.getId().equals(serverStatus1.getId())).findFirst().orElseThrow();
        assertThat(processingServerStatus1).isProcessing();

        // WHEN
        HttpResponse<String> pauseAllResponse = http.post("/api/servers/pause");
        assertThat(pauseAllResponse).hasStatusCode(200);

        // THEN
        List<BackgroundJobServerStatus> pausedBackgroundJobServers = storageProvider.getBackgroundJobServers();
        assertThat(pausedBackgroundJobServers.get(0)).isPaused();
        assertThat(pausedBackgroundJobServers.get(1)).isPaused();

        // WHEN
        HttpResponse<String> resumeAllResponse = http.post("/api/servers/resume");
        assertThat(resumeAllResponse).hasStatusCode(200);

        // THEN
        List<BackgroundJobServerStatus> resumedBackgroundJobServers = storageProvider.getBackgroundJobServers();
        assertThat(resumedBackgroundJobServers.get(0)).isProcessing();
        assertThat(resumedBackgroundJobServers.get(1)).isProcessing();
    }

    @Test
    void testGetJobTypes() {
        storageProvider.save(aScheduledJob().withJobDetails(systemOutPrintLnJobDetails("hello")).build());
        storageProvider.save(anEnqueuedJobWithName().withJobDetails(defaultJobDetails()).build());
        storageProvider.saveRecurringJob(aDefaultRecurringJob().build());

        HttpResponse<String> getJobResponse = http.get("/api/testing/job-types");
        RegressionJobDetailsModels jobTypes = getJsonMapper().deserialize(getJobResponse.body(), RegressionJobDetailsModels.class);
        assertThat(jobTypes).hasSize(3);
    }

    @Test
    void testIntegration() {
        Job job = anEnqueuedJobWithName()
                .withMetadata("traceId", "trace-id-value")
                .build();
        storageProvider.save(job);

        HttpResponse<String> getResponse = http.get("/api/integration?name=Jaeger&id=" + job.getId());
        assertThat(getResponse)
                .hasStatusCode(302)
                .hasHeaderValueContaining("location", "http://not-important/trace/trace-id-value");
    }

    protected void setUpWebServerAndClient(int port, StorageProvider storageProvider, JsonMapper jsonMapper) {
        this.storageProvider = storageProvider;
        dashboardWebServer = setUpWebServer(jsonMapper, port);
        http = setupHttpClient(port);
    }

    protected JobRunrDashboardWebServer setUpWebServer(JsonMapper jsonMapper, int port) {
        JobRunrDashboardWebServerConfiguration configuration = usingStandardDashboardConfiguration()
                .andPort(port)
                .andDynamicQueueConfiguration("Tenants", "tenant: ")
                .andIntegration(
                        new JaegerObservabilityIntegration("http://not-important"),
                        new GitHubIssueTrackingIntegration("org", "repo")
                );
        JobRunrDashboardWebServer dashboardWebServer = new JobRunrDashboardWebServer(configuration, storageProvider, null, jsonMapper, new Queues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue));
        dashboardWebServer.setJobFilters(asList(new LabelPrefixDynamicQueueProvider("tenant", ":")));
        dashboardWebServer.start();
        return dashboardWebServer;
    }

    protected TeenyHttpClient setupHttpClient(int port) {
        return new TeenyHttpClient("http://localhost:" + port);
    }


    private List<Job> failedJobs(int amount) {
        List<Job> failedJobs = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            failedJobs.add(aFailedJobWithRetries().build());
        }
        storageProvider.save(failedJobs);
        return failedJobs;
    }

    private static String getJobIdsAsCommaSeperatedString(List<Job> jobs) {
        return jobs.stream().map(job -> job.getId().toString()).collect(joining(","));
    }
}