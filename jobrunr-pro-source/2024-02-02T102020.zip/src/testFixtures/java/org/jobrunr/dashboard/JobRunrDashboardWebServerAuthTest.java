package org.jobrunr.dashboard;

import org.jobrunr.dashboard.integrations.GitHubIssueTrackingIntegration;
import org.jobrunr.dashboard.integrations.JaegerObservabilityIntegration;
import org.jobrunr.dashboard.server.http.client.TeenyHttpClient;
import org.jobrunr.dashboard.server.security.AuthenticationProvider;
import org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRules;
import org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRulesBuilder;
import org.jobrunr.dashboard.server.security.basic.BasicAuthenticationProvider;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.StateName;
import org.jobrunr.server.strategy.LabelPrefixDynamicQueueProvider;
import org.jobrunr.storage.InMemoryStorageProvider;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.utils.FreePortFinder;
import org.jobrunr.utils.mapper.JsonMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static java.lang.String.format;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.dashboard.JobRunrDashboardWebServerConfiguration.usingStandardDashboardConfiguration;
import static org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRules.allowAll;
import static org.jobrunr.dashboard.server.security.JobRunrUserAuthorizationRules.denyAll;
import static org.jobrunr.stubs.TestService.*;
import static org.junit.jupiter.params.provider.Arguments.arguments;

public abstract class JobRunrDashboardWebServerAuthTest {
    private static final String GET = "GET";
    private static final String POST = "POST";
    private static final String DELETE = "DELETE";

    protected static final String USERNAME = "mr-test";
    protected static final String PASSWORD = "testing";

    protected StorageProvider storageProvider;

    protected JobRunrDashboardWebServer dashboardWebServer;
    protected TeenyHttpClient http;

    protected abstract JsonMapper getJsonMapper();

    @AfterEach
    protected void stopWebServer() {
        dashboardWebServer.stop();
        storageProvider.close();
    }

    public static Stream<Arguments> getInputAndExpectedResult() {
        return Stream.of(
                arguments(GET, "/api/features", allowAll(), 200),
                arguments(GET, "/api/features", denyAll(), 403),
                arguments(GET, "/api/dynamic-queues/stats", allowAll(), 200),
                arguments(GET, "/api/dynamic-queues/stats", denyAll(), 403),
                arguments(GET, "/api/jobs", allowAll(), 200),
                arguments(GET, "/api/jobs", denyAll(), 403),
                arguments(GET, format("/api/jobs/%s", UUID.randomUUID()), allowAll(), 404),
                arguments(GET, format("/api/jobs/%s", UUID.randomUUID()), denyAll(), 403),
                arguments(POST, format("/api/jobs/%s/requeue", UUID.randomUUID()), allowAll(), 404),
                arguments(POST, format("/api/jobs/%s/requeue", UUID.randomUUID()), denyAll(), 403),
                arguments(POST, format("/api/jobs/requeue?jobIds=%s,%s", UUID.randomUUID(), UUID.randomUUID()), allowAll(), 204),
                arguments(POST, format("/api/jobs/requeue?jobIds=%s,%s", UUID.randomUUID(), UUID.randomUUID()), denyAll(), 403),
                arguments(DELETE, format("/api/jobs/%s", UUID.randomUUID()), allowAll(), 404),
                arguments(DELETE, format("/api/jobs/%s", UUID.randomUUID()), denyAll(), 403),
                arguments(DELETE, format("/api/jobs?jobIds=%s,%s", UUID.randomUUID(), UUID.randomUUID()), allowAll(), 204),
                arguments(DELETE, format("/api/jobs?jobIds=%s,%s", UUID.randomUUID(), UUID.randomUUID()), denyAll(), 403),
                arguments(GET, "/api/job-signatures", allowAll(), 200),
                arguments(GET, "/api/job-signatures", denyAll(), 403),
                arguments(GET, "/api/job-exception-types", allowAll(), 200),
                arguments(GET, "/api/job-exception-types", denyAll(), 403),
                arguments(DELETE, "/api/problems/some-problem", allowAll(), 500),
                arguments(DELETE, "/api/problems/some-problem", denyAll(), 500),
                arguments(GET, "/api/priority-queues", allowAll(), 200),
                arguments(GET, "/api/priority-queues", denyAll(), 200),
                arguments(GET, "/api/batch-jobs?state=ENQUEUED", allowAll(), 200),
                arguments(GET, "/api/batch-jobs?state=ENQUEUED", denyAll(), 403),
                arguments(GET, format("/api/batch-jobs/%s/%s", UUID.randomUUID(), StateName.AWAITING), allowAll(), 200),
                arguments(GET, format("/api/batch-jobs/%s/%s", UUID.randomUUID(), StateName.AWAITING), denyAll(), 403),
                arguments(GET, "/api/recurring-jobs?order=jobName:ASC", allowAll(), 200),
                arguments(GET, "/api/recurring-jobs?order=jobName:ASC", denyAll(), 403),
                arguments(POST, "/api/recurring-jobs/pause?ids=recurring-job-1", allowAll(), 204),
                arguments(POST, "/api/recurring-jobs/pause?ids=recurring-job-1", denyAll(), 403),
                arguments(POST, "/api/recurring-jobs/resume?ids=recurring-job-1", allowAll(), 204),
                arguments(POST, "/api/recurring-jobs/resume?ids=recurring-job-1", denyAll(), 403),
                arguments(POST, "/api/recurring-jobs/trigger?ids=recurring-job-1", allowAll(), 204),
                arguments(POST, "/api/recurring-jobs/trigger?ids=recurring-job-1", denyAll(), 403),
                arguments(POST, format("/api/recurring-jobs/edit?id=%s&scheduleExpression=*/15+*+*+*+*+*", "with-schedule-skipped-during-downtime"), allowAll(), 500),
                arguments(POST, format("/api/recurring-jobs/edit?id=%s&scheduleExpression=*/15+*+*+*+*+*", "with-schedule-skipped-during-downtime"), denyAll(), 403),
                arguments(GET, "/api/recurring-job-signatures", allowAll(), 200),
                arguments(GET, "/api/recurring-job-signatures", denyAll(), 403),
                arguments(GET, "/api/servers", allowAll(), 200),
                arguments(GET, "/api/servers", denyAll(), 403),
                arguments(POST, format("/api/servers/%s/pause", UUID.randomUUID()), allowAll(), 500),
                arguments(POST, format("/api/servers/%s/pause", UUID.randomUUID()), denyAll(), 403),
                arguments(POST, "/api/servers/pause", allowAll(), 200),
                arguments(POST, "/api/servers/pause", denyAll(), 403),
                arguments(POST, format("/api/servers/%s/resume", UUID.randomUUID()), allowAll(), 500),
                arguments(POST, format("/api/servers/%s/resume", UUID.randomUUID()), denyAll(), 403),
                arguments(POST, "/api/servers/resume", allowAll(), 200),
                arguments(POST, "/api/servers/resume", denyAll(), 403),
                arguments(GET, "/api/testing/job-types", allowAll(), 200),
                arguments(GET, "/api/testing/job-types", JobRunrUserAuthorizationRulesBuilder.denyAll().canAccessJobs(true).build(), 403),
                arguments(GET, "/api/testing/job-types", JobRunrUserAuthorizationRulesBuilder.denyAll().canAccessRecurringJobs(true).build(), 403),
                arguments(GET, "/api/integration?name=Jaeger&id=an-identifier", allowAll(), 500),
                arguments(GET, "/api/integration?name=Jaeger&id=an-identifier", denyAll(), 500),
                arguments(GET, "/api/current-user", allowAll(), 200),
                arguments(GET, "/api/current-user", denyAll(), 200)
        );
    }

    @ParameterizedTest
    @MethodSource("getInputAndExpectedResult")
    protected void doTest(String method, String url, JobRunrUserAuthorizationRules authorizationRules, int httpStatusCode) {
        setUpWebServerAndClient(authorizationRules);
        if (GET.equals(method)) {
            doGet(url, httpStatusCode);
        } else if (POST.equals(method)) {
            doPost(url, httpStatusCode);
        } else if (DELETE.equals(method)) {
            doDelete(url, httpStatusCode);
        } else {
            throw new IllegalArgumentException("Unknown HTTP verb");
        }
    }

    protected void setUpWebServerAndClient(JobRunrUserAuthorizationRules authorizationRules) {
        int port = FreePortFinder.nextFreePort(8000);
        final JsonMapper jsonMapper = getJsonMapper();
        storageProvider = new InMemoryStorageProvider();
        storageProvider.setJobMapper(new JobMapper(jsonMapper));
        setUpWebServerAndClient(port, storageProvider, jsonMapper, authorizationRules);
    }

    protected void doGet(String url, int httpStatusCode) {
        HttpResponse<String> getResponse = http.get(url);
        assertThat(getResponse)
                .hasStatusCode(httpStatusCode);
    }

    protected void doPost(String url, int httpStatusCode) {
        HttpResponse<String> postResponse = http.post(url);
        assertThat(postResponse)
                .hasStatusCode(httpStatusCode);
    }

    protected void doDelete(String url, int httpStatusCode) {
        HttpResponse<String> deleteResponse = http.delete(url);
        assertThat(deleteResponse)
                .hasStatusCode(httpStatusCode);
    }

    protected void setUpWebServerAndClient(int port, StorageProvider storageProvider, JsonMapper jsonMapper, JobRunrUserAuthorizationRules authorizationRules) {
        this.storageProvider = storageProvider;
        dashboardWebServer = setUpWebServer(jsonMapper, port, authorizationRules);
        http = setupHttpClient(port);
    }

    protected JobRunrDashboardWebServer setUpWebServer(JsonMapper jsonMapper, int port, JobRunrUserAuthorizationRules authorizationRules) {
        JobRunrDashboardWebServerConfiguration configuration = usingStandardDashboardConfiguration()
                .andPort(port)
                .andDynamicQueueConfiguration("Tenants", "tenant: ")
                .andAuthentication(authenticationProvider(authorizationRules))
                .andIntegration(
                        new JaegerObservabilityIntegration("http://not-important"),
                        new GitHubIssueTrackingIntegration("org", "repo")
                );
        JobRunrDashboardWebServer dashboardWebServer = new JobRunrDashboardWebServer(configuration, storageProvider, null, jsonMapper, new Queues(DefaultQueue, HighPrioQueue, DefaultQueue, LowPrioQueue));
        dashboardWebServer.setJobFilters(List.of(new LabelPrefixDynamicQueueProvider("tenant", ":")));
        dashboardWebServer.start();
        return dashboardWebServer;
    }

    protected TeenyHttpClient setupHttpClient(int port) {
        return setHttpClientHeaders(new TeenyHttpClient("http://localhost:" + port));
    }

    protected TeenyHttpClient setHttpClientHeaders(TeenyHttpClient teenyHttpClient) {
        return teenyHttpClient.withHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString(format("%s:%s", USERNAME, PASSWORD).getBytes(StandardCharsets.UTF_8)));
    }

    protected AuthenticationProvider authenticationProvider(JobRunrUserAuthorizationRules authorizationRules) {
        return new BasicAuthenticationProvider(USERNAME, PASSWORD, authorizationRules);
    }
}
