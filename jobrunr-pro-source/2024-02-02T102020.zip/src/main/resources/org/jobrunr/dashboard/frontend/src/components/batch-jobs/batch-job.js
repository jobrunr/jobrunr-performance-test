import BatchSidebar from "./sidebar";
import JobView from "../jobs/job-view";

const BatchJob = (props) => {
    return (
        <div style={{display: "flex"}}>
            <BatchSidebar {...props} />
            <JobView {...props} />
        </div>
    );
}
export default BatchJob;