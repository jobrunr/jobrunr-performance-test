import {useContext, useState} from 'react';
import {Link, useLocation, useNavigate} from "react-router-dom";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TablePagination from '@mui/material/TablePagination';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TimeAgo from "react-timeago/lib";
import {styled} from '@mui/material/styles';
import LoadingIndicator from "../LoadingIndicator";
import {prefixWithPublicUrl} from "../../utils/helper-functions";
import Checkbox from "@mui/material/Checkbox";
import Grid from "@mui/material/Grid";
import {allItemsSelected, selectAllItems, selectedItems, selectItem} from "../utils/job-selections";
import {Actions} from "./actions/actions";
import {capitalize} from "../utils/string-utils";
import JobLabel from "../utils/job-label";
import {UserContext} from "../../UserContext";
import {ItemsNotFound} from "../utils/items-not-found";
import {ColoredLinearProgress} from "../ui/ColoredLinearProgress";

const IdColumn = styled(TableCell)`
    width: 20%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
`;

const BatchJobsTable = ({isLoading, jobPage, jobState}) => {
    const location = useLocation();
    const navigate = useNavigate();
    const [jobs, setJobs] = useState(jobPage.items.map(job => ({...job, selected: false})));
    const {authorizationRules: {canDeleteJobs, canEnqueueJobs}} = useContext(UserContext);
    const showDeleteButton = !(['DELETED'].includes(jobState)) && canDeleteJobs;
    const showEnqueueButton = !(['AWAITING', 'ENQUEUED'].includes(jobState)) && canEnqueueJobs;
    const hasWriteAccess = showDeleteButton || showEnqueueButton;

    let column = capitalize(jobState);
    let columnFunction = (job) => job.jobHistory[job.jobHistory.length - 1].createdAt;
    switch (jobState) {
        case 'AWAITING':
            column = 'Created';
            break;
        case 'SCHEDULED':
            columnFunction = (job) => job.jobHistory[job.jobHistory.length - 1].scheduledAt;
            break;
        case 'PROCESSING':
            column = "Started";
            break;
        default:
        // code block
    }

    const getProgressBar = (batchJob) => {
        let progressBar = {progress: 0};
        for (let key in batchJob.metadata) {
            if (key.indexOf('jobRunrDashboardProgressBar-') > -1) {
                progressBar = batchJob.metadata[key];
            }
        }
        return progressBar;
    }

    const handleChangePage = (event, newPage) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.set("page", newPage);
        navigate(`?${urlSearchParams.toString()}`);
    };

    const handleChangeRowsPerPage = (event) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.set("itemsPerPage", event.target.value);
        navigate(`?${urlSearchParams.toString()}`);
    }

    return <> {isLoading
        ? <LoadingIndicator/>
        : <> {jobPage.items < 1
            ? <ItemsNotFound id="no-jobs-found-message">No batch jobs found.</ItemsNotFound>
            : <>
                <Grid item xs={12} container style={{minHeight: "60px"}}>
                    <Grid item xs={6}>
                        {hasWriteAccess &&
                            <Actions selectedState={jobState}
                                     allJobsSelected={allItemsSelected(jobs)}
                                     selectedJobs={selectedItems(jobs)}
                                     pageSize={jobPage.limit}
                                     showDeleteButton={showDeleteButton}
                                     showEnqueueButton={showEnqueueButton}
                            />
                        }
                    </Grid>
                    <Grid item xs={6}>
                        <TablePagination
                            id="jobs-table-pagination-header"
                            component="div"
                            style={{marginTop: '0.5rem'}}
                            rowsPerPageOptions={[20, 50, 100]}
                            count={jobPage.total}
                            rowsPerPage={jobPage.limit}
                            page={jobPage.currentPage}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                        />
                    </Grid>
                </Grid>
                <TableContainer>
                    <Table id="jobs-table" style={{width: "100%"}} aria-label="jobs table">
                        <TableHead>
                            <TableRow>
                                {hasWriteAccess &&
                                    <TableCell padding="checkbox">
                                        <Checkbox checked={allItemsSelected(jobs)}
                                                  onClick={evt => selectAllItems(evt, setJobs, jobs)}/>
                                    </TableCell>
                                }
                                <IdColumn>Id</IdColumn>
                                <TableCell style={{width: "60%"}}>Job name</TableCell>
                                <TableCell>Progress</TableCell>
                                <TableCell>{column}</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {jobs.map(batchJob => (
                                <TableRow key={batchJob.id}>
                                    {hasWriteAccess &&
                                        <TableCell padding="checkbox">
                                            <Checkbox checked={batchJob.selected}
                                                      onClick={() => selectItem(batchJob, setJobs, jobs)}/>
                                        </TableCell>
                                    }
                                    <IdColumn component="th" scope="row">
                                        <Link to={prefixWithPublicUrl(`/batch-jobs/${batchJob.id}`)}
                                              state={{job: batchJob}}>
                                            {batchJob.id}
                                        </Link>
                                    </IdColumn>
                                    <TableCell>
                                        {batchJob.labels?.length > 0 &&
                                            <>
                                                {batchJob.labels.map((label) => <JobLabel key={label}
                                                                                          to={prefixWithPublicUrl(`/jobs?label=${label}`)}
                                                                                          text={label}/>)}
                                                <span style={{marginRight: '0.5rem'}}></span>
                                            </>
                                        }
                                        <Link to={prefixWithPublicUrl(`/batch-jobs/${batchJob.id}`)}
                                              state={{job: batchJob}}>
                                            {batchJob.jobName}
                                        </Link>
                                    </TableCell>
                                    <TableCell>
                                        <ColoredLinearProgress variant="determinate"
                                                               value={getProgressBar(batchJob).progress}/>
                                    </TableCell>
                                    <TableCell>
                                        <Link to={prefixWithPublicUrl(`/batch-jobs/${batchJob.id}`)}
                                              state={{job: batchJob}}>
                                            <TimeAgo date={new Date(columnFunction(batchJob))}
                                                     title={new Date(columnFunction(batchJob)).toString()}/>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    id="jobs-table-pagination"
                    component="div"
                    rowsPerPageOptions={[20, 50, 100]}
                    count={jobPage.total}
                    rowsPerPage={jobPage.limit}
                    page={jobPage.currentPage}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </>
        }
        </>
    }
    </>;
}

export default BatchJobsTable;