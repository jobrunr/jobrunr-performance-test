import {Fragment, useContext, useState} from 'react';
import {Link, useLocation, useNavigate} from "react-router-dom";
import {Link as UILink, TableSortLabel} from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TablePagination from '@mui/material/TablePagination';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TimeAgo from "react-timeago/lib";
import {styled} from '@mui/material/styles';
import LoadingIndicator from "../LoadingIndicator";
import {prefixWithPublicUrl} from "../../utils/helper-functions";
import Checkbox from "@mui/material/Checkbox";
import Grid from "@mui/material/Grid";
import {allItemsSelected, selectAllItems, selectedItems, selectItem} from "../utils/job-selections";
import {JobActions} from "./actions/job-actions";
import {capitalize} from "../utils/string-utils";
import {jobStateToHumanReadableName} from "../utils/job-utils";
import JobLabel from "../utils/job-label";
import {UserContext} from "../../UserContext";
import {ItemsNotFound} from "../utils/items-not-found";

const IdColumn = styled(TableCell)`
    width: 20%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
`;

const jobStateColumnInfo = (location, navigate, jobState) => {
    const urlSearchParams = new URLSearchParams(location.search);
    const sortQueryParam = urlSearchParams.get('sort') || '';

    const handleSort = (newSort) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.delete('page');
        urlSearchParams.set('sort', newSort);
        navigate(`?${urlSearchParams.toString()}`);
    };

    return {
        column1: {
            name: "Job name",
            isSorted: sortQueryParam.startsWith('jobName'),
            order: sortQueryParam.endsWith('ASC') ? 'asc' : 'desc',
            sortOnClick: () => sortQueryParam.includes('jobName:ASC') ? handleSort('jobName:DESC') : handleSort('jobName:ASC'),
        },
        column2: {
            name: jobState === 'AWAITING' ? 'Created' : jobState === 'PROCESSING' ? 'Started' : capitalize(jobState),
            isSorted: !sortQueryParam.startsWith('jobName'),
            order: sortQueryParam.includes('ASC') ? 'asc' : 'desc',
            sortOnClick: () => {
                if (jobState === 'ENQUEUED') return !sortQueryParam.includes('ASC') ? handleSort('priority:ASC,updatedAt:ASC') : handleSort('updatedAt:DESC');
                else if (jobState === 'SCHEDULED') return !sortQueryParam.includes('ASC') ? handleSort('scheduledAt:ASC') : handleSort('scheduledAt:DESC');
                else !sortQueryParam.includes('ASC') ? handleSort('updatedAt:ASC') : handleSort('updatedAt:DESC')
            },
            valueFunction: jobState === 'SCHEDULED'
                ? (job) => job.jobHistory[job.jobHistory.length - 1].scheduledAt
                : (job) => job.jobHistory[job.jobHistory.length - 1].createdAt
        },
    }
};

const JobsTable = (props) => {
    const location = useLocation();
    const navigate = useNavigate();
    const isLoading = props.isLoading;
    const jobPage = props.jobPage;
    const jobState = props.jobState;
    const [jobs, setJobs] = useState(jobPage.items.map(job => ({...job, selected: false})));

    const columnInfo = jobStateColumnInfo(location, navigate, jobState.toUpperCase());
    const {authorizationRules: {canAccessUnredactedJobs, canDeleteJobs, canEnqueueJobs}} = useContext(UserContext);
    const showDeleteButton = !(['DELETED'].includes(jobState)) && canDeleteJobs;
    const showEnqueueButton = !(['AWAITING', 'ENQUEUED'].includes(jobState)) && canEnqueueJobs;
    const hasWriteAccess = showDeleteButton || showEnqueueButton;

    const handleChangePage = (event, newPage) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.set('page', newPage);
        navigate(`?${urlSearchParams.toString()}`);
    };

    const handleChangeRowsPerPage = (event) => {
        let urlSearchParams = new URLSearchParams(location.search);
        urlSearchParams.delete('action');
        urlSearchParams.set('itemsPerPage', event.target.value);
        navigate(`?${urlSearchParams.toString()}`);
    }

    const jobsMatchingFiltersWithoutState = () => {
        const toUrl = (state) => {
            let urlSearchParams = new URLSearchParams(location.search);
            urlSearchParams.set("state", state);
            return (
                <UILink
                    component="button"
                    variant="body1"
                    style={{color: '#26a8ed'}}
                    onClick={() => navigate(`?${urlSearchParams.toString()}`)}
                    underline="hover">{state}</UILink>
            );
        }

        if (props.jobPageWithoutState && props.jobPageWithoutState.total > 0) {
            const matchingStates = [...new Set(props.jobPageWithoutState.items.map(job => job.jobHistory[job.jobHistory.length - 1].state))];
            return <> - there are jobs matching your filters with the
                {matchingStates.map((state, index) => (
                    <Fragment
                        key={index}>{matchingStates[index - 1] ? matchingStates[index + 1] ? ', ' : ' and ' : ''} {toUrl(state)}</Fragment>
                ))}&nbsp;state.
            </>
        }
        return <></>;
    }

    return (
        <> {isLoading
            ? <LoadingIndicator/>
            : <> {jobPage.items < 1
                ? <>
                    <ItemsNotFound id="no-jobs-found-message">
                        No {jobStateToHumanReadableName(jobState)} found{jobsMatchingFiltersWithoutState()}
                    </ItemsNotFound>
                </>
                : <>
                    <Grid item xs={12} container style={{minHeight: "60px"}}>
                        <Grid item xs={6}>
                            {hasWriteAccess &&
                                <JobActions selectedState={jobState}
                                            allJobsSelected={allItemsSelected(jobs)}
                                            selectedJobs={selectedItems(jobs)}
                                            jobPage={jobPage}
                                            showDeleteButton={showDeleteButton}
                                            showEnqueueButton={showEnqueueButton}
                                />
                            }
                        </Grid>
                        <Grid item xs={6}>
                            <TablePagination
                                id="jobs-table-pagination-header"
                                component="div"
                                rowsPerPageOptions={[20, 50, 100]}
                                count={jobPage.total}
                                rowsPerPage={jobPage.limit}
                                page={jobPage.currentPage}
                                onPageChange={handleChangePage}
                                onRowsPerPageChange={handleChangeRowsPerPage}
                            />
                        </Grid>
                    </Grid>
                    <TableContainer>
                        <Table id="jobs-table" atyle={{width: "100%"}} aria-label="jobs table">
                            <TableHead>
                                <TableRow>
                                    {hasWriteAccess &&
                                        <TableCell padding="checkbox">
                                            <Checkbox checked={allItemsSelected(jobs)}
                                                      onClick={evt => selectAllItems(evt, setJobs, jobs)}/>
                                        </TableCell>
                                    }
                                    <IdColumn style={{fontWeight: 'bold'}}>Id</IdColumn>
                                    <TableCell style={{width: '60%', fontWeight: 'bold'}}>
                                        {canAccessUnredactedJobs ?
                                            <TableSortLabel active={columnInfo.column1.isSorted}
                                                            direction={columnInfo.column1.order}
                                                            onClick={columnInfo.column1.sortOnClick}>
                                                {columnInfo.column1.name}
                                            </TableSortLabel> :
                                            <span>Job signature</span>
                                        }
                                    </TableCell>
                                    <TableCell style={{fontWeight: 'bold'}}>
                                        <TableSortLabel active={columnInfo.column2.isSorted}
                                                        direction={columnInfo.column2.order}
                                                        onClick={columnInfo.column2.sortOnClick}>
                                            {columnInfo.column2.name}
                                        </TableSortLabel>
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {jobs.map(job => (
                                    <TableRow key={job.id}>
                                        {hasWriteAccess &&
                                            <TableCell padding="checkbox">
                                                <Checkbox checked={job.selected}
                                                          onClick={() => selectItem(job, setJobs, jobs)}/>
                                            </TableCell>
                                        }
                                        <IdColumn component="th" scope="row">
                                            <Link to={prefixWithPublicUrl(`/jobs/${job.id}`)} state={{job: job}}>
                                                {job.id}
                                            </Link>
                                        </IdColumn>
                                        <TableCell>
                                            {job.labels?.length > 0 &&
                                                <>
                                                    {job.labels.map((label) => <JobLabel key={label}
                                                                                         to={prefixWithPublicUrl(`/jobs?label=${label}`)}
                                                                                         text={label}/>)}
                                                    <span style={{marginRight: '0.5rem'}}></span>
                                                </>
                                            }
                                            <Link to={prefixWithPublicUrl(`/jobs/${job.id}`)} state={{job: job}}>
                                                {job.jobName}
                                            </Link>
                                        </TableCell>
                                        <TableCell>
                                            <Link to={prefixWithPublicUrl(`/jobs/${job.id}`)} state={{job: job}}>
                                                <TimeAgo date={new Date(columnInfo.column2.valueFunction(job))}
                                                         title={new Date(columnInfo.column2.valueFunction(job)).toString()}/>
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        id="jobs-table-pagination"
                        component="div"
                        rowsPerPageOptions={[20, 50, 100]}
                        count={jobPage.total}
                        rowsPerPage={jobPage.limit}
                        page={jobPage.currentPage}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                </>
            }
            </>
        }
        </>
    );
}

export default JobsTable;