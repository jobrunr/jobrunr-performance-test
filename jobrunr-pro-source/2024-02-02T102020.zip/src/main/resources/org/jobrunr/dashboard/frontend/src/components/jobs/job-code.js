import Grid from "@mui/material/Grid";
import {styled} from "@mui/material/styles";
import Highlight from "../utils/highlighter";
import priorityQueuesState from "../../PriorityQueuesStateContext";

const JobCodeContainer = styled(Grid)`
    padding-top: 0 !important;

    & > pre {
        margin-top: 0;
        margin-bottom: 12px;
    }
`

const JobDetailsContainer = styled(Grid)`
    margin-bottom: 12px;
    background-color: #fff;
    padding-top: 0 !important;

    & > dl {
        display: flex;
        flex-flow: row;
        flex-wrap: wrap;
        width: 100%;
        overflow: visible;
        margin: 0 0 0.5em 0;
    }

    & > dl dt {
        flex: 0 0 30%;
        text-align: right;
        text-overflow: ellipsis;
        overflow: hidden;
    }

    & > dl dd {
        flex: 0 0 65%;
        text-align: left;
        margin-left: 0.8em;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
`

const JobCode = ({job, redacted}) => {
    const priorityQueues = priorityQueuesState.usePriorityQueues();

    const fqClassName = job.jobDetails.className;
    const className = job.jobDetails.className.substring(job.jobDetails.className.lastIndexOf(".") + 1);
    const staticFieldName = job.jobDetails.staticFieldName;
    const methodName = job.jobDetails.methodName;
    const parameters = job.jobDetails.jobParameters.map(jobParameter => redacted ? "\u2588\u2588\u2588\u2588" : jobParameter.object).join(", ")

    let totalFunction = className;
    if (staticFieldName) {
        totalFunction += "." + staticFieldName;
    }
    totalFunction += "." + methodName;
    totalFunction += "(" + parameters + ")";


    const code = `
    import ${fqClassName};
    
    ${totalFunction};
    `;

    return (
        <Grid item xs={12}>
            <Grid container spacing={3}>
                <JobCodeContainer item xs={8}>
                    <Highlight language='java'>
                        {code}
                    </Highlight>
                </JobCodeContainer>
                <JobDetailsContainer item xs={4}>
                    {job.recurringJobId &&
                        <dl>
                            <dt>Recurring&nbsp;job:</dt>
                            <dd><a href={`../recurring-jobs?id=${job.recurringJobId}`}>{job.recurringJobId}</a></dd>
                        </dl>
                    }
                    <dl>
                        <dt>Priority:</dt>
                        <dd>{priorityQueues[job.priority]}</dd>
                    </dl>
                    <dl>
                        <dt>Server tag:</dt>
                        <dd>{job.serverTag}</dd>
                    </dl>
                    {job.rateLimiter &&
                        <dl>
                            <dt>Rate limiter:</dt>
                            <dd>{job.rateLimiter}</dd>
                        </dl>
                    }
                    {!job.rateLimiter && job.mutex &&
                        <dl>
                            <dt>Mutex:</dt>
                            <dd>{job.mutex}</dd>
                        </dl>
                    }
                </JobDetailsContainer>
            </Grid>
        </Grid>
    );
};

export default JobCode;