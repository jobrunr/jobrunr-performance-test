import {useEffect, useState} from 'react';
import {useLocation, useNavigate} from "react-router-dom";
import Typography from '@mui/material/Typography';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Chip,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Select
} from "@mui/material";
import {ExpandMoreOutlined} from "@mui/icons-material";
import {styled} from "@mui/material/styles";
import {DeleteForever} from "mdi-material-ui";
import priorityQueuesState from "../../PriorityQueuesStateContext";
import SearchField from "../utils/search-field";
import serversState from "../../ServersStateContext";
import {prefixWithContextPath} from "../../utils/helper-functions";
import {DateTimePicker} from "../ui/DateTimePicker";

const Heading = styled(Typography)(({theme}) => ({
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '8%',
    flexShrink: 0,
    margin: theme.spacing(1)
}))

const SecondaryHeading = styled("div")(({theme}) => ({
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary
}))

const NoFiltersSelected = styled("span")(({theme}) => ({
    display: 'inline-block',
    margin: theme.spacing(1)
}));

const JobsFilterPanel = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const priorityQueues = priorityQueuesState.usePriorityQueues();
    const [jobSignatures, setJobSignatures] = useState([]);
    const [servers, setServers] = useState(serversState.getServers());

    useEffect(() => {
        fetch(prefixWithContextPath(`/api/job-signatures`))
            .then(res => res.json())
            .then(response => {
                setJobSignatures(response);
            })
            .catch(error => console.log(error));
    }, []);

    useEffect(() => {
        serversState.addListener(setServers);
        return () => serversState.removeListener(setServers);
    }, []);

    const urlSearchParams = new URLSearchParams(location.search);

    const setFilter = (filterName, filterValue, hasError) => {
        if (filterValue !== null) {
            if (hasError) {
                urlSearchParams.delete(filterName);
                urlSearchParams.set(filterName + 'Error', true);
            } else {
                urlSearchParams.set(filterName, filterValue);
                urlSearchParams.delete(filterName + 'Error');
            }

            navigate(`?${urlSearchParams.toString()}`);
        } else {
            removeFilter(filterName);
        }
    }

    const setDateFilter = (filterName, filterValue) => {
        let parsedDate = Date.parse(filterValue);
        if (!isNaN(parsedDate)) {
            filterValue.setUTCSeconds(0, 0);
            setFilter(filterName, filterValue.toISOString());
        }
    }

    const removeFilter = (filterName) => {
        urlSearchParams.delete(filterName);
        navigate(`?${urlSearchParams.toString()}`);
    }

    const isInvalidUUID = (value) => {
        return value.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i) === null;
    }

    const getActiveFilters = () => {
        const labelMapping = (urlParam) => {
            switch (urlParam) {
                case 'jobName':
                    return `Job name: ${urlSearchParams.get(urlParam)}`;
                case 'jobFingerprint':
                    return `Job fingerprint: ${urlSearchParams.get(urlParam)}`;
                case 'jobSignature':
                    return `Job signature: ${urlSearchParams.get(urlParam)}`;
                case 'priority':
                    return `Job queue: ${priorityQueues[urlSearchParams.get(urlParam)]}`;
                case 'serverTag':
                    return `Server tag: ${urlSearchParams.get(urlParam)}`;
                case 'awaitingOn':
                    return `Awaiting on: ${urlSearchParams.get(urlParam)}`;
                case 'createdAtFrom':
                    return `Created after: ${urlSearchParams.get(urlParam)}`;
                case 'createdAtTo':
                    return `Created before: ${urlSearchParams.get(urlParam)}`;
                case 'updatedAtFrom':
                    return `Updated after: ${urlSearchParams.get(urlParam)}`;
                case 'updatedAtTo':
                    return `Updated before: ${urlSearchParams.get(urlParam)}`;
                default:
                    return "Unknown filter";
            }
        }

        let filterKeys = Array.from(urlSearchParams.keys())
            .filter(key => !['state', 'page', 'queuePriority', 'itemsPerPage', 'update'].includes(key));

        return (
            <>
                {filterKeys.length > 0
                    ? <>
                        {filterKeys.map((key) => (
                            <Chip key={key}
                                  label={labelMapping(key)}
                                  onDelete={() => removeFilter(key)}
                                  deleteIcon={<DeleteForever/>}
                                  sx={{margin: 0.5}}
                            />
                        ))}
                    </>
                    : <NoFiltersSelected>No filters selected</NoFiltersSelected>
                }
            </>
        )
    }

    return (
        <Accordion>
            <AccordionSummary
                expandIcon={<ExpandMoreOutlined/>}
                aria-controls="panel1a-content"
                id="panel1a-header"
            >
                <Heading>Filters</Heading>
                <SecondaryHeading>{getActiveFilters()}</SecondaryHeading>
            </AccordionSummary>
            <AccordionDetails>
                <Grid container>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3} style={{marginBottom: '1em'}}>
                        <Grid item xs={6}>
                            <SearchField id="job-name" label="Job name"
                                         defaultValue={urlSearchParams.get('jobName') ?? ''}
                                         onSearch={value => setFilter('jobName', value)}/>
                        </Grid>
                        <Grid item xs={6}>
                            <SearchField id="job-fingerprint" label="Job fingerprint"
                                         defaultValue={urlSearchParams.get('jobFingerprint') ?? ''}
                                         onSearch={value => setFilter('jobFingerprint', value)}/>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3} style={{marginBottom: '1em'}}>
                        <Grid item xs={6}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <InputLabel id="job-signature-select-label">Job signature</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="job-signature-select-label"
                                    id="job-signature-select"
                                    value={urlSearchParams.get('jobSignature') ?? ''}
                                    onChange={ev => setFilter('jobSignature', ev.target.value)}>
                                    {jobSignatures.map((jobSignature, index) => (
                                        <MenuItem key={index} value={jobSignature}>{jobSignature}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <InputLabel id="queue-select-label">Queue</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="queue-select-label"
                                    id="queue-select"
                                    value={urlSearchParams.get('priority') ?? ''}
                                    onChange={ev => setFilter('priority', ev.target.value)}>
                                    {priorityQueues.map((queue, index) => (
                                        <MenuItem key={index} value={index}>{queue}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2}>
                            <FormControl variant="standard" style={{width: '100%'}}>
                                <InputLabel id="server-tags-select-label">Server tag</InputLabel>
                                <Select
                                    variant="standard"
                                    labelId="server-tags-select-label"
                                    id="server-tags-select"
                                    value={urlSearchParams.get('serverTag') ?? ''}
                                    onChange={ev => setFilter('serverTag', ev.target.value)}>
                                    {servers.flatMap(server => server.serverTags).map((serverTag, index) => (
                                        <MenuItem key={index} value={serverTag}>{serverTag}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={2}>
                            <SearchField id="awaiting-on-job-id" label="Awaiting on"
                                         defaultValue={urlSearchParams.get('awaitingOn') ?? ''}
                                         onSearch={value => setFilter('awaitingOn', value, isInvalidUUID(value))}
                                         hasError={urlSearchParams.has('awaitingOnError')}
                                         errorText="Not a valid UUID"/>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} lg={12} container spacing={3}>
                        <Grid item xs={3}>
                            <DateTimePicker
                                label="Created after"
                                maxDate={urlSearchParams.get('createdAtTo')}
                                value={urlSearchParams.get('createdAtFrom')}
                                onChange={value => setDateFilter('createdAtFrom', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('createdAtFrom')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={3}>
                            <DateTimePicker
                                label="Created before"
                                minDate={urlSearchParams.get('createdAtFrom')}
                                value={urlSearchParams.get('createdAtTo')}
                                onChange={value => setDateFilter('createdAtTo', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('createdAtTo')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={3}>
                            <DateTimePicker
                                label="Updated after"
                                maxDate={urlSearchParams.get('updatedAtTo')}
                                value={urlSearchParams.get('updatedAtFrom')}
                                onChange={value => setDateFilter('updatedAtFrom', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('updatedAtFrom')
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={3}>
                            <DateTimePicker
                                label="Updated before"
                                minDate={urlSearchParams.get('updatedAtFrom')}
                                value={urlSearchParams.get('updatedAtTo')}
                                onChange={value => setDateFilter('updatedAtTo', value)}
                                onKeyPress={ev => {
                                    if (ev.key === 'Enter') {
                                        removeFilter('updatedAtTo')
                                    }
                                }}
                            />
                        </Grid>
                    </Grid>
                </Grid>

            </AccordionDetails>
        </Accordion>
    );
};

export default JobsFilterPanel;