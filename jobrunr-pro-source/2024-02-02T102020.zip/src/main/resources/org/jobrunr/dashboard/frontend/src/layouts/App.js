import {useContext} from 'react';
import {Navigate, Route, Routes} from 'react-router-dom';
import {styled} from "@mui/material/styles";
import TopAppBar from "./TopAppBar";
import {UserContext} from "../UserContext";
import DynamicQueuesView from "../components/dynamic-queues/dynamic-queues-view";
import RecurringJobs from "../components/recurring-jobs/recurring-jobs";
import JobsView from "../components/jobs/jobs-view";
import WithSidebar from "../components/utils/with-sidebar";
import Overview from "../components/overview/overview";
import Sidebar from "../components/jobs/sidebar";
import JobView from "../components/jobs/job-view";
import BatchJobsView from "../components/batch-jobs/batch-jobs-view";
import BatchSidebar from "../components/batch-jobs/sidebar";
import Panic from "../components/panic/panic-view";
import Servers from "../components/servers/servers";
import {AuthorizedRoute} from "./AuthorizedRoute";

export const Main = styled("main")(({theme}) => ({
    padding: theme.spacing(3),
    marginTop: 56
}));

export const App = function () {
    const {authorizationRules} = useContext(UserContext);

    return (
        <div>
            <TopAppBar/>
            <Main>
                <Routes>
                    <Route path='overview' element={<Overview/>}/>
                    <Route path='jobs/:jobId' element={
                        <AuthorizedRoute component={WithSidebar(Sidebar, JobView)}
                                         hasAccess={authorizationRules.canAccessJobs}/>
                    }/>
                    <Route path='jobs' element={
                        <AuthorizedRoute component={WithSidebar(Sidebar, JobsView)}
                                         hasAccess={authorizationRules.canAccessJobs}/>
                    }/>
                    <Route path='batch-jobs/:jobId' element={
                        <AuthorizedRoute component={WithSidebar(BatchSidebar, JobView)}
                                         hasAccess={authorizationRules.canAccessJobs}/>
                    }/>
                    <Route path='batch-jobs' element={
                        <AuthorizedRoute component={WithSidebar(BatchSidebar, BatchJobsView)}
                                         hasAccess={authorizationRules.canAccessJobs}/>
                    }/>
                    <Route path='recurring-jobs' element={
                        <AuthorizedRoute component={RecurringJobs}
                                         hasAccess={authorizationRules.canAccessRecurringJobs}/>
                    }/>
                    <Route path='dynamic-queues' element={
                        <AuthorizedRoute component={DynamicQueuesView}
                                         hasAccess={authorizationRules.canAccessJobs}/>
                    }/>
                    <Route path='servers' element={
                        <AuthorizedRoute component={Servers}
                                         hasAccess={authorizationRules.canAccessBackgroundJobServers}/>
                    }/>
                    <Route path='panic' element={<Panic/>}/>
                    <Route path="*" element={<Navigate to="overview" replace/>}/>
                </Routes>
            </Main>
        </div>
    );
};