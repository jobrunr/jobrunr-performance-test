import {useEffect, useState} from "react";
import ButtonGroup from "@mui/material/ButtonGroup";
import Button from "@mui/material/Button";
import {prefixWithContextPath} from "../../../utils/helper-functions";
import {Alert, FormControlLabel, Snackbar} from "@mui/material";
import {useLocation, useNavigate} from "react-router-dom";
import Checkbox from "@mui/material/Checkbox";
import {DeleteJobsDialog} from "../../ui/DeleteDialog";


export const Actions = (props) => {
    const location = useLocation();
    const navigate = useNavigate();
    const selectedState = props.selectedState;
    const selectedJobs = props.selectedJobs;
    const actionsDisabled = selectedJobs.length < 1;
    const showSelectAllJobsNotification = props.allJobsSelected && selectedJobs.length >= props.pageSize;

    const [allJobsSelected, setAllJobsSelected] = useState(false);
    const [apiStatus, setApiStatus] = useState(null);
    const [showDeleteJobsDialog, setShowDeleteJobsDialog] = useState(false);

    const urlSearchParams = new URLSearchParams(location.search);
    const action = urlSearchParams.get('action');

    useEffect(() => {
        if (action) {
            if (action === 'requeue') {
                setApiStatus({type: 'requeue', severity: 'success', message: 'Successfully requeued batch jobs'});
            } else if (action === 'delete') {
                setApiStatus({type: 'delete', severity: 'success', message: 'Successfully deleted batch jobs'});
            }
        }
    }, [action]);

    const refreshPage = (action) => {
        urlSearchParams.set('action', action);
        navigate(`?${urlSearchParams.toString()}`, {replace: true});
    };

    const handleCloseAlert = () => {
        setApiStatus(null);
    };

    const queueSelectedJobs = () => {
        fetch(getJobApiUrlForSelectedJobs('/api/jobs/requeue'), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 204) {
                    refreshPage('requeue');
                } else {
                    setApiStatus({type: 'requeue', severity: 'error', message: 'Error requeueing batchjobs'});
                }
            })
            .catch(error => console.error(error));
    };

    const deleteSelectedJobs = () => {
        fetch(getJobApiUrlForSelectedJobs('/api/jobs'), {
            method: 'DELETE',
        })
            .then(res => {
                if (res.status === 204) {
                    refreshPage('delete');
                } else {
                    setApiStatus({type: 'delete', severity: 'error', message: 'Error deleting batch jobs'});
                }
            })
            .catch(error => console.error(error));
    };

    const getJobApiUrlForSelectedJobs = (url) => {
        if (allJobsSelected) {
            const urlSearchParams = new URLSearchParams(location.search);
            return prefixWithContextPath(`${url}?${urlSearchParams.toString()}`);
        } else {
            const jobIds = selectedJobs.map(job => job.id).join();
            return prefixWithContextPath(`${url}?jobIds=${jobIds}`);
        }
    }

    const toggleShowDeleteJobsDialog = () => {
        setShowDeleteJobsDialog(prev => !prev);
    }

    return (
        <>
            <ButtonGroup style={{margin: '1rem 0 -0.5rem 1rem'}} disabled={actionsDisabled}>
                {props.showDeleteButton &&
                    <Button variant="outlined" color="primary" onClick={toggleShowDeleteJobsDialog}>
                        Delete
                    </Button>
                }
                {props.showEnqueueButton &&
                    <Button variant="outlined" color="primary" onClick={queueSelectedJobs}>
                        {selectedState === 'SCHEDULED' ? 'Enqueue' : 'Requeue'}
                    </Button>
                }
            </ButtonGroup>
            {showSelectAllJobsNotification &&
                <FormControlLabel
                    style={{marginLeft: '1rem'}}
                    control={<Checkbox checked={allJobsSelected}
                                       onChange={(evt) => setAllJobsSelected(evt.target.checked)}
                                       name="selectAllJobs"/>}
                    label="Select all jobs on other pages too?"
                />
            }

            {apiStatus &&
                <Snackbar open={true} autoHideDuration={3000} onClose={handleCloseAlert}
                          anchorOrigin={{vertical: "bottom", horizontal: "center"}}>
                    <Alert severity={apiStatus.severity}>
                        {apiStatus.message}
                    </Alert>
                </Snackbar>
            }

            <DeleteJobsDialog
                open={showDeleteJobsDialog}
                handleClose={toggleShowDeleteJobsDialog}
                handleDelete={deleteSelectedJobs}
                all={allJobsSelected} amount={selectedJobs.length}/>
        </>
    )
}