import {useEffect, useState} from "react";
import {useLocation, useNavigate} from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import JobsTable from "../jobs-table";
import {prefixWithContextPath} from "../../../utils/helper-functions";
import LoadingIndicator from "../../LoadingIndicator";
import {JobState} from "./job-state";
import {ColoredLinearProgress} from "../../ui/ColoredLinearProgress";


const getProgressBar = (job, index) => {
    if (job.metadata && job.metadata['jobRunrDashboardProgressBar-' + (index + 1)]) {
        return job.metadata['jobRunrDashboardProgressBar-' + (index + 1)];
    }
    return null;
}

const ProcessingChildJobs = ({index, job, jobState}) => {
    const navigate = useNavigate();
    const location = useLocation();
    const urlSearchParams = new URLSearchParams(location.search);
    const page = (urlSearchParams.has('page') ? urlSearchParams.get('page') : 0);
    const state = (urlSearchParams.has(`processing-child-job-state-${index}`) ? urlSearchParams.get(`processing-child-job-state-${index}`) : 'ENQUEUED');
    const itemsPerPage = urlSearchParams.get('itemsPerPage') || 20;

    const [expanded, setExpanded] = useState(urlSearchParams.has(`processing-child-job-state-${index}`) || job.jobHistory.length === (index + 1));
    const [value, setValue] = useState(state);
    const [isLoading, setIsLoading] = useState(true);
    const [childJobPage, setChildJobPage] = useState({total: 0, limit: 20, currentPage: 0, items: []});

    useEffect(() => {
        const offset = (page) * itemsPerPage;
        const limit = itemsPerPage;
        setIsLoading(true);
        fetch(prefixWithContextPath(`/api/batch-jobs/${job.id}/${state}?offset=${offset}&limit=${limit}`))
            .then(res => {
                if (res.status === 200) {
                    res.json()
                        .then(result => {
                            setChildJobPage(result);
                            setIsLoading(false);
                            // all useRef examples are not working
                            setTimeout(() => document.getElementById(`processing-child-panel-header-${index}`).scrollIntoView(), 5);
                        });
                } else {
                    console.log(`No batch jobs found for state ${state}`);
                    setIsLoading(false);
                }
            })
            .catch(error => console.error(error));
    }, [job.id, page, state, itemsPerPage, index]);

    const progressBar = getProgressBar(job, index);
    const handleChange = () => {
        setExpanded(!expanded);
    };
    const handleTabChange = (event, newValue) => {
        navigate({search: `?processing-child-job-state-${index}=${newValue}`}, {replace: true});
        setValue(newValue);
    };

    return (
        <JobState
            state="processing"
            title="Processing child jobs"
            date={new Date(jobState.createdAt)}
            id={`processing-child-panel-header-${index}`}
            removeDetailsPadding
            expanded={expanded}
            onChange={handleChange}
        >
            {progressBar &&
                <ColoredLinearProgress variant="determinate" value={progressBar.progress}/>
            }
            <div style={{padding: "8px 16px 16px"}}>
                <Tabs
                    value={value}
                    indicatorColor="primary"
                    textColor="primary"
                    onChange={handleTabChange}
                >
                    <Tab label="Pending" value="AWAITING"/>
                    <Tab label="Scheduled" value="SCHEDULED"/>
                    <Tab label="Enqueued" value="ENQUEUED"/>
                    <Tab label="Processing" value="PROCESSING"/>
                    <Tab label="Succeeded" value="SUCCEEDED"/>
                    <Tab label="Failed" value="FAILED"/>
                    <Tab label="Deleted" value="DELETED"/>
                </Tabs>
                <Box p={3}>
                    {isLoading
                        ? <LoadingIndicator/>
                        : <JobsTable key={childJobPage} isLoading={isLoading} jobPage={childJobPage}
                                     jobState={jobState.state}/>
                    }
                </Box>
            </div>
        </JobState>
    )
};

export default ProcessingChildJobs;