import {memo, useContext, useEffect, useState} from 'react';
import {Link, useNavigate, useParams} from "react-router-dom";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Alert from '@mui/material/Alert';
import Paper from '@mui/material/Paper';
import Snackbar from "@mui/material/Snackbar";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import {SortAscending, SortDescending} from "mdi-material-ui";
import Scheduled from "./states/scheduled-state";
import Enqueued from "./states/enqueued-state";
import EnqueuedChildJobs from "./states/enqueued-child-state";
import Processing from "./states/processing-state";
import Succeeded from "./states/succeeded-state";
import Failed from "./states/failed-state";
import Deleted from "./states/deleted-state";
import JobCode from "./job-code";
import LoadingIndicator from "../LoadingIndicator";
import ProcessingChildJobs from "./states/processing-child-state";
import Awaiting from "./states/awaiting-state";
import priorityQueuesState from "../../PriorityQueuesStateContext";
import {jobStateToHumanReadableTitle} from "../utils/job-utils";
import SucceededNotification from "./notifications/succeeded-notification";
import FailedNotification from "./notifications/failed-notification";
import DeletedNotification from "./notifications/deleted-notification";
import JobDetailsNotCacheableNotification from "./notifications/job-details-not-cacheable-notification";
import VersionFooter from "../utils/version-footer";
import SmartEventSource from "../../utils/SmartEventSource";
import {prefixWithContextPath, prefixWithPublicUrl} from "../../utils/helper-functions";
import JobLabel from "../utils/job-label";
import {ItemsNotFound} from "../utils/items-not-found";
import {FeatureContext} from "../../FeaturesContext";
import JobNotRunnableNotification from "./notifications/job-not-runnable-notification";
import {DeleteJobDialog} from "../ui/DeleteDialog";
import {RequeueImmediatelyDialog} from "../ui/RequeueDialog";
import {UserContext} from "../../UserContext";

const JobView = () => {
    const navigate = useNavigate();
    const features = useContext(FeatureContext);
    const priorityQueues = priorityQueuesState.usePriorityQueues();

    const [apiStatus, setApiStatus] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [job, setJob] = useState(null);
    const [stateBreadcrumb, setStateBreadcrumb] = useState({});
    const [jobStates, setJobStates] = useState([]);
    const [order, setOrder] = useState(true);
    const [showDeleteJobDialog, setShowDeleteJobDialog] = useState(false);
    const [showRequeueJobDialog, setShowRequeueJobDialog] = useState(false);
    const {jobId} = useParams();
    const {authorizationRules: {canDeleteJobs, canEnqueueJobs, canAccessUnredactedJobs}} = useContext(UserContext);

    useEffect(() => {
        getJob(jobId);

        const eventSource = new SmartEventSource(prefixWithContextPath("/sse/jobs/" + jobId));
        eventSource.onmessage = e => onJob(JSON.parse(e.data));
        return () => eventSource.close();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jobId]);

    useEffect(() => {
        if (job) {
            if (order) {
                setJobStates([...job.jobHistory]);
            } else {
                setJobStates([...job.jobHistory].reverse());
            }
        }
    }, [job, order]);

    const getJob = (id) => {
        fetch(prefixWithContextPath(`/api/jobs/${id}`))
            .then(res => {
                if (res.status === 200) {
                    res.json()
                        .then(job => onJob(job));
                } else {
                    onJobNotFound();
                }
            })
            .catch(error => console.error(error));
    }

    const deleteJob = () => {
        fetch(prefixWithContextPath(`/api/jobs/${jobId}`), {
            method: 'DELETE',
        })
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({type: 'delete', severity: 'success', message: 'Successfully deleted job'});
                } else {
                    setApiStatus({type: 'delete', severity: 'error', message: 'Error deleting job'});
                }
            })
            .catch(error => console.error(error));
    };
    const requeueJob = () => {
        fetch(prefixWithContextPath(`/api/jobs/${jobId}/requeue`), {
            method: 'POST',
        })
            .then(res => {
                if (res.status === 204) {
                    setApiStatus({type: 'requeue', severity: 'success', message: 'Successfully requeued job'});
                    getJob(jobId);
                } else {
                    setApiStatus({type: 'requeue', severity: 'error', message: 'Error requeueing job'});
                }
            })
            .catch(error => console.error(error))
            .finally(() => toggleRequeueJobDialog())
        ;
    };

    const onJob = (job) => {
        setJob(job);
        setIsLoading(false);
        let state = job.jobHistory[job.jobHistory.length - 1].state;
        setStateBreadcrumb({
            state: state,
            name: jobStateToHumanReadableTitle(state),
            link: state.toUpperCase(),
            priority: job.priority
        })
    }

    const onJobNotFound = () => {
        setJob(null);
        setIsLoading(false);
    }

    const handleCloseAlert = (event, reason) => {
        const mustGoBack = 'delete' === apiStatus.type;
        setApiStatus(null);
        if (mustGoBack) {
            navigate(-1);
        }
    };

    const changeSortOrder = () => {
        setOrder(!order);
    };

    const toggleDeleteJobDialog = () => {
        setShowDeleteJobDialog(prev => !prev);
    }

    const toggleRequeueJobDialog = () => {
        setShowRequeueJobDialog(prev => !prev);
    }

    return (
        <main style={{width: "100%"}}>
            {isLoading
                ? <LoadingIndicator/>
                : <>{job === null
                    ?
                    <Paper><ItemsNotFound id="no-jobs-found-message">
                        Job not found
                    </ItemsNotFound></Paper>
                    : <>
                        <Breadcrumbs id="breadcrumb" separator={<NavigateNextIcon fontSize="small"/>}
                                     aria-label="breadcrumb">
                            <Link color="inherit" to={prefixWithPublicUrl("/jobs")}>Jobs</Link>
                            <Link color="inherit"
                                  to={prefixWithPublicUrl(`/jobs?state=${stateBreadcrumb.link}`)}>{stateBreadcrumb.name}</Link>
                            {stateBreadcrumb.link === 'ENQUEUED' && priorityQueues.length > 1 &&
                                <Link color="inherit"
                                      to={prefixWithPublicUrl(`/jobs?state=${stateBreadcrumb.link}&priority=${job.priority}`)}>{priorityQueues[job.priority]}</Link>
                            }
                            <Typography color="textPrimary">{job.id}</Typography>
                        </Breadcrumbs>
                        <Box my={3} style={{marginBottom: 0}}>
                            <Card style={{display: "flex"}}>
                                <CardContent style={{width: "100%"}}>
                                    <Grid container spacing={3} justifyContent="space-between">
                                        <Grid item xs={8}>
                                            <Typography id="job-id-title" color="textSecondary">
                                                Job Id: {job.id}
                                                {job.metadata['traceId'] &&
                                                    <small style={{marginLeft: '2em'}}>
                                                        Trace Id:&nbsp;
                                                        {features['observability']
                                                            ? <a title={"Open in " + features['observability']}
                                                                 target="_blank" rel="noreferrer"
                                                                 href={prefixWithContextPath(`/api/integration?name=${features['observability']}&id=${job.id}`)}>{job.metadata['traceId']}</a>
                                                            : <span
                                                                id='observability-traceId'>{job.metadata['traceId']}</span>
                                                        }
                                                    </small>
                                                }
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={4} container justifyContent="flex-end">
                                            <ButtonGroup>
                                                {canEnqueueJobs && stateBreadcrumb.state !== 'ENQUEUED' &&
                                                    <Button variant="outlined" color="primary"
                                                            onClick={toggleRequeueJobDialog}>
                                                        Requeue
                                                    </Button>
                                                }
                                                {canDeleteJobs && stateBreadcrumb.state !== 'DELETED' &&
                                                    <Button variant="outlined" color="primary"
                                                            onClick={toggleDeleteJobDialog}>
                                                        Delete
                                                    </Button>
                                                }
                                            </ButtonGroup>
                                        </Grid>
                                        <Grid item xs={12} style={{paddingTop: 0}}>
                                            <Typography id="job-name-title" variant="h5" component="h2" gutterBottom
                                                        style={{wordBreak: "break-word"}}>
                                                {job.jobName} {job.labels?.map((label) => <JobLabel key={label}
                                                                                                    to={prefixWithPublicUrl(`/jobs?label=${label}`)}
                                                                                                    text={label}/>)}
                                            </Typography>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </Card>
                        </Box>

                        <Grid container spacing={3}>
                            <JobCode job={job} redacted={!canAccessUnredactedJobs}/>

                            {job.jobDetails.cacheable === false && <JobDetailsNotCacheableNotification job={job}/>}
                            <JobNotRunnableNotification job={job}/>
                            {stateBreadcrumb.state === 'SUCCEEDED' && <SucceededNotification job={job}/>}
                            {stateBreadcrumb.state === 'FAILED' && <FailedNotification job={job}/>}
                            {stateBreadcrumb.state === 'DELETED' && <DeletedNotification job={job}/>}

                            <Grid item xs={12}>
                                <Typography variant="h5" component="h2">
                                    History&nbsp;
                                    <IconButton
                                        id={`jobhistory-sort-${order ? "desc" : "asc"}-btn`}
                                        color="inherit"
                                        onClick={changeSortOrder}
                                        style={{scrollMarginTop: '70px'}}
                                        size="large"
                                    >
                                        {order ? <SortDescending/> : <SortAscending/>}
                                    </IconButton>
                                </Typography>
                            </Grid>

                            <Grid id="job-history-panel" item xs={12}>
                                {
                                    jobStates.map((jobState, index) => {
                                        switch (jobState.state) {
                                            case 'AWAITING':
                                                return <Awaiting key={index} jobState={jobState}/>;
                                            case 'SCHEDULED':
                                                return <Scheduled key={index} jobState={jobState}/>;
                                            case 'ENQUEUED':
                                                return <Enqueued key={index} jobState={jobState}/>;
                                            case 'PROCESSING':
                                                if (job['@class'] === 'org.jobrunr.jobs.BatchJob') {
                                                    return <EnqueuedChildJobs key={index} index={index} job={job}
                                                                              jobState={jobState}/>;
                                                } else {
                                                    return <Processing key={index} index={index} job={job}
                                                                       jobState={jobState}/>;
                                                }
                                            case 'PROCESSED':
                                                return <ProcessingChildJobs key={index} index={index} job={job}
                                                                            jobState={jobState}/>;
                                            case 'FAILED':
                                                return <Failed key={index} index={index} job={job}
                                                               jobState={jobState}
                                                               redacted={!canAccessUnredactedJobs}/>;
                                            case 'SUCCEEDED':
                                                return <Succeeded key={index} job={job} jobState={jobState}/>;
                                            case 'DELETED':
                                                return <Deleted key={index} jobState={jobState}/>;
                                            default:
                                                return <div key={index}>Unknown state</div>
                                        }
                                    })}
                            </Grid>
                        </Grid>
                        {apiStatus &&
                            <Snackbar open={true}
                                      autoHideDuration={3000}
                                      onClose={handleCloseAlert}
                                      anchorOrigin={{vertical: "bottom", horizontal: "center"}}
                            >
                                <Alert severity={apiStatus.severity}>
                                    {apiStatus.message}
                                </Alert>
                            </Snackbar>
                        }
                    </>
                }
                </>
            }
            <VersionFooter/>
            <RequeueImmediatelyDialog handleClose={toggleRequeueJobDialog} open={showRequeueJobDialog}
                                      handleRequeue={requeueJob}/>
            <DeleteJobDialog handleClose={toggleDeleteJobDialog} open={showDeleteJobDialog} handleDelete={deleteJob}/>
        </main>
    );
};

export default memo(JobView);