import {Fragment} from "react";
import {Link} from "react-router-dom";
import List from '@mui/material/List';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import {Schedule} from "@mui/icons-material";
import {AlertCircleOutline, Check, Cogs, Delete, LockClock, TimerSand} from "mdi-material-ui";
import {prefixWithPublicUrl} from "../../utils/helper-functions";
import ListItemButton from "@mui/material/ListItemButton";

const categories = [
    {name: "awaiting", state: "AWAITING", label: "Pending", icon: <LockClock/>},
    {name: "scheduled", state: "SCHEDULED", label: "Scheduled", icon: <Schedule/>},
    {name: "enqueued", state: "ENQUEUED", label: "Enqueued", icon: <TimerSand/>},
    {name: "processing", state: "PROCESSED", label: "Processing", icon: <Cogs/>},
    {name: "succeeded", state: "SUCCEEDED", label: "Succeeded", icon: <Check/>},
    {name: "failed", state: "FAILED", label: "Failed", icon: <AlertCircleOutline/>},
    {name: "deleted", state: "DELETED", label: "Deleted", icon: <Delete/>},
];

const BatchSidebar = () => {
    return (
        <List component="div">
            {categories.map(({name, state, label, icon}) => (
                <Fragment key={label}>
                    <ListItemButton id={`${name}-menu-btn`} title={label}
                                    component={Link} to={prefixWithPublicUrl(`/batch-jobs?state=${state}`)}>
                        <ListItemIcon>{icon}</ListItemIcon>
                        <ListItemText primary={label}/>
                    </ListItemButton>
                </Fragment>
            ))}
        </List>
    );
};

export default BatchSidebar;