import {BrowserRouter, Route, Routes} from "react-router-dom";
import {createRoot} from 'react-dom/client';
import {AdapterDateFns} from "@mui/x-date-pickers/AdapterDateFns";
import {LocalizationProvider} from "@mui/x-date-pickers";
import AdminUI from "layouts/Admin.js";
import {prefixWithPublicUrl} from "./utils/helper-functions";

import "assets/css/material-dashboard-react.css?v=1.8.1";
import "assets/css/androidstudio.css";

const root = createRoot(document.getElementById("root"));

root.render(
    <LocalizationProvider dateAdapter={AdapterDateFns}>
        <BrowserRouter>
            <Routes>
                <Route path={prefixWithPublicUrl("/*")} element={<AdminUI/>}/>
            </Routes>
        </BrowserRouter>
    </LocalizationProvider>
);