import {useEffect, useState} from "react";
import {useLocation} from "react-router-dom";
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Box from "@mui/material/Box";
import LoadingIndicator from "../LoadingIndicator";
import {batchJobStateToHumanReadableTitle} from "../utils/job-utils";
import VersionFooter from "../utils/version-footer";
import {prefixWithContextPath} from "../../utils/helper-functions";
import BatchJobsTable from "./batch-jobs-table";

const BatchJobsView = (props) => {
    const location = useLocation();

    const urlSearchParams = new URLSearchParams(location.search);
    const page = urlSearchParams.get('page');
    const jobState = urlSearchParams.get('state') ?? 'ENQUEUED';
    const queuePriority = urlSearchParams.get('priority');
    const itemsPerPage = urlSearchParams.get('itemsPerPage') || 20;
    const [isLoading, setIsLoading] = useState(true);
    const [jobPage, setJobPage] = useState({total: 0, limit: itemsPerPage, currentPage: 0, items: []});

    let sort = 'priority:ASC,updatedAt:ASC';
    switch (jobState.toUpperCase()) {
        case 'SUCCEEDED':
        case 'FAILED':
            sort = 'updatedAt:DESC';
            break;
        default:
    }

    useEffect(() => {
        setIsLoading(true);
        const offset = (page) * itemsPerPage;
        const limit = itemsPerPage;
        let apiSearchParams = new URLSearchParams(location.search);
        apiSearchParams.set('offset', offset);
        apiSearchParams.set('limit', limit);
        apiSearchParams.set('order', sort);
        apiSearchParams.set('state', jobState);
        fetch(prefixWithContextPath(`/api/batch-jobs?${apiSearchParams.toString()}`))
            .then(res => res.json())
            .then(response => {
                setJobPage(response);
                setIsLoading(false);
            })
            .catch(error => console.log(error));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, jobState, sort, queuePriority, location.key]);

    return (
        <main style={{width: "100%"}}>
            <Box my={1} style={{marginBottom: '1rem'}}>
                <Typography id="title" variant="h4">{batchJobStateToHumanReadableTitle(jobState)}</Typography>
            </Box>
            {isLoading
                ? <LoadingIndicator/>
                :
                <>
                    <div>&nbsp;</div>
                    <Paper>
                        <BatchJobsTable jobPage={jobPage} jobState={jobState}/>
                    </Paper>
                    <VersionFooter/>
                </>
            }
        </main>
    );
};

export default BatchJobsView;