ALTER TABLE jobrunr_jobs
    ADD jobName NVARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_jobs
    ADD jobFingerprint NVARCHAR(255) NOT NULL DEFAULT '';

CREATE INDEX jobrunr_job_jobName_idx ON jobrunr_jobs (jobName);
CREATE INDEX jobrunr_job_jobFingerprint_idx ON jobrunr_jobs (jobFingerprint);
