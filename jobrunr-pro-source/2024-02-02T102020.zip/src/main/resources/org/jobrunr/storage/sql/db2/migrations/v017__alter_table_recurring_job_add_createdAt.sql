ALTER TABLE jobrunr_recurring_jobs
    ADD updatedAtMillis BIGINT DEFAULT '0' NOT NULL;
CREATE INDEX jobrunr_rj_updated_at_idx ON jobrunr_recurring_jobs (updatedAtMillis);