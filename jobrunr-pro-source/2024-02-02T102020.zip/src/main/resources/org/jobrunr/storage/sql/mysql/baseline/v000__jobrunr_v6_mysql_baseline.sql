/*!40101 SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE = @@TIME_ZONE */;
/*!40103 SET TIME_ZONE = '+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0 */;
/*!40101 SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0 */;

-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobrunr_backgroundjobservers`
(
    `id`                         char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
    `workerPoolSize`             int(11)                                                   NOT NULL,
    `pollIntervalInSeconds`      int(11)                                                   NOT NULL,
    `serverTags`                 varchar(512) DEFAULT NULL,
    `firstHeartbeat`             datetime(6)                                               NOT NULL,
    `lastHeartbeat`              datetime(6)                                               NOT NULL,
    `running`                    int(11)                                                   NOT NULL,
    `systemTotalMemory`          bigint(20)                                                NOT NULL,
    `systemFreeMemory`           bigint(20)                                                NOT NULL,
    `systemCpuLoad`              decimal(3,
                                     2)                                                    NOT NULL,
    `processMaxMemory`           bigint(20)                                                NOT NULL,
    `processFreeMemory`          bigint(20)                                                NOT NULL,
    `processAllocatedMemory`     bigint(20)                                                NOT NULL,
    `processCpuLoad`             decimal(3,
                                     2)                                                    NOT NULL,
    `deleteSucceededJobsAfter`   varchar(32)  DEFAULT NULL,
    `permanentlyDeleteJobsAfter` varchar(32)  DEFAULT NULL,
    `name`                       varchar(128) DEFAULT NULL,
    PRIMARY KEY
        (
         `id`
            ),
    KEY `jobrunr_bgjobsrvrs_fsthb_idx`
        (
         `firstHeartbeat`
            ),
    KEY `jobrunr_bgjobsrvrs_lsthb_idx`
        (
         `lastHeartbeat`
            )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

-- ==========================================
-- JobRunr Jobs
-- ==========================================
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
/*!40101 SET character_set_client = @saved_cs_client */;
CREATE TABLE `jobrunr_jobs`
(
    `id`             char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
    `version`        int(11)                                                   NOT NULL,
    `jobAsJson`      mediumtext                                                         DEFAULT NULL,
    `jobSignature`   varchar(512)                                              NOT NULL,
    `state`          varchar(36)                                               NOT NULL,
    `createdAt`      datetime(6)                                               NOT NULL,
    `updatedAt`      datetime(6)                                               NOT NULL,
    `scheduledAt`    datetime(6)                                                        DEFAULT NULL,
    `priority`       int(11)                                                   NOT NULL DEFAULT 2,
    `serverTag`      varchar(128)                                              NOT NULL DEFAULT 'DEFAULT',
    `mutex`          varchar(128)                                                       DEFAULT NULL,
    `mutexInUse`     varchar(128)                                                       DEFAULT NULL,
    `awaitingOn`     char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci          DEFAULT NULL,
    `isBatch`        int(11)                                                   NOT NULL DEFAULT 0,
    `recurringJobId` varchar(128)                                                       DEFAULT NULL,
    `deleteAt`       timestamp(6)                                              NULL     DEFAULT NULL,
    `jobName`        varchar(512)                                              NOT NULL DEFAULT '',
    `jobFingerprint` varchar(512)                                              NOT NULL DEFAULT '',
    `labels`         varchar(196)                                                       DEFAULT NULL,
    PRIMARY KEY
        (
         `id`
            ),
    UNIQUE KEY `jobrunr_job_mutexInUse_idx`
        (
         `mutexInUse`
            ),
    KEY `jobrunr_state_idx`
        (
         `state`
            ),
    KEY `jobrunr_job_signature_idx`
        (
         `jobSignature`
            ),
    KEY `jobrunr_job_created_at_idx`
        (
         `createdAt`
            ),
    KEY `jobrunr_job_updated_at_idx`
        (
         `updatedAt`
            ),
    KEY `jobrunr_job_scheduled_at_idx`
        (
         `scheduledAt`
            ),
    KEY `jobrunr_job_priority_idx`
        (
         `priority`
            ),
    KEY `jobrunr_job_serverTag_idx`
        (
         `serverTag`
            ),
    KEY `jobrunr_job_mutex_idx`
        (
         `mutex`
            ),
    KEY `jobrunr_job_rci_idx`
        (
         `recurringJobId`
            ),
    KEY `jobrunr_job_delete_at_idx`
        (
         `deleteAt`
            ),
    KEY `jobrunr_job_jobName_idx`
        (
         `jobName`
            ),
    KEY `jobrunr_job_jobFingerprint_idx`
        (
         `jobFingerprint`
            ),
    KEY `jobrunr_job_priority_updatedAt_state_idx`
        (
         `priority`,
         `updatedAt`,
         `state`
            ),
    KEY `jobrunr_job_isBatch_idx`
        (
         `isBatch`
            ),
    KEY `jobrunr_job_state_prio_idx`
        (
         `state`,
         `priority`
            ),
    KEY `jobrunr_job_waiting_on_idx`
        (
         `awaitingOn`,
         `state`
            ),
    KEY `jobrunr_job_jobLabels_idx`
        (
         `labels`
            )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci;


-- ==========================================
-- JobRunr Job Stats View
-- ==========================================
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `jobrunr_jobs_stats` AS
SELECT 1 AS `total`,
       1 AS `awaiting`,
       1 AS `scheduled`,
       1 AS `enqueued`,
       1 AS `enqueued_queue_0`,
       1 AS `enqueued_queue_1`,
       1 AS `enqueued_queue_2`,
       1 AS `enqueued_queue_3`,
       1 AS `enqueued_queue_4`,
       1 AS `processing`,
       1 AS `failed`,
       1 AS `succeeded`,
       1 AS `allTimeSucceeded`,
       1 AS `deleted`,
       1 AS `nbrOfBackgroundJobServers`,
       1 AS `nbrOfRecurringJobs`,
       1 AS `nbrOfBatchJobs`
        */;
SET character_set_client = @saved_cs_client;


-- ==========================================
-- JobRunr Metadata
-- ==========================================
DROP TABLE IF EXISTS `jobrunr_metadata`;
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobrunr_metadata`
(
    `id`        varchar(156) NOT NULL,
    `name`      varchar(92)  NOT NULL,
    `owner`     varchar(64)  NOT NULL,
    `value`     text         NOT NULL,
    `createdAt` datetime(6)  NOT NULL,
    `updatedAt` datetime(6)  NOT NULL,
    PRIMARY KEY
        (
         `id`
            )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobrunr_metadata` WRITE;
/*!40000 ALTER TABLE `jobrunr_metadata`
    DISABLE KEYS */;
INSERT INTO `jobrunr_metadata`
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0', '2023-01-1 00:00:00.000000',
        '2023-01-1 00:00:00.000000');
/*!40000 ALTER TABLE `jobrunr_metadata`
    ENABLE KEYS */;
UNLOCK TABLES;


-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
/*!40101 SET @saved_cs_client = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobrunr_recurring_jobs`
(
    `id`                        char(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
    `version`                   int(11)                                                    NOT NULL,
    `paused`                    int(11)                                                    NOT NULL,
    `createdAt`                 datetime(6)                                                NOT NULL,
    `updatedAt`                 datetime(6)                                                NOT NULL,
    `jobAsJson`                 text                                                       NOT NULL,
    `jobName`                   varchar(512)                                               NOT NULL DEFAULT '',
    `jobSignature`              varchar(512)                                               NOT NULL DEFAULT '',
    `labels`                    varchar(196)                                                        DEFAULT NULL,
    `priority`                  int(11)                                                    NOT NULL DEFAULT 2,
    `serverTag`                 varchar(128)                                               NOT NULL DEFAULT 'DEFAULT',
    `runsMoreThanOncePerMinute` int(11)                                                    NOT NULL DEFAULT 0,
    `nextRunAt`                 timestamp(6)                                               NOT NULL DEFAULT '2020-01-01 00:00:00.000000',
    PRIMARY KEY
        (
         `id`
            ),
    KEY `jobrunr_rj_idx`
        (
         `updatedAt`,
         `runsMoreThanOncePerMinute`,
         `paused`,
         `nextRunAt`
            )
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


-- ==========================================
-- JobRunr Job Stats View
-- ==========================================
/*!50001 DROP VIEW IF EXISTS `jobrunr_jobs_stats`*/;
/*!50001 SET @saved_cs_client = @@character_set_client */;
/*!50001 SET @saved_cs_results = @@character_set_results */;
/*!50001 SET @saved_col_connection = @@collation_connection */;
/*!50001 SET character_set_client = utf8mb4 */;
/*!50001 SET character_set_results = utf8mb4 */;
/*!50001 SET collation_connection = utf8mb4_general_ci */;
CREATE VIEW `jobrunr_jobs_stats` AS
with job_stat_results as (select `jobrunr_jobs`.`state`    AS `state`,
                                 `jobrunr_jobs`.`priority` AS `priority`,
                                 count(0)                  AS `count`
                          from `jobrunr_jobs`
                          group by `jobrunr_jobs`.`state`, `jobrunr_jobs`.`priority`
                          with rollup)
select coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` is null
                   and `job_stat_results`.`priority` is null), 0)              AS `total`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'AWAITING'
                   and `job_stat_results`.`priority` is null), 0)              AS `awaiting`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'SCHEDULED'
                   and `job_stat_results`.`priority` is null), 0)              AS `scheduled`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` is null), 0)              AS `enqueued`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` = 0), 0)                  AS `enqueued_queue_0`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` = 1), 0)                  AS `enqueued_queue_1`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` = 2), 0)                  AS `enqueued_queue_2`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` = 3), 0)                  AS `enqueued_queue_3`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'ENQUEUED'
                   and `job_stat_results`.`priority` = 4), 0)                  AS `enqueued_queue_4`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'PROCESSING'
                   and `job_stat_results`.`priority` is null), 0)              AS `processing`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'FAILED'
                   and `job_stat_results`.`priority` is null), 0)              AS `failed`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'SUCCEEDED'
                   and `job_stat_results`.`priority` is null), 0)              AS `succeeded`,
       coalesce((select cast(cast(`jm`.`value` as char(10) charset utf8mb4) as decimal(10, 0))
                 from `jobrunr_metadata` `jm`
                 where `jm`.`id` = 'succeeded-jobs-counter-cluster'), 0)       AS `allTimeSucceeded`,
       coalesce((select `job_stat_results`.`count`
                 from `job_stat_results`
                 where `job_stat_results`.`state` = 'DELETED'
                   and `job_stat_results`.`priority` is null), 0)              AS `deleted`,
       (select count(0) from `jobrunr_backgroundjobservers`)                   AS `nbrOfBackgroundJobServers`,
       (select count(0) from `jobrunr_recurring_jobs`)                         AS `nbrOfRecurringJobs`,
       (select count(0) from `jobrunr_jobs` `jobs` where `jobs`.`isBatch` = 1) AS `nbrOfBatchJobs`;

/*!50001 SET character_set_client = @saved_cs_client */;
/*!50001 SET character_set_results = @saved_cs_results */;
/*!50001 SET collation_connection = @saved_col_connection */;
/*!40103 SET TIME_ZONE = @OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE = @OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES = @OLD_SQL_NOTES */;