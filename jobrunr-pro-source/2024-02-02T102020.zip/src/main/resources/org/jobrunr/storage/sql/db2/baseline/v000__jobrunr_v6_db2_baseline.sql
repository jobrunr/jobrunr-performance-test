-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
create table JOBRUNR_BACKGROUNDJOBSERVERS
(
    ID                         nchar(36)     not null primary key,
    WORKERPOOLSIZE             INTEGER       not null,
    POLLINTERVALINSECONDS      INTEGER       not null,
    SERVERTAGS                 NVARCHAR(512) not null,
    FIRSTHEARTBEAT             TIMESTAMP(6)  not null,
    LASTHEARTBEAT              TIMESTAMP(6)  not null,
    RUNNING                    INTEGER       not null,
    SYSTEMTOTALMEMORY          DECIMAL(19)   not null,
    SYSTEMFREEMEMORY           DECIMAL(19)   not null,
    SYSTEMCPULOAD              DECIMAL(3, 2) not null,
    PROCESSMAXMEMORY           DECIMAL(19)   not null,
    PROCESSFREEMEMORY          DECIMAL(19)   not null,
    PROCESSALLOCATEDMEMORY     DECIMAL(19)   not null,
    PROCESSCPULOAD             DECIMAL(3, 2) not null,
    DELETESUCCEEDEDJOBSAFTER   NVARCHAR(32),
    PERMANENTLYDELETEJOBSAFTER NVARCHAR(32),
    NAME                       NVARCHAR(128)
);

create index JOBRUNR_BGJOBSRVRS_FSTHB_IDX on JOBRUNR_BACKGROUNDJOBSERVERS (FIRSTHEARTBEAT);
create index JOBRUNR_BGJOBSRVRS_LSTHB_IDX on JOBRUNR_BACKGROUNDJOBSERVERS (LASTHEARTBEAT);


-- ==========================================
-- JobRunr Jobs
-- ==========================================
create table JOBRUNR_JOBS
(
    ID             nchar(36)         not null primary key,
    VERSION        BIGINT            not null,
    JOBASJSON      CLOB              not null,
    JOBSIGNATURE   NVARCHAR(255) not null,
    STATE          NVARCHAR(36) not null,
    CREATEDAT      TIMESTAMP(6)      not null,
    UPDATEDAT      TIMESTAMP(6)      not null,
    SCHEDULEDAT    TIMESTAMP(6),
    PRIORITY       INTEGER default 2 not null,
    SERVERTAG      NVARCHAR(128) default 'DEFAULT' not null,
    MUTEX          NVARCHAR(128),
    MUTEXINUSE     NVARCHAR(128),
    AWAITINGON     nchar(36),
    ISBATCH        INTEGER default 0 not null,
    RECURRINGJOBID NVARCHAR(156),
    DELETEAT       TIMESTAMP(6),
    JOBNAME        NVARCHAR(255) default '' not null,
    JOBFINGERPRINT NVARCHAR(255) default '' not null,
    LABELS         NVARCHAR(196)
);

create index JOBRUNR_JOB_CREATED_AT_IDX on JOBRUNR_JOBS (CREATEDAT);
create index JOBRUNR_JOB_DELETE_AT_IDX on JOBRUNR_JOBS (DELETEAT);
create index JOBRUNR_JOB_ISBATCH_IDX on JOBRUNR_JOBS (ISBATCH);
create index JOBRUNR_JOB_JOBFINGERPRINT_IDX on JOBRUNR_JOBS (JOBFINGERPRINT);
create index JOBRUNR_JOB_JOBLABELS_IDX on JOBRUNR_JOBS (LABELS);
create index JOBRUNR_JOB_JOBNAME_IDX on JOBRUNR_JOBS (JOBNAME);
create unique index JOBRUNR_JOB_MUTEXINUSE_IDX on JOBRUNR_JOBS (MUTEXINUSE) EXCLUDE NULL KEYS;
create index JOBRUNR_JOB_MUTEX_IDX on JOBRUNR_JOBS (MUTEX);
create index JOBRUNR_JOB_PRIORITY_IDX on JOBRUNR_JOBS (PRIORITY);
create index JOBRUNR_JOB_PRIO_UPDTAT_ST_IDX on JOBRUNR_JOBS (PRIORITY, UPDATEDAT, STATE);
create index JOBRUNR_JOB_RCI_IDX on JOBRUNR_JOBS (RECURRINGJOBID);
create index JOBRUNR_JOB_SCHEDULED_AT_IDX on JOBRUNR_JOBS (SCHEDULEDAT);
create index JOBRUNR_JOB_SERVERTAG_IDX on JOBRUNR_JOBS (SERVERTAG);
create index JOBRUNR_JOB_SIGNATURE_IDX on JOBRUNR_JOBS (JOBSIGNATURE);
create index JOBRUNR_JOB_STATE_PRIO_IDX on JOBRUNR_JOBS (STATE, PRIORITY);
create index JOBRUNR_JOB_UPDATED_AT_IDX on JOBRUNR_JOBS (UPDATEDAT);
create index JOBRUNR_JOB_WAITING_ON_IDX on JOBRUNR_JOBS (AWAITINGON, STATE);
create index JOBRUNR_STATE_IDX on JOBRUNR_JOBS (STATE);


-- ==========================================
-- JobRunr Metadata
-- ==========================================
create table JOBRUNR_METADATA
(
    ID        NVARCHAR(156) not null primary key,
    NAME      NVARCHAR(92) not null,
    OWNER     NVARCHAR(64) not null,
    VALUE     CLOB         not null,
    CREATEDAT TIMESTAMP(6) not null,
    UPDATEDAT TIMESTAMP(6) not null
);
INSERT INTO jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0',
        TIMESTAMP '2023-01-1 00:00:00.000000', TIMESTAMP '2023-01-1 00:00:00.000000');

-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
create table JOBRUNR_RECURRING_JOBS
(
    ID                        NVARCHAR(128) not null primary key,
    VERSION                   BIGINT                                            not null,
    PAUSED                    INTEGER                                           not null,
    CREATEDAT                 TIMESTAMP(6)                                      not null,
    UPDATEDAT                 TIMESTAMP(6)                                      not null,
    JOBASJSON                 CLOB(1048576) not null,
    JOBNAME                   NVARCHAR(512) default '' not null,
    JOBSIGNATURE              NVARCHAR(512) default '' not null,
    LABELS                    NVARCHAR(196),
    PRIORITY                  INTEGER      default 2                            not null,
    SERVERTAG                 NVARCHAR(128) default 'DEFAULT' not null,
    RUNSMORETHANONCEPERMINUTE INTEGER      default 0                            not null,
    NEXTRUNAT                 TIMESTAMP(6) default '2020-01-01-00.00.00.000000' not null
);

create index JOBRUNR_RJ_IDX on JOBRUNR_RECURRING_JOBS (UPDATEDAT, RUNSMORETHANONCEPERMINUTE, PAUSED, NEXTRUNAT);

-- ==========================================
-- JobRunr Jobs Stats View
-- ==========================================
CREATE VIEW jobrunr_jobs_stats
as
with job_stat_results as (SELECT state, priority, count(*) as count
    FROM jobrunr_jobs
    GROUP BY ROLLUP (state, priority
)
)
select coalesce((select count from job_stat_results where state IS NULL), 0)                             as total,
       coalesce((select count from job_stat_results where state = 'AWAITING' and priority IS NULL), 0)   as awaiting,
       coalesce((select count from job_stat_results where state = 'SCHEDULED' and priority IS NULL), 0)  as scheduled,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority IS NULL), 0)   as enqueued,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 0), 0)       as enqueued_queue_0,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 1), 0)       as enqueued_queue_1,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 2), 0)       as enqueued_queue_2,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 3), 0)       as enqueued_queue_3,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 4), 0)       as enqueued_queue_4,
       coalesce((select count from job_stat_results where state = 'PROCESSING' and priority IS NULL), 0) as processing,
       coalesce((select count from job_stat_results where state = 'FAILED' and priority IS NULL), 0)     as failed,
       coalesce((select count from job_stat_results where state = 'SUCCEEDED' and priority IS NULL), 0)  as succeeded,
       coalesce((select cast(cast(value as char(10)) as decimal(10, 0))
                 from jobrunr_metadata jm
                 where jm.id = 'succeeded-jobs-counter-cluster'), 0)                                     as allTimeSucceeded,
       coalesce((select count from job_stat_results where state = 'DELETED' and priority IS NULL), 0)    as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                               as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                                     as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                                   as nbrOfBatchJobs
from sysibm.sysdummy1;

