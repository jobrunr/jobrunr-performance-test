DROP INDEX jobrunr_job_prio_updtAt_st_idx;
ALTER TABLE jobrunr_jobs
    ADD dynamicQueue NVARCHAR(48);

CREATE INDEX jobrunr_job_to_process_idx ON jobrunr_jobs (priority ASC, updatedAt ASC, state, serverTag, dynamicQueue);