ALTER TABLE jobrunr_jobs
    ADD jobExceptionType NVARCHAR(192);

CREATE INDEX jobrunr_jsexct_idx ON jobrunr_jobs (state, jobExceptionType ASC);