package org.jobrunr.jobs.filters;

import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.filters.retry.CustomRetryPolicy;
import org.jobrunr.jobs.filters.retry.ExponentialBackoffRetryPolicy;
import org.jobrunr.jobs.filters.retry.PerJobRetryPolicy;
import org.jobrunr.jobs.queues.Queues;
import org.jobrunr.jobs.states.FailedState;
import org.jobrunr.jobs.states.ScheduledState;
import org.jobrunr.stubs.TestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;
import java.util.function.Predicate;

import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.MILLIS;
import static org.assertj.core.api.Assertions.within;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.JobRunrException.problematicConfigurationException;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJob;
import static org.jobrunr.jobs.JobTestBuilder.aFailedJobWithRetries;
import static org.jobrunr.jobs.JobTestBuilder.aJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJob;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.jobs.states.StateName.ENQUEUED;
import static org.jobrunr.jobs.states.StateName.FAILED;
import static org.jobrunr.jobs.states.StateName.SCHEDULED;

class DefaultRetryFilterTest {

    private DefaultRetryFilter defaultRetryFilter;

    @BeforeEach
    void setupRetryFilter() {
        defaultRetryFilter = new DefaultRetryFilter();
    }

    @Test
    void skipsIfTestIsNotFailed() {
        final Job job = anEnqueuedJobWithName().build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(ENQUEUED);
    }

    @Test
    void retryFilterSchedulesJobAgainIfItIsFailed() {
        final Job job = aFailedJob().build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion + 1);
        assertThat(job.getState()).isEqualTo(SCHEDULED);
    }

    @Test
    void retryFilterSchedulesJobAgainIfItIsFailedButMaxNumberOfRetriesIsNotReached() {
        final Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWorkThatFailsWithAnnotation())
                .withState(new FailedState("a message", new RuntimeException("boem")))
                .build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion + 1);
        assertThat(job.getState()).isEqualTo(SCHEDULED);
    }


    @Test
    void retryFilterDoesNotScheduleJobAgainIfMaxNumberOfRetriesIsReached() {
        final Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWorkThatFailsWithAnnotation())
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .withState(new FailedState("firstRetry", new RuntimeException("boom")))
                .build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(FAILED);
    }

    @Test
    void retryFilterDoesNotScheduleJobAgainIfTheExceptionIsProblematic() {
        final Job job = aFailedJob().withState(new FailedState("a message", problematicConfigurationException("big problem"))).build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(FAILED);
    }

    @Test
    void retryFilterDoesNotScheduleJobAgainIfItHasFailed10Times() {
        final Job job = aFailedJobWithRetries().build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(FAILED);
    }

    @Test
    void retryFilterKeepsDefaultRetryFilterValueOf10IfRetriesOnJobAnnotationIsNotProvided() {
        final Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWork())
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion + 1);
        assertThat(job.getState()).isEqualTo(SCHEDULED);
    }

    @Test
    void retryFilterKeepsDefaultGivenRetryFilterValueIfRetriesOnJobAnnotationIsNotProvided() {
        defaultRetryFilter = new DefaultRetryFilter(0);
        final Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWork())
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        defaultRetryFilter.onStateElection(job, job.getJobState());
        int afterVersion = job.getJobStates().size();

        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(FAILED);
    }

    @Test
    void retryFilterUsesValueOfRetriesOnJobAnnotationIfProvided() {
        defaultRetryFilter = new DefaultRetryFilter(0);

        // GIVEN FIRST FAILURE, NOT YET RETRIED
        Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWorkThatFailsWithAnnotation())
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .build();
        applyDefaultJobFilter(job);
        int beforeVersion = job.getJobStates().size();

        // WHEN
        defaultRetryFilter.onStateElection(job, job.getJobState());

        // THEN
        int afterVersion = job.getJobStates().size();
        assertThat(afterVersion).isEqualTo(beforeVersion + 1);
        assertThat(job.getState()).isEqualTo(SCHEDULED);

        // GIVEN SECOND FAILURE, ALREADY RETRIED
        job = aCopyOf(job)
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .build();
        beforeVersion = job.getJobStates().size();

        // WHEN
        defaultRetryFilter.onStateElection(job, job.getJobState());

        // THEN
        afterVersion = job.getJobStates().size();
        assertThat(afterVersion).isEqualTo(beforeVersion);
        assertThat(job.getState()).isEqualTo(FAILED);
    }

    @Test
    void retryFilterUsesCustomRetryPolicy() {
        CustomRetryPolicy customRetryPolicy = new CustomRetryPolicy(2);
        defaultRetryFilter = new DefaultRetryFilter(customRetryPolicy);
        final Job job = aJob()
                .<TestService>withJobDetails(ts -> ts.doWork())
                .withState(new FailedState("a message", new RuntimeException("boom")))
                .build();
        applyDefaultJobFilter(job);
        defaultRetryFilter.onStateElection(job, job.getJobState());

        assertThat(job).hasState(SCHEDULED);
        assertThat(((ScheduledState) job.getJobState()).getScheduledAt()).isCloseTo(now().plusSeconds(2), within(200, MILLIS));
    }

    @Test
    void retryPolicyIsInvokedIfJobHasFailed() {
        // GIVEN
        TestRetryPolicyPredicate jobPredicate = new TestRetryPolicyPredicate();
        PerJobRetryPolicy customRetryPolicy = new PerJobRetryPolicy(
                new ExponentialBackoffRetryPolicy(),
                new CustomRetryPolicy(2).ifJob(jobPredicate)
        );
        defaultRetryFilter = new DefaultRetryFilter(customRetryPolicy);
        final Job job = aFailedJob().build();
        applyDefaultJobFilter(job);

        // WHEN
        defaultRetryFilter.onStateElection(job, job.getJobState());

        // THEN
        assertThat(jobPredicate.predicateHasBeenInvoked).isTrue();
    }

    @Test
    void retryPolicyIsNotTestedOrInvokedIfJobHasStateDifferentFromFailed() {
        // GIVEN
        TestRetryPolicyPredicate jobPredicate = new TestRetryPolicyPredicate();
        PerJobRetryPolicy customRetryPolicy = new PerJobRetryPolicy(
                new ExponentialBackoffRetryPolicy(),
                new CustomRetryPolicy(2).ifJob(jobPredicate)
        );
        defaultRetryFilter = new DefaultRetryFilter(customRetryPolicy);
        final Job job = anEnqueuedJob().build();
        applyDefaultJobFilter(job);

        // WHEN
        defaultRetryFilter.onStateElection(job, job.getJobState());

        // THEN
        assertThat(jobPredicate.predicateHasBeenInvoked).isFalse();
    }

    void applyDefaultJobFilter(Job job) {
        new DefaultJobFilter(UUID.randomUUID(), new Queues()).onCreating(job);
    }

    private static class TestRetryPolicyPredicate implements Predicate<Job> {

        private boolean predicateHasBeenInvoked;

        @Override
        public boolean test(Job job) {
            this.predicateHasBeenInvoked = true;
            return false;
        }
    }
}