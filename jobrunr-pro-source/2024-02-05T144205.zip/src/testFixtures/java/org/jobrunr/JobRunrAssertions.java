package org.jobrunr;

import ch.qos.logback.LoggerAssert;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterAssert;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.data.SpanDataAssert;
import net.javacrumbs.jsonunit.assertj.JsonAssert;
import net.javacrumbs.jsonunit.assertj.JsonAssertions;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Condition;
import org.assertj.core.api.IdListAssert;
import org.assertj.core.api.ListAssert;
import org.assertj.db.DatabaseAssertions;
import org.jobrunr.dashboard.server.http.client.HttpResponseAssert;
import org.jobrunr.dashboard.server.security.JobRunrUser;
import org.jobrunr.dashboard.server.security.JobRunrUserAssert;
import org.jobrunr.jobs.DynamicQueueStats;
import org.jobrunr.jobs.DynamicQueueStatsAssert;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobAssert;
import org.jobrunr.jobs.JobDetails;
import org.jobrunr.jobs.JobDetailsAssert;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.jobs.RecurringJobAssert;
import org.jobrunr.jobs.filters.retry.RetryPolicy;
import org.jobrunr.jobs.filters.retry.RetryPolicyAssert;
import org.jobrunr.scheduling.AbstractJobScheduler;
import org.jobrunr.scheduling.JobResultWithBackOffInfo;
import org.jobrunr.scheduling.JobResultWithBackOffInfoAssert;
import org.jobrunr.scheduling.JobSchedulerAssert;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.BackgroundJobServerAssert;
import org.jobrunr.server.BackgroundJobServerConfiguration;
import org.jobrunr.server.BackgroundJobServerConfigurationAssert;
import org.jobrunr.server.BackgroundJobServerStatusAssert;
import org.jobrunr.storage.BackgroundJobServerStatus;
import org.jobrunr.storage.ConcurrentJobModificationException;
import org.jobrunr.storage.JobRunrMetadata;
import org.jobrunr.storage.JobRunrMetadataAssert;
import org.jobrunr.storage.JobSearchRequest;
import org.jobrunr.storage.JobSearchRequestAssert;
import org.jobrunr.storage.Page;
import org.jobrunr.storage.PageAssert;
import org.jobrunr.storage.RecurringJobSearchRequest;
import org.jobrunr.storage.RecurringJobSearchRequestAssert;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.StorageProviderAssert;
import org.jobrunr.storage.navigation.DynamicAmountRequest;
import org.jobrunr.storage.navigation.DynamicAmountRequestAssert;
import org.jobrunr.utils.resilience.BackOffResult;
import org.jobrunr.utils.resilience.BackOffResultAssert;

import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.http.HttpResponse;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

public class JobRunrAssertions extends Assertions {

    public static Condition<Throwable> failedJob(Job job) {
        return new Condition<>(x -> x instanceof ConcurrentJobModificationException && ((ConcurrentJobModificationException) x).getConcurrentUpdatedJobs().contains(job), "Should contain job");
    }

    public static JobAssert assertThat(Job job) {
        return JobAssert.assertThat(job);
    }

    public static <T extends Job> ListAssert<T> assertThatJobs(Page<T> jobPage) {
        return assertThatJobs(jobPage.getItems());
    }

    public static <T extends Job> IdListAssert<T> assertThatJobs(List<T> jobs) {
        return (IdListAssert<T>) new IdListAssert<>(jobs).usingRecursiveFieldByFieldElementComparatorIgnoringFields("locker", "newState", "jobHistory.exception", "stateIndexBeforeStateChange");
    }

    public static IdListAssert<RecurringJob> assertThatRecurringJobs(List<RecurringJob> recurringJobs) {
        return (IdListAssert<RecurringJob>) new IdListAssert<>(recurringJobs).usingRecursiveFieldByFieldElementComparatorIgnoringFields("locker", "jobHistory.exception");
    }

    public static RecurringJobAssert assertThat(RecurringJob recurringJob) {
        return RecurringJobAssert.assertThat(recurringJob);
    }

    public static JobDetailsAssert assertThat(JobDetails jobDetails) {
        return JobDetailsAssert.assertThat(jobDetails);
    }

    public static JobRunrMetadataAssert assertThat(JobRunrMetadata metadata) {
        return JobRunrMetadataAssert.assertThat(metadata);
    }

    public static JobSearchRequestAssert assertThat(JobSearchRequest searchRequest) {
        return JobSearchRequestAssert.assertThat(searchRequest);
    }

    public static RecurringJobSearchRequestAssert assertThat(RecurringJobSearchRequest searchRequest) {
        return RecurringJobSearchRequestAssert.assertThat(searchRequest);
    }

    public static <T> PageAssert<T> assertThat(Page<T> page) {
        return PageAssert.assertThat(page);
    }

    public static BackgroundJobServerConfigurationAssert assertThat(BackgroundJobServerConfiguration backgroundJobServerConfiguration) {
        return BackgroundJobServerConfigurationAssert.assertThat(backgroundJobServerConfiguration);
    }

    public static BackgroundJobServerAssert assertThat(BackgroundJobServer backgroundJobServer) {
        return BackgroundJobServerAssert.assertThat(backgroundJobServer);
    }

    public static BackgroundJobServerStatusAssert assertThat(BackgroundJobServerStatus backgroundJobServerStatus) {
        return BackgroundJobServerStatusAssert.assertThat(backgroundJobServerStatus);
    }

    public static DynamicQueueStatsAssert assertThat(DynamicQueueStats dynamicQueueStats) {
        return DynamicQueueStatsAssert.assertThat(dynamicQueueStats);
    }

    public static StorageProviderAssert assertThat(StorageProvider storageProvider) {
        return StorageProviderAssert.assertThat(storageProvider);
    }

    public static DynamicAmountRequestAssert assertThat(DynamicAmountRequest dynamicAmountRequest) {
        return DynamicAmountRequestAssert.assertThat(dynamicAmountRequest);
    }

    public static JobRunrUserAssert assertThat(JobRunrUser jobRunrUser) {
        return JobRunrUserAssert.assertThat(jobRunrUser);
    }

    public static HttpResponseAssert assertThat(HttpResponse httpResponse) {
        return HttpResponseAssert.assertThat(httpResponse);
    }

    public static JsonAssert.ConfigurableJsonAssert assertThatJson(String json) {
        return JsonAssertions.assertThatJson(json);
    }

    public static DatabaseAssertions assertThat(DataSource dataSource) {
        return DatabaseAssertions.assertThat(dataSource);
    }

    public static JobSchedulerAssert assertThat(AbstractJobScheduler jobScheduler) {
        return JobSchedulerAssert.assertThat(jobScheduler);
    }

    public static JobResultWithBackOffInfoAssert assertThat(JobResultWithBackOffInfo result) {
        return JobResultWithBackOffInfoAssert.assertThat(result);
    }

    public static BackOffResultAssert assertThat(BackOffResult backOffResult) {
        return BackOffResultAssert.assertThat(backOffResult);
    }

    public static RetryPolicyAssert assertThat(RetryPolicy retryPolicy) {
        return RetryPolicyAssert.assertThat(retryPolicy);
    }

    public static MeterAssert assertThat(Meter meter) {
        return MeterAssert.assertThat(meter);
    }

    public static SpanDataAssert assertThat(SpanData spanData) {
        return SpanDataAssert.assertThat(spanData);
    }

    public static LoggerAssert assertThat(ListAppender<ILoggingEvent> listAppender) {
        return LoggerAssert.assertThat(listAppender);
    }

    public static String contentOfResource(String resourceName) {
        try {
            if (resourceName.startsWith("src/")) {
                return Files.readString(Path.of(resourceName));
            }
            return Files.readString(Paths.get(JobRunrAssertions.class.getResource(resourceName).toURI()));
        } catch (FileSystemNotFoundException e) {
            try (InputStream is = JobRunrAssertions.class.getResource(resourceName).openStream();) {
                if (is == null) return null;
                try (InputStreamReader isr = new InputStreamReader(is);
                     BufferedReader reader = new BufferedReader(isr)) {
                    return reader.lines().collect(Collectors.joining(System.lineSeparator()));
                }
            } catch (Exception ex) {
                throw new AssertionError(ex);
            }
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    }

}
