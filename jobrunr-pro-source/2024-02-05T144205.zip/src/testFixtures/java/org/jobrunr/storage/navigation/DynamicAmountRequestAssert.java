package org.jobrunr.storage.navigation;

import org.assertj.core.api.AbstractAssert;
import org.assertj.core.api.Assertions;

public class DynamicAmountRequestAssert extends AbstractAssert<DynamicAmountRequestAssert, DynamicAmountRequest> {
    private DynamicAmountRequestAssert(DynamicAmountRequest dynamicAmountRequest) {
        super(dynamicAmountRequest, DynamicAmountRequestAssert.class);
    }

    public static DynamicAmountRequestAssert assertThat(DynamicAmountRequest DynamicAmountRequest) {
        return new DynamicAmountRequestAssert(DynamicAmountRequest);
    }

    public DynamicAmountRequestAssert isEqualTo(AmountRequest amountRequest) {
        Assertions.assertThat(actual)
                .usingRecursiveComparison()
                .comparingOnlyFields("order", "limit")
                .isEqualTo(amountRequest);
        return this;
    }
}
