package org.jobrunr.server.queue;


import org.assertj.core.api.Condition;
import org.jobrunr.jobs.Job;
import org.jobrunr.jobs.JobDetails;
import org.jobrunr.jobs.JobDetailsTestBuilder;
import org.jobrunr.jobs.filters.JobDefaultFilters;
import org.jobrunr.server.BackgroundJobServer;
import org.jobrunr.server.queue.TurboQueue.AvailableWorkerTimeDynamicAmountRequest;
import org.jobrunr.server.queue.TurboQueue.WindowedAverage;
import org.jobrunr.server.strategy.DynamicQueueStrategy;
import org.jobrunr.server.strategy.WorkDistributionStrategy;
import org.jobrunr.storage.navigation.AmountRequest;
import org.jobrunr.storage.navigation.DynamicAmountRequest;
import org.jobrunr.stubs.TestService;
import org.jobrunr.utils.JobUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static java.time.Duration.ofSeconds;
import static java.time.Instant.now;
import static java.util.stream.Collectors.toList;
import static java.util.stream.IntStream.range;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.data.Offset.offset;
import static org.jobrunr.JobRunrAssertions.assertThat;
import static org.jobrunr.jobs.JobDetailsTestBuilder.systemOutPrintLnJobDetails;
import static org.jobrunr.jobs.JobTestBuilder.aCopyOf;
import static org.jobrunr.jobs.JobTestBuilder.anEnqueuedJobWithName;
import static org.jobrunr.server.BackgroundJobServerConfiguration.usingStandardBackgroundJobServerConfiguration;
import static org.jobrunr.storage.Paging.AmountBasedList.ascOnPriorityAndUpdatedAt;
import static org.jobrunr.utils.CollectionUtils.unionToList;
import static org.jobrunr.utils.SleepUtils.sleep;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.refEq;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.getInternalState;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

@ExtendWith(MockitoExtension.class)
class TurboQueueTest {

    @Mock
    BackgroundJobServer backgroundJobServer;
    @Mock
    WorkDistributionStrategy workDistributionStrategy;
    @Mock
    DynamicQueueStrategy dynamicQueueStrategy;

    TurboQueue turboQueue;

    @BeforeEach
    void setUp() {
        lenient().when(backgroundJobServer.getConfiguration()).thenReturn(usingStandardBackgroundJobServerConfiguration().andPollInterval(ofSeconds(5)));
        lenient().when(backgroundJobServer.getWorkDistributionStrategy()).thenReturn(workDistributionStrategy);
        lenient().when(backgroundJobServer.getDynamicQueueStrategy()).thenReturn(dynamicQueueStrategy);
        lenient().when(workDistributionStrategy.getWorkerCount()).thenReturn(10);
        lenient().when(backgroundJobServer.getJobFilters()).thenReturn(new JobDefaultFilters(UUID.randomUUID()));

        turboQueue = new TurboQueue(backgroundJobServer);
    }

    @Test
    void testJobsToProcessNoJobsAndNoRunningAverageAvailable() {
        // WHEN
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        verify(dynamicQueueStrategy, times(1)).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndLessResultsThanRequestedThenNoExtraDynamicQueueCall() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobs(2));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(2);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndNoRunningAverageAvailable() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobs(10));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    // is this test correct? Don't we want to fetch only if we have short running jobs?
    @Test
    void testJobsToProcessWithJobsProcessingButNoRunningAverageAvailable() {
        // GIVEN
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(10)))
                .thenReturn(generateJobs(10));
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(5));

        // THEN
        assertThat(jobsToProcess).hasSize(5);
        verify(dynamicQueueStrategy).getJobsToProcess(dynamicAmountRequest(10));
    }

    @Test
    void testJobsToProcessAndVeryShortRunningAverageAvailable() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(dynamicAmountRequest(50)))
                .thenReturn(generateJobs(50, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy, times(2)).getJobsToProcess(dynamicAmountRequest(50));
    }

    @Test
    void testJobsToProcessAndVeryLongRunningAverageAvailable() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(10))))
                .thenReturn(generateJobs(10, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(10)));
    }

    @Test
    void testJobsToProcessIncreasesQueueFactorIfMoreJobsAreAvailable() {
        // GIVEN
        Job shortRunningJob = setupJobWithShortRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(any(AmountRequest.class)))
                .thenReturn(generateJobs(10, shortRunningJob.getJobDetails()));
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // WHEN
        sleep(20);
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy, times(2)).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(10)));
        verify(dynamicQueueStrategy, times(1)).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(12)));
    }

    @Test
    void testJobsToProcessDoesNotIncreaseQueueFactorIfJobsTakeLong() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(any(AmountRequest.class)))
                .thenReturn(generateJobs(10, longRunningJob.getJobDetails()));
        turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // WHEN
        sleep(20);
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy, times(2)).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(10)));
        assertThat(getQueueSizeFactor()).isEqualTo(1.0);
    }

    @Test
    void testJobsToProcessDoesNotOnboardNewJobsIfAllThreadsOccupiedByLongRunningJobs() {
        // GIVEN
        Job longRunningJob = setupJobWithLongRunningAverage();
        List<Job> jobs = generateJobs(10, longRunningJob.getJobDetails());
        fillQueueWithJobs(jobs);
        turboQueue.onThreadReleased(aCopyOf(jobs.remove(0)).withSucceededState(0, 11_000).build());
        turboQueue.onThreadReleased(aCopyOf(jobs.remove(0)).withSucceededState(0, 9_000).build());

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(2));

        // THEN
        assertThat(jobsToProcess1).hasSize(2);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);


        // WHEN
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(8));

        // THEN
        assertThat(jobsToProcess2).hasSize(8);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorOnlyOnboardsLimitedNewJobsIfQueueOccupiedByLongRunningJobs() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job longRunningJob = setupJobWithLongRunningAverage();
        when(dynamicQueueStrategy.getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(40))))
                .thenReturn(generateJobs(40, longRunningJob.getJobDetails()));


        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        assertThat(jobsToProcess1).hasSize(6);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(40)));


        // WHEN
        clearInvocations(dynamicQueueStrategy);
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(4));

        // THEN
        assertThat(jobsToProcess2).hasSize(4);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorDoesNotOnboardNewJobsIfQueueOccupiedByLongRunningJobs() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobs(10, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        assertThat(jobsToProcess1).hasSize(6);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);


        // WHEN
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(4));

        // THEN
        assertThat(jobsToProcess2).hasSize(4);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorDoesNotOnboardNewJobsIfQueueOccupiedByMoreLongRunningJobsThenWorkers() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobs(2, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobs(30, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess1 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(6));

        // THEN
        assertThat(jobsToProcess1).hasSize(6);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);


        // WHEN
        List<Job> jobsToProcess2 = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(4));

        // THEN
        assertThat(jobsToProcess2).hasSize(4);
        sleep(20);
        verifyNoInteractions(dynamicQueueStrategy);
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorDoesNotExceedMaxQueueSize() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobs(25, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(40)));
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorOnlyOnboardsNewJobsForShortRunningJobsA() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobs(25, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobs(5, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(20)));
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorOnlyOnboardsNewJobsForShortRunningJobsB() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        fillQueueWithJobs(generateJobs(25, shortRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobs(8, longRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(8)));
    }

    @Test
    void testJobsToProcessWithMaxQueueSizeFactorOnboardsNewJobsIfLongRunningJobsAreAboutToFinish() {
        // GIVEN
        setQueueSizeFactor(4.0);

        Job longRunningJob = setupJobWithLongRunningAverage();
        Job shortRunningJob = setupJobWithShortRunningAverage();
        fillQueueWithJobs(generateJobs(now().minusSeconds(58), 8, longRunningJob.getJobDetails()));
        fillQueueWithJobs(generateJobs(25, shortRunningJob.getJobDetails()));

        // WHEN
        List<Job> jobsToProcess = turboQueue.getJobsToProcess(ascOnPriorityAndUpdatedAt(10));

        // THEN
        assertThat(jobsToProcess).hasSize(10);
        sleep(20);
        verify(dynamicQueueStrategy).getJobsToProcess(refEq(ascOnPriorityAndUpdatedAt(40)));
    }

    @Test
    void runningAverageIsImmediatelyAvailable() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(60_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(61_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(59000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_500L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 56_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_000L);

        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 61_000).build());
        assertThat(getWindowedAverage(job.getJobDetails()).getAverageProcessingTimeInMillis()).isEqualTo(58_500L);
    }

    @Test
    void runningAverageIsNotImpactedByOutlier() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 52_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 64_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());
        long runningAverageInMillisBeforeOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 10_000).build());
        long runningAverageInMillisAfterOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterOutlier).isEqualTo(runningAverageInMillisBeforeOutlier);
    }

    @Test
    void runningAverageIsNotAnOutlierIfStandardDeviationReallySmallAndItIsWithin1Percent() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_005).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 59_995).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_005).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 59_995).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());
        long runningAverageInMillisBeforeNewValue = windowedAverage.getAverageProcessingTimeInMillis();

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_055).build());
        long runningAverageInMillisAfterNewValue = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterNewValue).isNotCloseTo(runningAverageInMillisBeforeNewValue, offset(5L));
    }

    @Test
    void runningAverageIsResetAfterFiveOutliers() {
        // GIVEN
        Job job = anEnqueuedJobWithName().withProcessingState().build();
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 60_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 62_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 55_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 57_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 52_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 64_000).build());
        WindowedAverage windowedAverage = getWindowedAverage(job.getJobDetails());

        // WHEN
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 10_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 12_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 9_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 13_000).build());
        turboQueue.onThreadReleased(aCopyOf(job).withSucceededState(0, 8_000).build());
        long runningAverageInMillisAfterOutlier = windowedAverage.getAverageProcessingTimeInMillis();

        // THEN
        assertThat(runningAverageInMillisAfterOutlier).isZero();
        assertThat(getWindowedAverage(job.getJobDetails())).isNull();
    }

    @Test
    void dynamicAmountRequestWithoutAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, null, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(10));
    }

    @Test
    void dynamicAmountRequestWithAverageProcessingTimeEqualTo0IsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 0L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50));
    }

    @Test
    void dynamicAmountRequestWithVerySmallAverageProcessingTimeAvailableIsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 10L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50));
    }

    @Test
    void dynamicAmountRequestWithMediumAverageProcessingTimeAvailableIsCappedUsingJobAmountRequestFactor() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(50)); // (10 * 5000) / 900 but capped
    }

    @Test
    void dynamicAmountRequestWithLargerAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 2500L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(20)); // (10 * 5000) / 2500
    }

    @Test
    void dynamicAmountRequestWithVeryLargeAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 30_000L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(10)); // (10 * 5000) / 30_000 == 2 but 10 workers available, so 10
    }

    @Test
    void dynamicAmountRequestWithOneWorkerOnlyAndVeryLargeAverageProcessingTimeAvailable() {
        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(2, 5000, 5, 30_000L, new ConcurrentHashMap<>());

        assertThat(dynamicAmountRequest).isEqualTo(ascOnPriorityAndUpdatedAt(2)); // (1 * 5000) / 30_000 == 0 but 2 workers available, so 2
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableButNoJobAverageAvailableIsCappedToAvailableWorkerCount() {
        Job job = setupJobWithShortRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = new ConcurrentHashMap<>();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobs(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(10);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndSlowRunningJobsFromStorageProviderAcceptsLimitedJobs() {
        Job job = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobs(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(10);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndFastRunningJobsFromStorageProviderAcceptsAllJob() {
        Job job = setupJobWithShortRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = generateJobs(50, job.getJobDetails());

        assertThat(dynamicAmountRequest.filter(jobs)).hasSize(50);
    }

    @Test
    void dynamicAmountRequestVerySmallAverageProcessingTimeAvailableAndBothSlowAndFastRunningJobsFromStorageProviderAcceptsLimitedJobs() {
        Job shortRunningJob = setupJobWithShortRunningAverage();
        Job longRunningJob = setupJobWithLongRunningAverage();
        ConcurrentMap<String, WindowedAverage> allWindowedJobProcessingTimeAverages = getAllWindowedJobProcessingTimeAverages();

        AvailableWorkerTimeDynamicAmountRequest dynamicAmountRequest = new AvailableWorkerTimeDynamicAmountRequest(10, 5000, 5, 900L, allWindowedJobProcessingTimeAverages);

        List<Job> jobs = unionToList(generateJobs(8, longRunningJob.getJobDetails()), generateJobs(42, shortRunningJob.getJobDetails()));

        assertThat(dynamicAmountRequest.filter(jobs))
                .hasSize(19)
                .areExactly(8, jobsWithJobDetails(longRunningJob.getJobDetails()))
                .areExactly(11, jobsWithJobDetails(shortRunningJob.getJobDetails()));
    }

    private Job setupJobWithLongRunningAverage() {
        Job longRunningJob = createLongRunningJob();
        setupJobWithRunningAverage(longRunningJob);
        return longRunningJob;
    }

    private Job setupJobWithShortRunningAverage() {
        Job shortRunningJob = createShortRunningJob();
        setupJobWithRunningAverage(shortRunningJob);
        return shortRunningJob;
    }

    private Job createLongRunningJob() {
        TestService testService = mock(TestService.class);
        return anEnqueuedJobWithName().withJobDetails(() -> testService.doWorkThatTakesLong(60)).withProcessingState().withSucceededState(0, 60_000).build();
    }

    private Job createShortRunningJob() {
        TestService testService = mock(TestService.class);
        return anEnqueuedJobWithName().withJobDetails(() -> testService.doWork()).withProcessingState().withSucceededState(0, 900).build();
    }

    private void setupJobWithRunningAverage(Job job) {
        turboQueue.onThreadReleased(job);
    }

    private void fillQueueWithJobs(List<Job> jobs) {
        ((ArrayDeque<Job>) getInternalState(turboQueue, "jobQueue")).addAll(jobs);
    }

    private void setQueueSizeFactor(double queueSizeFactor) {
        setInternalState(turboQueue, "queueSizeFactor", queueSizeFactor);
    }

    private double getQueueSizeFactor() {
        return getInternalState(turboQueue, "queueSizeFactor");
    }

    private WindowedAverage getWindowedAverage(JobDetails jobDetails) {
        return getWindowedAverage(JobUtils.getJobSignature(jobDetails));
    }

    private WindowedAverage getWindowedAverage(String jobSignature) {
        Map<String, WindowedAverage> averageJobProcessingTime = getAllWindowedJobProcessingTimeAverages();
        return averageJobProcessingTime.get(jobSignature);
    }

    private ConcurrentMap<String, WindowedAverage> getAllWindowedJobProcessingTimeAverages() {
        return getInternalState(turboQueue, "averageProcessingTimePerJob");
    }

    private static List<Job> generateJobs(int amount) {
        return generateJobs(amount, systemOutPrintLnJobDetails("a test"));
    }

    private static List<Job> generateJobs(int amount, JobDetailsTestBuilder jobDetailsBuilder) {
        return generateJobs(amount, jobDetailsBuilder.build());
    }

    private static List<Job> generateJobs(int amount, JobDetails jobDetails) {
        return range(0, amount).boxed().map(i -> anEnqueuedJobWithName().withJobDetails(jobDetails).withProcessingState().build()).collect(toList());
    }

    private static List<Job> generateJobs(Instant processingStartedAt, int amount, JobDetails jobDetails) {
        return range(0, amount).boxed().map(i -> anEnqueuedJobWithName().withJobDetails(jobDetails).withProcessingState(processingStartedAt).build()).collect(toList());
    }

    private static AmountRequest dynamicAmountRequest(int amount) {
        return argThat(x -> ascOnPriorityAndUpdatedAt(amount).asString().equals(x.asString()) && x instanceof DynamicAmountRequest);
    }

    private static Condition<Job> jobsWithJobDetails(JobDetails jobDetails) {
        return new Condition<>(j -> j.getJobSignature().equals(JobUtils.getJobSignature(jobDetails)), "expected %s", JobUtils.getJobSignature(jobDetails));
    }
}