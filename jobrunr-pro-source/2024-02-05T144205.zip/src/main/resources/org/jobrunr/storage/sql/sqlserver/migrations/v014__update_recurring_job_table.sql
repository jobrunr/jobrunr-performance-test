DROP TABLE jobrunr_recurring_jobs;

CREATE TABLE jobrunr_recurring_jobs
(
    id        NCHAR(128) PRIMARY KEY,
    version   INT       NOT NULL,
    paused    INT       NOT NULL,
    createdAt DATETIME2 NOT NULL,
    updatedAt DATETIME2 NOT NULL,
    jobAsJson text      NOT NULL
);