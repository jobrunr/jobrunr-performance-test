ALTER TABLE jobrunr_jobs
    ADD jobName VARCHAR(512) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_jobs
    ADD jobFingerprint VARCHAR(512) NOT NULL DEFAULT '';

CREATE INDEX jobrunr_job_jobName_idx ON jobrunr_jobs (jobName);
CREATE INDEX jobrunr_job_jobFingerprint_idx ON jobrunr_jobs (jobFingerprint);
