-- PostgreSQL 9.6.12
SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;
COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';

SET default_tablespace = '';
SET default_with_oids = false;


-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
CREATE TABLE public.jobrunr_backgroundjobservers
(
    id                         character(36)                  NOT NULL,
    workerpoolsize             integer                        NOT NULL,
    pollintervalinseconds      integer                        NOT NULL,
    servertags                 character varying(512)         NOT NULL,
    firstheartbeat             timestamp(6) without time zone NOT NULL,
    lastheartbeat              timestamp(6) without time zone NOT NULL,
    running                    integer                        NOT NULL,
    systemtotalmemory          bigint                         NOT NULL,
    systemfreememory           bigint                         NOT NULL,
    systemcpuload              numeric(3, 2)                  NOT NULL,
    processmaxmemory           bigint                         NOT NULL,
    processfreememory          bigint                         NOT NULL,
    processallocatedmemory     bigint                         NOT NULL,
    processcpuload             numeric(3, 2)                  NOT NULL,
    deletesucceededjobsafter   character varying(32),
    permanentlydeletejobsafter character varying(32),
    name                       character varying(128)
);
ALTER TABLE public.jobrunr_backgroundjobservers
    OWNER TO test;

-- ==========================================
-- JobRunr Jobs
-- ==========================================
CREATE TABLE public.jobrunr_jobs
(
    id             character(36)                                               NOT NULL,
    version        integer                                                     NOT NULL,
    jobasjson      text                                                        NOT NULL,
    jobsignature   character varying(512)                                      NOT NULL,
    state          character varying(36)                                       NOT NULL,
    createdat      timestamp without time zone                                 NOT NULL,
    updatedat      timestamp without time zone                                 NOT NULL,
    scheduledat    timestamp without time zone,
    priority       integer                DEFAULT 2                            NOT NULL,
    servertag      character varying(128) DEFAULT 'DEFAULT'::character varying NOT NULL,
    mutex          character varying(128),
    mutexinuse     character varying(128),
    awaitingon     character(36),
    isbatch        integer                DEFAULT 0                            NOT NULL,
    recurringjobid character varying(128),
    deleteat       timestamp without time zone,
    jobname        character varying(512) DEFAULT ''::character varying        NOT NULL,
    jobfingerprint character varying(512) DEFAULT ''::character varying        NOT NULL,
    labels         character varying(196)
);
ALTER TABLE public.jobrunr_jobs
    OWNER TO test;
ALTER TABLE ONLY public.jobrunr_jobs
    ADD CONSTRAINT jobrunr_jobs_pkey PRIMARY KEY (id);


-- ==========================================
-- JobRunr Metadata
-- ==========================================
CREATE TABLE public.jobrunr_metadata
(
    id        character varying(156)      NOT NULL,
    name      character varying(92)       NOT NULL,
    owner     character varying(64)       NOT NULL,
    value     text                        NOT NULL,
    createdat timestamp without time zone NOT NULL,
    updatedat timestamp without time zone NOT NULL
);
ALTER TABLE public.jobrunr_metadata
    OWNER TO test;
ALTER TABLE ONLY public.jobrunr_metadata
    ADD CONSTRAINT jobrunr_metadata_pkey PRIMARY KEY (id);
INSERT INTO public.jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0', '2023-01-1 00:00:00.000000',
        '2023-01-1 00:00:00.000000');


-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
CREATE TABLE public.jobrunr_recurring_jobs
(
    id                        character(128)                                                                         NOT NULL,
    version                   integer                                                                                NOT NULL,
    paused                    integer                                                                                NOT NULL,
    createdat                 timestamp without time zone                                                            NOT NULL,
    updatedat                 timestamp without time zone                                                            NOT NULL,
    jobasjson                 text                                                                                   NOT NULL,
    jobname                   character varying(512)      DEFAULT ''::character varying                              NOT NULL,
    jobsignature              character varying(512)      DEFAULT ''::character varying                              NOT NULL,
    labels                    character varying(196),
    priority                  integer                     DEFAULT 2                                                  NOT NULL,
    servertag                 character varying(128)      DEFAULT 'DEFAULT'::character varying                       NOT NULL,
    runsmorethanonceperminute integer                     DEFAULT 0                                                  NOT NULL,
    nextrunat                 timestamp without time zone DEFAULT '2020-01-01 00:00:00'::timestamp without time zone NOT NULL
);
ALTER TABLE public.jobrunr_recurring_jobs
    OWNER TO test;
CREATE VIEW public.jobrunr_jobs_stats AS
WITH job_stat_results AS (SELECT jobrunr_jobs.state,
                                 jobrunr_jobs.priority,
                                 count(*) AS count
                          FROM public.jobrunr_jobs
                          GROUP BY ROLLUP (jobrunr_jobs.state, jobrunr_jobs.priority))
SELECT COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (job_stat_results.state IS NULL)), (0)::bigint)                          AS total,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'AWAITING'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS awaiting,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'SCHEDULED'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS scheduled,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS enqueued,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority = 0))),
                (0)::bigint)                                                                    AS enqueued_queue_0,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority = 1))),
                (0)::bigint)                                                                    AS enqueued_queue_1,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority = 2))),
                (0)::bigint)                                                                    AS enqueued_queue_2,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority = 3))),
                (0)::bigint)                                                                    AS enqueued_queue_3,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'ENQUEUED'::text) AND (job_stat_results.priority = 4))),
                (0)::bigint)                                                                    AS enqueued_queue_4,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'PROCESSING'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS processing,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'FAILED'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS failed,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'SUCCEEDED'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS succeeded,
       COALESCE((SELECT ((jm.value)::character(10))::numeric(10, 0) AS value
                 FROM public.jobrunr_metadata jm
                 WHERE ((jm.id)::text = 'succeeded-jobs-counter-cluster'::text)), (0)::numeric) AS alltimesucceeded,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE (((job_stat_results.state)::text = 'DELETED'::text) AND (job_stat_results.priority IS NULL))),
                (0)::bigint)                                                                    AS deleted,
       (SELECT count(*) AS count
        FROM public.jobrunr_backgroundjobservers)                                               AS nbrofbackgroundjobservers,
       (SELECT count(*) AS count
        FROM public.jobrunr_recurring_jobs)                                                     AS nbrofrecurringjobs,
       (SELECT count(*) AS count
        FROM public.jobrunr_jobs jobs
        WHERE (jobs.isbatch = 1))                                                               AS nbrofbatchjobs;
ALTER TABLE public.jobrunr_jobs_stats
    OWNER TO test;

CREATE INDEX jobrunr_bgjobsrvrs_fsthb_idx ON public.jobrunr_backgroundjobservers USING btree (firstheartbeat);
CREATE INDEX jobrunr_bgjobsrvrs_lsthb_idx ON public.jobrunr_backgroundjobservers USING btree (lastheartbeat);
CREATE INDEX jobrunr_job_created_at_idx ON public.jobrunr_jobs USING btree (createdat);
CREATE INDEX jobrunr_job_delete_at_idx ON public.jobrunr_jobs USING btree (deleteat);
CREATE INDEX jobrunr_job_isbatch_idx ON public.jobrunr_jobs USING btree (id) WHERE (isbatch = 1);
CREATE INDEX jobrunr_job_jobfingerprint_idx ON public.jobrunr_jobs USING btree (jobfingerprint);
CREATE INDEX jobrunr_job_joblabels_idx ON public.jobrunr_jobs USING btree (labels);
CREATE INDEX jobrunr_job_jobname_idx ON public.jobrunr_jobs USING btree (jobname);
CREATE INDEX jobrunr_job_mutex_idx ON public.jobrunr_jobs USING btree (mutex);
CREATE UNIQUE INDEX jobrunr_job_mutexinuse_idx ON public.jobrunr_jobs USING btree (mutexinuse);
CREATE INDEX jobrunr_job_priority_idx ON public.jobrunr_jobs USING btree (priority);
CREATE INDEX jobrunr_job_priority_updatedat_state_idx ON public.jobrunr_jobs USING btree (priority, updatedat, state);
CREATE INDEX jobrunr_job_rci_idx ON public.jobrunr_jobs USING btree (recurringjobid);
CREATE INDEX jobrunr_job_scheduled_at_idx ON public.jobrunr_jobs USING btree (scheduledat);
CREATE INDEX jobrunr_job_servertag_idx ON public.jobrunr_jobs USING btree (servertag);
CREATE INDEX jobrunr_job_signature_idx ON public.jobrunr_jobs USING btree (jobsignature);
CREATE INDEX jobrunr_job_state_prio_idx ON public.jobrunr_jobs USING btree (state, priority);
CREATE INDEX jobrunr_job_updated_at_idx ON public.jobrunr_jobs USING btree (updatedat);
CREATE INDEX jobrunr_job_waiting_on_idx ON public.jobrunr_jobs USING btree (awaitingon, state);
CREATE INDEX jobrunr_rj_idx ON public.jobrunr_recurring_jobs USING btree (updatedat, runsmorethanonceperminute, paused, nextrunat);
CREATE INDEX jobrunr_state_idx ON public.jobrunr_jobs USING btree (state);
