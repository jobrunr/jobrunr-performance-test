--Sql Server 15.0

-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
create table jobrunr_backgroundjobservers
(
    id                         nchar(36)     not null primary key,
    workerPoolSize             int           not null,
    pollIntervalInSeconds      int           not null,
    serverTags                 varchar(512),
    firstHeartbeat             datetime2     not null,
    lastHeartbeat              datetime2     not null,
    running                    int           not null,
    systemTotalMemory          bigint        not null,
    systemFreeMemory           bigint        not null,
    systemCpuLoad              decimal(3, 2) not null,
    processMaxMemory           bigint        not null,
    processFreeMemory          bigint        not null,
    processAllocatedMemory     bigint        not null,
    processCpuLoad             decimal(3, 2) not null,
    deleteSucceededJobsAfter   varchar(32),
    permanentlyDeleteJobsAfter varchar(32),
    name                       varchar(128)
);

-- ==========================================
-- JobRunr Jobs
-- ==========================================
create table jobrunr_jobs
(
    id             nchar(36)                       not null primary key,
    version        int                             not null,
    jobAsJson      nvarchar(max),
    jobSignature   nvarchar(512),
    state          varchar(36)                     not null,
    createdAt      datetime2                       not null,
    updatedAt      datetime2                       not null,
    scheduledAt    datetime2,
    priority       int           default 2         not null,
    serverTag      varchar(128)  default 'DEFAULT' not null,
    mutex          varchar(128),
    mutexInUse     varchar(128),
    awaitingOn     nchar(36),
    isBatch        int           default 0         not null,
    recurringJobId varchar(128),
    deleteAt       datetime2,
    jobName        nvarchar(512) default ''        not null,
    jobFingerprint nvarchar(512) default ''        not null,
    labels         nvarchar(196)
);

create index jobrunr_state_idx on jobrunr_jobs (state);
create index jobrunr_job_signature_idx on jobrunr_jobs (jobSignature);
create index jobrunr_job_created_at_idx on jobrunr_jobs (createdAt);
create index jobrunr_job_updated_at_idx on jobrunr_jobs (updatedAt);
create index jobrunr_job_scheduled_at_idx on jobrunr_jobs (scheduledAt);
create index jobrunr_job_priority_idx on jobrunr_jobs (priority);
create index jobrunr_job_serverTag_idx on jobrunr_jobs (serverTag);
create index jobrunr_job_mutex_idx on jobrunr_jobs (mutex);
create unique index jobrunr_job_mutexInUse_idx on jobrunr_jobs (mutexInUse) where [mutexInUse] IS NOT NULL;
create index jobrunr_job_waiting_on_idx on jobrunr_jobs (awaitingOn, state);
create index jobrunr_job_rci_idx on jobrunr_jobs (recurringJobId);
create index jobrunr_job_delete_at_idx on jobrunr_jobs (deleteAt);
create index jobrunr_job_jobName_idx on jobrunr_jobs (jobName);
create index jobrunr_job_jobFingerprint_idx on jobrunr_jobs (jobFingerprint);
create index jobrunr_job_priority_updatedAt_state_idx on jobrunr_jobs (priority, updatedAt, state);
create index jobrunr_job_state_prio_idx on jobrunr_jobs (state, priority);
create index jobrunr_job_isBatch_idx on jobrunr_jobs (isBatch);
create index jobrunr_job_jobLabels_idx on jobrunr_jobs (labels);
create index jobrunr_bgjobsrvrs_fsthb_idx on jobrunr_backgroundjobservers (firstHeartbeat);
create index jobrunr_bgjobsrvrs_lsthb_idx on jobrunr_backgroundjobservers (lastHeartbeat);

-- ==========================================
-- JobRunr Metadata
-- ==========================================
create table jobrunr_metadata
(
    id        varchar(156) not null primary key,
    name      varchar(92)  not null,
    owner     varchar(64)  not null,
    value     nvarchar(max),
    createdAt datetime2    not null,
    updatedAt datetime2    not null
);

INSERT INTO jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0', '2023-01-1 00:00:00.000000',
        '2023-01-1 00:00:00.000000');

-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
create table jobrunr_recurring_jobs
(
    id                        nchar(128)                                  not null primary key,
    version                   int                                         not null,
    paused                    int                                         not null,
    createdAt                 datetime2                                   not null,
    updatedAt                 datetime2                                   not null,
    jobAsJson                 varchar(max)                                not null,
    updatedAtMillis           bigint        default '0'                   not null,
    jobName                   nvarchar(512) default ''                    not null,
    jobSignature              nvarchar(512) default ''                    not null,
    labels                    nvarchar(196),
    priority                  int           default 2                     not null,
    serverTag                 nvarchar(128) default 'DEFAULT'             not null,
    runsMoreThanOncePerMinute int           default 0                     not null,
    nextRunAt                 datetime2     default '2020-01-01 00:00:00' not null
);
create index jobrunr_rj_idx on jobrunr_recurring_jobs (updatedAt, runsMoreThanOncePerMinute, paused, nextRunAt);
GO

-- ==========================================
-- JobRunr Jobs Stats View
-- ==========================================
CREATE VIEW jobrunr_jobs_stats
as
with job_stat_results as (SELECT state, priority, count(*) as count
                          FROM jobrunr_jobs
                          GROUP BY ROLLUP (state, priority))
select coalesce((select count from job_stat_results where state IS NULL), 0)                             as total,
       coalesce((select count from job_stat_results where state = 'AWAITING' and priority IS NULL), 0)   as awaiting,
       coalesce((select count from job_stat_results where state = 'SCHEDULED' and priority IS NULL), 0)  as scheduled,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority IS NULL), 0)   as enqueued,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 0), 0)       as enqueued_queue_0,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 1), 0)       as enqueued_queue_1,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 2), 0)       as enqueued_queue_2,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 3), 0)       as enqueued_queue_3,
       coalesce((select count from job_stat_results where state = 'ENQUEUED' and priority = 4), 0)       as enqueued_queue_4,
       coalesce((select count from job_stat_results where state = 'PROCESSING' and priority IS NULL), 0) as processing,
       coalesce((select count from job_stat_results where state = 'FAILED' and priority IS NULL), 0)     as failed,
       coalesce((select count from job_stat_results where state = 'SUCCEEDED' and priority IS NULL), 0)  as succeeded,
       coalesce((select cast(cast(value as char(10)) as decimal(10, 0))
                 from jobrunr_metadata jm
                 where jm.id = 'succeeded-jobs-counter-cluster'), 0)                                     as allTimeSucceeded,
       coalesce((select count from job_stat_results where state = 'DELETED' and priority IS NULL), 0)    as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                               as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                                     as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                                   as nbrOfBatchJobs
;
