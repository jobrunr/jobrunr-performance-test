DROP TABLE jobrunr_recurring_jobs;

CREATE TABLE jobrunr_recurring_jobs
(
    id        NCHAR(128) PRIMARY KEY,
    version   INT       NOT NULL,
    paused    INT       NOT NULL,
    createdAt TIMESTAMP NOT NULL,
    updatedAt TIMESTAMP NOT NULL,
    jobAsJson text      NOT NULL
);