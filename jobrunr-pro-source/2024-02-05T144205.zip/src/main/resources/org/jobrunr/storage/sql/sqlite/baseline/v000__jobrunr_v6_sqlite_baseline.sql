--Sqlite 3.39.2

-- ==========================================
-- JobRunr Jobs
-- ==========================================
CREATE TABLE jobrunr_jobs
(
    id             NCHAR(36) PRIMARY KEY,
    version        int          NOT NULL,
    jobAsJson      text         NOT NULL,
    jobSignature   VARCHAR(512) NOT NULL,
    state          VARCHAR(36)  NOT NULL,
    createdAt      TIMESTAMP    NOT NULL,
    updatedAt      TIMESTAMP    NOT NULL,
    scheduledAt    TIMESTAMP,
    priority       int          NOT NULL default 2,
    serverTag      VARCHAR(128) NOT NULL DEFAULT 'DEFAULT',
    mutex          VARCHAR(128),
    mutexInUse     VARCHAR(128),
    awaitingOn     NCHAR(36),
    isBatch        int          NOT NULL DEFAULT 0,
    recurringJobId VARCHAR(128),
    deleteAt       TIMESTAMP,
    jobName        VARCHAR(512) NOT NULL DEFAULT '',
    jobFingerprint VARCHAR(512) NOT NULL DEFAULT '',
    labels         VARCHAR(196)
);


-- ==========================================
-- JobRunr Metadata
-- ==========================================
CREATE TABLE jobrunr_metadata
(
    id        varchar(156) PRIMARY KEY,
    name      varchar(92) NOT NULL,
    owner     varchar(64) NOT NULL,
    value     text        NOT NULL,
    createdAt TIMESTAMP   NOT NULL,
    updatedAt TIMESTAMP   NOT NULL
);
INSERT INTO jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0', '2023-01-1 00:00:00.000000',
        '2023-01-1 00:00:00.000000');


-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
CREATE TABLE jobrunr_recurring_jobs
(
    id                        NCHAR(128) PRIMARY KEY,
    version                   INT          NOT NULL,
    paused                    INT          NOT NULL,
    createdAt                 TIMESTAMP    NOT NULL,
    updatedAt                 TIMESTAMP    NOT NULL,
    jobAsJson                 text         NOT NULL,
    jobName                   VARCHAR(512) NOT NULL DEFAULT '',
    jobSignature              VARCHAR(512) NOT NULL DEFAULT '',
    labels                    VARCHAR(196),
    priority                  INT          NOT NULL default 2,
    serverTag                 VARCHAR(128) NOT NULL DEFAULT 'DEFAULT',
    runsMoreThanOncePerMinute INT          NOT NULL DEFAULT 0,
    nextRunAt                 TIMESTAMP    NOT NULL DEFAULT '2020-01-01 00:00:00'
);


-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
CREATE TABLE jobrunr_backgroundjobservers
(
    id                         NCHAR(36) PRIMARY KEY,
    workerPoolSize             int           NOT NULL,
    pollIntervalInSeconds      int           NOT NULL,
    serverTags                 VARCHAR(512)  NOT NULL,
    firstHeartbeat             TIMESTAMP(6)  NOT NULL,
    lastHeartbeat              TIMESTAMP(6)  NOT NULL,
    running                    int           NOT NULL,
    systemTotalMemory          BIGINT        NOT NULL,
    systemFreeMemory           BIGINT        NOT NULL,
    systemCpuLoad              NUMERIC(3, 2) NOT NULL,
    processMaxMemory           BIGINT        NOT NULL,
    processFreeMemory          BIGINT        NOT NULL,
    processAllocatedMemory     BIGINT        NOT NULL,
    processCpuLoad             NUMERIC(3, 2) NOT NULL,
    deleteSucceededJobsAfter   VARCHAR(32),
    permanentlyDeleteJobsAfter VARCHAR(32),
    name                       VARCHAR(128)
);


CREATE INDEX jobrunr_state_idx ON jobrunr_jobs (state);
CREATE INDEX jobrunr_job_signature_idx ON jobrunr_jobs (jobSignature);
CREATE INDEX jobrunr_job_created_at_idx ON jobrunr_jobs (createdAt);
CREATE INDEX jobrunr_job_updated_at_idx ON jobrunr_jobs (updatedAt);
CREATE INDEX jobrunr_job_scheduled_at_idx ON jobrunr_jobs (scheduledAt);
CREATE INDEX jobrunr_job_priority_idx ON jobrunr_jobs (priority);
CREATE INDEX jobrunr_job_serverTag_idx ON jobrunr_jobs (serverTag);
CREATE INDEX jobrunr_job_mutex_idx ON jobrunr_jobs (mutex);
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs (mutexInUse);
CREATE INDEX jobrunr_job_rci_idx ON jobrunr_jobs (recurringJobId);
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs (deleteAt);
CREATE INDEX jobrunr_job_jobName_idx ON jobrunr_jobs (jobName);
CREATE INDEX jobrunr_job_jobFingerprint_idx ON jobrunr_jobs (jobFingerprint);
CREATE INDEX jobrunr_job_priority_updatedAt_state_idx ON jobrunr_jobs (priority ASC, updatedAt ASC, state);
CREATE INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs (state, priority ASC);
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs (isBatch);
CREATE INDEX jobrunr_bgjobsrvrs_fsthb_idx ON jobrunr_backgroundjobservers (firstHeartbeat);
CREATE INDEX jobrunr_bgjobsrvrs_lsthb_idx ON jobrunr_backgroundjobservers (lastHeartbeat);
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (awaitingOn ASC, state ASC);
CREATE INDEX jobrunr_job_jobLabels_idx ON jobrunr_jobs (labels);
CREATE INDEX jobrunr_rj_idx ON jobrunr_recurring_jobs (updatedAt, runsMoreThanOncePerMinute, paused, nextRunAt);


-- ==========================================
-- JobRunr Job Stats View
-- ==========================================
CREATE VIEW jobrunr_jobs_stats
as
select count(*)                                                                                as total,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'AWAITING')                  as awaiting,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'SCHEDULED')                 as scheduled,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED')                  as enqueued,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED' and priority = 0) as enqueued_queue_0,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED' and priority = 1) as enqueued_queue_1,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED' and priority = 2) as enqueued_queue_2,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED' and priority = 3) as enqueued_queue_3,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'ENQUEUED' and priority = 4) as enqueued_queue_4,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'PROCESSING')                as processing,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'FAILED')                    as failed,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'SUCCEEDED')                 as succeeded,
       (select cast(cast(value as char(10)) as decimal(10, 0))
        from jobrunr_metadata jm
        where jm.id = 'succeeded-jobs-counter-cluster')                                        as allTimeSucceeded,
       (select count(*) from jobrunr_jobs jobs where jobs.state = 'DELETED')                   as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                     as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                           as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                         as nbrOfBatchJobs
from jobrunr_jobs j;