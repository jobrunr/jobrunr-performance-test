CREATE INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs (priority ASC) where state = 'ENQUEUED';
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs (id) where isBatch = 1;