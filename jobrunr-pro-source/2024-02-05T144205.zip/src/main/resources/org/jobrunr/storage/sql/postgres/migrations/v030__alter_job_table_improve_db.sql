DROP INDEX jobrunr_job_priority_idx;
DROP INDEX jobrunr_state_idx;
DROP INDEX jobrunr_job_created_at_idx;
DROP INDEX jobrunr_job_updated_at_idx;
DROP INDEX jobrunr_job_scheduled_at_idx;
DROP INDEX jobrunr_job_delete_at_idx;
DROP INDEX jobrunr_job_signature_idx;
DROP INDEX jobrunr_job_to_process_idx;
DROP INDEX jobrunr_job_isBatch_idx;
DROP INDEX jobrunr_job_rci_idx;
DROP INDEX jobrunr_job_mutex_idx;
DROP INDEX jobrunr_job_mutexInUse_idx;
DROP INDEX jobrunr_job_waiting_on_idx;
DROP INDEX jobrunr_job_rate_limiter_idx;
DROP INDEX jobrunr_job_state_exception_type_idx;

-- below indices can't be used (move to GIN indices)?
DROP INDEX jobrunr_job_jobfingerprint_idx;
DROP INDEX jobrunr_job_jobname_idx;
DROP INDEX jobrunr_job_joblabels_idx;


ALTER TABLE jobrunr_jobs
    ALTER COLUMN id TYPE uuid USING id::uuid,
    ALTER COLUMN awaitingOn TYPE uuid USING awaitingon::uuid,
    ALTER COLUMN parentJobId TYPE uuid USING parentJobId::uuid;

ALTER TABLE jobrunr_backgroundjobservers
    ALTER COLUMN id TYPE uuid USING id::uuid;

CREATE INDEX jobrunr_job_created_at_idx ON jobrunr_jobs USING BRIN (createdAt);
CREATE INDEX jobrunr_job_updated_at_idx ON jobrunr_jobs (updatedAt, state);
CREATE INDEX jobrunr_job_scheduled_at_idx ON jobrunr_jobs (scheduledAt ASC, priority ASC, state) WHERE scheduledAt IS NOT NULL;
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs (deleteAt, state) WHERE deleteAt IS NOT NULL;
CREATE INDEX jobrunr_job_signature_idx ON jobrunr_jobs (state, jobSignature);
CREATE INDEX jobrunr_job_to_process_idx ON jobrunr_jobs (priority ASC, updatedAt ASC, serverTag, mutex, dynamicQueue) WHERE state = 'ENQUEUED';
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs (isBatch, state) WHERE isBatch = 1;
CREATE INDEX jobrunr_job_rci_idx ON jobrunr_jobs (recurringJobId) WHERE recurringJobId IS NOT NULL;
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs (mutexInUse) WHERE mutexinuse IS NOT NULL;
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (updatedAt, state, awaitingOn, rateLimiter) WHERE awaitingOn IS NOT NULL;
CREATE INDEX jobrunr_job_rate_limiter_idx ON jobrunr_jobs (priority ASC, updatedAt ASC, state, rateLimiter) WHERE rateLimiter IS NOT NULL;
CREATE INDEX jobrunr_job_state_exception_type_idx ON jobrunr_jobs (state, jobExceptionType) WHERE jobExceptionType IS NOT NULL;