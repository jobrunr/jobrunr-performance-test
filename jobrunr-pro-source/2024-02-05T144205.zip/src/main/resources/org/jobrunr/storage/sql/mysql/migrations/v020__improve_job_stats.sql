DROP VIEW jobrunr_jobs_stats;
DROP INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs;


CREATE INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs (state ASC, priority ASC);
CREATE VIEW jobrunr_jobs_stats AS
select coalesce(max((select job_stat_results.count where state IS NULL and priority IS NULL)), 0)        as total,
       coalesce(max((select job_stat_results.count where state = 'AWAITING' and priority IS NULL)), 0)   as awaiting,
       coalesce(max((select job_stat_results.count where state = 'SCHEDULED' and priority IS NULL)), 0)  as scheduled,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority IS NULL)), 0)   as enqueued,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority = 0)), 0)       as enqueued_queue_0,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority = 1)), 0)       as enqueued_queue_1,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority = 2)), 0)       as enqueued_queue_2,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority = 3)), 0)       as enqueued_queue_3,
       coalesce(max((select job_stat_results.count where state = 'ENQUEUED' and priority = 4)), 0)       as enqueued_queue_4,
       coalesce(max((select job_stat_results.count where state = 'PROCESSING' and priority IS NULL)), 0) as processing,
       coalesce(max((select job_stat_results.count where state = 'FAILED' and priority IS NULL)), 0)     as failed,
       coalesce(max((select job_stat_results.count where state = 'SUCCEEDED' and priority IS NULL)), 0)  as succeeded,
       coalesce((select cast(cast(value as char(10)) as decimal(10, 0))
                 from jobrunr_metadata jm
                 where jm.id = 'succeeded-jobs-counter-cluster'), 0)                                     as allTimeSucceeded,
       coalesce(max((select job_stat_results.count where state = 'DELETED' and priority IS NULL)), 0)    as deleted,
       (select count(*) from jobrunr_backgroundjobservers)                                               as nbrOfBackgroundJobServers,
       (select count(*) from jobrunr_recurring_jobs)                                                     as nbrOfRecurringJobs,
       (select count(*) from jobrunr_jobs jobs where jobs.isBatch = 1)                                   as nbrOfBatchJobs
from (SELECT state, priority, count(*) as count
      FROM jobrunr_jobs
      GROUP BY state, priority
      WITH ROLLUP) job_stat_results;