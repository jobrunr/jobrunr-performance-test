ALTER TABLE jobrunr_jobs
    ADD priority int NOT NULL default 2;
ALTER TABLE jobrunr_jobs
    ADD serverTag VARCHAR(128) NOT NULL DEFAULT 'DEFAULT';
ALTER TABLE jobrunr_jobs
    ADD mutex VARCHAR(128);
ALTER TABLE jobrunr_jobs
    ADD mutexInUse VARCHAR(128);
ALTER TABLE jobrunr_jobs
    ADD awaitingOn NCHAR(36);
ALTER TABLE jobrunr_jobs
    ADD isBatch int NOT NULL DEFAULT 0;

CREATE INDEX jobrunr_job_priority_idx ON jobrunr_jobs (priority);
CREATE INDEX jobrunr_job_serverTag_idx ON jobrunr_jobs (serverTag);
CREATE INDEX jobrunr_job_mutex_idx ON jobrunr_jobs (mutex);
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs (mutexInUse) WHERE mutexInUse IS NOT NULL;
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (awaitingOn);
