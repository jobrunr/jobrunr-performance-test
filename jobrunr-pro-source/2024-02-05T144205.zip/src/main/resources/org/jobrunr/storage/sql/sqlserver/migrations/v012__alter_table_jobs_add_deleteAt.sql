ALTER TABLE jobrunr_jobs
    ADD deleteAt DATETIME2;
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs (deleteAt);