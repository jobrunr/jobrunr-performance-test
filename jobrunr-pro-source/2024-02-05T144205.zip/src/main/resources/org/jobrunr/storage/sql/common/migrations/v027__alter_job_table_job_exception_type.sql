ALTER TABLE jobrunr_jobs
    ADD jobExceptionType VARCHAR(512);

CREATE INDEX jobrunr_job_state_exception_type_idx ON jobrunr_jobs (state, jobExceptionType ASC);