ALTER TABLE jobrunr_jobs
    ADD labels VARCHAR(196);

CREATE INDEX jobrunr_job_jobLabels_idx ON jobrunr_jobs (labels);
