DROP INDEX jobrunr_recurring_job_updated_at_idx ON jobrunr_recurring_jobs;
-- ALTER TABLE jobrunr_recurring_jobs DROP COLUMN updatedAtMillis // cannot be dropped due to strange constraint

ALTER TABLE jobrunr_recurring_jobs ADD jobName NVARCHAR(512) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_recurring_jobs ADD jobSignature NVARCHAR(512) NOT NULL DEFAULT '';
ALTER TABLE jobrunr_recurring_jobs ADD labels NVARCHAR(196);
ALTER TABLE jobrunr_recurring_jobs ADD priority INT NOT NULL default 2;
ALTER TABLE jobrunr_recurring_jobs ADD serverTag NVARCHAR(128) NOT NULL DEFAULT 'DEFAULT';
ALTER TABLE jobrunr_recurring_jobs ADD runsMoreThanOncePerMinute INT NOT NULL DEFAULT 0;
ALTER TABLE jobrunr_recurring_jobs ADD nextRunAt DATETIME2 NOT NULL DEFAULT '2020-01-01 00:00:00';

CREATE INDEX jobrunr_rj_idx ON jobrunr_recurring_jobs (updatedAt, runsMoreThanOncePerMinute, paused, nextRunAt);