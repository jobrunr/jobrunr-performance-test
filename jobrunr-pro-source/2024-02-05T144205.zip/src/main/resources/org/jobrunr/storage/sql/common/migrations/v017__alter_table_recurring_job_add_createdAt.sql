ALTER TABLE jobrunr_recurring_jobs
    ADD updatedAtMillis BIGINT NOT NULL DEFAULT '0';
CREATE INDEX jobrunr_recurring_job_updated_at_idx ON jobrunr_recurring_jobs (updatedAtMillis);