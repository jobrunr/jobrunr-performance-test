ALTER TABLE jobrunr_jobs
    ADD rateLimiter VARCHAR(128);

CREATE INDEX jobrunr_job_rate_limiter_idx ON jobrunr_jobs (rateLimiter);