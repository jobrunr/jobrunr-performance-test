-- H2 2.1.210;
-- ==========================================
-- JobRunr Jobs
-- ==========================================
CREATE TABLE jobrunr_jobs
(
    "id"             CHARACTER(36)                            NOT NULL PRIMARY KEY,
    "version"        INTEGER                                  NOT NULL,
    "jobAsJson"      CHARACTER LARGE OBJECT                   NOT NULL,
    "jobSignature"   CHARACTER VARYING(512)                   NOT NULL,
    "state"          CHARACTER VARYING(36)                    NOT NULL,
    "createdAt"      TIMESTAMP                                NOT NULL,
    "updatedAt"      TIMESTAMP                                NOT NULL,
    "scheduledAt"    TIMESTAMP,
    "priority"       INTEGER                DEFAULT 2         NOT NULL,
    "serverTag"      CHARACTER VARYING(128) DEFAULT 'DEFAULT' NOT NULL,
    "mutex"          CHARACTER VARYING(128),
    "mutexInUse"     CHARACTER VARYING(128),
    "awaitingOn"     CHARACTER(36),
    "isBatch"        INTEGER                DEFAULT 0         NOT NULL,
    "recurringJobId" CHARACTER VARYING(128),
    "deleteAt"       TIMESTAMP,
    "jobName"        CHARACTER VARYING(512) DEFAULT ''        NOT NULL,
    "jobFingerprint" CHARACTER VARYING(512) DEFAULT ''        NOT NULL,
    "labels"         CHARACTER VARYING(196)
);

CREATE INDEX jobrunr_state_idx ON jobrunr_jobs ("state" NULLS FIRST);
CREATE INDEX jobrunr_job_signature_idx ON jobrunr_jobs ("jobSignature" NULLS FIRST);
CREATE INDEX jobrunr_job_jobLabels_idx ON jobrunr_jobs ("labels" NULLS FIRST);
CREATE INDEX jobrunr_job_created_at_idx ON jobrunr_jobs ("createdAt" NULLS FIRST);
CREATE INDEX jobrunr_job_updated_at_idx ON jobrunr_jobs ("updatedAt" NULLS FIRST);
CREATE INDEX jobrunr_job_scheduled_at_idx ON jobrunr_jobs ("scheduledAt" NULLS FIRST);
CREATE INDEX jobrunr_job_priority_idx ON jobrunr_jobs ("priority" NULLS FIRST);
CREATE INDEX jobrunr_job_serverTag_idx ON jobrunr_jobs ("serverTag" NULLS FIRST);
CREATE INDEX jobrunr_job_mutex_idx ON jobrunr_jobs ("mutex" NULLS FIRST);
CREATE UNIQUE INDEX jobrunr_job_mutexInUse_idx ON jobrunr_jobs ("mutexInUse" NULLS FIRST);
CREATE INDEX jobrunr_job_rci_idx ON jobrunr_jobs ("recurringJobId" NULLS FIRST);
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs ("deleteAt" NULLS FIRST);
CREATE INDEX jobrunr_job_jobName_idx ON jobrunr_jobs ("jobName" NULLS FIRST);
CREATE INDEX jobrunr_job_jobFingerprint_idx ON jobrunr_jobs ("jobFingerprint" NULLS FIRST);
CREATE INDEX jobrunr_job_priority_updatedAt_state_idx ON jobrunr_jobs ("priority" NULLS FIRST, "updatedAt" NULLS FIRST, "state" NULLS FIRST);
CREATE INDEX jobrunr_job_state_prio_idx ON jobrunr_jobs ("state" NULLS FIRST, "priority" NULLS FIRST);
CREATE INDEX jobrunr_job_isBatch_idx ON jobrunr_jobs ("isBatch" NULLS FIRST);
CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs ("awaitingOn" NULLS FIRST, "state" NULLS FIRST);


-- ==========================================
-- JobRunr Metadata
-- ==========================================
CREATE TABLE jobrunr_metadata
(
    "id"        CHARACTER VARYING(156)     NOT NULL,
    "name"      CHARACTER VARYING(92)      NOT NULL,
    "owner"     CHARACTER VARYING(64)      NOT NULL,
    "value"     CHARACTER VARYING(1048000) NOT NULL,
    "createdAt" TIMESTAMP                  NOT NULL,
    "updatedAt" TIMESTAMP                  NOT NULL
);
ALTER TABLE jobrunr_metadata
    ADD CONSTRAINT CONSTRAINT_METADATA_ID PRIMARY KEY ("id");
INSERT INTO jobrunr_metadata
VALUES ('succeeded-jobs-counter-cluster', 'succeeded-jobs-counter', 'cluster', '0',
        TIMESTAMP '2023-01-1 00:00:00.000000', TIMESTAMP '2023-01-1 00:00:00.000000');


-- ==========================================
-- JobRunr Recurring Jobs
-- ==========================================
CREATE TABLE jobrunr_recurring_jobs
(
    "id"                        CHARACTER(128)                                       NOT NULL,
    "version"                   INTEGER                                              NOT NULL,
    "paused"                    INTEGER                                              NOT NULL,
    "createdAt"                 TIMESTAMP                                            NOT NULL,
    "updatedAt"                 TIMESTAMP                                            NOT NULL,
    "jobAsJson"                 CHARACTER LARGE OBJECT                               NOT NULL,
    "jobName"                   CHARACTER VARYING(512) DEFAULT ''                    NOT NULL,
    "jobSignature"              CHARACTER VARYING(512) DEFAULT ''                    NOT NULL,
    "labels"                    CHARACTER VARYING(196),
    "priority"                  INTEGER                DEFAULT 2                     NOT NULL,
    "serverTag"                 CHARACTER VARYING(128) DEFAULT 'DEFAULT'             NOT NULL,
    "runsMoreThanOncePerMinute" INTEGER                DEFAULT 0                     NOT NULL,
    "nextRunAt"                 TIMESTAMP              DEFAULT '2020-01-01 00:00:00' NOT NULL
);
ALTER TABLE jobrunr_recurring_jobs
    ADD CONSTRAINT CONSTRAINT_RECURRING_JOBS_ID PRIMARY KEY ("id");
CREATE INDEX JOBRUNR_RJ_IDX ON jobrunr_recurring_jobs ("updatedAt" NULLS FIRST,
                                                       "runsMoreThanOncePerMinute" NULLS FIRST,
                                                       "paused" NULLS FIRST, "nextRunAt" NULLS
                                                       FIRST);

-- ==========================================
-- JobRunr Background Job Servers
-- ==========================================
CREATE TABLE jobrunr_backgroundjobservers
(
    "id"                         CHARACTER(36)          NOT NULL,
    "workerPoolSize"             INTEGER                NOT NULL,
    "pollIntervalInSeconds"      INTEGER                NOT NULL,
    "serverTags"                 CHARACTER VARYING(512) NOT NULL,
    "firstHeartbeat"             TIMESTAMP(6)           NOT NULL,
    "lastHeartbeat"              TIMESTAMP(6)           NOT NULL,
    "running"                    INTEGER                NOT NULL,
    "systemTotalMemory"          BIGINT                 NOT NULL,
    "systemFreeMemory"           BIGINT                 NOT NULL,
    "systemCpuLoad"              NUMERIC(3, 2)          NOT NULL,
    "processMaxMemory"           BIGINT                 NOT NULL,
    "processFreeMemory"          BIGINT                 NOT NULL,
    "processAllocatedMemory"     BIGINT                 NOT NULL,
    "processCpuLoad"             NUMERIC(3, 2)          NOT NULL,
    "deleteSucceededJobsAfter"   CHARACTER VARYING(32),
    "permanentlyDeleteJobsAfter" CHARACTER VARYING(32),
    "name"                       CHARACTER VARYING(128)
);
ALTER TABLE jobrunr_backgroundjobservers
    ADD CONSTRAINT CONSTRAINT_BGS_ID PRIMARY KEY ("id");
CREATE INDEX JOBRUNR_BGJOBSRVRS_FSTHB_IDX ON jobrunr_backgroundjobservers ("firstHeartbeat" NULLS FIRST);
CREATE INDEX JOBRUNR_BGJOBSRVRS_LSTHB_IDX ON jobrunr_backgroundjobservers ("lastHeartbeat" NULLS FIRST);


-- ==========================================
-- JobRunr Job Stats View
-- ==========================================
CREATE VIEW jobrunr_jobs_stats
            ("total", "awaiting", "scheduled", "enqueued", "enqueued_queue_0", "enqueued_queue_1", "enqueued_queue_2",
             "enqueued_queue_3", "enqueued_queue_4", "processing", "failed", "succeeded", "allTimeSucceeded", "deleted",
             "nbrOfBackgroundJobServers", "nbrOfRecurringJobs", "nbrOfBatchJobs")
AS
SELECT COUNT(*)                                             AS "total",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'AWAITING')                  AS "awaiting",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'SCHEDULED')                 AS "scheduled",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'ENQUEUED')                  AS "enqueued",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE ("jobs"."state" = 'ENQUEUED')
          AND ("priority" = 0))                             AS "enqueued_queue_0",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE ("jobs"."state" = 'ENQUEUED')
          AND ("priority" = 1))                             AS "enqueued_queue_1",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE ("jobs"."state" = 'ENQUEUED')
          AND ("priority" = 2))                             AS "enqueued_queue_2",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE ("jobs"."state" = 'ENQUEUED')
          AND ("priority" = 3))                             AS "enqueued_queue_3",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE ("jobs"."state" = 'ENQUEUED')
          AND ("priority" = 4))                             AS "enqueued_queue_4",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'PROCESSING')                AS "processing",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'FAILED')                    AS "failed",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'SUCCEEDED')                 AS "succeeded",
       (SELECT CAST(CAST("value" AS CHARACTER(10)) AS DECIMAL(10, 0))
        FROM jobrunr_metadata "jm"
        WHERE "jm"."id" = 'succeeded-jobs-counter-cluster') AS "allTimeSucceeded",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."state" = 'DELETED')                   AS "deleted",
       (SELECT COUNT(*)
        FROM jobrunr_backgroundjobservers)                  AS "nbrOfBackgroundJobServers",
       (SELECT COUNT(*)
        FROM jobrunr_recurring_jobs)                        AS "nbrOfRecurringJobs",
       (SELECT COUNT(*)
        FROM jobrunr_jobs "jobs"
        WHERE "jobs"."isBatch" = 1)                         AS "nbrOfBatchJobs"
FROM jobrunr_jobs "j"
GROUP BY ();