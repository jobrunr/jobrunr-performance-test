ALTER TABLE jobrunr_jobs
    ADD deleteAt TIMESTAMP;
CREATE INDEX jobrunr_job_delete_at_idx ON jobrunr_jobs (deleteAt);