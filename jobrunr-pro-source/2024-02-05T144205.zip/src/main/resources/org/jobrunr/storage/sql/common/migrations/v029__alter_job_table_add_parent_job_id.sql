ALTER TABLE jobrunr_jobs
    ADD parentJobId VARCHAR(36);