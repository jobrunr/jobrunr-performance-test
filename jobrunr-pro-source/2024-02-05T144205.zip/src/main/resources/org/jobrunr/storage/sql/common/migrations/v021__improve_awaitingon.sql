DROP INDEX jobrunr_job_waiting_on_idx;

CREATE INDEX jobrunr_job_waiting_on_idx ON jobrunr_jobs (awaitingOn ASC, state ASC);